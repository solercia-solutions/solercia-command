import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef, AfterViewChecked, InjectionToken, AfterViewInit, Signal, EnvironmentProviders } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { SafeHtml } from '@angular/platform-browser';
import { ChartConfiguration } from 'chart.js';
import * as i1 from '@angular/cdk/drag-drop';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

type SolButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';
type SolButtonSize = 'sm' | 'md' | 'lg';
declare class SolButtonComponent {
    /** Visual style variant. */
    readonly variant: _angular_core.InputSignal<SolButtonVariant>;
    /** Size preset. */
    readonly size: _angular_core.InputSignal<SolButtonSize>;
    /** Whether the button is disabled. */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Native button type attribute. */
    readonly type: _angular_core.InputSignal<string>;
    /** Shows a spinner and disables the button. */
    readonly loading: _angular_core.InputSignal<boolean>;
    /** Emitted on click when the button is not disabled or loading. */
    readonly clicked: _angular_core.OutputEmitterRef<void>;
    /** Computed CSS class string combining variant and size modifiers. */
    readonly cssClass: _angular_core.Signal<string>;
    onClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolButtonComponent, "sol-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, ["*"], true, never>;
}

declare class SolInputComponent implements ControlValueAccessor {
    readonly type: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly error: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly value: _angular_core.WritableSignal<string>;
    readonly isDisabled: _angular_core.WritableSignal<boolean>;
    onChange: (value: string) => void;
    onTouched: () => void;
    onInputChange(event: Event): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolInputComponent, "sol-input", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface SolSelectOption {
    value: string;
    label: string;
}
declare class SolSelectComponent implements ControlValueAccessor {
    private hostEl;
    /** Placeholder text when nothing is selected. */
    readonly placeholder: _angular_core.InputSignal<string>;
    /** Label displayed above the select. */
    readonly label: _angular_core.InputSignal<string>;
    /** Error message below. */
    readonly error: _angular_core.InputSignal<string>;
    /** Whether the select is disabled. */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Enable search filtering. */
    readonly searchable: _angular_core.InputSignal<boolean>;
    /** Enable multi-selection mode. */
    readonly multiple: _angular_core.InputSignal<boolean>;
    /** Options array — use this instead of ng-content for searchable/multi. */
    readonly options: _angular_core.InputSignal<SolSelectOption[]>;
    /** Show a "Todos" / clear option in single mode. */
    readonly showAllOption: _angular_core.InputSignal<boolean>;
    /** Label for the "all" option in single mode. */
    readonly allOptionLabel: _angular_core.InputSignal<string>;
    readonly isOpen: _angular_core.WritableSignal<boolean>;
    readonly dropUp: _angular_core.WritableSignal<boolean>;
    readonly searchTerm: _angular_core.WritableSignal<string>;
    readonly singleValue: _angular_core.WritableSignal<string>;
    readonly multiValues: _angular_core.WritableSignal<Set<string>>;
    readonly searchInput: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    readonly filteredOptions: _angular_core.Signal<SolSelectOption[]>;
    readonly displayText: _angular_core.Signal<string>;
    readonly triggerClass: _angular_core.Signal<string>;
    private onChange;
    private onTouched;
    onDocumentClick(event: MouseEvent): void;
    constructor(hostEl: ElementRef);
    toggleDropdown(): void;
    closeDropdown(): void;
    onSearchInput(event: Event): void;
    isSelected(value: string): boolean;
    onOptionClick(value: string): void;
    onSelectSingle(value: string): void;
    selectAll(): void;
    selectNone(): void;
    onBlur(): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(_: boolean): void;
    private emitMultiValue;
    ngAfterViewInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolSelectComponent, "sol-select", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "searchable": { "alias": "searchable"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "showAllOption": { "alias": "showAllOption"; "required": false; "isSignal": true; }; "allOptionLabel": { "alias": "allOptionLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SolTextareaComponent implements ControlValueAccessor {
    /** Placeholder text for the textarea. */
    readonly placeholder: _angular_core.InputSignal<string>;
    /** Label displayed above the textarea. */
    readonly label: _angular_core.InputSignal<string>;
    /** Error message displayed below the textarea. */
    readonly error: _angular_core.InputSignal<string>;
    /** Whether the textarea is disabled. */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Number of visible text rows. */
    readonly rows: _angular_core.InputSignal<number>;
    /** Internal value signal. */
    readonly value: _angular_core.WritableSignal<string>;
    /** Computed CSS class string for the textarea element. */
    readonly textareaClass: _angular_core.Signal<"sol-textarea__native" | "sol-textarea__native sol-textarea__native--error">;
    private onChange;
    private onTouched;
    onInput(event: Event): void;
    onBlur(): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolTextareaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolTextareaComponent, "sol-textarea", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SolToggleSize = 'sm' | 'md';
declare class SolToggleComponent implements ControlValueAccessor {
    /** Optional label displayed beside the toggle. */
    readonly label: _angular_core.InputSignal<string>;
    /** Whether the toggle is disabled. */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Size preset: sm or md. */
    readonly size: _angular_core.InputSignal<SolToggleSize>;
    /** Internal checked state. */
    readonly checked: _angular_core.WritableSignal<boolean>;
    /** Computed host wrapper class. */
    readonly hostClass: _angular_core.Signal<string>;
    /** Computed track class combining size and on/off state. */
    readonly trackClass: _angular_core.Signal<string>;
    /** Computed thumb class combining size and on/off state. */
    readonly thumbClass: _angular_core.Signal<string>;
    private onChange;
    private onTouched;
    toggle(): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolToggleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolToggleComponent, "sol-toggle", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SolModalComponent {
    /** Whether the modal is open. */
    open: _angular_core.InputSignal<boolean>;
    /** Title displayed in the modal header. */
    title: _angular_core.InputSignal<string>;
    /** Width preset for the modal panel. */
    size: _angular_core.InputSignal<"sm" | "md" | "lg" | "xl">;
    /** Whether the modal can be closed by the user. */
    closeable: _angular_core.InputSignal<boolean>;
    /** Whether clicking the backdrop closes the modal. */
    closeOnBackdrop: _angular_core.InputSignal<boolean>;
    /** Emitted when the modal requests to be closed. */
    closed: _angular_core.OutputEmitterRef<void>;
    /** Computed CSS class for the panel size. */
    panelClasses: _angular_core.Signal<string>;
    onEscapeKey(): void;
    onBackdropClick(): void;
    close(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolModalComponent, "sol-modal", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "closeable": { "alias": "closeable"; "required": false; "isSignal": true; }; "closeOnBackdrop": { "alias": "closeOnBackdrop"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, ["*"], true, never>;
}

type BadgeVariant = 'success' | 'warning' | 'danger' | 'info' | 'neutral';
type BadgeSize = 'sm' | 'md';
declare class SolBadgeComponent {
    /** Visual variant controlling the badge color. */
    variant: _angular_core.InputSignal<BadgeVariant>;
    /** Size preset for the badge. */
    size: _angular_core.InputSignal<BadgeSize>;
    /** Map from variant to its corresponding CSS variable. */
    private readonly variantColorMap;
    /** Computed CSS classes combining base, size, and variant. */
    hostClasses: _angular_core.Signal<string>;
    /** Computed inline styles for variant-based coloring using color-mix. */
    hostStyles: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolBadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolBadgeComponent, "sol-badge", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class SolCardComponent {
    /** Whether the card has internal padding. */
    padding: _angular_core.InputSignal<boolean>;
    /** Whether the card shows a hover shadow effect. */
    hoverable: _angular_core.InputSignal<boolean>;
    /** Computed CSS classes combining base, padding, and hover states. */
    hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolCardComponent, "sol-card", never, { "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "hoverable": { "alias": "hoverable"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type SpinnerSize = 'sm' | 'md' | 'lg';
declare class SolSpinnerComponent {
    private readonly i18n;
    /** Size preset for the spinner. */
    size: _angular_core.InputSignal<SpinnerSize>;
    /** Custom color override. Defaults to var(--sol-color-primary). */
    color: _angular_core.InputSignal<string>;
    /** Computed CSS classes combining base and size. */
    hostClasses: _angular_core.Signal<string>;
    /** Computed inline style for color override. */
    hostStyles: _angular_core.Signal<string>;
    /** Etiqueta accesible traducida (`shared.spinner.loading`), reactiva al idioma activo. */
    readonly ariaLabel: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolSpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolSpinnerComponent, "sol-spinner", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface SolTabItem {
    id: string;
    label: string;
    icon?: string;
}
declare class SolTabsComponent {
    readonly tabs: _angular_core.InputSignal<SolTabItem[]>;
    readonly activeTab: _angular_core.InputSignal<string>;
    readonly tabChange: _angular_core.OutputEmitterRef<string>;
    indicatorStyle: _angular_core.Signal<string>;
    selectTab(id: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolTabsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolTabsComponent, "sol-tabs", never, { "tabs": { "alias": "tabs"; "required": true; "isSignal": true; }; "activeTab": { "alias": "activeTab"; "required": false; "isSignal": true; }; }, { "tabChange": "tabChange"; }, never, never, true, never>;
}

declare class SolFormFieldComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly error: _angular_core.InputSignal<string>;
    readonly hint: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolFormFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolFormFieldComponent, "sol-form-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class SolPaginationComponent {
    readonly totalItems: _angular_core.InputSignal<number>;
    readonly pageSize: _angular_core.InputSignal<number>;
    readonly currentPage: _angular_core.InputSignal<number>;
    readonly pageSizeOptions: _angular_core.InputSignal<number[]>;
    readonly pageChanged: _angular_core.OutputEmitterRef<number>;
    readonly pageSizeChanged: _angular_core.OutputEmitterRef<number>;
    readonly totalPages: _angular_core.Signal<number>;
    readonly startItem: _angular_core.Signal<number>;
    readonly endItem: _angular_core.Signal<number>;
    readonly pages: _angular_core.Signal<number[]>;
    onPageChange(page: number): void;
    onPageSizeChange(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolPaginationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolPaginationComponent, "sol-pagination", never, { "totalItems": { "alias": "totalItems"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; }, { "pageChanged": "pageChanged"; "pageSizeChanged": "pageSizeChanged"; }, never, never, true, never>;
}

declare class SolSearchInputComponent {
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly searchChange: _angular_core.OutputEmitterRef<string>;
    readonly value: _angular_core.WritableSignal<string>;
    onInput(event: Event): void;
    onClear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolSearchInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolSearchInputComponent, "sol-search-input", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, { "searchChange": "searchChange"; }, never, never, true, never>;
}

/**
 * Icon Registry — inner SVG path content (without the <svg> wrapper).
 *
 * Two sources, per key:
 *
 * 1. Heroicons v2.0 (MIT License — tailwindlabs/heroicons), the default source.
 *    To add one: copy the inner content of the matching `outline/<name>.svg`
 *    (24×24) into `outline`, and `solid/<name>.svg` into `fill`, from
 *    heroicons.com or the `heroicons` npm package. Keep the exact `d`
 *    attribute (do not hand-edit path data).
 * 2. Custom glyphs with no Heroicons equivalent (see the "íconos propios"
 *    section below, and the rich-editor toolbar icons): original design,
 *    line-art by nature — see the **outline-only** rule below.
 *
 * Naming: kebab-case key (`/^[a-z0-9]+(-[a-z0-9]+)*$/`), enforced by
 * `icon.registry.spec.ts` (gate — also fails on an empty `outline`).
 *
 * Structure per icon (`IconDef`):
 *   outline — stroke-based paths (designed for fill="none", stroke="currentColor")
 *   fill    — solid paths       (designed for fill="currentColor", stroke="none")
 *           — OR `''` (empty string) for an **outline-only** icon: a glyph
 *             built from open/thin strokes (a line, an antenna, a needle...)
 *             that has NO real solid silhouette. Filling that same path data
 *             with `fill="currentColor"` would give many of its subpaths
 *             ZERO area — the icon would render incomplete or invisible.
 *             `icon.component.ts` detects `fill === ''` and degrades
 *             `variant="fill"` to the outline stroke rendering instead of
 *             breaking the icon. This is NOT "outline === fill" (that used
 *             to be the convention and was the bug): the outline path is
 *             reused, but rendered with the outline's stroke wrapper, never
 *             with `fill="currentColor"`.
 *
 * Gate: no `<sol-icon>` consumer inside `projects/solercia/ui/src/lib/**`
 * may inline its own `<svg>`/`<path>` — everything goes through this
 * registry (see the lint/test gate described in `icon.registry.spec.ts`).
 */
interface IconDef {
    outline: string;
    /** Solid path data, or `''` for an outline-only icon (see above). */
    fill: string;
}
declare const ICON_REGISTRY: Readonly<Record<string, IconDef>>;

type SolIconSize = 'sm' | 'md' | 'lg';
type SolIconVariant = 'outline' | 'fill';
/** All valid icon names. Add here when you extend icon.registry.ts. */
type SolIconName = keyof typeof ICON_REGISTRY;
declare class SolIconComponent {
    private readonly sanitizer;
    /** Icon name — must exist in ICON_REGISTRY. */
    readonly name: _angular_core.InputSignal<string>;
    /** Size token. Defaults to 'md' (20 × 20 px). */
    readonly size: _angular_core.InputSignal<SolIconSize>;
    /**
     * Visual variant:
     *   'outline' — stroke paths on transparent background
     *   'fill'    — solid filled shape
     *
     * Outline-only icons (registry entries with `fill === ''`, e.g. `bold`,
     * `robot`) have no solid silhouette — requesting `variant="fill"` on one
     * of them renders its outline stroke instead (never a broken/invisible
     * icon). See `IconDef.fill` in `icon.registry.ts`.
     *
     * Color is controlled via Tailwind's text-* class on the host element.
     * Example: <sol-icon name="edit" variant="fill" class="text-blue-500" />
     */
    readonly variant: _angular_core.InputSignal<SolIconVariant>;
    readonly sizeClass: _angular_core.Signal<string>;
    readonly svg: _angular_core.Signal<SafeHtml>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolIconComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolIconComponent, "sol-icon", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SolTooltipComponent {
    readonly text: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolTooltipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolTooltipComponent, "sol-tooltip", never, { "text": { "alias": "text"; "required": true; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type SolCheckboxSize = 'sm' | 'md' | 'lg';
type SolCheckboxColor = 'primary' | 'secondary' | 'success' | 'danger' | 'amber' | 'teal' | 'indigo' | 'purple' | 'pink';
type SolCheckboxShape = 'rounded' | 'square' | 'circle';
declare class SolCheckboxComponent implements ControlValueAccessor {
    /** Text label beside the checkbox. */
    readonly label: _angular_core.InputSignal<string>;
    /** Whether the checkbox is disabled. */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Size preset. */
    readonly size: _angular_core.InputSignal<SolCheckboxSize>;
    /** Color variant. */
    readonly color: _angular_core.InputSignal<SolCheckboxColor>;
    /** Shape of the checkbox box. */
    readonly shape: _angular_core.InputSignal<SolCheckboxShape>;
    /** Whether to show ripple effect on click. */
    readonly ripple: _angular_core.InputSignal<boolean>;
    /** Custom icon: check (default), minus (indeterminate), heart, star. */
    readonly icon: _angular_core.InputSignal<"heart" | "check" | "minus" | "star">;
    /** Link text shown after the label. */
    readonly linkText: _angular_core.InputSignal<string>;
    /** Link href. */
    readonly linkHref: _angular_core.InputSignal<string>;
    /** Emits when checked state changes (for template-driven usage). */
    readonly changed: _angular_core.OutputEmitterRef<boolean>;
    /** Internal checked state. */
    readonly checked: _angular_core.WritableSignal<boolean>;
    /** Ripple animation state. */
    readonly rippleActive: _angular_core.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    readonly iconViewBox: _angular_core.Signal<string>;
    readonly colorVar: _angular_core.Signal<string>;
    readonly hostClass: _angular_core.Signal<string>;
    readonly boxWrapperClass: _angular_core.Signal<string>;
    readonly boxClass: _angular_core.Signal<string>;
    onToggle(): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolCheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolCheckboxComponent, "sol-checkbox", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "ripple": { "alias": "ripple"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "linkText": { "alias": "linkText"; "required": false; "isSignal": true; }; "linkHref": { "alias": "linkHref"; "required": false; "isSignal": true; }; }, { "changed": "changed"; }, never, never, true, never>;
}

/**
 * Variantes de forma del skeleton (Paso 5 theming v2):
 * - `text` / `title`: líneas de texto con radio pequeño del tema.
 * - `stat` / `card`: bloques de tarjeta con el radio de card del tema.
 * - `row`: fila de tabla o lista.
 * - `circle`: avatar circular.
 * - `rounded` / `square`: formas genéricas previas (galería de imágenes,
 *   bloques dimensionados por altura). Se conservan por compatibilidad.
 */
type SolSkeletonVariant = 'text' | 'title' | 'stat' | 'card' | 'row' | 'circle' | 'rounded' | 'square';
/**
 * Placeholder de carga tokenizado: el estado de carga también es de marca.
 * La forma sale por completo de los tokens del tema — en un tema plano y
 * recto el skeleton es plano y recto; en uno redondeado y suave, también —
 * sin ninguna lógica por tenant:
 * - Fondo: `--sol-bg-sunken` (superficie hundida del tema).
 * - Radio: `--sol-card-radius` para bloques, `--sol-border-radius-sm` para
 *   líneas y filas, 50% para círculos.
 * - Shimmer: keyframe global `solShimmer` (styles.css) con duración derivada
 *   de `--sol-dur-slow`, así hereda el escalado por intensidad de motion y
 *   por prefers-reduced-motion que aplica el ThemeService a los tokens.
 *
 * Accesibilidad: el host va `aria-hidden` (es decoración); el `aria-busy`
 * del contenedor que carga lo declara el consumidor.
 */
declare class SolSkeletonComponent {
    readonly variant: _angular_core.InputSignal<SolSkeletonVariant>;
    /** Override opcional del ancho (los defaults salen de la variante). */
    readonly width: _angular_core.InputSignal<string>;
    /** Override opcional del alto (los defaults salen de la variante). */
    readonly height: _angular_core.InputSignal<string>;
    readonly aspectRatio: _angular_core.InputSignal<string>;
    /** Cantidad de bloques a repetir (p. ej. filas de una tabla). */
    readonly count: _angular_core.InputSignalWithTransform<number, unknown>;
    protected readonly cssClass: _angular_core.Signal<string>;
    /** Índices a iterar; count inválido o menor a 1 pinta un solo bloque. */
    protected readonly blocks: _angular_core.Signal<number[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolSkeletonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolSkeletonComponent, "sol-skeleton", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "aspectRatio": { "alias": "aspectRatio"; "required": false; "isSignal": true; }; "count": { "alias": "count"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SolFileUploadComponent {
    readonly accept: _angular_core.InputSignal<string>;
    readonly maxSizeBytes: _angular_core.InputSignal<number>;
    readonly label: _angular_core.InputSignal<string>;
    readonly hint: _angular_core.InputSignal<string>;
    readonly fileSelected: _angular_core.OutputEmitterRef<File>;
    readonly previewReady: _angular_core.OutputEmitterRef<string>;
    readonly fileError: _angular_core.OutputEmitterRef<string>;
    readonly fileRemoved: _angular_core.OutputEmitterRef<void>;
    readonly isDragOver: _angular_core.WritableSignal<boolean>;
    readonly isDragInvalid: _angular_core.WritableSignal<boolean>;
    readonly previewUrl: _angular_core.WritableSignal<string | null>;
    readonly fileName: _angular_core.WritableSignal<string | null>;
    readonly errorMessage: _angular_core.WritableSignal<string | null>;
    onDragOver(event: DragEvent): void;
    onDragLeave(): void;
    onDrop(event: DragEvent): void;
    onInputChange(event: Event): void;
    removeImage(event: Event): void;
    private processFile;
    private isAcceptedType;
    private getReadableTypes;
    /** Permite resetear el componente desde el exterior */
    reset(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolFileUploadComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolFileUploadComponent, "sol-file-upload", never, { "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "maxSizeBytes": { "alias": "maxSizeBytes"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; }, { "fileSelected": "fileSelected"; "previewReady": "previewReady"; "fileError": "fileError"; "fileRemoved": "fileRemoved"; }, never, never, true, never>;
}

interface DayPickerItem {
    dateStr: string;
    dayName: string;
    dayNumber: number;
    isToday?: boolean;
    isPast: boolean;
}
declare class SolDayPickerComponent {
    readonly days: _angular_core.InputSignal<DayPickerItem[]>;
    readonly selectedDate: _angular_core.InputSignal<string | null>;
    readonly dateSelected: _angular_core.OutputEmitterRef<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolDayPickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolDayPickerComponent, "sol-day-picker", never, { "days": { "alias": "days"; "required": true; "isSignal": true; }; "selectedDate": { "alias": "selectedDate"; "required": false; "isSignal": true; }; }, { "dateSelected": "dateSelected"; }, never, never, true, never>;
}

/** Vista activa del calendario dentro del popover. */
type DatePickerView = 'days' | 'months' | 'years';
/** Tamaño del campo disparador (md = alto de input estándar, sm = compacto). */
type SolDatePickerSize = 'sm' | 'md';
/** Celda de la grilla de días (6 semanas × 7 días = 42 celdas fijas). */
interface DayCell {
    date: Date;
    iso: string;
    day: number;
    inMonth: boolean;
    isToday: boolean;
    isSelected: boolean;
    isFocused: boolean;
    disabled: boolean;
    aria: string;
}
/** Celda de la grilla de meses (12 celdas). */
interface MonthCell {
    index: number;
    label: string;
    isCurrent: boolean;
    isSelected: boolean;
    disabled: boolean;
}
/** Celda de la grilla de años (década + 1 antes/después = 12 celdas). */
interface YearCell {
    year: number;
    inDecade: boolean;
    isCurrent: boolean;
    isSelected: boolean;
    disabled: boolean;
}
/**
 * `sol-date-picker` — calendario propio del design system, tematizado con
 * tokens `--sol-*` (light/dark) y con tres vistas navegables:
 *
 *  1. DÍAS  — grilla del mes (semana lunes→domingo, convención es-CO), con
 *     desborde atenuado del mes anterior/siguiente; hoy marcado, seleccionado
 *     con fondo primario. El encabezado "Mes AAAA" promueve a la vista MESES.
 *  2. MESES — grilla 3×4 del año; el encabezado "AAAA" promueve a la vista AÑOS.
 *  3. AÑOS  — grilla de la década (12 años); elegir un año vuelve a MESES.
 *
 * Presentación: un campo de texto de solo lectura con ícono de calendario que,
 * al enfocar o hacer clic, abre un popover con posicionamiento manual (arriba
 * o abajo según el viewport), que cierra con clic-fuera o Escape.
 *
 * API dual: funciona como componente controlado (`value` + `valueChange`) y
 * como `ControlValueAccessor` (ngModel / reactive forms). Emite siempre
 * `yyyy-MM-dd` (fecha local, sin conversión de zona horaria), el mismo formato
 * date-only que usa el resto de la plataforma.
 *
 * NOTA: es un componente DISTINTO de `sol-day-picker` (tira horizontal de días
 * del flujo de reserva). Ambos conviven en el design system.
 */
declare class SolDatePickerComponent implements ControlValueAccessor {
    private readonly i18n;
    private readonly hostEl;
    /** Valor seleccionado. Acepta `Date`, `yyyy-MM-dd`/ISO o `null`. */
    readonly value: _angular_core.InputSignal<string | Date | null | undefined>;
    /** Cota inferior seleccionable (fuera de rango queda deshabilitado). */
    readonly min: _angular_core.InputSignal<string | Date | null | undefined>;
    /** Cota superior seleccionable (fuera de rango queda deshabilitado). */
    readonly max: _angular_core.InputSignal<string | Date | null | undefined>;
    /** Placeholder del campo cuando no hay fecha; por defecto usa la clave i18n. */
    readonly placeholder: _angular_core.InputSignal<string>;
    /** Deshabilita el campo (también lo hace `setDisabledState` de formularios). */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Tamaño del campo disparador. */
    readonly size: _angular_core.InputSignal<SolDatePickerSize>;
    /** Emite la fecha elegida como `yyyy-MM-dd` (fecha local, sin UTC). */
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    private readonly triggerRef;
    /** Fecha seleccionada canónica (fuente de verdad del display). */
    private readonly selected;
    /** Deshabilitado impuesto por el formulario (CVA). */
    private readonly formDisabled;
    /** Mes/año que se está mostrando en la grilla. */
    private readonly viewDate;
    /** Día con foco de teclado dentro de la vista DÍAS. */
    private readonly focusedDate;
    readonly view: _angular_core.WritableSignal<DatePickerView>;
    readonly isOpen: _angular_core.WritableSignal<boolean>;
    readonly dropUp: _angular_core.WritableSignal<boolean>;
    readonly alignEnd: _angular_core.WritableSignal<boolean>;
    /** Suprime la apertura por foco al devolver el foco tras cerrar el popover. */
    private suppressFocusOpen;
    /** Hoy a medianoche, fijo durante la vida del componente. */
    private readonly today;
    private readonly placeholderKey;
    private readonly triggerAriaKey;
    private readonly dialogAriaKey;
    private readonly prevAriaKey;
    private readonly nextAriaKey;
    private readonly titleAriaKey;
    readonly placeholderText: _angular_core.Signal<string>;
    readonly triggerAria: _angular_core.Signal<string>;
    readonly dialogAria: _angular_core.Signal<string>;
    readonly prevAria: _angular_core.Signal<string>;
    readonly nextAria: _angular_core.Signal<string>;
    readonly titleAria: _angular_core.Signal<string>;
    onChange: (value: string) => void;
    onTouched: () => void;
    constructor();
    /** Locale efectivo (reactivo al idioma activo); es-CO por defecto. */
    private readonly locale;
    readonly isDisabled: _angular_core.Signal<boolean>;
    private readonly minDate;
    private readonly maxDate;
    /** Texto del campo: fecha seleccionada formateada (dd/mm/aaaa) o vacío. */
    readonly displayText: _angular_core.Signal<string>;
    /** Nombres cortos de los 7 días, empezando en lunes (convención es-CO). */
    readonly weekdayLabels: _angular_core.Signal<string[]>;
    /** Etiqueta del encabezado según la vista activa. */
    readonly headerLabel: _angular_core.Signal<string>;
    /** 42 celdas de día (6 semanas), agrupadas en filas de 7. */
    readonly weeks: _angular_core.Signal<DayCell[][]>;
    /** 12 meses del año en curso de la vista. */
    readonly months: _angular_core.Signal<MonthCell[]>;
    /** 12 años: la década más un año antes y otro después (atenuados). */
    readonly years: _angular_core.Signal<YearCell[]>;
    toggle(): void;
    /** Abre por foco, salvo cuando el foco proviene de un cierre programático. */
    onTriggerFocus(): void;
    open(): void;
    close(): void;
    /** Cierra al hacer clic fuera del componente. */
    onDocumentClick(event: MouseEvent): void;
    /** Calcula manualmente si el popover abre hacia arriba/derecha (viewport). */
    private positionPopover;
    goPrev(): void;
    goNext(): void;
    /** Promueve la vista: días → meses → años. */
    promoteView(): void;
    pickDay(date: Date): void;
    pickMonth(index: number): void;
    pickYear(year: number): void;
    onTriggerKeydown(event: KeyboardEvent): void;
    onPopoverKeydown(event: KeyboardEvent): void;
    writeValue(value: Date | string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /** True si `date` está fuera del rango `[min, max]` (comparación por día). */
    private outOfRange;
    /** Ajusta `date` dentro de `[min, max]` para arrancar el foco en un día válido. */
    private clampToRange;
    /** Devuelve el foco al campo sin re-disparar la apertura por foco. */
    private focusTrigger;
    /** Enfoca la celda con foco tras el próximo render (roving tabindex). */
    private focusActiveCellSoon;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolDatePickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolDatePickerComponent, "sol-date-picker", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

interface SolViewToggleOption {
    value: string;
    label: string;
    icon?: SolIconName;
}
declare class SolViewToggleComponent {
    readonly options: _angular_core.InputSignal<SolViewToggleOption[]>;
    readonly value: _angular_core.InputSignal<string>;
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    onSelect(value: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolViewToggleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolViewToggleComponent, "sol-view-toggle", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

/**
 * Estado vacío estándar del design system (E2): ícono + título +
 * descripción opcional + slot para una acción. Recibe CLAVES i18n (no
 * texto) y las resuelve vía I18nService, reactivo al idioma activo.
 *
 * Uso:
 * ```html
 * <sol-empty-state icon="building" titleKey="pages.x.empty.title" descriptionKey="pages.x.empty.description">
 *   <sol-button (clicked)="crear()">…</sol-button>
 * </sol-empty-state>
 * ```
 */
declare class SolEmptyStateComponent {
    private readonly i18n;
    /** Ícono del registry a mostrar. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Clave i18n del título (obligatoria). */
    readonly titleKey: _angular_core.InputSignal<string>;
    /** Clave i18n de la descripción (opcional). */
    readonly descriptionKey: _angular_core.InputSignal<string>;
    /**
     * Las claves son inputs (dinámicas), así que no se puede usar `i18n.t()`
     * directo: se lee `activeLang` dentro del computed para recalcular la
     * traducción cuando cambia el idioma.
     */
    readonly title: _angular_core.Signal<string>;
    readonly description: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolEmptyStateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolEmptyStateComponent, "sol-empty-state", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "titleKey": { "alias": "titleKey"; "required": true; "isSignal": true; }; "descriptionKey": { "alias": "descriptionKey"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Un paso del stepper. Recibe CLAVES i18n (no texto) — patrón
 * `sol-empty-state` — y las resuelve vía I18nService, reactivo al idioma.
 */
interface SolStepperStep {
    /** Identificador estable del paso (track y testing). */
    id: string;
    /** Clave i18n de la etiqueta del paso. */
    labelKey: string;
    /** Clave i18n de la descripción corta opcional. */
    descriptionKey?: string;
    /** Marca el paso en estado de error (prevalece sobre completado). */
    error?: boolean;
}
type SolStepperOrientation = 'horizontal' | 'vertical';
type SolStepperStepState = 'completed' | 'current' | 'pending' | 'error';
/**
 * `'linear'` (default, comportamiento 0.1.x sin cambios): en modo
 * `interactive`, solo son navegables los pasos ya alcanzados (hasta
 * `furthestIndex`/`activeIndex`) — wizard clásico.
 * `'free'` (D7, 11-a-solercia-ui): CUALQUIER paso es navegable, incluso uno
 * nunca visitado — pipeline CRM accionable (mover un lead a cualquier
 * etapa). El estado visual (completado/actual/pendiente) no cambia; solo
 * cambia CUÁLES pasos aceptan clic/teclado.
 */
type SolStepperNavigation = 'linear' | 'free';
/**
 * `sol-stepper` — átomo del design system (E4, primer consumidor:
 * onboarding v2).
 *
 * - Estados DERIVADOS del índice activo y de la frontera alcanzada
 *   (`furthestIndex`): activo → actual, cualquier paso hasta la frontera →
 *   completado, más allá → pendiente; `step.error` prevalece.
 * - A11y: lista con `aria-orientation`, `aria-current="step"` en el paso
 *   actual, `aria-disabled` en los no navegables y roving tabindex con
 *   navegación por flechas/Home/End cuando es interactivo.
 * - Interactivo: los pasos ya alcanzados (índice ≤ `furthestIndex`) son
 *   navegables en AMBOS sentidos; los futuros jamás emiten. Sin
 *   `furthestIndex` la frontera es el propio `activeIndex` → wizard lineal
 *   clásico (solo hacia atrás), preservando el comportamiento previo.
 * - `navigation` (D7, 11-a-solercia-ui): `'linear'` (default) es EXACTAMENTE
 *   el comportamiento anterior; `'free'` habilita el pipeline accionable —
 *   cualquier paso, visitado o no, es navegable. Extensión OCP pura: un
 *   input nuevo, cero cambios en la API 0.1.x.
 * - Light/dark vía tokens `--sol-*` con fallbacks, como todo átomo.
 */
declare class SolStepperComponent {
    private readonly i18n;
    private readonly host;
    /** Pasos a renderizar, en orden. */
    readonly steps: _angular_core.InputSignal<SolStepperStep[]>;
    /** Índice (base 0) del paso actual. */
    readonly activeIndex: _angular_core.InputSignal<number>;
    /**
     * Índice máximo ya alcanzado (frontera). Los pasos hasta aquí se muestran
     * completados y son navegables en ambos sentidos. Si es `null` (default),
     * la frontera es el propio `activeIndex` → wizard lineal clásico.
     */
    readonly furthestIndex: _angular_core.InputSignal<number | null>;
    readonly orientation: _angular_core.InputSignal<SolStepperOrientation>;
    /**
     * `true` permite navegar a pasos YA alcanzados (clic/teclado), atrás o
     * adelante hasta `furthestIndex`. Los pasos futuros nunca son navegables.
     */
    readonly interactive: _angular_core.InputSignal<boolean>;
    /**
     * `'linear'` (default) preserva la API 0.1.x sin cambios de comportamiento.
     * `'free'` habilita el pipeline accionable: con `interactive=true`,
     * CUALQUIER paso (incluso uno no alcanzado) es navegable — ver
     * {@link SolStepperNavigation}.
     */
    readonly navigation: _angular_core.InputSignal<SolStepperNavigation>;
    /** Clave i18n del nombre accesible de la lista de pasos. */
    readonly ariaLabelKey: _angular_core.InputSignal<string>;
    /** Índice del paso visitado al que el usuario quiere volver. */
    readonly stepSelected: _angular_core.OutputEmitterRef<number>;
    /** Claves dinámicas → traducción reactiva al idioma (patrón sol-empty-state). */
    readonly labels: _angular_core.Signal<string[]>;
    readonly descriptions: _angular_core.Signal<string[]>;
    readonly ariaLabel: _angular_core.Signal<string>;
    /** Texto solo-lector-de-pantalla del estado de cada paso. */
    readonly stateLabels: _angular_core.Signal<Record<SolStepperStepState, string>>;
    /**
     * Frontera efectiva: `furthestIndex` si se proporcionó, si no el propio
     * `activeIndex` (wizard lineal). Nunca por debajo del activo.
     */
    readonly effectiveFurthest: _angular_core.Signal<number>;
    stateOf(index: number): SolStepperStepState;
    /**
     * Navegable = interactivo y distinto del actual. En `navigation:'linear'`
     * (default) además exige estar dentro de la frontera alcanzada — igual
     * que antes de D7. En `navigation:'free'` cualquier paso califica (pipeline
     * accionable): el estado visual sigue siendo el mismo, solo cambia qué
     * acepta clic/teclado.
     */
    isNavigable(index: number): boolean;
    /** `aria-disabled` solo aplica en modo interactivo; en visual puro no hay semántica de botón. */
    ariaDisabledOf(index: number): string | null;
    /** Roving tabindex: único tab-stop en el paso actual cuando es interactivo. */
    tabIndexOf(index: number): number;
    onStepClick(index: number): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolStepperComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolStepperComponent, "sol-stepper", never, { "steps": { "alias": "steps"; "required": true; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "furthestIndex": { "alias": "furthestIndex"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "interactive": { "alias": "interactive"; "required": false; "isSignal": true; }; "navigation": { "alias": "navigation"; "required": false; "isSignal": true; }; "ariaLabelKey": { "alias": "ariaLabelKey"; "required": false; "isSignal": true; }; }, { "stepSelected": "stepSelected"; }, never, never, true, never>;
}

type SolProgressMode = 'continuous' | 'segmented';
type SolProgressSize = 'sm' | 'md' | 'lg';
type SolProgressVariant = 'primary' | 'success' | 'warning' | 'danger';
/**
 * `sol-progress-bar` — átomo del design system.
 *
 * Dos modos:
 *  - `continuous`: una barra que se llena según `value` (0..`max`).
 *  - `segmented`: N segmentos (`steps`); los que están hasta `current`
 *    (incluido) se pintan con el color de la variante, el resto quedan en
 *    el track (`--sol-bg-sunken`). Ideal como indicador de fase de un wizard.
 *
 * Tematizado 100% con `var(--sol-*)` (light/dark). Accesible: expone
 * `role="progressbar"` con `aria-valuenow/min/max` y `aria-valuetext`
 * (el texto legible: "50 %" o "Paso 2 de 4"), aunque la etiqueta visible
 * (`showLabel`) esté oculta.
 */
declare class SolProgressBarComponent {
    private readonly i18n;
    /** `continuous` (value/max) o `segmented` (steps/current). */
    readonly mode: _angular_core.InputSignal<SolProgressMode>;
    /** Valor actual del modo continuo (se recorta a `[0, max]`). */
    readonly value: _angular_core.InputSignal<number>;
    /** Valor máximo del modo continuo. */
    readonly max: _angular_core.InputSignal<number>;
    /** Número total de segmentos (modo segmentado). */
    readonly steps: _angular_core.InputSignal<number>;
    /** Índice (base 0) del segmento actual; `0..current` se pintan activos. */
    readonly current: _angular_core.InputSignal<number>;
    /** Altura de la barra. */
    readonly size: _angular_core.InputSignal<SolProgressSize>;
    /** Color por estado. */
    readonly variant: _angular_core.InputSignal<SolProgressVariant>;
    /** Muestra la etiqueta visible ("50 %" o "Paso X de N"). */
    readonly showLabel: _angular_core.InputSignal<boolean>;
    /** Override del texto de la etiqueta; si se deja vacío se deriva del modo. */
    readonly label: _angular_core.InputSignal<string>;
    /** Override del nombre accesible; si se deja vacío usa la clave i18n por defecto. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly rootClass: _angular_core.Signal<string>;
    /** Segmentos como arreglo de índices para el `@for`. */
    readonly segments: _angular_core.Signal<number[]>;
    /** Valor recortado del modo continuo. */
    private readonly clampedValue;
    /** Porcentaje de llenado (0..100). */
    readonly percent: _angular_core.Signal<number>;
    /** `aria-valuenow`. */
    readonly ariaNow: _angular_core.Signal<number>;
    /** `aria-valuemax` del modo segmentado. */
    readonly ariaMax: _angular_core.Signal<number>;
    /** Texto legible de la etiqueta (visible y para `aria-valuetext`). */
    readonly labelText: _angular_core.Signal<string>;
    /** Nombre accesible del control. */
    readonly ariaLabelText: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolProgressBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolProgressBarComponent, "sol-progress-bar", never, { "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "steps": { "alias": "steps"; "required": false; "isSignal": true; }; "current": { "alias": "current"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "showLabel": { "alias": "showLabel"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Un paso del wizard. El texto se resuelve así (primero que exista):
 *   `label` (literal, override) → `labelKey` (clave i18n) → cadena vacía.
 * `icon` (opcional) es un nombre de `sol-icon` que se muestra en el
 * encabezado del paso activo.
 */
interface SolWizardStep {
    /** Identificador estable del paso (track y testing). */
    id: string;
    /** Etiqueta literal (tiene prioridad sobre `labelKey`). */
    label?: string;
    /** Clave i18n de la etiqueta. */
    labelKey?: string;
    /** Ícono opcional (nombre en el registry de `sol-icon`). */
    icon?: SolIconName | string;
}
/** `boolean` o predicado sobre el índice del paso actual. */
type SolWizardCanAdvance = boolean | ((currentIndex: number) => boolean);
/**
 * Marca un `<ng-template>`/`<ng-container *solWizardStep>` como el cuerpo de
 * un paso. El wizard renderiza SOLO la plantilla cuyo orden posicional
 * coincide con el paso actual. Debe ser hijo directo de `<sol-wizard>`.
 *
 * ```html
 * <sol-wizard [steps]="steps" [(current)]="current" (finish)="guardar()">
 *   <ng-container *solWizardStep>...contenido paso 1...</ng-container>
 *   <ng-container *solWizardStep>...contenido paso 2...</ng-container>
 * </sol-wizard>
 * ```
 */
declare class SolWizardStepDirective {
    readonly template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolWizardStepDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SolWizardStepDirective, "[solWizardStep]", never, {}, {}, never, never, true, never>;
}
/**
 * `sol-wizard` — asistente por pasos tipo pills/card del design system.
 *
 * Composición (no reimplementa piezas existentes):
 *  - HEADER: `sol-progress-bar` segmentado (N fases = N pasos, el actual y
 *    los previos coloreados) + `sol-stepper` interactivo para las pills
 *    (número → ✓ al completar, conector, retroceso a pasos ya visitados,
 *    a11y y teclado ya resueltos por el átomo).
 *  - CUERPO: proyección por paso vía `*solWizardStep` (patrón recomendado);
 *    si no hay plantillas, cae a un `<ng-content>` único que el consumidor
 *    controla con el `current` enlazado en dos vías.
 *  - FOOTER: "Anterior" (ghost) y "Siguiente" (primary) con `sol-button`;
 *    en el último paso "Siguiente" pasa a "Finalizar" y emite `finish`.
 *
 * `current` es un `model` (two-way `[(current)]`). Además emite `next`,
 * `previous`, `stepChange` y `finish`. `canAdvance` (bool o predicado)
 * deshabilita el avance. Texto por i18n `es-CO` con override por input.
 */
declare class SolWizardComponent {
    private readonly i18n;
    /** Pasos a renderizar, en orden. */
    readonly steps: _angular_core.InputSignal<SolWizardStep[]>;
    /** Índice (base 0) del paso actual — enlazable en dos vías `[(current)]`. */
    readonly current: _angular_core.ModelSignal<number>;
    /** Muestra la barra de fases segmentada en el header. */
    readonly showProgressBar: _angular_core.InputSignal<boolean>;
    /** Oculta "Anterior" en el primer paso; si es `false`, lo muestra deshabilitado. */
    readonly hidePreviousOnFirst: _angular_core.InputSignal<boolean>;
    /** Permite/impide avanzar (bool o predicado del índice actual). */
    readonly canAdvance: _angular_core.InputSignal<SolWizardCanAdvance>;
    /** Overrides de texto (si se dejan vacíos usan la clave i18n / el default es-CO). */
    readonly previousLabel: _angular_core.InputSignal<string>;
    readonly nextLabel: _angular_core.InputSignal<string>;
    readonly finishLabel: _angular_core.InputSignal<string>;
    /** Se emite al avanzar (paso no final). */
    readonly next: _angular_core.OutputEmitterRef<void>;
    /** Se emite al retroceder con "Anterior". */
    readonly previous: _angular_core.OutputEmitterRef<void>;
    /** Se emite con el nuevo índice cada vez que cambia el paso. */
    readonly stepChange: _angular_core.OutputEmitterRef<number>;
    /** Se emite al confirmar el último paso. */
    readonly finish: _angular_core.OutputEmitterRef<void>;
    /** Plantillas de paso proyectadas (orden posicional = orden de `steps`). */
    private readonly stepTemplatesQuery;
    readonly stepTemplates: _angular_core.Signal<readonly SolWizardStepDirective[]>;
    readonly currentTemplate: _angular_core.Signal<TemplateRef<any>>;
    /** Frontera máxima alcanzada (para el retroceso por pills del stepper). */
    readonly furthest: _angular_core.WritableSignal<number>;
    readonly stepCount: _angular_core.Signal<number>;
    readonly isFirst: _angular_core.Signal<boolean>;
    readonly isLast: _angular_core.Signal<boolean>;
    readonly activeStep: _angular_core.Signal<SolWizardStep | undefined>;
    /** Mapea los pasos del wizard al contrato de `sol-stepper` (labelKey). */
    readonly stepperSteps: _angular_core.Signal<SolStepperStep[]>;
    readonly canAdvanceNow: _angular_core.Signal<boolean>;
    readonly activeLabel: _angular_core.Signal<string>;
    readonly previousText: _angular_core.Signal<string>;
    readonly nextText: _angular_core.Signal<string>;
    readonly finishText: _angular_core.Signal<string>;
    /** Resuelve texto: override → clave i18n (si existe) → default es-CO. */
    private text;
    /** Navega a un paso ya visitado (pills del stepper). */
    goTo(index: number): void;
    goPrevious(): void;
    goNext(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolWizardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolWizardComponent, "sol-wizard", never, { "steps": { "alias": "steps"; "required": true; "isSignal": true; }; "current": { "alias": "current"; "required": false; "isSignal": true; }; "showProgressBar": { "alias": "showProgressBar"; "required": false; "isSignal": true; }; "hidePreviousOnFirst": { "alias": "hidePreviousOnFirst"; "required": false; "isSignal": true; }; "canAdvance": { "alias": "canAdvance"; "required": false; "isSignal": true; }; "previousLabel": { "alias": "previousLabel"; "required": false; "isSignal": true; }; "nextLabel": { "alias": "nextLabel"; "required": false; "isSignal": true; }; "finishLabel": { "alias": "finishLabel"; "required": false; "isSignal": true; }; }, { "current": "currentChange"; "next": "next"; "previous": "previous"; "stepChange": "stepChange"; "finish": "finish"; }, ["stepTemplatesQuery"], ["*"], true, never>;
}

/**
 * Matemática PURA de `sol-virtual-scroll` (E5) — sin DOM, sin Angular.
 *
 * El componente delega aquí todo el cálculo: resolución de alturas
 * (estimada + medida), offsets por prefix-sums, búsqueda binaria del primer
 * ítem visible, ventana renderizada con buffer, detección de "estar al
 * fondo" (anclaje tipo chat) y clasificación de cambios de lista
 * (append/prepend/reset) que gobiernan el anclaje y el chip
 * "mensajes nuevos".
 */
/** Ventana de ítems a renderizar + espaciadores que preservan el scroll. */
interface VirtualWindow {
    /** Primer índice renderizado (inclusivo). */
    start: number;
    /** Último índice renderizado (exclusivo). */
    end: number;
    /** Alto en px del espaciador superior (ítems no renderizados arriba). */
    padTop: number;
    /** Alto en px del espaciador inferior (ítems no renderizados abajo). */
    padBottom: number;
    /** Alto total del contenido en px. */
    totalHeight: number;
}

/** Contexto del template de ítem proyectado. */
interface SolVirtualScrollItemContext<T> {
    $implicit: T;
    index: number;
}
interface VisibleRow<T> {
    item: T;
    index: number;
    key: string | number;
}
/**
 * `sol-virtual-scroll` — virtual scroll PROPIO del design system (E5), sin
 * CDK ni librerías: renderiza solo los ítems visibles + buffer con
 * espaciadores que preservan el alto total.
 *
 * - **Altura variable**: cada ítem arranca con `estimatedItemHeight` y se
 *   corrige con la altura REAL medida tras el render (por clave estable,
 *   así la medición sobrevive a prepends). La matemática vive en
 *   `virtual-window.ts` (funciones puras con spec propia).
 * - **Anclaje al fondo (patrón chat)**: con `followOutput` activo, los
 *   ítems nuevos al final empujan el scroll al fondo SOLO si el usuario ya
 *   estaba al fondo; si scrolleó hacia arriba, el scroll no se arrastra y
 *   aparece el chip "mensajes nuevos" con el conteo.
 * - **Paginación hacia atrás**: emite `nearTop` al acercarse al inicio y
 *   compensa el scroll cuando se prepende una página de ítems antiguos
 *   (sin salto visual).
 *
 * Uso:
 * ```html
 * <sol-virtual-scroll [items]="messages()" [itemKey]="byId" [estimatedItemHeight]="64" (nearTop)="loadOlder()">
 *   <ng-template let-msg let-index="index">…</ng-template>
 * </sol-virtual-scroll>
 * ```
 * El host debe darle altura (ocupa el 100% de su contenedor).
 */
declare class SolVirtualScrollComponent<T = unknown> implements AfterViewChecked {
    private readonly i18n;
    /** Lista completa de ítems (el componente solo renderiza la ventana). */
    readonly items: _angular_core.InputSignal<readonly T[]>;
    /**
     * Clave ESTABLE por ítem (ej. id del mensaje). Gobierna el track del
     * render, el mapa de alturas medidas y la detección append/prepend.
     * Por defecto usa el índice (suficiente para listas append-only).
     */
    readonly itemKey: _angular_core.InputSignal<(item: T, index: number) => string | number>;
    /** Altura estimada por ítem mientras no exista medición real. */
    readonly estimatedItemHeight: _angular_core.InputSignal<number>;
    /** Buffer en px renderizado por fuera del viewport (arriba y abajo). */
    readonly bufferPx: _angular_core.InputSignal<number>;
    /** Anclaje al fondo tipo chat (nuevos ítems empujan si ya estabas al fondo). */
    readonly followOutput: _angular_core.InputSignal<boolean>;
    /** Distancia al inicio (px) que dispara `nearTop` (paginación hacia atrás). */
    readonly nearTopThreshold: _angular_core.InputSignal<number>;
    /** Se acerca al inicio de la lista: cargar página anterior. */
    readonly nearTop: _angular_core.OutputEmitterRef<void>;
    /** Cambió el estado "está al fondo" (ej. para ocultar acciones). */
    readonly atBottomChange: _angular_core.OutputEmitterRef<boolean>;
    /** Template del ítem, proyectado por el consumidor. */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<any>>;
    private readonly viewportRef;
    private readonly scrollTop;
    private readonly viewportHeight;
    private readonly measured;
    private readonly _atBottom;
    private readonly _newItemsCount;
    /** ¿El usuario está al fondo del hilo? */
    readonly atBottom: _angular_core.Signal<boolean>;
    /** Ítems nuevos llegados mientras el usuario estaba scrolleado arriba. */
    readonly newItemsCount: _angular_core.Signal<number>;
    readonly chipLabel: _angular_core.Signal<string>;
    private readonly keys;
    private readonly offsets;
    readonly window: _angular_core.Signal<VirtualWindow>;
    readonly visibleRows: _angular_core.Signal<VisibleRow<T>[]>;
    private prevKeys;
    private pendingScrollToBottom;
    private pendingPrependCount;
    private nearTopArmed;
    private lastEmittedAtBottom;
    constructor();
    ngAfterViewChecked(): void;
    onScroll(): void;
    /** Salta al fondo del hilo y limpia el chip de mensajes nuevos. */
    scrollToBottom(): void;
    jumpToBottom(): void;
    private onItemsChanged;
    private measureRenderedRows;
    private applyScrollToBottom;
    private syncFromViewport;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolVirtualScrollComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolVirtualScrollComponent<any>, "sol-virtual-scroll", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "itemKey": { "alias": "itemKey"; "required": false; "isSignal": true; }; "estimatedItemHeight": { "alias": "estimatedItemHeight"; "required": false; "isSignal": true; }; "bufferPx": { "alias": "bufferPx"; "required": false; "isSignal": true; }; "followOutput": { "alias": "followOutput"; "required": false; "isSignal": true; }; "nearTopThreshold": { "alias": "nearTopThreshold"; "required": false; "isSignal": true; }; }, { "nearTop": "nearTop"; "atBottomChange": "atBottomChange"; }, ["itemTemplate"], never, true, never>;
}

/**
 * Adapter puro tokens → Chart.js (E3).
 *
 * Traduce los tokens `--sol-*` del tema activo (light/dark) a una
 * `ChartConfiguration` de Chart.js. TODO lo que decide colores, fuentes,
 * grid, leyenda y tooltips vive aquí como funciones puras — sin canvas, sin
 * DOM — para que los specs de Vitest lo cubran sin mockear el motor.
 *
 * `SolChartComponent` es el ÚNICO consumidor: lee las variables CSS en
 * runtime (getComputedStyle) y delega en `buildChartConfig`. Las vistas
 * jamás importan Chart.js ni este archivo directamente — usan `<sol-chart>`.
 */
/** Tipos declarativos soportados por sol-chart. `sparkline` es una línea minimalista sin ejes ni leyenda. */
type SolChartType = 'line' | 'bar' | 'doughnut' | 'sparkline';
/** Serie de datos. El `label` llega YA resuelto por i18n (sol-chart no traduce datos). */
interface SolChartSeries {
    label: string;
    data: number[];
    /** Color explícito (CSS). Si falta, se asigna cíclicamente de la paleta de tokens. */
    color?: string;
}
/** Datos declarativos del chart: etiquetas del eje + series. */
interface SolChartData {
    labels: string[];
    series: SolChartSeries[];
}
/** Configuración mínima opcional de sol-chart. */
interface SolChartOptions {
    /** Fuerza mostrar/ocultar la leyenda. Por defecto se decide por tipo y número de series. */
    legend?: boolean;
    /** Límite superior del eje Y (ej. 100 para porcentajes de ocupación). */
    yMax?: number;
}

/** Contrato mínimo que sol-chart necesita de una instancia del motor. */
interface SolChartEngineHandle {
    destroy(): void;
}
/** Fábrica de instancias del motor de gráficas (canvas + config → handle). */
type SolChartEngineFactory = (canvas: HTMLCanvasElement, config: ChartConfiguration) => SolChartEngineHandle;
/**
 * Punto ÚNICO de acople con Chart.js: la fábrica por defecto instancia
 * `new Chart(...)`. Los specs la sustituyen para probar el componente sin
 * canvas real; un eventual cambio de motor se resuelve aquí y en el adapter.
 */
declare const SOL_CHART_ENGINE: InjectionToken<SolChartEngineFactory>;
/**
 * `sol-chart` (E3): envoltura propia de Chart.js con API declarativa.
 *
 * - Las vistas declaran `type` + `data` (+ `options` mínimas) y NUNCA
 *   importan Chart.js — regla del proyecto (theming por tenant y cambio de
 *   motor centralizados).
 * - Los colores/fuentes/grid salen de las variables `--sol-*` del tema
 *   ACTIVO, leídas en runtime con getComputedStyle; al alternar light/dark
 *   (`ThemeService.isDark`) el chart se re-renderiza solo.
 * - A11y: el canvas expone `role="img"` + `aria-label` resuelto por clave
 *   i18n (`ariaLabelKey`), reactivo al idioma activo.
 *
 * Uso:
 * ```html
 * <sol-chart
 *   type="doughnut"
 *   [data]="{ labels: estados(), series: [{ label: citasLabel(), data: conteos() }] }"
 *   ariaLabelKey="pages.dashboard.charts.byState.aria"
 * />
 * ```
 */
declare class SolChartComponent {
    private readonly themeService;
    private readonly i18n;
    private readonly engineFactory;
    private readonly destroyRef;
    private readonly canvasRef;
    /** Tipo declarativo de la gráfica. */
    readonly type: _angular_core.InputSignal<SolChartType>;
    /** Etiquetas + series. Los textos llegan YA resueltos por i18n. */
    readonly data: _angular_core.InputSignal<SolChartData>;
    /** Configuración mínima opcional (leyenda, tope del eje Y). */
    readonly options: _angular_core.InputSignal<SolChartOptions>;
    /** Clave i18n del `aria-label` del canvas (obligatoria — a11y). */
    readonly ariaLabelKey: _angular_core.InputSignal<string>;
    /** Alto del contenedor (el canvas es responsive dentro de él). */
    readonly height: _angular_core.InputSignal<string>;
    /** La clave es un input dinámico: se recalcula al cambiar el idioma activo. */
    readonly ariaLabel: _angular_core.Signal<string>;
    private chart;
    constructor();
    private render;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolChartComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolChartComponent, "sol-chart", never, { "type": { "alias": "type"; "required": true; "isSignal": true; }; "data": { "alias": "data"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "ariaLabelKey": { "alias": "ariaLabelKey"; "required": true; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Hook opcional para subir una imagen y devolver su URL definitiva. */
type SolRichImageUploader = (file: File) => Promise<string>;
/**
 * Usuario mencionable con `@` (opt-in). Al elegirlo se inserta un chip
 * `<span data-mention-id="id">@name</span>` y se emite su `id` en
 * `mentionsChange`.
 */
interface MentionUser {
    id: string;
    name: string;
}
/**
 * Tarea enlazable con `#` (opt-in). Al elegirla se inserta un chip
 * `<span data-task-key="key">key</span>` y se emite su `key` en
 * `taskLinksChange`.
 */
interface LinkableTask {
    key: string;
    title: string;
}
/** Estado de los formatos activos bajo el cursor (para resaltar la toolbar). */
interface ActiveFormats {
    bold: boolean;
    italic: boolean;
    underline: boolean;
    strike: boolean;
    bulletList: boolean;
    numberedList: boolean;
    alignLeft: boolean;
    alignCenter: boolean;
    alignRight: boolean;
}
/**
 * `sol-rich-editor` — editor de texto enriquecido PROPIO del design system.
 *
 * - `ControlValueAccessor`: funciona con `ngModel`/reactive forms. El value
 *   NUNCA es el `innerHTML` crudo del área editable: es SIEMPRE el HTML limpio
 *   serializado por `serializeElementToTcpdfHtml` (canónico, apto para TCPDF).
 *   El DOM vivo del `contenteditable` es efímero; el value se deriva de él.
 * - Comandos: enfoque HÍBRIDO. Los comandos de formato inline, listas,
 *   encabezados y alineación usan `document.execCommand` (robusto para el
 *   manejo del cursor/selección entre navegadores, aunque esté deprecado); la
 *   inserción de imágenes, tablas y enlaces usa la API `Selection`/`Range`
 *   propia. La "suciedad" que produce `execCommand` (p. ej. `<font>`, spans con
 *   estilo) es irrelevante: el serializador normaliza toda la salida.
 * - Pegado: SIEMPRE saneado por el mismo serializador (allowlist) antes de
 *   tocar el DOM. Las imágenes del portapapeles se insertan como data URL (o
 *   vía el hook `imageUpload`).
 * - Theming: adopta los tokens `var(--sol-*)` (bordes, foco, tipografía) y
 *   soporta light/dark como todo átomo del sistema.
 */
declare class SolRichEditorComponent implements ControlValueAccessor, AfterViewInit {
    private readonly i18n;
    private readonly destroyRef;
    /** Texto guía cuando el editor está vacío. */
    readonly placeholder: _angular_core.InputSignal<string>;
    /** Altura mínima del área editable (cualquier unidad CSS). */
    readonly minHeight: _angular_core.InputSignal<string>;
    /** Altura máxima opcional (scroll interno al superarla). */
    readonly maxHeight: _angular_core.InputSignal<string>;
    /** Etiqueta accesible del área editable (fallback: clave i18n por defecto). */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Deshabilita el editor (además del estado del formulario). */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Tamaño máximo en bytes de una imagen pegada/insertada (default 5 MB). */
    readonly imageMaxBytes: _angular_core.InputSignal<number>;
    /** Hook opcional para subir la imagen y usar su URL en vez del data URL. */
    readonly imageUpload: _angular_core.InputSignal<SolRichImageUploader | null>;
    /**
     * Usuarios mencionables con `@` (opt-in). Vacío ⇒ menciones DESACTIVADAS:
     * el editor se comporta exactamente igual que sin esta capacidad.
     */
    readonly mentionableUsers: _angular_core.InputSignal<MentionUser[]>;
    /**
     * Tareas enlazables con `#` (opt-in). Vacío ⇒ enlaces DESACTIVADOS: el
     * editor se comporta exactamente igual que sin esta capacidad.
     */
    readonly linkableTasks: _angular_core.InputSignal<LinkableTask[]>;
    /** Emite el HTML limpio en cada cambio (además del flujo CVA). */
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    /** IDs únicos (orden de documento) de los usuarios mencionados en el contenido. */
    readonly mentionsChange: _angular_core.OutputEmitterRef<string[]>;
    /** Keys únicas (orden de documento) de las tareas enlazadas en el contenido. */
    readonly taskLinksChange: _angular_core.OutputEmitterRef<string[]>;
    private readonly editable;
    private readonly fileInput;
    private readonly linkInput;
    private readonly _value;
    private readonly _disabledByForm;
    readonly active: _angular_core.WritableSignal<ActiveFormats>;
    readonly showHeadingMenu: _angular_core.WritableSignal<boolean>;
    readonly showTableMenu: _angular_core.WritableSignal<boolean>;
    readonly showLinkMenu: _angular_core.WritableSignal<boolean>;
    readonly tableRows: _angular_core.WritableSignal<number>;
    readonly tableCols: _angular_core.WritableSignal<number>;
    readonly linkUrl: _angular_core.WritableSignal<string>;
    readonly imageError: _angular_core.WritableSignal<string>;
    readonly showMentionPopover: _angular_core.WritableSignal<boolean>;
    readonly showTaskPopover: _angular_core.WritableSignal<boolean>;
    readonly activeIndex: _angular_core.WritableSignal<number>;
    readonly popoverTop: _angular_core.WritableSignal<number>;
    readonly popoverLeft: _angular_core.WritableSignal<number>;
    private readonly mentionQuery;
    private readonly taskQuery;
    /** Rango que abarca `@query`/`#query`; se reemplaza por el chip al elegir. */
    private triggerRange;
    /** Menciones activas solo si hay usuarios; si no, el trigger `@` se ignora. */
    readonly mentionsEnabled: _angular_core.Signal<boolean>;
    /** Enlaces activos solo si hay tareas; si no, el trigger `#` se ignora. */
    readonly tasksEnabled: _angular_core.Signal<boolean>;
    readonly filteredUsers: _angular_core.Signal<MentionUser[]>;
    readonly filteredTasks: _angular_core.Signal<LinkableTask[]>;
    readonly isDisabled: _angular_core.Signal<boolean>;
    readonly isEmpty: _angular_core.Signal<boolean>;
    readonly editorAriaLabel: _angular_core.Signal<string>;
    /** Rango fijo para la rejilla del selector de tablas. */
    readonly gridRange: _angular_core.Signal<number[]>;
    /** Etiquetas i18n reactivas al idioma (patrón sol-stepper). */
    readonly labels: _angular_core.Signal<{
        toolbar: string;
        bold: string;
        italic: string;
        underline: string;
        strike: string;
        heading: string;
        paragraph: string;
        heading1: string;
        heading2: string;
        heading3: string;
        bulletList: string;
        numberedList: string;
        alignLeft: string;
        alignCenter: string;
        alignRight: string;
        insertImage: string;
        insertTable: string;
        insertLink: string;
        removeLink: string;
        removeFormat: string;
        tablePicker: string;
        linkPlaceholder: string;
        linkConfirm: string;
        editorAria: string;
        imageTooLarge: string;
        mentionList: string;
        taskList: string;
    }>;
    /** Selección guardada al abrir menús que roban el foco (enlace/imagen). */
    private savedRange;
    /** Valor pendiente de aplicar al DOM (antes de que la vista esté lista). */
    private pendingValue;
    private viewReady;
    private activeUpdateHandle;
    private errorHandle;
    private onChange;
    private onTouched;
    ngAfterViewInit(): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    /** Devuelve el HTML limpio (canónico TCPDF-safe) actual. */
    getHtml(): string;
    onInput(): void;
    onBlur(): void;
    /** Navegación del popover de menciones/tareas (solo cuando está abierto). */
    onKeyDown(event: KeyboardEvent): void;
    /** Inicial en mayúscula para el avatar del popover de menciones. */
    initial(name: string): string;
    /** Recalcula el estado de la toolbar de forma diferida (tras el DOM). */
    scheduleActiveUpdate(): void;
    cmd(command: string): void;
    applyHeading(tag: 'p' | 'h1' | 'h2' | 'h3'): void;
    align(direction: 'left' | 'center' | 'right'): void;
    removeFormat(): void;
    toggleMenu(which: 'heading' | 'table' | 'link'): void;
    closeMenus(): void;
    hoverTable(rows: number, cols: number): void;
    insertTable(rows: number, cols: number): void;
    confirmLink(): void;
    removeLink(): void;
    pickImage(): void;
    onFileSelected(event: Event): void;
    private handleImageFile;
    private insertImage;
    private showImageError;
    /**
     * Analiza el texto anterior al cursor: si hay un trigger `@`/`#` activo (al
     * inicio o precedido por espacio) y su lista está habilitada, abre el popover
     * respectivo; si no, lo cierra.
     */
    private detectAutocomplete;
    /** Trigger + consulta inmediatamente antes del cursor colapsado (o null). */
    private getQueryBeforeCursor;
    /** Ubica el popover bajo el caret (cálculo manual; sin librerías de posición). */
    private positionPopover;
    closePopovers(): void;
    selectMention(event: Event | null, index: number): void;
    selectTask(event: Event | null, index: number): void;
    /**
     * Reemplaza el rango `@query`/`#query` por un chip `<span>` no editable con
     * el atributo data-* dado, y deja el cursor tras él con un espacio.
     */
    private insertChip;
    /** Marca los chips como no editables tras (re)pintar el contenido. */
    private hardenChips;
    /** IDs/keys únicos (orden de documento) de los chips presentes en el DOM. */
    private collectChipValues;
    onPaste(event: ClipboardEvent): void;
    preventSteal(event: Event): void;
    onTriggerMousedown(event: Event): void;
    private focusEditable;
    private selectionInsideEditor;
    private saveSelection;
    private restoreSelection;
    private insertNodeAtCaret;
    private insertHtmlAtCaret;
    private insertTextAtCaret;
    private exec;
    private safeExec;
    private emitChange;
    private applyPending;
    private updateActiveFormats;
    private selectedImage;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolRichEditorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolRichEditorComponent, "sol-rich-editor", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "minHeight": { "alias": "minHeight"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "imageMaxBytes": { "alias": "imageMaxBytes"; "required": false; "isSignal": true; }; "imageUpload": { "alias": "imageUpload"; "required": false; "isSignal": true; }; "mentionableUsers": { "alias": "mentionableUsers"; "required": false; "isSignal": true; }; "linkableTasks": { "alias": "linkableTasks"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "mentionsChange": "mentionsChange"; "taskLinksChange": "taskLinksChange"; }, never, never, true, never>;
}

/**
 * Cabecera de página del design system: título (H1) + subtítulo opcional a la
 * izquierda, con un slot proyectado de acciones alineadas a la derecha (p. ej.
 * un botón "Crear"). Tematizado con `var(--sol-*)` — soporta light y dark.
 *
 * Uso:
 * ```html
 * <sol-page-header title="Profesionales" subtitle="Gestiona tu equipo">
 *   <sol-button (clicked)="crear()">Crear</sol-button>
 * </sol-page-header>
 * ```
 */
declare class SolPageHeaderComponent {
    /** Título principal (H1). Obligatorio. */
    readonly title: _angular_core.InputSignal<string>;
    /** Subtítulo opcional bajo el título. */
    readonly subtitle: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolPageHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolPageHeaderComponent, "sol-page-header", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/** Estilo visual del botón de ícono, alineado con las variantes de `sol-button`. */
type SolIconButtonVariant = 'default' | 'danger' | 'ghost';
/** Tamaño (cuadrado) del botón de ícono. */
type SolIconButtonSize = 'sm' | 'md' | 'lg';
/**
 * Botón cuadrado de solo ícono, con `aria-label` obligatorio por accesibilidad.
 * El ícono sale del registry de la librería vía `sol-icon` (nunca SVG inline).
 * Tematizado con `var(--sol-*)` — soporta light y dark.
 *
 * Uso:
 * ```html
 * <sol-icon-button icon="edit" ariaLabel="Editar" (clicked)="editar()" />
 * <sol-icon-button icon="trash" variant="danger" ariaLabel="Eliminar" (clicked)="eliminar()" />
 * ```
 */
declare class SolIconButtonComponent {
    /** Ícono del registry a mostrar. Obligatorio. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Etiqueta accesible obligatoria (el botón no tiene texto visible). */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Atributo `type` nativo del botón. */
    readonly type: _angular_core.InputSignal<"button" | "submit">;
    /** Estilo visual. */
    readonly variant: _angular_core.InputSignal<SolIconButtonVariant>;
    /** Tamaño cuadrado. */
    readonly size: _angular_core.InputSignal<SolIconButtonSize>;
    /** Deshabilita el botón. */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Se emite al hacer clic cuando el botón no está deshabilitado. */
    readonly clicked: _angular_core.OutputEmitterRef<void>;
    /** Clases CSS combinando variante y tamaño. */
    readonly cssClass: _angular_core.Signal<string>;
    onClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolIconButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolIconButtonComponent, "sol-icon-button", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": true; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, never, true, never>;
}

/** Fila genérica de la tabla: un objeto plano indexable por clave. */
type SolDataTableRow = Record<string, unknown>;
/**
 * Descriptor de columna que dirige el render de `sol-data-table`.
 *
 * - `key`: ruta al valor en la fila (soporta anidamiento con puntos, `a.b.c`).
 * - `label`: encabezado visible de la columna.
 * - `sortable`: habilita el orden por esa columna al hacer clic en el th.
 * - `width`: ancho CSS opcional del th (`'120px'`, `'20%'`…).
 * - `badge`: marca la columna de estado (chip): en el modo móvil colapsado su
 *   valor se muestra como chip junto al título en la cabecera de la fila.
 * - `cellTemplate`: plantilla opcional para renderizar la celda (recibe el
 *   valor resuelto como `$implicit` y la fila completa como `row`).
 */
interface DataTableColumn {
    key: string;
    label: string;
    sortable?: boolean;
    width?: string;
    badge?: boolean;
    cellTemplate?: TemplateRef<{
        $implicit: unknown;
        row: SolDataTableRow;
    }>;
}
/**
 * Tabla de datos genérica dirigida por columnas: búsqueda, orden, paginación,
 * estado de carga (skeleton), estado vacío y acciones por fila. En viewport
 * móvil colapsa cada fila a un resumen expandible (sin scroll horizontal)
 * cuando el tema activo lo prefiere (`component.table.mobile: "collapse"`).
 *
 * Componente presentacional: no conoce dominio. Las acciones no genéricas se
 * proyectan por el slot `#rowActions` (TemplateRef que recibe la fila).
 * Tematizado con `var(--sol-*)` — soporta light y dark.
 */
declare class SolDataTableComponent {
    private readonly themeService;
    readonly data: _angular_core.InputSignal<SolDataTableRow[]>;
    readonly columns: _angular_core.InputSignal<DataTableColumn[]>;
    /**
     * Estado de carga de la fuente de datos: sustituye el cuerpo por filas
     * skeleton tokenizadas y oculta la paginación mientras esté activo.
     */
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly searchPlaceholder: _angular_core.InputSignal<string>;
    readonly emptyMessage: _angular_core.InputSignal<string>;
    readonly paginated: _angular_core.InputSignal<boolean>;
    readonly showToolbar: _angular_core.InputSignal<boolean>;
    readonly filterPosition: _angular_core.InputSignal<"right" | "left">;
    readonly showActions: _angular_core.InputSignal<boolean>;
    readonly showEditAction: _angular_core.InputSignal<boolean>;
    readonly showDeleteAction: _angular_core.InputSignal<boolean>;
    readonly trackByKey: _angular_core.InputSignal<string>;
    /** Encabezado de la columna de acciones. */
    readonly actionsLabel: _angular_core.InputSignal<string>;
    /**
     * aria-label del botón ▶ de expansión de fila en el modo móvil. El default
     * se alinea con el texto de la clave i18n `shared.table.toggleDetails`
     * para que cualquier consumidor que no lo sobreescriba (vía
     * `[toggleDetailsLabel]`) obtenga el texto correcto sin necesidad de
     * traducción explícita.
     */
    readonly toggleDetailsLabel: _angular_core.InputSignal<string>;
    /**
     * Activa la animación de entrada (`solRowReveal`, ver directiva interna
     * arriba) en cada fila/tarjeta. Default `true`: preserva el
     * comportamiento visual del widget local que este componente reemplazó
     * (PR7a/T51) sin requerir cambios en los consumidores existentes — el
     * intensity "none"/`prefers-reduced-motion` del tema ya neutraliza el
     * efecto (duración ~1ms, distancia 0) para quien no lo quiera, sin
     * necesidad de apagar este input.
     */
    readonly rowReveal: _angular_core.InputSignal<boolean>;
    readonly editClicked: _angular_core.OutputEmitterRef<SolDataTableRow>;
    readonly deleteClicked: _angular_core.OutputEmitterRef<SolDataTableRow>;
    /**
     * Plantilla de acciones por fila proyectada con `#rowActions`. Recibe la fila
     * como `$implicit`. Cuando existe, reemplaza los botones editar/eliminar por
     * defecto: aquí van las acciones específicas del dominio del consumidor.
     */
    readonly rowActionsTemplate: Signal<TemplateRef<{
        $implicit: SolDataTableRow;
    }> | undefined>;
    /**
     * Carga "estirada" a un mínimo visible (anti-flash): con un backend rápido
     * `loading` se apaga antes de que el skeleton se perciba. `loadingVisible`
     * mantiene el skeleton un instante mínimo — es lo que consume el template.
     */
    protected readonly loadingVisible: Signal<boolean>;
    readonly searchTerm: _angular_core.WritableSignal<string>;
    readonly currentPage: _angular_core.WritableSignal<number>;
    readonly pageSize: _angular_core.WritableSignal<number>;
    readonly sortKey: _angular_core.WritableSignal<string>;
    readonly sortDirection: _angular_core.WritableSignal<"desc" | "asc">;
    /**
     * Clave de replay de `solRowReveal`: cambia con cualquier búsqueda, orden
     * o paginación — reinicia la animación de entrada de las filas visibles
     * (paridad con el widget local: `solRevealReplay` sobre el mismo filtro).
     */
    readonly revealReplayKey: Signal<string>;
    /** Señal reactiva de viewport móvil (breakpoint canónico 767px). */
    readonly isMobileViewport: Signal<boolean>;
    /** Índices de las filas fantasma del estado de carga (7 filas fijas). */
    protected readonly skeletonRows: number[];
    /**
     * Token aditivo `component.table.mobile` del ThemeFile activo.
     * "collapse" (default): filas colapsables sin scroll horizontal.
     * "scroll": conserva la tabla con overflow-x. El token ajusta la
     * preferencia — NUNCA la estructura del componente.
     */
    private readonly tableMobileMode;
    /** El modo colapsado aplica solo en viewport móvil con preferencia "collapse". */
    readonly mobileCollapse: Signal<boolean>;
    /** Filas expandidas del modo colapsado (por id de trackBy). */
    readonly expandedRows: _angular_core.WritableSignal<ReadonlySet<string | number>>;
    /** Columna título de la fila colapsada = primera columna configurada. */
    readonly mobileTitleCol: Signal<DataTableColumn | undefined>;
    /** Columna del chip de estado = la marcada con `badge: true` (si existe). */
    readonly mobileBadgeCol: Signal<DataTableColumn | undefined>;
    /** Subdato = la segunda columna que no sea el chip de estado. */
    readonly mobileSubtitleCol: Signal<DataTableColumn | undefined>;
    /** Columnas ocultas en el colapso: todas menos título, subdato y chip. */
    readonly mobileDetailCols: Signal<DataTableColumn[]>;
    readonly filteredData: Signal<SolDataTableRow[]>;
    readonly pagedData: Signal<SolDataTableRow[]>;
    resolveValue(row: SolDataTableRow, key: string): unknown;
    trackId(index: number, row: SolDataTableRow): string | number;
    /** Estado de expansión de una fila en el modo móvil colapsado. */
    isRowExpanded(id: string | number): boolean;
    /** Expande/colapsa una fila del modo móvil colapsado. */
    toggleRow(id: string | number): void;
    onSearch(term: string): void;
    onSort(key: string): void;
    onPageSizeChange(size: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolDataTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolDataTableComponent, "sol-data-table", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "paginated": { "alias": "paginated"; "required": false; "isSignal": true; }; "showToolbar": { "alias": "showToolbar"; "required": false; "isSignal": true; }; "filterPosition": { "alias": "filterPosition"; "required": false; "isSignal": true; }; "showActions": { "alias": "showActions"; "required": false; "isSignal": true; }; "showEditAction": { "alias": "showEditAction"; "required": false; "isSignal": true; }; "showDeleteAction": { "alias": "showDeleteAction"; "required": false; "isSignal": true; }; "trackByKey": { "alias": "trackByKey"; "required": false; "isSignal": true; }; "actionsLabel": { "alias": "actionsLabel"; "required": false; "isSignal": true; }; "toggleDetailsLabel": { "alias": "toggleDetailsLabel"; "required": false; "isSignal": true; }; "rowReveal": { "alias": "rowReveal"; "required": false; "isSignal": true; }; }, { "editClicked": "editClicked"; "deleteClicked": "deleteClicked"; }, ["rowActionsTemplate"], ["[tableFilters]", "[tableActions]"], true, never>;
}

/**
 * Serializador HTML "limpio" para `sol-rich-editor`.
 *
 * NÚCLEO DEL VALOR: recorre el DOM del área editable (o un HTML pegado) y
 * produce HTML SEMÁNTICO CANÓNICO apto para generar PDFs con TCPDF (Laravel).
 * TCPDF tiene un parser HTML muy limitado: rompe con `<div>`/`<span>` con
 * estilos inline arbitrarios, clases desconocidas y —sobre todo— tablas
 * anidadas. Este serializador garantiza una salida acotada y predecible.
 *
 * ── Allowlist de TAGS de salida ──────────────────────────────────────────
 *   Bloque:  <p> <h1> <h2> <h3> <ul> <ol> <li> <table><tbody><tr><td> <br>
 *   Inline:  <strong> <em> <u> <s> <a> <img>
 *   Chip:    <span data-mention-id="…"> / <span data-task-key="…">  (OPT-IN)
 *   Nada más. Todo lo demás se desanida (unwrap), se convierte o se descarta.
 *
 * ── Chips de mención (@) y enlace de tarea (#) — OPT-IN ───────────────────
 *   Un `<span>` se PRESERVA en la salida SOLO si porta `data-mention-id` o
 *   `data-task-key`. En ese caso se emite un span canónico con EXACTAMENTE ese
 *   único atributo data-* (valor escapado) y su texto; cualquier otro atributo
 *   del span de entrada (class, style, on*, contenteditable, href…) se DESCARTA
 *   —no hay passthrough—. Un `<span>` normal (sin data de chip) se desanida
 *   como siempre. Esto no abre XSS: solo el atributo data-* controlado y el
 *   texto escapado sobreviven; el span nunca lleva estilos ni handlers.
 *
 * ── Conversión de tags de entrada ────────────────────────────────────────
 *   <b>/<strong>       → <strong>
 *   <i>/<em>           → <em>
 *   <u>/<ins>          → <u>
 *   <s>/<strike>/<del> → <s>
 *   <div>              → <p>   (o se desanida si contiene bloques)
 *   <h4..h6>           → <h3>  (se acota la jerarquía)
 *   <span>/<font>      → se desanida; sus estilos (negrita/cursiva/subrayado/
 *                        tachado) se traducen a los tags semánticos anteriores.
 *   <thead>/<tbody>/<tfoot> → se aplanan dentro de <tbody>.
 *
 * ── Allowlist de PROPIEDADES CSS de ENTRADA ──────────────────────────────
 *   Solo se INSPECCIONAN estas cuatro; el resto de estilos inline se descarta:
 *     - font-weight       → se convierte a <strong>
 *     - font-style        → se convierte a <em>
 *     - text-decoration   → se convierte a <u> y/o <s>
 *     - text-align        → se conserva como style="text-align:…" en el bloque
 *   IMPORTANTE: los estilos NO se copian tal cual a la salida. El serializador
 *   DESCARTA todos los estilos de entrada y RE-GENERA solo los canónicos que
 *   él controla:
 *     - `style="text-align:center|right|justify"` en bloques (p/h1-3/celda)
 *     - `style="display:block;margin:0 auto"` en imágenes centradas
 *   Por eso el `style` de las imágenes centradas no viola la allowlist: no es
 *   un passthrough del usuario, es salida canónica autogenerada.
 *
 * ── Tablas anidadas ──────────────────────────────────────────────────────
 *   TCPDF rompe con tablas dentro de celdas. Cuando una <table> aparece dentro
 *   de una celda, se APLANA: sus celdas se serializan como texto inline
 *   separado por <br> dentro de la celda contenedora (nunca se emiten tags de
 *   tabla anidados). Igual criterio para bloques/listas dentro de celdas: se
 *   convierten a inline + <br> para mantener las celdas TCPDF-safe.
 *
 * ── Seguridad (anti-XSS) ─────────────────────────────────────────────────
 *   `sanitizeHtmlToTcpdf` parsea el HTML no confiable con DOMParser (documento
 *   INERTE: no ejecuta scripts, no dispara handlers, no carga recursos) y luego
 *   serializa por allowlist. `<script>`, `<style>`, `<iframe>`, handlers `on*`,
 *   `href="javascript:"` y `src` no permitidos se descartan.
 */
/**
 * Tags permitidos en la salida (para documentación/validación externa).
 * `span` SOLO se emite para chips de mención/tarea (`data-mention-id` /
 * `data-task-key`); un `<span>` normal se sigue desanidando.
 */
declare const TCPDF_ALLOWED_TAGS: readonly ["p", "h1", "h2", "h3", "strong", "em", "u", "s", "ul", "ol", "li", "table", "tbody", "tr", "td", "a", "img", "br", "span"];
/**
 * Propiedades CSS de ENTRADA que el serializador inspecciona. `text-align` se
 * conserva como estilo canónico en bloques; las otras tres se traducen a tags
 * semánticos (no se emiten como `style`).
 */
declare const TCPDF_ALLOWED_STYLE_PROPERTIES: readonly ["text-align", "font-weight", "font-style", "text-decoration"];
/**
 * Serializa el contenido de un elemento (típicamente el `contenteditable`) a
 * HTML canónico TCPDF-safe. Función PURA: no muta el DOM recibido.
 */
declare function serializeElementToTcpdfHtml(root: HTMLElement): string;
/**
 * Sanea un HTML NO CONFIABLE (pegado, o valor externo del formulario) a HTML
 * canónico TCPDF-safe. Parsea con DOMParser (documento inerte: sin ejecución
 * de scripts ni carga de recursos) y aplica la allowlist. Devuelve '' si no hay
 * DOMParser disponible (p. ej. SSR).
 */
declare function sanitizeHtmlToTcpdf(rawHtml: string): string;

type SolAvatarSize = 'sm' | 'md' | 'lg';
/**
 * Hash determinista (multiplicador 31, estilo `String.hashCode` de Java) de
 * una semilla a un índice `[0, paletteSize)`. PURA: sin `Date`/`Math.random`/
 * estado — la misma semilla SIEMPRE produce el mismo índice, en cualquier
 * instancia y en cualquier momento (spec: solercia-ui-vocero-atoms#color
 * estable entre instancias).
 *
 * Tolera `null`/`undefined` (índice 0/neutral) sin lanzar: `input.required()`
 * de Angular solo exige que el BINDING exista en el template — no que el
 * valor resuelto sea no-nulo en runtime. Un `[name]="entidad.nombre"` mientras
 * la data todavía carga pasa `undefined` sin que Angular lo bloquee (NG0950
 * solo dispara si el binding falta por completo, no si resuelve a `undefined`).
 */
declare function hashToPaletteIndex(seed: string | null | undefined, paletteSize?: number): number;
/**
 * Iniciales a partir de un nombre: nombre compuesto → primera letra de la
 * primera y de la última palabra ("Ana Torres" → "AT"); una sola palabra →
 * sus 2 primeras letras; vacío/solo espacios → cadena vacía; `null`/
 * `undefined` (mismo motivo que `hashToPaletteIndex` arriba) → `'?'` como
 * placeholder visual explícito. PURA.
 *
 * Segmenta por CODE POINT (`[...palabra]`), no por UTF-16 code unit
 * (`charAt`/índice numérico): un nombre que empieza con un carácter fuera
 * del BMP (la mayoría de emoji) ocupa 2 code units — `charAt(0)` corta el
 * primero suelto y produce U+FFFD (replacement character) en vez de la
 * inicial completa.
 */
declare function computeInitials(name: string | null | undefined): string;
/**
 * `sol-avatar` — iniciales + color de fondo estable por hash del `name`,
 * elegido entre una paleta fija de 8 tonos desaturados (spec:
 * solercia-ui-vocero-atoms). Sin conocimiento de dominio: recibe un `name`
 * genérico (persona, empresa, lo que sea) — nunca un modelo de negocio.
 *
 * Sin texto que traducir: las iniciales se derivan del propio `name` (dato
 * del consumidor, no copia de UI), así que no hay i18n que resolver aquí.
 */
declare class SolAvatarComponent {
    /**
     * Nombre o identificador de entrada — determina iniciales y color.
     * Tipado `string | null | undefined` a propósito: `input.required()` exige
     * que el BINDING exista en el template, no que su valor ya esté resuelto
     * (p. ej. `[name]="entidad.nombre"` mientras `entidad` todavía carga).
     */
    readonly name: _angular_core.InputSignal<string | null | undefined>;
    /** URL de imagen opcional; si se da, reemplaza las iniciales. */
    readonly imageUrl: _angular_core.InputSignal<string | null>;
    readonly size: _angular_core.InputSignal<SolAvatarSize>;
    readonly initials: _angular_core.Signal<string>;
    readonly paletteIndex: _angular_core.Signal<number>;
    readonly hostClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolAvatarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolAvatarComponent, "sol-avatar", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "imageUrl": { "alias": "imageUrl"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Tono semántico compartido por los átomos de vocero (`sol-score-badge`,
 * `sol-trend`) y cualquier otro componente que necesite un color por
 * significado en vez de por valor concreto. Único lugar donde se define —
 * antes vivía duplicado (declaración propia en `score-badge` + mapa de
 * color repetido en `trend`), violando SRP y arriesgando que un tono nuevo
 * se agregue en un componente y se olvide en el otro.
 */
type SolTone = 'success' | 'warning' | 'danger' | 'info' | 'neutral';

/** Umbral ascendente: `upTo` es el límite EXCLUSIVO superior de `tone`. */
interface SolScoreThreshold {
    upTo: number;
    tone: SolTone;
}
/** Default del spec: éxito ≥80, advertencia ≥50, peligro <50. */
declare const DEFAULT_SCORE_THRESHOLDS: readonly SolScoreThreshold[];
/**
 * Resuelve el tono de `score` contra `thresholds` (ordenados ascendente por
 * `upTo`): el primero cuyo `upTo` sea mayor que `score` gana; si ninguno lo
 * es, se usa el tono del último umbral. PURA — sin dependencias de Angular.
 */
declare function resolveScoreTone(score: number, thresholds: readonly SolScoreThreshold[]): SolTone;
/**
 * `sol-score-badge` — puntaje numérico con tono resuelto contra umbrales
 * configurables (spec: solercia-ui-vocero-atoms). Genérico: no sabe si el
 * puntaje viene de un lead, una corrida del laboratorio o cualquier otra
 * métrica — eso lo decide el consumidor vía `[value]`/`[thresholds]`.
 *
 * Estados especiales:
 *   - `pending=true` ("en curso"): la métrica aún se está calculando.
 *   - `value=null` ("sin dato"): no hay puntaje disponible todavía.
 * Ambos usan el tono neutral y un texto por clave i18n en vez del número.
 */
declare class SolScoreBadgeComponent {
    private readonly i18n;
    /** Puntaje a mostrar; `null` = sin dato todavía. */
    readonly value: _angular_core.InputSignal<number | null>;
    /** Escala del puntaje (default 100). Los umbrales siempre se evalúan en escala 0-100. */
    readonly max: _angular_core.InputSignal<number>;
    readonly thresholds: _angular_core.InputSignal<readonly SolScoreThreshold[]>;
    /** `true` mientras la métrica se está calculando (p. ej. corrida del laboratorio en curso). */
    readonly pending: _angular_core.InputSignal<boolean>;
    /**
     * `true` cuando no hay puntaje utilizable: `value=null` (sin dato todavía)
     * O `value` es `NaN` (p. ej. una división 0/0 corriente arriba, o un
     * `parseFloat` fallido). Sin esta guarda, `NaN < umbral` es SIEMPRE `false`
     * y `resolveScoreTone` cae al último tono ("éxito") mostrando una insignia
     * verde con el texto literal "NaN".
     */
    private readonly hasNoData;
    /** Puntaje normalizado a 0-100 para evaluar contra los umbrales (el texto mostrado usa el valor crudo). */
    private readonly normalizedValue;
    readonly tone: _angular_core.Signal<SolTone>;
    readonly displayText: _angular_core.Signal<string>;
    readonly hostStyles: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolScoreBadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolScoreBadgeComponent, "sol-score-badge", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "thresholds": { "alias": "thresholds"; "required": false; "isSignal": true; }; "pending": { "alias": "pending"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SolTrendDirection = 'up' | 'down' | 'flat';
/** PURA: signo del delta determina la dirección. `0` siempre es `'flat'`. */
declare function resolveTrendDirection(delta: number): SolTrendDirection;
/** Formato por defecto: signo explícito (`+5`, `-15`, `0`). PURA. */
declare function defaultTrendFormat(delta: number): string;
/**
 * `sol-trend` — delta con flecha (↑/↓/plano) y signo, comparando `current`
 * contra `previous` (spec: solercia-ui-vocero-atoms). Genérico: no sabe si
 * mide un score, ingresos o cualquier otra métrica.
 */
declare class SolTrendComponent {
    private readonly i18n;
    /** Valor actual de la métrica. */
    readonly current: _angular_core.InputSignal<number>;
    /** Valor previo a comparar; `null` = sin comparación disponible todavía. */
    readonly previous: _angular_core.InputSignal<number | null>;
    /** `true` invierte la semántica de color: subir es malo (p. ej. tasa de abandono). */
    readonly invert: _angular_core.InputSignal<boolean>;
    /** Formateador opcional del delta (p. ej. agregar "%"). Default: signo explícito. */
    readonly format: _angular_core.InputSignal<(delta: number) => string>;
    /**
     * `null` = "sin dato" (sin `previous` AÚN, o el delta resultó `NaN` — p. ej.
     * `current`/`previous` no numéricos corriente arriba). Sin esta guarda,
     * `resolveTrendDirection(NaN)` cae a `'flat'` mostrando el texto literal
     * "NaN" en vez del estado de "sin dato".
     */
    readonly delta: _angular_core.Signal<number | null>;
    readonly direction: _angular_core.Signal<SolTrendDirection>;
    readonly tone: _angular_core.Signal<SolTone>;
    readonly toneColor: _angular_core.Signal<string>;
    readonly iconName: _angular_core.Signal<string | null>;
    readonly displayText: _angular_core.Signal<string>;
    readonly ariaLabel: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolTrendComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolTrendComponent, "sol-trend", never, { "current": { "alias": "current"; "required": true; "isSignal": true; }; "previous": { "alias": "previous"; "required": false; "isSignal": true; }; "invert": { "alias": "invert"; "required": false; "isSignal": true; }; "format": { "alias": "format"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SolMessageStatus = 'pending' | 'sent' | 'delivered' | 'read' | 'failed';
/**
 * `sol-message-status` — ticks de estado de un mensaje (spec:
 * solercia-ui-vocero-atoms), inspirado en el patrón de WhatsApp. Genérico:
 * no sabe qué es un "mensaje" de dominio, solo un estado de entrega.
 *
 * `read` reutiliza el MISMO ícono `double-check` que `delivered` — la
 * diferencia visual es el color (token de marca `--sol-color-primary`),
 * igual que WhatsApp distingue el doble-check gris del azul.
 */
declare class SolMessageStatusComponent {
    private readonly i18n;
    readonly status: _angular_core.InputSignal<SolMessageStatus>;
    readonly iconName: _angular_core.Signal<string>;
    readonly color: _angular_core.Signal<string>;
    readonly statusLabel: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolMessageStatusComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolMessageStatusComponent, "sol-message-status", never, { "status": { "alias": "status"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Nodo genérico y recursivo del timeline jerárquico (spec:
 * solercia-ui-timeline#Modelo genérico jerárquico). Sin conocimiento de
 * dominio: NUNCA referencia `epic`/`sprint`/`historia de usuario` — el
 * consumidor mapea su propio modelo a este contrato.
 *
 * `label`/`labelKey` son mutuamente alternativos: `label` para texto crudo
 * (dato del consumidor, p. ej. el nombre de un proyecto — no es copy de UI),
 * `labelKey` para una clave i18n cuando la etiqueta SÍ es texto genérico de
 * UI. Si ninguno se da, la fila se renderiza sin etiqueta (cadena vacía).
 */
interface TimelineNode {
    id: string | number;
    label?: string;
    labelKey?: string;
    /** Tolera `string`/`Date`/`null`/`undefined`; una fecha inválida se trata como ausente. */
    start?: string | Date | null;
    end?: string | Date | null;
    /** Estado genérico → color vía `statusToken` (default: `ui/tone/sol-tone.ts`). */
    status?: string;
    children?: TimelineNode[];
    /**
     * Estado INICIAL de colapso al montar. El componente lo copia a un estado
     * interno propio (patrón "espejo", igual que `sol-kanban-board`) — clics
     * posteriores NO mutan este objeto de entrada.
     */
    collapsed?: boolean;
}
/** Entrada de leyenda: `status` (el mismo valor que trae `TimelineNode.status`) + clave i18n del texto. */
interface TimelineLegendItem {
    status: string;
    labelKey: string;
}
/** Resuelve un `status` genérico a un color CSS (`var(--sol-color-*)` u otro). */
type SolTimelineStatusResolver = (status: string | undefined) => string;
/** Rango de fechas en epoch-ms (inclusivo), usado por el motor de posicionamiento. */
interface SolTimelineRange {
    start: number;
    end: number;
}

interface PositionedTimelineRow {
    node: TimelineNode;
    depth: number;
    leftPct: number;
    widthPct: number;
}
/**
 * Rango global del timeline: `min(start)/max(end)` de {@link resolveNodeRange}
 * sobre cada nodo RAÍZ de `nodes` — MISMO criterio que posiciona la barra de
 * cada nodo individual (ver el comentario de `resolveNodeRange`). `null` si
 * ninguna raíz tiene un rango resoluble.
 */
declare function computeGlobalRange(nodes: TimelineNode[] | null | undefined): SolTimelineRange | null;
/**
 * Aplana `nodes` a filas posicionadas (`leftPct`/`widthPct` como % de
 * `range`), recorriendo hasta N niveles. Un nodo (y todo su subárbol) SIN
 * fecha resoluble se omite aquí — se maneja aparte, ver
 * {@link collectUndatedNodes} (spec: sección "sin fechas", igual que
 * `sprint-timeline` hoy). Los hijos de un nodo colapsado (según
 * `options.isCollapsed`, o `node.collapsed` por defecto) no se incluyen.
 *
 * `leftPct`/`widthPct` se CLAMPEAN a `[0,100]` como red defensiva adicional
 * (aunque `resolveNodeRange`/`computeGlobalRange` ya comparten criterio y no
 * deberían producir valores fuera de rango).
 *
 * `options.visited` protege contra CICLOS en la propia estructura del árbol
 * (`node.children` recorrido aquí directamente, independiente de la guarda
 * interna de `resolveNodeRange`): un nodo ya visitado en esta llamada se
 * omite en vez de recursar sin fin.
 */
declare function positionRows(nodes: TimelineNode[] | null | undefined, range: SolTimelineRange, options?: {
    depth?: number;
    isCollapsed?: (node: TimelineNode) => boolean;
    visited?: WeakSet<TimelineNode>;
}): PositionedTimelineRow[];
/**
 * Recorre `nodes` y devuelve, en una lista PLANA (sin jerarquía — igual que
 * `sprint-timeline` hoy), todo nodo cuyo subárbol completo no tenga ninguna
 * fecha resoluble. Un nodo con fecha propia o con AL MENOS un descendiente
 * con fecha no entra aquí (se posiciona vía {@link positionRows}).
 * `visited` protege contra ciclos, igual que en `positionRows`.
 */
declare function collectUndatedNodes(nodes: TimelineNode[] | null | undefined, visited?: WeakSet<TimelineNode>): TimelineNode[];
interface SolTimelineAxisTick {
    leftPct: number;
    year: number;
    month: number;
}
/**
 * Marcas del eje temporal (un tick por mes dentro de `range`, más el límite
 * final). PURA y AGNÓSTICA de i18n a propósito: devuelve `{year, month}`
 * crudos — el componente resuelve el nombre del mes por clave i18n (spec:
 * eje temporal en español, cero texto hardcodeado).
 *
 * DEDUPLICA el tick final contra el último generado por el bucle: si `end`
 * cae EXACTO en el 1º de un mes, el bucle ya agrega ese tick en `leftPct=100`
 * — sumar el tick de cierre de nuevo produciría dos entradas idénticas
 * (misma posición, mismo mes) y rompería el `@for track` del componente
 * (`NG0955`, clave de tracking duplicada).
 */
declare function computeMonthAxisTicks(range: SolTimelineRange): SolTimelineAxisTick[];
/**
 * Resolución de color por defecto cuando el consumidor no da `statusToken`:
 * normaliza `status` (minúsculas, sin espacios) contra un mapa reducido de
 * estados comunes → `SolTone`; cualquier estado no reconocido cae a
 * `'neutral'`. Reutiliza `ui/tone/sol-tone.ts` (mismo mapa que
 * `sol-score-badge`/`sol-trend`) en vez de inventar colores nuevos.
 *
 * `typeof status === 'string'` ANTES de `.trim()` (no solo `status?.`):
 * un `status` no-string (dato malformado o de un futuro esquema numérico)
 * pasaría el chequeo de nulidad de `?.` pero `.trim` no existe en un
 * `number` — mismo bug de forma que el `name` de `sol-avatar` en el PR3.
 */
declare const defaultStatusToken: SolTimelineStatusResolver;

/**
 * `sol-timeline` — timeline jerárquico N-niveles, genérico y sin
 * dependencias externas (spec: solercia-ui-timeline, design.md D5).
 * Generaliza el motor `%` de `sprint-timeline` de `gestion_proyectos`;
 * NUNCA conoce `epic`/`sprint`/`historia de usuario` — el consumidor mapea
 * su dominio al contrato `TimelineNode`.
 *
 * Colapso/expansión: "espejo" propio (mismo patrón que `sol-kanban-board`),
 * sembrado desde `node.collapsed` de la entrada y actualizado por clic —
 * NUNCA muta los objetos de entrada. Emite `nodeToggled` para que el
 * consumidor persista el estado si lo necesita.
 *
 * Robustez de entrada (lección del PR3): `nodes` tolera `null`/`undefined`
 * (Angular no garantiza que un `input.required()` resuelva a un valor
 * no-nulo en runtime) y cada nodo tolera fechas inválidas/ausentes — ver
 * `timeline-position.ts`.
 */
declare class SolTimelineComponent {
    private readonly i18n;
    /**
     * Nodos raíz del timeline. Tipado `TimelineNode[] | null | undefined` a
     * propósito: `input.required()` exige que el BINDING exista, no que su
     * valor ya esté resuelto (lección del PR3 — `sol-avatar`).
     */
    readonly nodes: _angular_core.InputSignal<TimelineNode[] | null | undefined>;
    /** Resuelve `status` → color CSS. Default: `ui/tone/sol-tone.ts` (mismo mapa que score-badge/trend). */
    readonly statusToken: _angular_core.InputSignal<SolTimelineStatusResolver | null>;
    readonly legend: _angular_core.InputSignal<TimelineLegendItem[]>;
    /** `false` deshabilita por completo el control de colapso (todo se renderiza expandido). */
    readonly collapsible: _angular_core.InputSignal<boolean>;
    readonly nodeToggled: _angular_core.OutputEmitterRef<{
        id: string | number;
        collapsed: boolean;
    }>;
    readonly nodeClicked: _angular_core.OutputEmitterRef<TimelineNode>;
    /** Espejo interno del colapso — sembrado desde `node.collapsed`, nunca muta la entrada. */
    private readonly collapsedIds;
    /**
     * Siembra `collapsedIds` SOLO la primera vez que `nodes()` tiene contenido
     * REAL (`length > 0`) — no basta con que el `effect` haya corrido una vez.
     * Distinto del patrón "espejo" de `sol-kanban-board`: ahí el re-siembro en
     * CADA cambio de `columns` es un rollback DELIBERADO (el consumidor
     * reasigna el input para deshacer un drag fallido). Aquí NO —
     * `TimelineNode.collapsed` es explícitamente el estado INICIAL al montar
     * (ver `timeline.model.ts`); reasignar `nodes` después (p. ej. porque
     * llegó una actualización del backend) NUNCA debe descartar lo que el
     * usuario ya colapsó/expandió con clics.
     *
     * CORRECCIÓN (bug introducido por el fix anterior): marcar "ya sembrado"
     * en la PRIMERA corrida del effect, sin mirar si `nodes()` traía datos,
     * rompía el caso `[nodes]="stream$ | async"` — el patrón asíncrono que
     * este mismo componente documenta arriba y habilita con
     * `input.required<TimelineNode[] | null | undefined>()`. Si la primera
     * emisión es `null`/`undefined`/`[]` (mientras la data carga), el
     * sembrado se marcaba completo SIN sembrar nada; cuando llegaban los
     * datos reales con `node.collapsed=true`, ya no se sembraban — los nodos
     * que debían iniciar colapsados se renderizaban expandidos. La condición
     * correcta es `!hasSeededCollapse && nodes()?.length` (con contenido
     * real), no solo `!hasSeededCollapse`.
     */
    private hasSeededCollapse;
    constructor();
    readonly hasAnyNodes: _angular_core.Signal<boolean>;
    private readonly globalRange;
    readonly rows: _angular_core.Signal<PositionedTimelineRow[]>;
    readonly undatedNodes: _angular_core.Signal<TimelineNode[]>;
    private readonly monthLabels;
    readonly axisLabels: _angular_core.Signal<{
        leftPct: number;
        label: string;
    }[]>;
    readonly emptyLabel: _angular_core.Signal<string>;
    readonly undatedTitle: _angular_core.Signal<string>;
    readonly expandLabel: _angular_core.Signal<string>;
    readonly collapseLabel: _angular_core.Signal<string>;
    labelOf(node: TimelineNode): string;
    legendLabel(item: TimelineLegendItem): string;
    colorOf(node: TimelineNode): string;
    resolveColor(status: string | undefined): string;
    isCollapsedRow(node: TimelineNode): boolean;
    toggle(node: TimelineNode): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolTimelineComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolTimelineComponent, "sol-timeline", never, { "nodes": { "alias": "nodes"; "required": true; "isSignal": true; }; "statusToken": { "alias": "statusToken"; "required": false; "isSignal": true; }; "legend": { "alias": "legend"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; }, { "nodeToggled": "nodeToggled"; "nodeClicked": "nodeClicked"; }, never, never, true, never>;
}

/**
 * Contrato genérico de `sol-kanban-*` (spec: solercia-ui-kanban). Sin
 * conocimiento de dominio: NUNCA referencia `Task`/`Sprint`/`Lead` — el
 * consumidor extiende `KanbanItem` con su propio modelo y proyecta su propio
 * contenido de tarjeta vía `cardTemplate`.
 */
/** Marcador mínimo: cualquier item necesita un `id` estable para `track`. */
interface KanbanItem {
    id: string | number;
}
/**
 * Columna genérica. `title`/`titleKey` son mutuamente alternativos (mismo
 * patrón que `TimelineNode` del PR4): `title` para texto crudo del
 * consumidor, `titleKey` para una clave i18n cuando el título es texto
 * genérico de UI.
 *
 * `terminalAnchor` marca la columna como ancla terminal (patrón
 * ganada/perdida) SIN que la librería conozca su significado de negocio —
 * el consumidor decide el ícono/etiqueta vía `anchorTemplate` proyectado en
 * `sol-kanban-column`.
 */
interface KanbanColumn<T extends KanbanItem = KanbanItem> {
    id: string;
    title?: string;
    titleKey?: string;
    items: T[];
    /** Color/token CSS del header y del ancla (p. ej. `var(--sol-color-success)`). Default: tono neutral. */
    accent?: string;
    droppable?: boolean;
    terminalAnchor?: boolean;
}
/**
 * Emitido al soltar una tarjeta arrastrada (cableado real en el PR5b —
 * `@angular/cdk/drag-drop`). Nombres de campo alineados con el spec
 * (`previousIndex`/`currentIndex`, igual que `CdkDragDrop` de CDK).
 */
interface KanbanItemMoved<T extends KanbanItem = KanbanItem> {
    item: T;
    fromColumnId: string;
    toColumnId: string;
    previousIndex: number;
    currentIndex: number;
}
/** Acción genérica sobre una columna (p. ej. `{columnId, action: 'add'}`) — el string de `action` lo define el consumidor. */
interface KanbanColumnAction {
    columnId: string;
    action: string;
}
/**
 * Acción reservada del botón "+ Agregar" que `sol-kanban-column` emite y
 * `sol-kanban-board` reconoce para derivar `addRequested`. Constante
 * compartida (no un literal `'add'` repetido en 2 archivos) — un renombre
 * futuro no puede romper `addRequested` en silencio si un solo lado se
 * actualiza.
 */
declare const KANBAN_ADD_ACTION = "add";

/** Contexto del `ng-template` de tarjeta: `let-item` (`$implicit`) o `let-item="item"`. */
interface KanbanCardTemplateContext<T extends KanbanItem> {
    $implicit: T;
    item: T;
}
/**
 * `sol-kanban-card` — contenedor presentacional de un item; el CONTENIDO va
 * por `cardTemplate` proyectado (spec: solercia-ui-kanban#Estructura
 * genérica sin conocimiento de dominio).
 *
 * `cdkDrag` vía `hostDirectives` (PR5b, D1/T38): el HOST de la tarjeta se
 * vuelve arrastrable SIN que ningún consumidor escriba `cdkDrag` jamás — la
 * directiva se adopta internamente (`hostDirectives: [CdkDrag]`, forma
 * "desnuda" que NO reexpone ningún input/output de CDK hacia consumidores de
 * `<sol-kanban-card>`) y se cablea imperativamente (`data`, `previewClass`)
 * inyectando la instancia (`inject(CdkDrag, { host: true })`). Cualquier
 * archivo dentro de `ui/kanban/` puede importar `@angular/cdk/drag-drop`
 * (gate ESLint T40 exime el directorio completo, no un archivo puntual —
 * `kanban-board.component.ts` también importa `CdkDropListGroup`).
 *
 * A11y — CORRECCIÓN 4R (PR5b): `cdkDrag` de `@angular/cdk` 22.0.5 SOLO
 * registra listeners de `mousedown`/`touchstart`/`dragstart` — CERO soporte
 * de teclado (`keydown`). El comentario original de esta clase afirmaba lo
 * contrario; era falso y dejaba el tablero INOPERABLE para un usuario sin
 * mouse/touch (el drag es la única forma de mover una tarjeta). Por eso
 * `sol-kanban-column` ofrece un mecanismo alternativo 100% accesible por
 * teclado (un `<select>` nativo por tarjeta: "subir"/"bajar"/"mover a
 * columna X") que invoca el MISMO `KanbanReorderService` y emite el MISMO
 * `itemMoved` que el drag — ver `kanban-column.component.ts`. No se
 * reimplementa el drag por teclado de CDK (complejo y frágil); se da
 * paridad FUNCIONAL por una vía distinta.
 */
declare class SolKanbanCardComponent<T extends KanbanItem = KanbanItem> {
    private readonly cdkDrag;
    /** El item de dominio del consumidor — genérico, la librería nunca lo interpreta. */
    readonly item: _angular_core.InputSignal<T>;
    /** Template proyectado que renderiza el CONTENIDO de la tarjeta. */
    readonly cardTemplate: _angular_core.InputSignal<TemplateRef<KanbanCardTemplateContext<T>>>;
    /**
     * `true` mientras esta tarjeta está siendo arrastrada, `false` al soltar
     * (corrección 4R WARNING, PR5b): `sol-kanban-board` necesita saber si hay
     * ALGÚN drag activo en el tablero para POSPONER el re-seed del espejo
     * (D4) — reasignar `columns()` mientras CDK arrastra el nodo DOM de esta
     * misma tarjeta podría destruirlo/recrearlo (`@for`) y corromper el
     * gesto. Se bubblea vía `sol-kanban-column` hasta el board.
     */
    readonly dragActiveChanged: _angular_core.OutputEmitterRef<boolean>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolKanbanCardComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolKanbanCardComponent<any>, "sol-kanban-card", never, { "item": { "alias": "item"; "required": true; "isSignal": true; }; "cardTemplate": { "alias": "cardTemplate"; "required": true; "isSignal": true; }; }, { "dragActiveChanged": "dragActiveChanged"; }, never, never, true, [{ directive: typeof i1.CdkDrag; inputs: {}; outputs: {}; }]>;
}

/**
 * Evento de drop CRUDO — SIN tipos de `@angular/cdk/drag-drop` — que
 * `sol-kanban-column` emite hacia `sol-kanban-board` tras extraer los campos
 * relevantes de un `CdkDragDrop` real (spec: solercia-ui-kanban#Arrastrar y
 * soltar encapsulado — "NO DEBE filtrar tipos de CDK en su API pública"). El
 * único archivo que conoce `CdkDragDrop` es `kanban-column.component.ts`
 * (dentro de `ui/kanban/`, autorizado por el gate T40); este tipo y el
 * servicio de abajo son CDK-free por diseño, testeables sin DOM.
 */
interface KanbanRawDropEvent {
    fromColumnId: string;
    toColumnId: string;
    previousIndex: number;
    currentIndex: number;
}
/** Resultado de aplicar un `KanbanRawDropEvent`: columnas con NUEVA referencia + el evento público a emitir. */
interface KanbanReorderResult<T extends KanbanItem = KanbanItem> {
    columns: KanbanColumn<T>[];
    moved: KanbanItemMoved<T>;
}
/**
 * `KanbanReorderService` — transforma `(columns, KanbanRawDropEvent)` en un
 * nuevo arreglo de columnas + el `KanbanItemMoved` a emitir (spec: D4 del
 * design — "la transformación `CdkDragDrop → KanbanItemMoved` se extrae a
 * `KanbanReorderService` PURO, sin DOM, testeable en aislamiento").
 *
 * Cubre los 2 escenarios obligatorios del spec:
 * - mover una tarjeta ENTRE columnas (`fromColumnId !== toColumnId`)
 * - reordenar DENTRO de la misma columna (`fromColumnId === toColumnId`)
 *
 * NO muta los arreglos de entrada: siempre devuelve columnas/arreglos NUEVOS
 * (spread), para que el componente pueda hacer `mirroredColumns.set(...)`
 * con una referencia distinta y disparar la reactividad de signals.
 *
 * Optimista + rollback (D4): este servicio NO persiste nada — el consumidor
 * de `sol-kanban-board` recibe `itemMoved`, hace su PATCH y, si falla,
 * reasigna `[columns]` a la referencia PREVIA; el `effect` del board
 * (D4, siempre re-siembra el espejo) recompone el espejo desde esa
 * referencia anterior = rollback automático. A diferencia de `sol-timeline`
 * (donde re-sembrar en cada cambio era el BUG, PR4), en `sol-kanban` es el
 * comportamiento CORRECTO desde PR5a: es precisamente lo que permite este
 * rollback sin lógica adicional en el board.
 *
 * Robustez (lecciones PR3/PR4/PR5a): columnas ausentes/vacías, columna
 * origen/destino inexistente, índice fuera de rango o item ausente en el
 * índice indicado → devuelve `null` (no-op); el llamador simplemente ignora
 * un resultado `null` sin romper el tablero.
 */
declare class KanbanReorderService {
    reorder<T extends KanbanItem>(columns: readonly KanbanColumn<T>[] | null | undefined, event: KanbanRawDropEvent | null | undefined): KanbanReorderResult<T> | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KanbanReorderService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<KanbanReorderService>;
}

/**
 * `sol-kanban-board` — orquestador de columnas (spec: solercia-ui-kanban).
 * Sin conocimiento de dominio: recibe `columns` genéricas + `cardTemplate`
 * proyectado — nunca referencia `Task`/`Sprint`/`Lead`.
 *
 * Espejo interno (`signal` + `effect`, D4 del design): mantiene una copia
 * propia de `columns()`, re-sembrada en CADA cambio del input — a
 * diferencia de `sol-timeline` (donde re-sembrar en cada cambio era un bug
 * de UX), aquí es el comportamiento CORRECTO: el espejo debe reflejar
 * SIEMPRE la última verdad del input, no un estado "sembrado una vez".
 *
 * DnD (PR5b, D1/D4/T38): `cdkDropListGroup` en el contenedor conecta
 * automáticamente los `cdkDropList` de TODAS las columnas hijas (sin
 * `[cdkDropListConnectedTo]` manual). Cada columna reenvía su drop ya
 * traducido a `KanbanRawDropEvent` (CDK-free) vía `(itemDropped)`; el board
 * delega en `KanbanReorderService` (puro) para calcular el nuevo arreglo de
 * columnas + el `KanbanItemMoved` a emitir, y aplica el resultado SOLO sobre
 * el espejo (`mirroredColumns.set(...)`) — NUNCA sobre `columns()` (el
 * input, que sigue siendo propiedad del consumidor).
 *
 * Optimista + rollback (D4): el board NO persiste nada. El consumidor de
 * `itemMoved` hace su PATCH optimista y, si falla, DEBE llamar `rollback()`
 * para restaurar el espejo desde el `columns()` actual del input.
 *
 * CORRECCIÓN 4R (WARNING): el `effect` de abajo re-siembra el espejo cuando
 * `columns()` CAMBIA — pero los signal inputs comparan por `Object.is`, así
 * que reasignar la MISMA referencia (p. ej. la que el consumidor ya tenía
 * antes del drop) NO dispara nada: el rollback fallaría en silencio. Por
 * eso `rollback()` NO depende del juego de referencias — fuerza el re-seed
 * leyendo `columns()` directamente, sin pasar por la comparación del
 * signal. El consumidor puede además reasignar una referencia NUEVA (un
 * clon) para lograr el mismo efecto vía el `effect` normal, pero `rollback()`
 * es el mecanismo recomendado y documentado.
 *
 * CORRECCIÓN 4R (WARNING — reseed durante un drag activo): si el consumidor
 * reasigna `columns()` (refresh en vivo) MIENTRAS el usuario arrastra una
 * tarjeta, re-sembrar el espejo de inmediato destruiría/recrearía el nodo
 * DOM que CDK tiene tomado (`@for`), corrompiendo el gesto. Por eso el
 * `effect` de abajo POSPONE el re-seed si `isDragging()` es `true`
 * (guardado en `pendingColumnsSeed`, sin tocar `mirroredColumns` todavía) y
 * lo aplica recién cuando el drag TERMINA (`onCardDragActiveChanged`). La
 * lectura de `isDragging()` usa `untracked()` a propósito: el `effect` NO
 * debe reaccionar a que `isDragging` cambie por sí solo (si reaccionara,
 * CADA fin de drag re-sembraría desde el `columns()` viejo del consumidor y
 * pisaría la actualización optimista que `onItemDropped` ya aplicó — el
 * caso normal de cada drag-and-drop sin refresh en vivo). El `effect` solo
 * debe reaccionar cuando `columns()` mismo cambia.
 *
 * CORRECCIÓN QUIRÚRGICA (re-gate post-4R) — el drop GANA sobre un refresh
 * pospuesto del MISMO gesto: en CDK real, `cdkDropListDropped` dispara ANTES
 * que `cdkDrag.ended` para un mismo gesto. Si en ese gesto ocurrieron AMBOS
 * — un refresh externo (queda en `pendingColumnsSeed`) Y un drop real
 * (`onItemDropped` ya actualizó `mirroredColumns` de forma optimista y
 * emitió `itemMoved`) —, aplicar el `pendingColumnsSeed` al terminar el
 * drag SOBRESCRIBIRÍA el resultado del drop, perdiendo el reorden del
 * usuario en silencio (aunque el consumidor ya recibió `itemMoved`). Fix:
 * `droppedThisGesture` marca que hubo drop; `onCardDragActiveChanged(false)`
 * DESCARTA el `pendingColumnsSeed` si hubo drop (no lo pierde de verdad: se
 * re-reflejará en el PRÓXIMO cambio real de `columns()`, y el consumidor es
 * la fuente de verdad al persistir el `itemMoved` que ya recibió). Decisión
 * consciente: el drop optimista del usuario gana en SU PROPIO gesto.
 *
 * Mecanismo alternativo accesible por teclado (corrección 4R CRITICAL):
 * `cdkDrag` de CDK no soporta teclado — `sol-kanban-column` ofrece un
 * `<select>` nativo por tarjeta que emite el MISMO `itemDropped`. El board
 * anuncia cada `itemMoved` (venga del drag o del select) vía una región
 * `aria-live="polite"` — ver `announcement` y la plantilla.
 *
 * Robustez de entrada (lecciones PR3/PR4): `columns` tolera `null`/
 * `undefined` (se trata como arreglo vacío); un elemento `null`/`undefined`
 * dentro del arreglo se filtra sin romper el render.
 */
declare class SolKanbanBoardComponent<T extends KanbanItem = KanbanItem> {
    /** Tolera `null`/`undefined` (lección PR3/PR4): `input.required()` no garantiza no-nulo en runtime. */
    readonly columns: _angular_core.InputSignal<KanbanColumn<T>[] | null | undefined>;
    readonly cardTemplate: _angular_core.InputSignal<TemplateRef<KanbanCardTemplateContext<T>>>;
    readonly headerTemplate: _angular_core.InputSignal<TemplateRef<{
        $implicit: KanbanColumn<T> | null | undefined;
    }> | null>;
    /**
     * Template del ancla terminal (ganada/perdida/etc.), reenviado tal cual a
     * `sol-kanban-column`. Sin este reenvío, un consumidor que arme su
     * pipeline vía `sol-kanban-board` (en vez de `sol-kanban-column` directo)
     * no podría usar el ancla terminal sin tocar la librería — violaría el
     * objetivo O ("agregar dominio = pasar templates, sin tocar el
     * componente"). La columna YA soportaba `anchorTemplate`; solo faltaba
     * exponerlo/reenviarlo desde el board.
     */
    readonly anchorTemplate: _angular_core.InputSignal<TemplateRef<{
        $implicit: KanbanColumn<T> | null | undefined;
    }> | null>;
    readonly emptyTemplate: _angular_core.InputSignal<TemplateRef<unknown> | null>;
    readonly columnAction: _angular_core.OutputEmitterRef<KanbanColumnAction>;
    /** Atajo de conveniencia: se re-emite cada vez que llega `columnAction` con `action === 'add'`. */
    readonly addRequested: _angular_core.OutputEmitterRef<string>;
    /**
     * Único output público del arrastre (spec#Arrastrar y soltar encapsulado
     * — "DEBE exponer únicamente un output tipado `itemMoved`"). El board NO
     * persiste: el consumidor hace el PATCH optimista y, ante error, reasigna
     * `[columns]` para el rollback (ver doc de la clase).
     */
    readonly itemMoved: _angular_core.OutputEmitterRef<KanbanItemMoved<T>>;
    private readonly reorderService;
    private readonly i18n;
    /** `protected` (no `private`): el template de este mismo componente necesita leerlo, y Angular exige acceso no-privado para bindings de plantilla. */
    protected readonly mirroredColumns: _angular_core.WritableSignal<KanbanColumn<T>[]>;
    /** `true` mientras CUALQUIER tarjeta del board está siendo arrastrada (corrección 4R WARNING). */
    private readonly isDragging;
    /** Seed diferido: `columns()` que llegó mientras `isDragging()` era `true`, pendiente de aplicar al terminar el drag. `null` = nada pendiente. */
    private pendingColumnsSeed;
    /**
     * `true` si `onItemDropped` aplicó un drop DENTRO del gesto de drag actual
     * (corrección quirúrgica, re-gate post-4R). En CDK real, `dropped` dispara
     * ANTES que `ended` para el MISMO gesto — si TAMBIÉN hubo un refresh
     * externo pospuesto (`pendingColumnsSeed`) durante ese gesto, aplicarlo al
     * terminar el drag (`onCardDragActiveChanged(false)`) SOBRESCRIBIRÍA el
     * resultado del drop que el usuario acaba de hacer (aunque `itemMoved` ya
     * se emitió) — el reorden se perdería en silencio. Decisión: el drop
     * optimista del usuario GANA dentro de su propio gesto; el refresh externo
     * pospuesto se DESCARTA (no se pierde de verdad: se re-reflejará en el
     * PRÓXIMO cambio real de `columns()`, y el consumidor es la fuente de
     * verdad de todos modos al persistir el `itemMoved` que ya recibió).
     */
    private droppedThisGesture;
    /** Anuncio `aria-live` del último movimiento (drag real o select accesible) — corrección 4R CRITICAL. */
    protected readonly announcement: _angular_core.WritableSignal<string>;
    constructor();
    /** Frecuencia de `id` entre las columnas actuales — soporte de `trackColumn` (fix NG0955 con id duplicado/ausente). */
    private readonly columnIdFrequency;
    /** `track` seguro: cae al índice si el `id` de la columna está ausente o duplicado. */
    trackColumn(column: KanbanColumn<T>, index: number): unknown;
    onColumnAction(action: KanbanColumnAction): void;
    /**
     * Delega en `KanbanReorderService` (puro): si el evento es válido (columna
     * origen/destino existen, índice dentro de rango), aplica el resultado
     * SOLO sobre el espejo y emite `itemMoved`. Un resultado `null` (evento
     * inconsistente/columna inexistente) se ignora sin lanzar — mismo espíritu
     * de robustez que el resto de `sol-kanban-*` (lecciones PR3/PR4/PR5a).
     * Recibe el MISMO `KanbanRawDropEvent` tanto del drag real (CDK) como del
     * `<select>` accesible de `sol-kanban-column` — ambos caminos comparten
     * exactamente esta lógica y el mismo `itemMoved` (corrección 4R CRITICAL).
     */
    onItemDropped(event: KanbanRawDropEvent): void;
    /**
     * Fuerza el re-seed del espejo desde el `columns()` ACTUAL (corrección 4R
     * WARNING) — NO depende de que la referencia cambie (a diferencia del
     * `effect`, que compara por `Object.is`). El consumidor la llama tras un
     * PATCH fallido para deshacer la actualización optimista. Respeta el
     * mismo diferido que el `effect` si hay un drag activo en curso.
     */
    rollback(): void;
    /**
     * Recibe el `dragActiveChanged` bubbleado desde CADA `sol-kanban-column`
     * (que a su vez lo recibe de cada `sol-kanban-card`). Al terminar el
     * drag (`active === false`), aplica cualquier reseed diferido pendiente
     * (corrección 4R WARNING).
     */
    protected onCardDragActiveChanged(active: boolean): void;
    /** Anuncia el movimiento por `aria-live` (corrección 4R CRITICAL) — mismo texto venga del drag o del select accesible. */
    private announceMove;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolKanbanBoardComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolKanbanBoardComponent<any>, "sol-kanban-board", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "cardTemplate": { "alias": "cardTemplate"; "required": true; "isSignal": true; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; "isSignal": true; }; "anchorTemplate": { "alias": "anchorTemplate"; "required": false; "isSignal": true; }; "emptyTemplate": { "alias": "emptyTemplate"; "required": false; "isSignal": true; }; }, { "columnAction": "columnAction"; "addRequested": "addRequested"; "itemMoved": "itemMoved"; }, never, never, true, never>;
}

/** Destino resuelto para el `<select>` de "mover a columna X" (id + etiqueta ya traducida). */
interface KanbanMoveTarget {
    id: string;
    label: string;
}
/**
 * `sol-kanban-column` — una columna con su lista de tarjetas, contador,
 * header y empty-state (spec: solercia-ui-kanban).
 *
 * `cdkDropList` (PR5b, D1/T38): el contenedor de items es un drop-list de
 * CDK — `[id]` (= `column.id`, usado por el board para resolver
 * origen/destino sin filtrar tipos de CDK), `[cdkDropListData]` (los items
 * actuales) y `[cdkDropListDisabled]` (respeta `column.droppable === false`).
 * `(cdkDropListDropped)` se traduce a un `KanbanRawDropEvent` CDK-free antes
 * de reenviarse al board vía `itemDropped` — cualquier archivo dentro de
 * `ui/kanban/` puede importar `@angular/cdk/drag-drop` (gate ESLint T40
 * exime el directorio completo: `kanban-card.component.ts` y
 * `kanban-board.component.ts` también lo importan). `(cdkDropListEntered)`/
 * `(cdkDropListExited)` alimentan el anillo de columna-destino activa
 * (spec#UX de arrastre del vocero).
 *
 * Mecanismo alternativo accesible por teclado (PR5b, corrección 4R —
 * CRITICAL): `cdkDrag` de CDK NO trae soporte de teclado (solo mouse/touch),
 * así que cada tarjeta expone un `<select>` NATIVO ("subir"/"bajar"/"mover a
 * columna X") — 100% operable por teclado sin reimplementar nada del drag.
 * El `change` del select se traduce al MISMO `KanbanRawDropEvent` y se
 * reenvía por el MISMO `itemDropped` que usa el drag real — ambos caminos
 * comparten `KanbanReorderService` en el board.
 *
 * `terminalAnchor` + `anchorTemplate` proyectado: la columna NUNCA conoce el
 * significado de negocio de un ancla (ganada/perdida/etc.) — solo renderiza
 * lo que el consumidor proyecta (spec#Anclas terminales por template
 * proyectado).
 *
 * Robustez de entrada (lecciones PR3/PR4): `column` y `column.items` toleran
 * `null`/`undefined` sin lanzar; `title`/`titleKey` se validan con
 * `typeof === 'string'` antes de usarse (nunca `.trim()`/acceso directo
 * sobre un dato que podría no ser string). Sin recursión/anidamiento en
 * este modelo (columnas → items planos) — no aplica guarda de ciclo.
 */
declare class SolKanbanColumnComponent<T extends KanbanItem = KanbanItem> {
    private readonly i18n;
    /** Tolera `null`/`undefined` (lección PR3/PR4): `input.required()` no garantiza no-nulo en runtime. */
    readonly column: _angular_core.InputSignal<KanbanColumn<T> | null | undefined>;
    readonly cardTemplate: _angular_core.InputSignal<TemplateRef<KanbanCardTemplateContext<T>>>;
    /** Override opcional del header completo. Sin este, se usa el título por defecto. */
    readonly headerTemplate: _angular_core.InputSignal<TemplateRef<{
        $implicit: KanbanColumn<T> | null | undefined;
    }> | null>;
    /** Template del ancla terminal — SOLO se renderiza si `column.terminalAnchor` es `true`. */
    readonly anchorTemplate: _angular_core.InputSignal<TemplateRef<{
        $implicit: KanbanColumn<T> | null | undefined;
    }> | null>;
    /** Override opcional del empty-state. Sin este, se usa el texto por defecto (clave i18n). */
    readonly emptyTemplate: _angular_core.InputSignal<TemplateRef<unknown> | null>;
    /**
     * TODAS las columnas del board (corrección 4R CRITICAL) — necesarias para
     * poblar las opciones "mover a columna X" del `<select>` accesible.
     * Reenviado tal cual desde `sol-kanban-board`; opcional (si no se provee,
     * el select solo ofrece subir/bajar dentro de la propia columna).
     */
    readonly allColumns: _angular_core.InputSignal<KanbanColumn<T>[] | null | undefined>;
    readonly action: _angular_core.OutputEmitterRef<KanbanColumnAction>;
    /** Bubblea el `dragActiveChanged` de CADA `sol-kanban-card` hacia el board (corrección 4R WARNING — pospone el re-seed del espejo durante un drag). */
    readonly dragActiveChanged: _angular_core.OutputEmitterRef<boolean>;
    /**
     * Reenvío CDK-free del drop (PR5b/T38): el board arma el reorden completo
     * (necesita ver TODAS las columnas para un move cross-columna); esta
     * columna solo conoce la suya, así que traduce el `CdkDragDrop` real a un
     * `KanbanRawDropEvent` plano ANTES de emitir — el tipo de CDK nunca sale
     * de este archivo hacia el board.
     */
    readonly itemDropped: _angular_core.OutputEmitterRef<KanbanRawDropEvent>;
    readonly items: _angular_core.Signal<T[]>;
    /** `id` del drop-list — string vacío si la columna es `null`/`undefined` o no trae `id` (degrade, no lanza). */
    readonly columnId: _angular_core.Signal<string>;
    /** Anillo de columna-destino activa mientras el cursor de arrastre está sobre esta columna (spec#UX de arrastre). */
    protected readonly isDropTargetActive: _angular_core.WritableSignal<boolean>;
    /** Frecuencia de `id` entre los items actuales — soporte de `trackItem` (fix NG0955 con id duplicado/ausente). */
    private readonly itemIdFrequency;
    /** `track` seguro: cae al índice si el `id` del item está ausente o duplicado, en vez de dejar que Angular lance `NG0955`. */
    trackItem(item: T, index: number): unknown;
    readonly title: _angular_core.Signal<string>;
    readonly accentColor: _angular_core.Signal<string>;
    readonly columnAria: _angular_core.Signal<string>;
    /**
     * Singular/plural correcto en español ("1 tarjeta" vs. "N tarjetas") — el
     * contrato `SolI18n` no soporta ICU MessageFormat, así que la elección de
     * clave se hace acá en vez de interpolar un plural incorrecto.
     */
    readonly itemCountAria: _angular_core.Signal<string>;
    readonly emptyLabel: _angular_core.Signal<string>;
    readonly addLabel: _angular_core.Signal<string>;
    /** Destinos válidos para "mover a columna X": todas las de `allColumns()` EXCEPTO la propia. */
    readonly otherColumns: _angular_core.Signal<KanbanMoveTarget[]>;
    readonly moveAriaLabel: _angular_core.Signal<string>;
    readonly movePlaceholder: _angular_core.Signal<string>;
    readonly moveUpLabel: _angular_core.Signal<string>;
    readonly moveDownLabel: _angular_core.Signal<string>;
    /** Método (no `computed`): necesita un parámetro (la etiqueta de la columna destino) para interpolar `{{column}}`. */
    moveToLabel(columnLabel: string): string;
    requestAdd(): void;
    /**
     * Traduce el `CdkDragDrop` real a `KanbanRawDropEvent` (sin tipos de CDK) y
     * lo reenvía al board. Descarta el caso trivial (soltar en el MISMO
     * índice, MISMO contenedor) — no hay reorden real que aplicar.
     */
    protected onCdkDropped(event: CdkDragDrop<T[]>): void;
    protected onCdkEntered(): void;
    protected onCdkExited(): void;
    /**
     * Traduce la opción elegida en el `<select>` accesible al MISMO
     * `KanbanRawDropEvent`/`itemDropped` que usa el drag real (corrección 4R
     * CRITICAL) — "subir"/"bajar" reordenan dentro de esta misma columna;
     * "mover a columna X" usa `Number.MAX_SAFE_INTEGER` como `currentIndex`
     * porque `KanbanReorderService.reorder()` ya clampa el índice al tamaño
     * real de la columna destino (equivale a "agregar al final" sin que esta
     * columna necesite conocer cuántos items tiene la columna destino).
     */
    protected onMoveSelected(index: number, event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolKanbanColumnComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolKanbanColumnComponent<any>, "sol-kanban-column", never, { "column": { "alias": "column"; "required": true; "isSignal": true; }; "cardTemplate": { "alias": "cardTemplate"; "required": true; "isSignal": true; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; "isSignal": true; }; "anchorTemplate": { "alias": "anchorTemplate"; "required": false; "isSignal": true; }; "emptyTemplate": { "alias": "emptyTemplate"; "required": false; "isSignal": true; }; "allColumns": { "alias": "allColumns"; "required": false; "isSignal": true; }; }, { "action": "action"; "dragActiveChanged": "dragActiveChanged"; "itemDropped": "itemDropped"; }, never, never, true, never>;
}

/**
 * Contrato genérico de `sol-calendar` (spec: solercia-ui-calendar). Sin
 * conocimiento de dominio: NUNCA referencia `clientName`/`professionalName`/
 * `stateId`/`stateName` (eso es dominio de citas, hoy en
 * `boki-front/src/widgets/calendar`) — el consumidor extiende `data` con su
 * propio modelo y proyecta su propio contenido de evento vía `eventTemplate`
 * (spec#Cuerpo de tarjeta por template proyectado).
 */
/**
 * Evento genérico de calendario. `start`/`end` aceptan `Date` o `string`
 * (ISO parseable) — la librería los normaliza internamente y degrada sin
 * lanzar ante un valor inválido (lecciones PR3/PR4/PR5: robustez de
 * entrada).
 *
 * LIMITACIÓN DOCUMENTADA (corrección 4R WARNING, re-gate PR6): un evento que
 * CRUZA MEDIANOCHE (`start` y `end` en días calendario distintos) se agrupa
 * y renderiza ÚNICAMENTE en el día de `start` — no se replica ni se recorta
 * al día de `end`. La caja se clampa al rango horario visible (nunca se
 * sale de la grilla), pero el soporte completo de eventos multi-día es
 * no-meta de esta versión (vista mes/multi-día ya diferida — ver
 * `calendar-layout.ts#buildDayColumns`).
 */
interface SolCalendarEvent {
    id: string | number;
    start: Date | string;
    end: Date | string;
    title: string;
    /**
     * Color CSS opcional, resuelto por `SolCalendarColorStrategy`
     * (spec#Resolución de color por Strategy inyectable). Sin `color`
     * explícito, la estrategia por defecto usa una superficie neutra — la
     * librería NUNCA asume una paleta de dominio.
     *
     * SOLO se acepta hex (`#rgb`/`#rrggbb`/`#rrggbbaa`), notación funcional
     * (`rgb()`/`rgba()`/`hsl()`/`hsla()`) o una referencia a token
     * (`var(--sol-*)`) — corrección 4R WARNING (risk): cualquier otro valor
     * (p. ej. `url(...)`, un vector de "CSS beacon" hacia una petición de
     * red) se rechaza y degrada a la superficie neutra por defecto. Ver
     * `calendar-color.ts#isSafeCssColor`.
     */
    color?: string;
    /** Passthrough para el template proyectado — el consumidor guarda ahí su propio modelo (p. ej. una cita completa). */
    data?: unknown;
}
/**
 * Vista soportada en esta versión (spec#paridad de vistas semana/día). Vista
 * mes y arrastrar-para-reagendar (`eventDropped`) quedan DIFERIDOS — decisión
 * ratificada, documentada, no implementados en 0.2.0 (`'month'` NO existe en
 * este tipo a propósito).
 */
type SolCalendarView = 'week' | 'day';
/**
 * Entrada de leyenda totalmente controlada por el consumidor
 * (spec#Leyenda configurable) — la librería NUNCA deriva una leyenda
 * hardcodeada de estados de dominio. `labelKey` se resuelve vía `SOL_I18N`
 * con el catálogo del CONSUMIDOR (la librería no conoce el significado).
 */
interface SolCalendarLegendItem {
    color: string;
    labelKey: string;
}
/** Conjunto de colores resuelto para un evento — mismo shape que el `StateColorSet` histórico del widget de citas, ahora genérico. */
interface StateColorSet {
    bg: string;
    border: string;
    text: string;
}

/**
 * Funciones puras del motor de posicionamiento de `sol-calendar` — extraídas
 * para testear en aislamiento (mismo espíritu que `timeline-position.ts` del
 * PR4 y `kanban-reorder.service.ts` del PR5b: la lógica no trivial vive
 * fuera del ciclo de render). Robustez de entrada (lecciones PR3/PR4/PR5):
 * `start`/`end` inválidos o ausentes DEGRADAN (valor por defecto, nunca
 * lanzan) — un evento malformado no debe romper la grilla completa.
 */
/** Convierte `start`/`end` (`Date | string`) a un `Date` válido; `null` si es inválido/ausente. */
declare function parseEventDate(value: Date | string | null | undefined): Date | null;
/** Clave de agrupación por día calendario (año-mes-día), ignora la hora. */
declare function dayKey(date: Date): string;
/** Lunes de la semana que contiene `date` (semana lunes→domingo), a medianoche. */
declare function getWeekStart(date: Date): Date;
interface CalendarDayColumn<T extends SolCalendarEvent = SolCalendarEvent> {
    date: Date;
    isToday: boolean;
    events: T[];
}
/**
 * Construye las columnas de día con sus eventos ya agrupados: 1 columna para
 * `'day'`, `dayCount` columnas (desde el lunes de la semana de `currentDate`)
 * para `'week'`. Tolera `events` null/undefined y elementos `null`/`undefined`
 * dentro del arreglo (se filtran); un evento con `start` inválido/ausente se
 * excluye de TODAS las columnas (no puede ubicarse en ningún día) sin lanzar.
 *
 * LIMITACIÓN DOCUMENTADA (corrección 4R WARNING — reliability, re-gate PR6):
 * un evento se agrupa ÚNICAMENTE por el día calendario de `start` — un
 * evento que CRUZA MEDIANOCHE (p. ej. `start` 23:30 / `end` 00:30 del día
 * siguiente) aparece SOLO en la columna del día de `start`; NO se replica
 * ni se recorta al día de `end`. Vista mes/multi-día es no-meta de esta
 * versión (ya diferida) — soportar eventos multi-día correctamente
 * requeriría particionar el evento por día, alcance NUEVO fuera de esta
 * corrección. `computeEventTop`/`computeEventHeight` sí clampan la caja al
 * rango horario visible para que NUNCA se salga de la grilla, incluso
 * cuando el evento cruza medianoche.
 */
declare function buildDayColumns<T extends SolCalendarEvent>(view: SolCalendarView, currentDate: Date, events: readonly (T | null | undefined)[] | null | undefined, dayCount: number): CalendarDayColumn<T>[];
/**
 * Offset vertical (px) del evento dentro de la grilla, según su hora de
 * inicio relativa a `hourStart`. `start` inválido/ausente → `0` (degrada,
 * no lanza). Clampado a `[0, (hourEnd-hourStart)*hourPx - minHeightPx]`
 * (corrección 4R WARNING — reliability, re-gate PR6): un evento que empieza
 * antes de `hourStart` se clampa al borde superior; uno que empieza en o
 * después de `hourEnd` (p. ej. cruza medianoche, `start` 23:30 con
 * `hourEnd`=22) se clampa al borde inferior — reservando `minHeightPx` para
 * que la caja NUNCA se salga por debajo de la grilla visible.
 */
declare function computeEventTop(event: SolCalendarEvent | null | undefined, hourStart: number, hourEnd: number, hourPx: number, minHeightPx?: number): number;
/**
 * Alto (px) del evento según la duración `end - start`. `start`/`end`
 * inválidos, ausentes, o duración no positiva → `minHeightPx` (degrada, no
 * lanza) — nunca menor que `minHeightPx` (visibilidad mínima garantizada).
 * Clampado (corrección 4R WARNING — reliability, re-gate PR6) para que
 * `top + height` NUNCA exceda el borde inferior de la grilla visible — un
 * evento que cruza medianoche (fuera de `[hourStart, hourEnd)`) ya no
 * produce una caja gigante fuera de la grilla; se recorta visualmente al
 * día de `start` (ver limitación documentada en `buildDayColumns`).
 */
declare function computeEventHeight(event: SolCalendarEvent | null | undefined, hourStart: number, hourEnd: number, hourPx: number, minHeightPx?: number): number;
/**
 * Offset (px) de la línea de "ahora" dentro del rango horario visible;
 * `-1` si "ahora" cae fuera de `[hourStart, hourEnd)` (no se muestra la línea).
 */
declare function computeNowTop(now: Date, hourStart: number, hourEnd: number, hourPx: number): number;

/** Contexto del `ng-template` de evento: `let-event` (`$implicit`) o `let-event="event"`. */
interface SolCalendarEventTemplateContext<T extends SolCalendarEvent = SolCalendarEvent> {
    $implicit: T;
    event: T;
}
/**
 * `sol-calendar-grid` — grilla de horas con posicionamiento absoluto (px por
 * minuto), línea de "ahora" y slots clicables (spec: solercia-ui-calendar).
 * Generaliza `boki-front/src/widgets/calendar/ui/calendar-grid.component.ts`:
 * eventos genéricos `{id,start,end,title,color?,data?}` (nunca
 * `clientName`/`professionalName`/`stateId`), color resuelto por
 * `SOL_CALENDAR_COLOR` (D3, en vez de una paleta hardcodeada) y el cuerpo de
 * cada tarjeta por `eventTemplate` proyectado (spec#Cuerpo de tarjeta por
 * template proyectado) — sin template, cae a mostrar solo `event.title`.
 *
 * Robustez de entrada (lecciones PR3/PR4/PR5): `events`/`view`/`currentDate`
 * toleran `null`/`undefined`/valores inválidos sin lanzar (degradan vía
 * `calendar-layout.ts`, funciones puras testeadas en aislamiento). Un evento
 * con `id` ausente/duplicado no rompe `@for` (fix NG0955, mismo patrón que
 * `sol-kanban`/`sol-timeline`).
 */
declare class SolCalendarGridComponent<T extends SolCalendarEvent = SolCalendarEvent> {
    private readonly colorResolver;
    private readonly themeService;
    private readonly i18n;
    private readonly destroyRef;
    /** Tolera `null`/`undefined` (lección PR3/PR4/PR5): `input.required()` no garantiza un dato válido en runtime. */
    readonly events: _angular_core.InputSignal<T[] | null | undefined>;
    readonly view: _angular_core.InputSignal<SolCalendarView | null | undefined>;
    readonly currentDate: _angular_core.InputSignal<Date | null | undefined>;
    /** Sin este, el cuerpo del evento cae a mostrar solo `event.title` (spec#Cuerpo de tarjeta por template proyectado). */
    readonly eventTemplate: _angular_core.InputSignal<TemplateRef<SolCalendarEventTemplateContext<T>> | null>;
    readonly eventClicked: _angular_core.OutputEmitterRef<T>;
    readonly slotClicked: _angular_core.OutputEmitterRef<{
        date: Date;
        time: string;
    }>;
    readonly HOUR_PX = 60;
    readonly HOUR_START = 6;
    readonly hours: number[];
    private readonly isMobileViewport;
    /**
     * Token aditivo `component.calendar.mobileDays` del ThemeFile activo (v2).
     * Default 5 (lunes–viernes ajustados al ancho); 7 conserva la semana
     * completa — mismo patrón que `component.table.mobile` en `sol-data-table`.
     */
    private readonly mobileDays;
    readonly dayCount: Signal<1 | 5 | 7>;
    private readonly validCurrentDate;
    readonly dayColumns: Signal<CalendarDayColumn<T>[]>;
    private readonly now;
    constructor();
    readonly nowTop: Signal<number>;
    /**
     * Frecuencia de `id` entre TODOS los eventos visibles (todas las columnas)
     * — soporte de `trackEvent` (fix NG0955 con id duplicado/ausente, mismo
     * patrón que `sol-kanban`/`sol-timeline`). `computed()` para no recalcular
     * en cada invocación de `trackEvent` dentro del mismo render.
     */
    private readonly allEventsIdFrequency;
    dayKeyOf(day: CalendarDayColumn<T>): string;
    trackEvent(event: T, index: number): unknown;
    formatHour(hour: number): string;
    dayLabel(date: Date): string;
    /**
     * DEUDA DOCUMENTADA (SUGGESTION del 4R, re-gate PR6, deliberadamente NO
     * implementada en esta corrección): `eventTop`/`eventHeight`/`eventColor`
     * se llaman COMO MÉTODOS dentro del `@for` de eventos, así que Angular
     * los reevalúa en CADA ciclo de detección de cambios (incluido el tick de
     * 60s de `now`, que solo afecta la línea de "ahora" pero dispara CD sobre
     * todo el componente). Con cientos de eventos visibles esto podría
     * degradar a lentitud. Mejora futura: memoizar el layout del día completo
     * vía un `computed()` sobre `(events, view, currentDate)` que devuelva
     * `{event, top, height, color}[]` ya resueltos, y que el `@for` itere esa
     * estructura en vez de llamar métodos por evento. No se implementó acá a
     * propósito — el 4R lo marcó opcional y esta corrección ya prioriza los 2
     * WARNING obligatorios (color inseguro + evento que cruza medianoche).
     */
    eventTop(event: T): number;
    eventHeight(event: T): number;
    /**
     * Delega en el `colorResolver` INYECTADO (corrección 4R WARNING —
     * resilience, re-gate PR6): una `SolCalendarColorStrategy` de dominio
     * provista por el consumidor es código EXTERNO a la librería — si lanza,
     * antes rompía el render de TODA la grilla (un solo evento defectuoso
     * tumbaba el resto). Ahora degrada a `NEUTRAL_CALENDAR_COLOR` SOLO para
     * ESE evento; el resto del calendario sigue renderizando con normalidad.
     */
    eventColor(event: T): StateColorSet;
    onEventClick(event: T, domEvent: MouseEvent): void;
    onSlotClick(date: Date, hour: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolCalendarGridComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolCalendarGridComponent<any>, "sol-calendar-grid", never, { "events": { "alias": "events"; "required": true; "isSignal": true; }; "view": { "alias": "view"; "required": true; "isSignal": true; }; "currentDate": { "alias": "currentDate"; "required": true; "isSignal": true; }; "eventTemplate": { "alias": "eventTemplate"; "required": false; "isSignal": true; }; }, { "eventClicked": "eventClicked"; "slotClicked": "slotClicked"; }, never, never, true, never>;
}

/**
 * `sol-calendar` — orquestador genérico de `sol-calendar-header` +
 * `sol-calendar-grid` + leyenda (spec: solercia-ui-calendar). Generaliza
 * `boki-front/src/widgets/calendar`: evento genérico `{id,start,end,title,
 * color?,data?}` (NUNCA `clientName`/`professionalName`/`stateId`), color
 * por `SOL_CALENDAR_COLOR` (Strategy inyectable, D3), cuerpo de tarjeta por
 * `eventTemplate` proyectado y leyenda TOTALMENTE controlada por `[legend]`
 * (spec#Leyenda configurable — sin default hardcodeado de estados de cita).
 *
 * Vista mes y arrastrar-para-reagendar (`eventDropped`) quedan DIFERIDOS —
 * decisión ratificada, documentada como no-meta de esta versión (`view`
 * solo tipa `'week'|'day'`, `'month'` no existe en el tipo a propósito).
 *
 * Espejo interno (`signal` + `effect`, D4 del design, mismo patrón que
 * `sol-kanban`/`sol-timeline`): `currentDate`/`view` son inputs que
 * SIEMBRAN el estado interno de navegación — el consumidor puede montar
 * `sol-calendar` sin wiring adicional (autocontenido: los clics de
 * "anterior"/"siguiente"/"hoy"/toggle de vista los maneja este componente
 * internamente), y también puede saltar programáticamente a otra fecha
 * reasignando el input.
 *
 * Robustez de entrada (lecciones PR3/PR4/PR5): `events`/`view`/`currentDate`
 * toleran `null`/`undefined`/valores inválidos sin lanzar (degradan a
 * arreglo vacío / `'week'` / fecha actual del sistema, respectivamente).
 */
declare class SolCalendarComponent<T extends SolCalendarEvent = SolCalendarEvent> {
    private readonly i18n;
    /** Tolera `null`/`undefined` (lección PR3/PR4/PR5): `input.required()` no garantiza un dato válido en runtime. */
    readonly events: _angular_core.InputSignal<T[] | null | undefined>;
    readonly view: _angular_core.InputSignal<SolCalendarView | null | undefined>;
    readonly currentDate: _angular_core.InputSignal<Date | null | undefined>;
    /** Sin este, `sol-calendar-grid` cae a mostrar solo `event.title` (spec#Cuerpo de tarjeta por template proyectado). */
    readonly eventTemplate: _angular_core.InputSignal<TemplateRef<SolCalendarEventTemplateContext<T>> | null>;
    /** Leyenda TOTALMENTE controlada por el consumidor — sin este input, no se muestra ninguna leyenda (spec#Leyenda configurable). */
    readonly legend: _angular_core.InputSignal<SolCalendarLegendItem[] | null | undefined>;
    readonly eventClicked: _angular_core.OutputEmitterRef<T>;
    readonly slotClicked: _angular_core.OutputEmitterRef<{
        date: Date;
        time: string;
    }>;
    /** `protected` (no `private`): el template necesita leerlos, y Angular exige acceso no-privado para bindings de plantilla. */
    protected readonly mirroredDate: _angular_core.WritableSignal<Date>;
    protected readonly mirroredView: _angular_core.WritableSignal<SolCalendarView>;
    constructor();
    protected readonly legendItems: _angular_core.Signal<SolCalendarLegendItem[]>;
    legendLabel(item: SolCalendarLegendItem): string;
    /**
     * Valida `item.color` contra la whitelist de `isSafeCssColor` antes de
     * interpolarlo en `[style.background]` (corrección 4R WARNING — risk,
     * re-gate PR6): `background` es una propiedad shorthand que ACEPTA
     * `url(...)` — un color de baja confianza (config de tenant futura)
     * podría disparar una petición de red ("CSS beacon") si se enlazara sin
     * validar. Un color no seguro degrada a un tono neutro por token.
     */
    legendDotColor(item: SolCalendarLegendItem): string;
    protected onDateChange(date: Date): void;
    protected onViewChange(view: SolCalendarView): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolCalendarComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolCalendarComponent<any>, "sol-calendar", never, { "events": { "alias": "events"; "required": true; "isSignal": true; }; "view": { "alias": "view"; "required": true; "isSignal": true; }; "currentDate": { "alias": "currentDate"; "required": true; "isSignal": true; }; "eventTemplate": { "alias": "eventTemplate"; "required": false; "isSignal": true; }; "legend": { "alias": "legend"; "required": false; "isSignal": true; }; }, { "eventClicked": "eventClicked"; "slotClicked": "slotClicked"; }, never, never, true, never>;
}

/**
 * `sol-calendar-header` — navegación (anterior/hoy/siguiente) + selector de
 * vista (semana/día). Generaliza
 * `boki-front/src/widgets/calendar/ui/calendar-header.component.ts`: SIN
 * leyenda (spec#Leyenda configurable — la renderiza `sol-calendar`, no el
 * header, para que "leyenda configurable" no dependa de esta sub-pieza) y
 * SIN conocimiento de dominio (nunca referencia estados de cita).
 *
 * Robustez de entrada (lecciones PR3/PR4/PR5): `currentDate`/`view` toleran
 * `null`/`undefined`/fecha inválida sin lanzar — degradan a una etiqueta
 * vacía y asumen `'week'` respectivamente.
 */
declare class SolCalendarHeaderComponent {
    private readonly i18n;
    /** Tolera `null`/`undefined`/fecha inválida (lección PR3/PR4/PR5): `input.required()` no garantiza un dato válido en runtime. */
    readonly currentDate: _angular_core.InputSignal<Date | null | undefined>;
    readonly view: _angular_core.InputSignal<SolCalendarView | null | undefined>;
    readonly dateChange: _angular_core.OutputEmitterRef<Date>;
    readonly viewChange: _angular_core.OutputEmitterRef<SolCalendarView>;
    readonly todayLabel: _angular_core.Signal<string>;
    readonly previousLabel: _angular_core.Signal<string>;
    readonly nextLabel: _angular_core.Signal<string>;
    readonly viewWeekLabel: _angular_core.Signal<string>;
    readonly viewDayLabel: _angular_core.Signal<string>;
    readonly dateRangeLabel: _angular_core.Signal<string>;
    navigatePrev(): void;
    navigateNext(): void;
    goToday(): void;
    setView(view: SolCalendarView): void;
    /** `currentDate()` normalizado: `null` si es `null`/`undefined`/inválido (degrada, no lanza). */
    private validDate;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolCalendarHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolCalendarHeaderComponent, "sol-calendar-header", never, { "currentDate": { "alias": "currentDate"; "required": true; "isSignal": true; }; "view": { "alias": "view"; "required": true; "isSignal": true; }; }, { "dateChange": "dateChange"; "viewChange": "viewChange"; }, never, never, true, never>;
}

/**
 * Puerto de resolución de color por evento (spec#Resolución de color por
 * Strategy inyectable — D3 del design, mismo patrón que `THEME_SOURCE`/
 * `SOL_I18N`). La librería NUNCA hardcodea una paleta de dominio (p. ej. la
 * paleta de 6 estados de cita) — el consumidor inyecta su propia estrategia
 * cuando necesita colorear por una regla de negocio.
 */
interface SolCalendarColorStrategy {
    resolve(event: SolCalendarEvent, isDark: boolean): StateColorSet;
}
/** Superficie neutra por tokens — fallback compartido por el default null-object (sin `color`/`color` no seguro) y por `sol-calendar-grid` cuando una Strategy inyectada lanza (corrección 4R WARNING — resilience). */
declare const NEUTRAL_CALENDAR_COLOR: StateColorSet;
/**
 * Whitelist estricta de formas CSS seguras para interpolar en
 * `color-mix()`/`[style]` (corrección 4R WARNING — risk, re-gate PR6):
 * hex (`#rgb`/`#rrggbb`/`#rrggbbaa`), notación funcional (`rgb()`/`rgba()`/
 * `hsl()`/`hsla()`) o referencia a token (`var(--sol-*)`). Cualquier otro
 * valor (p. ej. `url(...)`, `image-set(...)`, `expression(...)`) se
 * rechaza — `background`/`border`/`color` son propiedades shorthand que
 * ACEPTAN `url(...)`, así que un `color` de baja confianza (config de
 * tenant futura, dato de un consumidor no confiable) podría disparar una
 * petición de red ("CSS beacon") si se interpolara sin validar. NO acepta
 * nombres de color (`red`, `blue`) a propósito — whitelist mínima, no
 * exhaustiva.
 */
declare function isSafeCssColor(value: string): boolean;
/**
 * Token de inyección del puerto de color. Default: `DefaultCalendarColorStrategy`
 * (null-object) — la librería funciona "de fábrica" sin que el consumidor
 * provea nada; un consumidor con reglas de dominio (p. ej. la paleta de 6
 * estados de cita) provee su propia implementación vía
 * `{ provide: SOL_CALENDAR_COLOR, useClass/useValue: ... }`.
 */
declare const SOL_CALENDAR_COLOR: InjectionToken<SolCalendarColorStrategy>;

/**
 * Modelo de tokens en 3 niveles (W3C DTCG-aligned): primitivos → semánticos → componente.
 * Los niveles VIVEN en esta fuente TS + `themes/default.theme.json` y se resuelven hacia
 * abajo (ver `resolveCssVars` en `theme.service.ts`) hacia el conjunto de variables
 * `--sol-*` de la `EMIT_TABLE`.
 *
 * ThemeFile v2 (E8 — skins white-label): todos los bloques nuevos son OPCIONALES (`?`).
 * Un ThemeFile v1 sigue siendo válido sin cambios: cada token v2 ausente emite su
 * default (el look del `default.json` actual). Ver `ThemeFile-v2-SPEC.md` del handoff.
 */
/** Referencia a un token, p. ej. `"{color.blue.600}"` (se resuelve contra `primitives`), o un literal. */
type TokenRef = string;
/** Archivo completo de theming: metadatos + primitivos compartidos + configuración por modo. */
interface ThemeFile {
    meta: ThemeMeta;
    primitives: ThemePrimitives;
    modes: {
        light: ThemeModeConfig;
        dark: ThemeModeConfig;
    };
}
/** Metadatos invariantes de modo (no se emiten como CSS vars). */
interface ThemeMeta {
    tenant: string;
    logo: ThemeLogo;
    /** Frase de marca del tenant (login/onboarding). v2, opcional. */
    tagline?: string;
    /**
     * Fuentes web por tenant. v2, opcional. La URL de carga se construye SIEMPRE
     * por código a partir de `family` + `weights` (jamás una URL cruda del tenant).
     */
    fonts?: ThemeFont[];
}
/** Fuente web declarada por el tenant. Único proveedor permitido: Google Fonts (sanitizable por construcción). */
interface ThemeFont {
    family: string;
    provider: 'google';
    weights: number[];
}
interface ThemeLogo {
    url: string;
    /** Variante del logo para modo oscuro (opcional): un tenant sin `urlDark` usa `url` en ambos modos. */
    urlDark?: string;
    altText: string;
    width: number;
}
/** Nivel 1 — primitivos: paleta y escalas compartidas entre light y dark. */
interface ThemePrimitives {
    color: Record<string, Record<string, string> | string>;
    font: {
        /** `display` (v2, opcional) es la tipografía de titulares; sin ella se usa `sans`. */
        family: {
            sans: string;
            mono: string;
            display?: string;
        };
        size: {
            sm: string;
            base: string;
            lg: string;
            xl: string;
        };
        weight: {
            normal: number;
            bold: number;
        };
        lineHeight: {
            base: string;
        };
    };
    radius: {
        sm: string;
        md: string;
        lg: string;
        full: string;
    };
    space: {
        xs: string;
        sm: string;
        md: string;
        lg: string;
        xl: string;
    };
    size: {
        control: {
            sm: string;
            md: string;
            lg: string;
        };
    };
    z: Record<'1000' | '1050' | '1100', number>;
    borderWidth: {
        thin: string;
    };
    /** Duraciones y curvas de movimiento. v2, opcional (defaults del look actual). */
    motion?: ThemeMotionPrimitives;
}
/** Primitivos de movimiento: duraciones ("120ms") y curvas (cubic-bezier). */
interface ThemeMotionPrimitives {
    duration: {
        fast: string;
        base: string;
        slow: string;
    };
    easing: {
        standard: string;
        entrance: string;
    };
}
/** Configuración de un modo visual: capa semántica + capa de componente. */
interface ThemeModeConfig {
    semantic: ThemeSemantic;
    component: ThemeComponent;
}
/** Nivel 2 — semánticos: referencian primitivos, la asignación cambia entre light/dark. */
interface ThemeSemantic {
    color: Record<'primary' | 'secondary' | 'accent' | 'success' | 'warning' | 'danger' | 'info', TokenRef>;
    text: Record<'primary' | 'secondary' | 'muted', TokenRef>;
    surface: {
        page: TokenRef;
        surface: TokenRef;
        overlay: TokenRef;
        /** Fondos rebajados (inputs filled, filas alternas). v2, opcional. */
        sunken?: TokenRef;
        /** background-image de la página: SOLO gradients o "none" (se sanitiza; jamás `url(`). v2, opcional. */
        texture?: string;
    };
    border: {
        color: TokenRef;
        width: TokenRef;
    };
    layer: {
        dropdown: TokenRef;
        modal: TokenRef;
        tooltip: TokenRef;
    };
    /** box-shadow es un string crudo por naturaleza — 2 niveles, sin primitivo sintético. */
    shadow: {
        sm: string;
        md: string;
        lg: string;
    };
}
/** Nivel 3 — componente: tokens con consumidor puntual. Los bloques v2 son opcionales. */
interface ThemeComponent {
    control: {
        inputHeight: TokenRef;
        buttonHeight: TokenRef;
    };
    layout: {
        sidebarWidth: string;
        headerHeight: string;
    };
    shadow: {
        card: string;
    };
    /** Config de alertas — preservada por estabilidad de API aunque hoy no tiene consumidor. */
    alerts: ThemeAlerts;
    /** Carácter tipográfico de titulares y cifras. v2, opcional. */
    typography?: ThemeTypographyComponent;
    /** Forma de las cards (plana / elevada / glass). v2, opcional. */
    card?: ThemeCardComponent;
    /** Estilo de los inputs (filled / outline / underline). v2, opcional. */
    input?: ThemeInputComponent;
    /** Forma de los botones (pill / sharp / uppercase). v2, opcional. */
    button?: ThemeButtonComponent;
    /** Sidebar por tenant (puede ser oscuro aunque el modo sea light). v2, opcional. */
    sidebar?: ThemeSidebarComponent;
    /** Header translúcido/sólido. v2, opcional. */
    header?: ThemeHeaderComponent;
    /** Pantalla de login white-label. v2, opcional. */
    auth?: ThemeAuthComponent;
    /** Paleta categórica para series de gráficas. v2, opcional. */
    chart?: ThemeChartComponent;
    /** Movimiento (intensidad, estilo de entrada, press). v2, opcional. */
    motion?: ThemeMotionComponent;
    /** Fondo detrás de los diálogos (desenfoque del backdrop). v2, opcional. */
    overlay?: ThemeOverlayComponent;
    /** Preferencia responsive de data-tables (aditivo, nunca estructural). v2, opcional. */
    table?: ThemeTableComponent;
    /** Preferencia responsive del calendario (aditivo, nunca estructural). v2, opcional. */
    calendar?: ThemeCalendarComponent;
}
/**
 * Fondo detrás de un diálogo/modal. El color lo aporta `semantic.surface.overlay`;
 * este bloque añade el desenfoque (frosted glass) sobre lo que quede detrás.
 */
interface ThemeOverlayComponent {
    /** backdrop-filter del fondo: "none" | "blur(3px)" | "blur(8px) saturate(1.2)". */
    blur: string;
}
interface ThemeAlerts {
    borderRadius: string;
    showIcon: boolean;
    position: 'top-right' | 'top-center' | 'bottom-right';
    duration: number;
    /** Posición del toast en viewports angostos (default "top-center": tipo push bajo el header). v2, opcional. */
    positionMobile?: 'top-center' | 'top-right';
}
/** Carácter de titulares (h1/h2, valores de stat-card) y de cifras. */
interface ThemeTypographyComponent {
    displayWeight: number;
    displayTracking: string;
    displayTransform: string;
    /** Familia para cifras (ej. mono = look técnico). Opcional. */
    numericFamily?: string;
}
/** Forma de las cards. `border` y sombras son shorthands CSS completos. */
interface ThemeCardComponent {
    bg: TokenRef;
    /** Shorthand completo: "1px solid #DCE1EA" | "1px solid transparent". */
    border: string;
    radius: TokenRef;
    /** "none" para skins planos. */
    shadow: string;
    shadowHover: string;
    /** backdrop-filter: "none" | "blur(16px) saturate(1.4)". */
    blur: string;
    /** "0px" | "-4px". */
    hoverLift: string;
}
/** Estilo de los inputs. `variant` es documental; los tokens lo materializan. */
interface ThemeInputComponent {
    variant: 'filled' | 'outline' | 'underline';
    bg: TokenRef;
    /** Shorthand completo. */
    border: string;
    radius: TokenRef;
    /** underline se implementa con inset box-shadow. */
    shadow: string;
    focusBorder: string;
    /** "0 0 0 4px rgba(...)". */
    focusRing: string;
}
/** Forma de los botones. */
interface ThemeButtonComponent {
    /** "999px" pill | "4px" sharp. */
    radius: TokenRef;
    shadow: string;
    weight: number;
    /** "none" | "uppercase". */
    transform: string;
}
/** Sidebar por tenant. */
interface ThemeSidebarComponent {
    /** Puede ser oscuro aunque el modo sea light. */
    bg: TokenRef;
    text: TokenRef;
    activeBg: string;
    activeText: TokenRef;
    itemRadius: TokenRef;
    /** box-shadow inset para barra de acento, o "none". */
    indicator: string;
}
/** Header de la aplicación. */
interface ThemeHeaderComponent {
    /** rgba para efecto translúcido. */
    bg: string;
    blur: string;
}
/** Pantalla de login. `layout` NO es token: lo lee el template del login. */
interface ThemeAuthComponent {
    layout: 'split-left' | 'split-right' | 'centered';
    /** Fondo del panel hero (o glow de página en centered) — SOLO gradients (se sanitiza). */
    heroBg: string;
}
/** Paleta para series de gráficas (3-6 colores; se rellena/recorta a 6 al emitir). */
interface ThemeChartComponent {
    palette: string[];
}
/** Movimiento del tema. `intensity` multiplica duraciones y revealDistance al emitir. */
interface ThemeMotionComponent {
    /** `smooth` (v2.1) = multiplicador 1.0 (movimiento natural sin exagerar). */
    intensity: 'none' | 'subtle' | 'smooth' | 'expressive';
    /** Animación de entrada: subir / solo fade / escala con rebote / deslizar / zoom. */
    revealStyle: 'rise' | 'fade' | 'pop' | 'slide' | 'zoom';
    /** "8px" | "26px". */
    revealDistance: string;
    /** 0.99 | 0.97. */
    pressScale: number;
}
/** Preferencia responsive de data-tables. Default "collapse" (filas colapsables, sin scroll horizontal). */
interface ThemeTableComponent {
    mobile: 'collapse' | 'scroll';
}
/** Preferencia responsive del calendario. Default 5 (lunes–viernes). */
interface ThemeCalendarComponent {
    mobileDays: 5 | 7;
}

/** Modo visual soportado por todo tema (el toggle es preferencia local del usuario). */
type ThemeMode = 'light' | 'dark';
/** Contexto que recibe un default v2 calculado: modo activo + resolutor de rutas del contrato. */
interface EmitDefaultContext {
    mode: ThemeMode;
    /** Resuelve otra ruta del contrato (garantizada por las filas v1) al valor final del modo. */
    resolve: (path: string) => string;
}
/**
 * Default v1 de una fila v2: literal CSS, o función del contexto para defaults
 * derivados de otra ruta ya resuelta o dependientes del modo.
 */
type EmitDefaultV1 = string | ((ctx: EmitDefaultContext) => string);
/**
 * Fila de la tabla de emisión. SIN default ⇒ token v1 OBLIGATORIO (ruta ausente
 * o rota lanza y el tema se descarta). CON default ⇒ token v2 opcional (ruta
 * ausente emite el default = look del `default.json` actual).
 */
type EmitRow = readonly [name: string, path: string, defaultV1?: EmitDefaultV1];
/**
 * Tabla única de "qué variables existen": 95 filas (47 v1 obligatorias + 48 v2
 * con default). Cada fila es [nombreCssVar, rutaDelToken, defaultV1?]; la ruta
 * apunta dentro de `{ primitives, semantic, component }` (ver `resolveCssVars`).
 * Agregar/quitar una fila cambia el conjunto emitido — por eso el test de tokens
 * fija el conteo total y el de filas v1.
 */
declare const EMIT_TABLE: ReadonlyArray<EmitRow>;
/**
 * Un background-image del tenant es seguro si es "none" o comienza con un
 * gradient permitido y NO contiene `url(` en ninguna posición (tolera varios
 * gradients separados por coma). Caso contrario se emite el default.
 */
declare function isSafeBackgroundImage(value: string): boolean;
/** Opciones de resolución dependientes del entorno (se mantienen fuera de la función pura). */
interface ResolveCssVarsOptions {
    /** `prefers-reduced-motion: reduce` del sistema: fuerza el multiplicador "none". */
    reducedMotion?: boolean;
}
/**
 * Puro y exportado: aplana los 3 niveles (primitivos→semántico→componente) del
 * `ThemeFile` para un modo dado hacia el mapa plano nombre→valor de las
 * variables `--sol-*` de la EMIT_TABLE. Filas v1 son obligatorias (lanzan si
 * faltan); filas v2 ausentes emiten su default — un tema v1 emite el conjunto
 * completo. Es el núcleo testeable del sistema de tokens.
 */
declare function resolveCssVars(file: ThemeFile, mode: ThemeMode, options?: ResolveCssVarsOptions): Map<string, string>;
/**
 * Construye la URL de Google Fonts EXCLUSIVAMENTE con `family` + `weights`
 * (sanitización por construcción: jamás se usa una URL cruda del tenant).
 * Entradas con `provider !== "google"` se ignoran. `null` = sin fuentes.
 */
declare function buildGoogleFontsUrl(fonts: ThemeFont[] | undefined): string | null;
/**
 * Validación previa a aplicar un ThemeFile llegado en RUNTIME (asset o API):
 * un tema es renderizable si TODAS sus variables resuelven en AMBOS modos
 * (las v1 desde el tema; las v2 desde el tema o su default). Referencias
 * rotas, niveles ausentes o valores nulos lo descartan — el llamador cae al
 * tema anterior/default en vez de dejar el `:root` a medias.
 */
declare function isRenderableTheme(file: ThemeFile | null | undefined): file is ThemeFile;
/**
 * ThemeService — runtime de theming white-label, AGNÓSTICO del host.
 *
 * Emite los 95 tokens `--sol-*` sobre `:root` a partir de un `ThemeFile` y
 * reacciona a tres entradas: el tema del tenant (cargado por el puerto
 * `THEME_SOURCE` que provee el host), el default empaquetado
 * (`SOL_DEFAULT_THEME`) y el toggle light/dark. NO conoce el ORIGEN del tema
 * (HTTP, archivo, mock…): eso vive en el adaptador `ThemeSource` del host.
 *
 * RED DE FALLBACKS (de mejor a peor):
 * 1. tema del tenant (vía `THEME_SOURCE`),
 * 2. default empaquetado (`SOL_DEFAULT_THEME`),
 * 3. variables inline de `:root` (styles.css del host, red final).
 * Un source que falla / devuelve `null`, un `ThemeFile` de tenant inválido, o
 * un `SOL_DEFAULT_THEME` malformado degradan al siguiente nivel con un log,
 * sin dejar la app sin tema.
 *
 * ANTI-RACE: si el tenant activo cambia mientras su tema viaja, la respuesta
 * tardía se descarta (`isStaleResponse`).
 *
 * BRANDING: `logo` (URL SANITIZADA — solo http/https/relativas, jamás
 * `javascript:`), `brandName` y favicon del tenant (restaurado al volver al
 * default). Logo DUAL: `meta.logo.urlDark` es la variante para modo oscuro;
 * `logo()` expone la URL efectiva del modo actual y el favicon la sigue al
 * togglear. `activeTheme` expone el tema efectivo para consumidores reactivos
 * (ej. `sol-chart` re-renderiza al cambiar de tenant).
 */
declare class ThemeService {
    /** Puerto de carga del tema por tenant (lo provee el host; null-object por defecto → sin tema de tenant). */
    private readonly source;
    /** Opcional: sin resolver (specs/otros hosts) el servicio se comporta como single-theme (solo default). */
    private readonly tenantResolver;
    private readonly rawDefault;
    /**
     * Default empaquetado EN la librería (Vértice por defecto; el host puede
     * sobreescribir SOL_DEFAULT_THEME). VALIDADO como cualquier tema: un default
     * malformado cae a `null` → se activa la 3ª red (CSS inline de `:root`), sin
     * dejar la app rota (misma garantía que `tenantTheme`).
     */
    private readonly defaultTheme;
    /** Tema del tenant activo, ya validado. `null` = usar el default. */
    private readonly tenantTheme;
    private readonly _isDark;
    /** Tema EFECTIVO aplicado sobre `:root` (tenant → default → null = red de styles.css). */
    readonly activeTheme: _angular_core.Signal<ThemeFile | null>;
    readonly isDark: _angular_core.Signal<boolean>;
    /**
     * Logo EFECTIVO del tema con URL sanitizada. URL insegura → sin logo (jamás
     * javascript:). Logo dual: en modo dark `url` expone la variante `urlDark`
     * si existe y es segura; sin `urlDark` (o insegura), `url` sirve en ambos
     * modos. Depende de `_isDark`, así que reacciona al toggle en runtime.
     */
    readonly logo: _angular_core.Signal<ThemeLogo | null>;
    /** Nombre de marca del tenant (branding runtime): altText del logo o el slug del tenant. */
    readonly brandName: _angular_core.Signal<string | null>;
    /** href original del favicon empaquetado (index.html); se captura una sola vez. */
    private faviconOriginalHref;
    private faviconCaptured;
    constructor();
    /**
     * Aplica directamente un ThemeFile de tenant (enfoque PUSH: el host lo empuja
     * en vez de que la librería tire vía THEME_SOURCE). Validado como cualquier
     * tema: uno inválido cae al default. Útil para hosts que ya tienen el tema en
     * memoria (SSR, caché) o que no quieren implementar un ThemeSource.
     */
    setTenantTheme(theme: ThemeFile | null): void;
    toggleMode(): void;
    /**
     * Fuerza la recarga del tema del tenant activo (Theme Studio: tras el PUT
     * de `:id/theme` el tema recién persistido debe verse sin re-login ni
     * cambio de empresa). Re-lanza la misma petición del cambio de tenant —
     * hereda el anti-race y la red de fallbacks. Sin resolver o sin tenant
     * activo no hace nada (sigue el default).
     */
    refresh(): void;
    /**
     * Reacción al cambio de tenant (login, cambio de empresa activa, logout).
     * `null` (pre-login/logout) limpia el tema de tenant → vuelve el default.
     */
    private onTenantChange;
    /** Anti-race: la respuesta pertenece a un tenant que ya no es el activo. */
    private isStaleResponse;
    private loadDarkPreference;
    private applyDarkClass;
    private applyCssVariables;
    /** `prefers-reduced-motion: reduce` del sistema fuerza la intensidad "none" al emitir. */
    private prefersReducedMotion;
    /** Inyecta/reemplaza/retira el único <link> de fuentes del tenant (v2). */
    private applyFonts;
    private clearCssVariables;
    /** Aplica el favicon del tenant o restaura el empaquetado (`url === null`). */
    private applyFavicon;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ThemeService>;
}

/**
 * Registers the theming runtime. Instantiating ThemeService eagerly starts its
 * effects: it applies {@link SOL_DEFAULT_THEME} immediately and, if the host
 * wired SOL_TENANT_RESOLVER + THEME_SOURCE, begins reacting to tenant changes.
 *
 * The default theme is bundled in the library (no asset fetch required), so a
 * host that provides nothing still renders with a valid theme.
 */
declare function provideTheme(): EnvironmentProviders;

/**
 * Sanitización de URLs de assets de branding por tenant (E6).
 *
 * El logo del ThemeFile llega del API en RUNTIME (dato no confiable) y se
 * aplica en `<img [src]>` y en el favicon vía `setAttribute` — esta última
 * ruta queda FUERA del sanitizer de plantillas de Angular, por eso la
 * validación explícita: solo http/https/relativas; `javascript:`, `data:` y
 * cualquier otro esquema se descartan (mejor sin logo que con un vector XSS).
 */
/**
 * Devuelve la URL si es segura para un asset (http:, https: o relativa al
 * origen); `null` en cualquier otro caso. Nunca lanza.
 */
declare function sanitizeAssetUrl(url: string | null | undefined): string | null;

/**
 * Host-provided contract for resolving the active tenant. The design system is
 * agnostic of how the host identifies tenants; the host application wires its
 * own resolver. When absent, ThemeService behaves as single-theme (default only).
 */
interface SolTenantResolver {
    /** Active tenant/company id, or null pre-login / on logout. */
    activeTenantId(): number | null;
}
declare const SOL_TENANT_RESOLVER: InjectionToken<SolTenantResolver>;
/**
 * Host-provided PORT for loading a tenant's theme. This is what keeps the
 * library agnostic: the library asks "give me the theme for this tenant" and
 * does NOT know whether it comes from an HTTP API, a file, localStorage, or a
 * mock. The host supplies the adapter (e.g. an API client).
 *
 * Defaults to a null-object that returns `null` (no tenant theme), so the
 * library works out of the box and falls back to {@link SOL_DEFAULT_THEME}.
 */
interface ThemeSource {
    /**
     * Resolve the theme for a tenant. Return `null` to fall back to the default.
     * How the theme is fetched is entirely the host's concern.
     */
    loadTheme(tenantId: number | string): Promise<ThemeFile | null>;
}
declare const THEME_SOURCE: InjectionToken<ThemeSource>;
/**
 * The theme the library ships with and applies when there is no tenant theme.
 * Defaults to the bundled "Vértice" theme (a full ThemeFile that mirrors the
 * `jsonb` stored per company in the database). The host may override it with
 * its own brand default:
 *
 *   { provide: SOL_DEFAULT_THEME, useValue: myBrandTheme }
 */
declare const SOL_DEFAULT_THEME: InjectionToken<ThemeFile>;

/**
 * Minimal i18n contract consumed by the @solercia/ui components.
 *
 * The host application provides the implementation (Transloco, ngx-translate,
 * @angular/localize, or the built-in identity default). This keeps the library
 * agnostic of any specific i18n engine — mirroring Angular Material's `*Intl`
 * services.
 */
interface SolI18n {
    /** Active language as a reactive signal. */
    readonly activeLang: Signal<string>;
    /** Synchronous translation. Returns the key itself when it is missing. */
    translate(key: string, params?: Record<string, unknown>): string;
    /** Reactive translation: the returned signal recomputes when the language changes. */
    t(key: string, params?: Record<string, unknown>): Signal<string>;
    /** Translate several keys at once, in the same order. */
    tMany(keys: string[]): Signal<string[]>;
}
/**
 * Identity fallback used when the host does not provide an implementation.
 * Returns keys unchanged so components fall back to their built-in defaults.
 */
declare function createIdentitySolI18n(): SolI18n;
/**
 * Injection token for the i18n contract. Defaults to the identity fallback so
 * the library works out of the box; the host overrides it with a real engine.
 */
declare const SOL_I18N: InjectionToken<SolI18n>;

export { DEFAULT_SCORE_THRESHOLDS, EMIT_TABLE, KANBAN_ADD_ACTION, KanbanReorderService, NEUTRAL_CALENDAR_COLOR, SOL_CALENDAR_COLOR, SOL_CHART_ENGINE, SOL_DEFAULT_THEME, SOL_I18N, SOL_TENANT_RESOLVER, SolAvatarComponent, SolBadgeComponent, SolButtonComponent, SolCalendarComponent, SolCalendarGridComponent, SolCalendarHeaderComponent, SolCardComponent, SolChartComponent, SolCheckboxComponent, SolDataTableComponent, SolDatePickerComponent, SolDayPickerComponent, SolEmptyStateComponent, SolFileUploadComponent, SolFormFieldComponent, SolIconButtonComponent, SolIconComponent, SolInputComponent, SolKanbanBoardComponent, SolKanbanCardComponent, SolKanbanColumnComponent, SolMessageStatusComponent, SolModalComponent, SolPageHeaderComponent, SolPaginationComponent, SolProgressBarComponent, SolRichEditorComponent, SolScoreBadgeComponent, SolSearchInputComponent, SolSelectComponent, SolSkeletonComponent, SolSpinnerComponent, SolStepperComponent, SolTabsComponent, SolTextareaComponent, SolTimelineComponent, SolToggleComponent, SolTooltipComponent, SolTrendComponent, SolViewToggleComponent, SolVirtualScrollComponent, SolWizardComponent, SolWizardStepDirective, TCPDF_ALLOWED_STYLE_PROPERTIES, TCPDF_ALLOWED_TAGS, THEME_SOURCE, ThemeService, buildDayColumns, buildGoogleFontsUrl, collectUndatedNodes, computeEventHeight, computeEventTop, computeGlobalRange, computeInitials, computeMonthAxisTicks, computeNowTop, createIdentitySolI18n, dayKey, defaultStatusToken, defaultTrendFormat, getWeekStart, hashToPaletteIndex, isRenderableTheme, isSafeBackgroundImage, isSafeCssColor, parseEventDate, positionRows, provideTheme, resolveCssVars, resolveScoreTone, resolveTrendDirection, sanitizeAssetUrl, sanitizeHtmlToTcpdf, serializeElementToTcpdfHtml };
export type { CalendarDayColumn, DataTableColumn, DayPickerItem, KanbanCardTemplateContext, KanbanColumn, KanbanColumnAction, KanbanItem, KanbanItemMoved, LinkableTask, MentionUser, PositionedTimelineRow, SolAvatarSize, SolButtonSize, SolButtonVariant, SolCalendarColorStrategy, SolCalendarEvent, SolCalendarEventTemplateContext, SolCalendarLegendItem, SolCalendarView, SolChartData, SolChartEngineFactory, SolChartEngineHandle, SolChartOptions, SolChartSeries, SolChartType, SolCheckboxColor, SolCheckboxShape, SolCheckboxSize, SolDataTableRow, SolDatePickerSize, SolI18n, SolIconButtonSize, SolIconButtonVariant, SolIconName, SolIconSize, SolIconVariant, SolMessageStatus, SolProgressMode, SolProgressSize, SolProgressVariant, SolRichImageUploader, SolScoreThreshold, SolSelectOption, SolSkeletonVariant, SolStepperNavigation, SolStepperOrientation, SolStepperStep, SolStepperStepState, SolTabItem, SolTenantResolver, SolTimelineAxisTick, SolTimelineRange, SolTimelineStatusResolver, SolTone, SolTrendDirection, SolViewToggleOption, SolVirtualScrollItemContext, SolWizardCanAdvance, SolWizardStep, StateColorSet, ThemeAlerts, ThemeComponent, ThemeFile, ThemeFont, ThemeLogo, ThemeMeta, ThemeMode, ThemeModeConfig, ThemePrimitives, ThemeSemantic, ThemeSource, TimelineLegendItem, TimelineNode, TokenRef };
