import * as i0 from '@angular/core';
import { input, output, computed, ChangeDetectionStrategy, Component, signal, forwardRef, inject, viewChild, HostListener, InjectionToken, numberAttribute, ElementRef, effect, TemplateRef, Directive, model, contentChildren, linkedSignal, contentChild, untracked, Injectable, provideAppInitializer, DestroyRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { NgTemplateOutlet } from '@angular/common';
import { Chart, LineController, BarController, DoughnutController, LineElement, PointElement, BarElement, ArcElement, CategoryScale, LinearScale, Legend, Tooltip, Filler } from 'chart.js';
import * as i1 from '@angular/cdk/drag-drop';
import { CdkDrag, CdkDropList, CdkDropListGroup } from '@angular/cdk/drag-drop';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

class SolButtonComponent {
    /** Visual style variant. */
    variant = input('primary', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Size preset. */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Whether the button is disabled. */
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Native button type attribute. */
    type = input('button', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /** Shows a spinner and disables the button. */
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    /** Emitted on click when the button is not disabled or loading. */
    clicked = output();
    /** Computed CSS class string combining variant and size modifiers. */
    cssClass = computed(() => `sol-btn sol-btn--${this.variant()} sol-btn--${this.size()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cssClass" }] : /* istanbul ignore next */ []));
    onClick(event) {
        if (this.disabled() || this.loading()) {
            event.stopPropagation();
            return;
        }
        this.clicked.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolButtonComponent, isStandalone: true, selector: "sol-button", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clicked: "clicked" }, ngImport: i0, template: `
    <button
      [type]="type()"
      [class]="cssClass()"
      [disabled]="disabled() || loading()"
      (click)="onClick($event)"
    >
      @if (loading()) {
        <svg
          class="sol-btn__spinner"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <circle
            cx="12"
            cy="12"
            r="10"
            fill="none"
            stroke="currentColor"
            stroke-width="3"
            stroke-dasharray="31.4 31.4"
            stroke-linecap="round"
          />
        </svg>
      }
      <ng-content />
    </button>
  `, isInline: true, styles: [":host{display:inline-block;--sol-btn-primary-bg: var(--sol-color-primary, #6366f1);--sol-btn-primary-text: var(--sol-color-primary-contrast, #ffffff);--sol-btn-secondary-bg: var(--sol-color-secondary, #e2e8f0);--sol-btn-secondary-text: var(--sol-color-secondary-contrast, #1e293b);--sol-btn-danger-bg: var(--sol-color-danger, #ef4444);--sol-btn-danger-text: var(--sol-color-danger-contrast, #ffffff);--sol-btn-ghost-bg: transparent;--sol-btn-ghost-text: var(--sol-color-primary, #6366f1);--sol-btn-font-sm: var(--sol-font-size-sm, .75rem);--sol-btn-font-md: var(--sol-font-size-md, .875rem);--sol-btn-font-lg: var(--sol-font-size-lg, 1rem);--sol-btn-padding-sm: var(--sol-spacing-xs, .25rem) var(--sol-spacing-sm, .5rem);--sol-btn-padding-md: var(--sol-spacing-sm, .5rem) var(--sol-spacing-md, 1rem);--sol-btn-padding-lg: var(--sol-spacing-md, .75rem) var(--sol-spacing-lg, 1.5rem);--sol-btn-radius: var(--sol-button-radius, var(--sol-border-radius-md, .5rem));--sol-btn-font-weight: var(--sol-button-weight, 500);--sol-btn-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease);--sol-btn-focus-ring: var(--sol-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent));--sol-btn-disabled-opacity: var(--sol-disabled-opacity, .55)}.sol-btn{display:inline-flex;align-items:center;justify-content:center;gap:.5em;border:none;border-radius:var(--sol-btn-radius);box-shadow:var(--sol-button-shadow, none);font-family:inherit;font-weight:var(--sol-btn-font-weight);text-transform:var(--sol-button-transform, none);line-height:1;cursor:pointer;transition:background-color var(--sol-btn-transition),box-shadow var(--sol-btn-transition),transform var(--sol-btn-transition),filter var(--sol-btn-transition),opacity var(--sol-btn-transition);white-space:nowrap;-webkit-user-select:none;user-select:none}.sol-btn:active:not(:disabled){transform:scale(var(--sol-press-scale, .98))}.sol-btn:focus-visible{outline:none;box-shadow:var(--sol-btn-focus-ring)}.sol-btn:disabled{cursor:not-allowed;opacity:var(--sol-btn-disabled-opacity)}.sol-btn--primary{background-color:var(--sol-btn-primary-bg);color:var(--sol-btn-primary-text)}.sol-btn--primary:hover:not(:disabled){filter:brightness(1.1)}.sol-btn--primary:active:not(:disabled){filter:brightness(.95)}.sol-btn--secondary{background-color:var(--sol-btn-secondary-bg);color:var(--sol-btn-secondary-text)}.sol-btn--secondary:hover:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-secondary-bg) 80%,black)}.sol-btn--secondary:active:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-secondary-bg) 70%,black)}.sol-btn--danger{background-color:var(--sol-btn-danger-bg);color:var(--sol-btn-danger-text)}.sol-btn--danger:hover:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-danger-bg) 85%,black)}.sol-btn--danger:active:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-danger-bg) 75%,black)}.sol-btn--ghost{background-color:var(--sol-btn-ghost-bg);color:var(--sol-btn-ghost-text)}.sol-btn--ghost:hover:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-ghost-text) 10%,transparent)}.sol-btn--ghost:active:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-ghost-text) 18%,transparent)}.sol-btn--sm{font-size:var(--sol-font-size-sm, 12px);height:32px;padding:0 12px}.sol-btn--md{font-size:var(--sol-font-size-base, 14px);height:36px;padding:0 16px}.sol-btn--lg{font-size:var(--sol-font-size-base, 14px);height:40px;padding:0 20px}.sol-btn__spinner{width:1em;height:1em;flex-shrink:0;animation:sol-spin .75s linear infinite}@keyframes sol-spin{to{transform:rotate(360deg)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-button', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <button
      [type]="type()"
      [class]="cssClass()"
      [disabled]="disabled() || loading()"
      (click)="onClick($event)"
    >
      @if (loading()) {
        <svg
          class="sol-btn__spinner"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <circle
            cx="12"
            cy="12"
            r="10"
            fill="none"
            stroke="currentColor"
            stroke-width="3"
            stroke-dasharray="31.4 31.4"
            stroke-linecap="round"
          />
        </svg>
      }
      <ng-content />
    </button>
  `, styles: [":host{display:inline-block;--sol-btn-primary-bg: var(--sol-color-primary, #6366f1);--sol-btn-primary-text: var(--sol-color-primary-contrast, #ffffff);--sol-btn-secondary-bg: var(--sol-color-secondary, #e2e8f0);--sol-btn-secondary-text: var(--sol-color-secondary-contrast, #1e293b);--sol-btn-danger-bg: var(--sol-color-danger, #ef4444);--sol-btn-danger-text: var(--sol-color-danger-contrast, #ffffff);--sol-btn-ghost-bg: transparent;--sol-btn-ghost-text: var(--sol-color-primary, #6366f1);--sol-btn-font-sm: var(--sol-font-size-sm, .75rem);--sol-btn-font-md: var(--sol-font-size-md, .875rem);--sol-btn-font-lg: var(--sol-font-size-lg, 1rem);--sol-btn-padding-sm: var(--sol-spacing-xs, .25rem) var(--sol-spacing-sm, .5rem);--sol-btn-padding-md: var(--sol-spacing-sm, .5rem) var(--sol-spacing-md, 1rem);--sol-btn-padding-lg: var(--sol-spacing-md, .75rem) var(--sol-spacing-lg, 1.5rem);--sol-btn-radius: var(--sol-button-radius, var(--sol-border-radius-md, .5rem));--sol-btn-font-weight: var(--sol-button-weight, 500);--sol-btn-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease);--sol-btn-focus-ring: var(--sol-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent));--sol-btn-disabled-opacity: var(--sol-disabled-opacity, .55)}.sol-btn{display:inline-flex;align-items:center;justify-content:center;gap:.5em;border:none;border-radius:var(--sol-btn-radius);box-shadow:var(--sol-button-shadow, none);font-family:inherit;font-weight:var(--sol-btn-font-weight);text-transform:var(--sol-button-transform, none);line-height:1;cursor:pointer;transition:background-color var(--sol-btn-transition),box-shadow var(--sol-btn-transition),transform var(--sol-btn-transition),filter var(--sol-btn-transition),opacity var(--sol-btn-transition);white-space:nowrap;-webkit-user-select:none;user-select:none}.sol-btn:active:not(:disabled){transform:scale(var(--sol-press-scale, .98))}.sol-btn:focus-visible{outline:none;box-shadow:var(--sol-btn-focus-ring)}.sol-btn:disabled{cursor:not-allowed;opacity:var(--sol-btn-disabled-opacity)}.sol-btn--primary{background-color:var(--sol-btn-primary-bg);color:var(--sol-btn-primary-text)}.sol-btn--primary:hover:not(:disabled){filter:brightness(1.1)}.sol-btn--primary:active:not(:disabled){filter:brightness(.95)}.sol-btn--secondary{background-color:var(--sol-btn-secondary-bg);color:var(--sol-btn-secondary-text)}.sol-btn--secondary:hover:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-secondary-bg) 80%,black)}.sol-btn--secondary:active:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-secondary-bg) 70%,black)}.sol-btn--danger{background-color:var(--sol-btn-danger-bg);color:var(--sol-btn-danger-text)}.sol-btn--danger:hover:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-danger-bg) 85%,black)}.sol-btn--danger:active:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-danger-bg) 75%,black)}.sol-btn--ghost{background-color:var(--sol-btn-ghost-bg);color:var(--sol-btn-ghost-text)}.sol-btn--ghost:hover:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-ghost-text) 10%,transparent)}.sol-btn--ghost:active:not(:disabled){background-color:color-mix(in srgb,var(--sol-btn-ghost-text) 18%,transparent)}.sol-btn--sm{font-size:var(--sol-font-size-sm, 12px);height:32px;padding:0 12px}.sol-btn--md{font-size:var(--sol-font-size-base, 14px);height:36px;padding:0 16px}.sol-btn--lg{font-size:var(--sol-font-size-base, 14px);height:40px;padding:0 20px}.sol-btn__spinner{width:1em;height:1em;flex-shrink:0;animation:sol-spin .75s linear infinite}@keyframes sol-spin{to{transform:rotate(360deg)}}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], clicked: [{ type: i0.Output, args: ["clicked"] }] } });

class SolInputComponent {
    /* --- Signal inputs --- */
    type = input('text', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    error = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /* --- Internal state --- */
    value = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    isDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    /* --- CVA callbacks --- */
    onChange = () => { };
    onTouched = () => { };
    onInputChange(event) {
        const val = event.target.value;
        this.value.set(val);
        this.onChange(val);
    }
    /* --- ControlValueAccessor implementation --- */
    writeValue(value) {
        this.value.set(value ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabled.set(isDisabled);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolInputComponent, isStandalone: true, selector: "sol-input", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SolInputComponent),
                multi: true,
            },
        ], ngImport: i0, template: `
    <div class="sol-input-wrapper">
      @if (label()) {
        <label class="sol-input-label">{{ label() }}</label>
      }
      <input
        class="sol-input"
        [class.sol-input--error]="!!error()"
        [class.sol-input--disabled]="disabled() || isDisabled()"
        [type]="type()"
        [placeholder]="placeholder()"
        [disabled]="disabled() || isDisabled()"
        [value]="value()"
        (input)="onInputChange($event)"
        (blur)="onTouched()"
      />
      @if (error()) {
        <span class="sol-input-error">{{ error() }}</span>
      }
    </div>
  `, isInline: true, styles: [":host{display:block}.sol-input-wrapper{display:flex;flex-direction:column;gap:var(--sol-space-xs)}.sol-input-label{font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, 12px);font-weight:500;color:var(--sol-color-text-secondary, #64748B);text-transform:uppercase;letter-spacing:.05em;line-height:1}.sol-input{width:100%;height:var(--sol-size-input-height);padding:0 var(--sol-space-sm);font-family:var(--sol-font-family);font-size:var(--sol-font-size-base);color:var(--sol-color-text-primary);background:var(--sol-input-bg, var(--sol-bg-surface));border:var(--sol-input-border, var(--sol-border-width-default) solid var(--sol-border-color-default));border-radius:var(--sol-input-radius, var(--sol-border-radius-md));box-shadow:var(--sol-input-shadow, none);outline:none;box-sizing:border-box;transition:border-color var(--sol-dur-fast, .15s) var(--sol-ease, ease),box-shadow var(--sol-dur-fast, .15s) var(--sol-ease, ease)}.sol-input::placeholder{color:var(--sol-color-text-muted)}.sol-input:focus{border:var(--sol-input-focus-border, var(--sol-border-width-default) solid var(--sol-color-primary));box-shadow:var(--sol-input-focus-ring, 0 0 0 2px color-mix(in srgb, var(--sol-color-primary) 20%, transparent))}.sol-input--error{border-color:var(--sol-color-danger)}.sol-input--error:focus{border-color:var(--sol-color-danger);box-shadow:0 0 0 2px color-mix(in srgb,var(--sol-color-danger) 20%,transparent)}.sol-input--disabled{opacity:.5;cursor:not-allowed}.sol-input-error{font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-danger);line-height:1.3}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SolInputComponent),
                            multi: true,
                        },
                    ], template: `
    <div class="sol-input-wrapper">
      @if (label()) {
        <label class="sol-input-label">{{ label() }}</label>
      }
      <input
        class="sol-input"
        [class.sol-input--error]="!!error()"
        [class.sol-input--disabled]="disabled() || isDisabled()"
        [type]="type()"
        [placeholder]="placeholder()"
        [disabled]="disabled() || isDisabled()"
        [value]="value()"
        (input)="onInputChange($event)"
        (blur)="onTouched()"
      />
      @if (error()) {
        <span class="sol-input-error">{{ error() }}</span>
      }
    </div>
  `, styles: [":host{display:block}.sol-input-wrapper{display:flex;flex-direction:column;gap:var(--sol-space-xs)}.sol-input-label{font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, 12px);font-weight:500;color:var(--sol-color-text-secondary, #64748B);text-transform:uppercase;letter-spacing:.05em;line-height:1}.sol-input{width:100%;height:var(--sol-size-input-height);padding:0 var(--sol-space-sm);font-family:var(--sol-font-family);font-size:var(--sol-font-size-base);color:var(--sol-color-text-primary);background:var(--sol-input-bg, var(--sol-bg-surface));border:var(--sol-input-border, var(--sol-border-width-default) solid var(--sol-border-color-default));border-radius:var(--sol-input-radius, var(--sol-border-radius-md));box-shadow:var(--sol-input-shadow, none);outline:none;box-sizing:border-box;transition:border-color var(--sol-dur-fast, .15s) var(--sol-ease, ease),box-shadow var(--sol-dur-fast, .15s) var(--sol-ease, ease)}.sol-input::placeholder{color:var(--sol-color-text-muted)}.sol-input:focus{border:var(--sol-input-focus-border, var(--sol-border-width-default) solid var(--sol-color-primary));box-shadow:var(--sol-input-focus-ring, 0 0 0 2px color-mix(in srgb, var(--sol-color-primary) 20%, transparent))}.sol-input--error{border-color:var(--sol-color-danger)}.sol-input--error:focus{border-color:var(--sol-color-danger);box-shadow:0 0 0 2px color-mix(in srgb,var(--sol-color-danger) 20%,transparent)}.sol-input--disabled{opacity:.5;cursor:not-allowed}.sol-input-error{font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-danger);line-height:1.3}\n"] }]
        }], propDecorators: { type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });

/**
 * Icon Registry — inner SVG path content (without the <svg> wrapper).
 *
 * Two sources, per key:
 *
 * 1. Heroicons v2.0 (MIT License — tailwindlabs/heroicons), the default source.
 *    To add one: copy the inner content of the matching `outline/<name>.svg`
 *    (24×24) into `outline`, and `solid/<name>.svg` into `fill`, from
 *    heroicons.com or the `heroicons` npm package. Keep the exact `d`
 *    attribute (do not hand-edit path data).
 * 2. Custom glyphs with no Heroicons equivalent (see the "íconos propios"
 *    section below, and the rich-editor toolbar icons): original design,
 *    line-art by nature — see the **outline-only** rule below.
 *
 * Naming: kebab-case key (`/^[a-z0-9]+(-[a-z0-9]+)*$/`), enforced by
 * `icon.registry.spec.ts` (gate — also fails on an empty `outline`).
 *
 * Structure per icon (`IconDef`):
 *   outline — stroke-based paths (designed for fill="none", stroke="currentColor")
 *   fill    — solid paths       (designed for fill="currentColor", stroke="none")
 *           — OR `''` (empty string) for an **outline-only** icon: a glyph
 *             built from open/thin strokes (a line, an antenna, a needle...)
 *             that has NO real solid silhouette. Filling that same path data
 *             with `fill="currentColor"` would give many of its subpaths
 *             ZERO area — the icon would render incomplete or invisible.
 *             `icon.component.ts` detects `fill === ''` and degrades
 *             `variant="fill"` to the outline stroke rendering instead of
 *             breaking the icon. This is NOT "outline === fill" (that used
 *             to be the convention and was the bug): the outline path is
 *             reused, but rendered with the outline's stroke wrapper, never
 *             with `fill="currentColor"`.
 *
 * Gate: no `<sol-icon>` consumer inside `projects/solercia/ui/src/lib/**`
 * may inline its own `<svg>`/`<path>` — everything goes through this
 * registry (see the lint/test gate described in `icon.registry.spec.ts`).
 */
const ICON_REGISTRY = {
    // ── Navigation ──────────────────────────────────────────────────────────────
    home: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />`,
        fill: `<path d="M11.47 3.841a.75.75 0 0 1 1.06 0l8.69 8.69a.75.75 0 1 0 1.06-1.061l-8.689-8.69a2.25 2.25 0 0 0-3.182 0l-8.69 8.69a.75.75 0 1 0 1.061 1.06l8.69-8.689Z" /><path d="m12 5.432 8.159 8.159c.03.03.06.058.091.086v6.198c0 1.035-.84 1.875-1.875 1.875H15a.75.75 0 0 1-.75-.75v-4.5a.75.75 0 0 0-.75-.75h-3a.75.75 0 0 0-.75.75V21a.75.75 0 0 1-.75.75H5.625a1.875 1.875 0 0 1-1.875-1.875v-6.198a.914.914 0 0 0 .091-.086L12 5.432Z" />`,
    },
    menu: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />`,
        fill: `<path fill-rule="evenodd" d="M3 6.75A.75.75 0 0 1 3.75 6h16.5a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 6.75ZM3 12a.75.75 0 0 1 .75-.75h16.5a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 12Zm0 5.25a.75.75 0 0 1 .75-.75h16.5a.75.75 0 0 1 0 1.5H3.75a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />`,
    },
    list: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0ZM3.75 12h.007v.008H3.75V12Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm-.375 5.25h.007v.008H3.75v-.008Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />`,
        fill: `<path fill-rule="evenodd" d="M2.625 6.75a1.125 1.125 0 1 1 2.25 0 1.125 1.125 0 0 1-2.25 0Zm4.875 0A.75.75 0 0 1 8.25 6h12a.75.75 0 0 1 0 1.5h-12a.75.75 0 0 1-.75-.75ZM2.625 12a1.125 1.125 0 1 1 2.25 0 1.125 1.125 0 0 1-2.25 0ZM7.5 12a.75.75 0 0 1 .75-.75h12a.75.75 0 0 1 0 1.5h-12A.75.75 0 0 1 7.5 12Zm-4.875 5.25a1.125 1.125 0 1 1 2.25 0 1.125 1.125 0 0 1-2.25 0Zm4.875 0a.75.75 0 0 1 .75-.75h12a.75.75 0 0 1 0 1.5h-12a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />`,
    },
    'chevron-down': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />`,
        fill: `<path fill-rule="evenodd" d="M12.53 16.28a.75.75 0 0 1-1.06 0l-7.5-7.5a.75.75 0 0 1 1.06-1.06L12 14.69l6.97-6.97a.75.75 0 1 1 1.06 1.06l-7.5 7.5Z" clip-rule="evenodd" />`,
    },
    'chevron-right': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />`,
        fill: `<path fill-rule="evenodd" d="M16.28 11.47a.75.75 0 0 1 0 1.06l-7.5 7.5a.75.75 0 0 1-1.06-1.06L14.69 12 7.72 5.03a.75.75 0 0 1 1.06-1.06l7.5 7.5Z" clip-rule="evenodd" />`,
    },
    'chevron-left': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />`,
        fill: `<path fill-rule="evenodd" d="M7.72 12.53a.75.75 0 0 1 0-1.06l7.5-7.5a.75.75 0 1 1 1.06 1.06L9.31 12l6.97 6.97a.75.75 0 1 1-1.06 1.06l-7.5-7.5Z" clip-rule="evenodd" />`,
    },
    // ── Actions ──────────────────────────────────────────────────────────────────
    plus: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />`,
        fill: `<path fill-rule="evenodd" d="M12 3.75a.75.75 0 0 1 .75.75v6.75h6.75a.75.75 0 0 1 0 1.5h-6.75v6.75a.75.75 0 0 1-1.5 0v-6.75H4.5a.75.75 0 0 1 0-1.5h6.75V4.5a.75.75 0 0 1 .75-.75Z" clip-rule="evenodd" />`,
    },
    edit: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125" />`,
        fill: `<path d="M21.731 2.269a2.625 2.625 0 0 0-3.712 0l-1.157 1.157 3.712 3.712 1.157-1.157a2.625 2.625 0 0 0 0-3.712ZM19.513 8.199l-3.712-3.712-12.15 12.15a5.25 5.25 0 0 0-1.32 2.214l-.8 2.685a.75.75 0 0 0 .933.933l2.685-.8a5.25 5.25 0 0 0 2.214-1.32L19.513 8.2Z" />`,
    },
    trash: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />`,
        fill: `<path d="M3.375 3C2.339 3 1.5 3.84 1.5 4.875v.75c0 1.036.84 1.875 1.875 1.875h17.25c1.035 0 1.875-.84 1.875-1.875v-.75C22.5 3.839 21.66 3 20.625 3H3.375Z" /><path fill-rule="evenodd" d="M3.087 9l.54 9.176A3 3 0 0 0 6.62 21h10.757a3 3 0 0 0 2.995-2.824L20.913 9H3.087Zm6.163 3.75A.75.75 0 0 1 10 12h4a.75.75 0 0 1 0 1.5h-4a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />`,
    },
    sparkles: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9.813 15.904 9.375 17.25l-.438-1.346a2.25 2.25 0 0 0-1.591-1.591L6 13.875l1.346-.438a2.25 2.25 0 0 0 1.591-1.591L9.375 10.5l.438 1.346a2.25 2.25 0 0 0 1.591 1.591l1.346.438-1.346.438a2.25 2.25 0 0 0-1.591 1.591ZM18.259 8.715 18 9.75l-.259-1.035a3.375 3.375 0 0 0-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 0 0 2.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 0 0 2.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 0 0-2.456 2.456ZM16.894 20.567 16.5 21.75l-.394-1.183a2.25 2.25 0 0 0-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 0 0 1.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 0 0 1.423 1.423l1.183.394-1.183.394a2.25 2.25 0 0 0-1.423 1.423Z" />`,
        fill: `<path fill-rule="evenodd" d="M9 4.5a.75.75 0 0 1 .721.544l.813 2.846a3.75 3.75 0 0 0 2.576 2.576l2.846.813a.75.75 0 0 1 0 1.442l-2.846.813a3.75 3.75 0 0 0-2.576 2.576l-.813 2.846a.75.75 0 0 1-1.442 0l-.813-2.846a3.75 3.75 0 0 0-2.576-2.576l-2.846-.813a.75.75 0 0 1 0-1.442l2.846-.813A3.75 3.75 0 0 0 7.466 7.89l.813-2.846A.75.75 0 0 1 9 4.5ZM18 1.5a.75.75 0 0 1 .728.568l.258 1.036c.236.94.97 1.674 1.91 1.91l1.036.258a.75.75 0 0 1 0 1.456l-1.036.258a2.625 2.625 0 0 0-1.91 1.91l-.258 1.036a.75.75 0 0 1-1.456 0l-.258-1.036a2.625 2.625 0 0 0-1.91-1.91l-1.036-.258a.75.75 0 0 1 0-1.456l1.036-.258a2.625 2.625 0 0 0 1.91-1.91l.258-1.036A.75.75 0 0 1 18 1.5ZM16.5 15a.75.75 0 0 1 .712.513l.394 1.183c.15.447.5.799.948.948l1.183.395a.75.75 0 0 1 0 1.422l-1.183.395c-.447.15-.799.5-.948.948l-.395 1.183a.75.75 0 0 1-1.422 0l-.395-1.183a1.5 1.5 0 0 0-.948-.948l-1.183-.395a.75.75 0 0 1 0-1.422l1.183-.395a1.5 1.5 0 0 0 .948-.948l.395-1.183A.75.75 0 0 1 16.5 15Z" clip-rule="evenodd" />`,
    },
    heart: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z" />`,
        fill: `<path d="m11.645 20.91-.007-.003-.022-.012a15.247 15.247 0 0 1-.383-.218 25.18 25.18 0 0 1-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0 1 12 5.052 5.5 5.5 0 0 1 16.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 0 1-4.244 3.17 15.247 15.247 0 0 1-.383.219l-.022.012-.007.004-.003.001a.752.752 0 0 1-.704 0l-.003-.001Z" />`,
    },
    check: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 6 6 9-13.5" />`,
        fill: `<path fill-rule="evenodd" d="M19.916 4.626a.75.75 0 0 1 .208 1.04l-9 13.5a.75.75 0 0 1-1.154.114l-6-6a.75.75 0 0 1 1.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 0 1 1.04-.208Z" clip-rule="evenodd" />`,
    },
    x: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />`,
        fill: `<path fill-rule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd" />`,
    },
    search: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />`,
        fill: `<path fill-rule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5ZM2.25 10.5a8.25 8.25 0 1 1 14.59 5.28l4.69 4.69a.75.75 0 1 1-1.06 1.06l-4.69-4.69A8.25 8.25 0 0 1 2.25 10.5Z" clip-rule="evenodd" />`,
    },
    refresh: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />`,
        fill: `<path fill-rule="evenodd" d="M4.755 10.059a7.5 7.5 0 0 1 12.548-3.364l1.903 1.903h-3.183a.75.75 0 1 0 0 1.5h4.992a.75.75 0 0 0 .75-.75V4.356a.75.75 0 0 0-1.5 0v3.18l-1.9-1.9A9 9 0 0 0 3.306 9.67a.75.75 0 1 0 1.45.388Zm15.408 3.352a.75.75 0 0 0-.919.53 7.5 7.5 0 0 1-12.548 3.364l-1.902-1.903h3.183a.75.75 0 0 0 0-1.5H2.984a.75.75 0 0 0-.75.75v4.992a.75.75 0 0 0 1.5 0v-3.18l1.9 1.9a9 9 0 0 0 15.059-4.035.75.75 0 0 0-.53-.918Z" clip-rule="evenodd" />`,
    },
    // ── People ───────────────────────────────────────────────────────────────────
    user: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />`,
        fill: `<path fill-rule="evenodd" d="M7.5 6a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 0 1-.437-.695Z" clip-rule="evenodd" />`,
    },
    users: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />`,
        fill: `<path d="M4.5 6.375a4.125 4.125 0 1 1 8.25 0 4.125 4.125 0 0 1-8.25 0ZM14.25 8.625a3.375 3.375 0 1 1 6.75 0 3.375 3.375 0 0 1-6.75 0ZM1.5 19.125a7.125 7.125 0 0 1 14.25 0v.003l-.001.119a.75.75 0 0 1-.363.63 13.067 13.067 0 0 1-6.761 1.873c-2.472 0-4.786-.684-6.76-1.873a.75.75 0 0 1-.364-.63l-.001-.122ZM17.25 19.128l-.001.144a2.25 2.25 0 0 1-.233.96 10.088 10.088 0 0 0 5.06-1.01.75.75 0 0 0 .42-.643 4.875 4.875 0 0 0-6.957-4.611 8.586 8.586 0 0 1 1.71 5.157v.003Z" />`,
    },
    // ── Business ─────────────────────────────────────────────────────────────────
    building: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" />`,
        fill: `<path fill-rule="evenodd" d="M4.5 2.25a.75.75 0 0 0 0 1.5v16.5h-.75a.75.75 0 0 0 0 1.5h16.5a.75.75 0 0 0 0-1.5h-.75V3.75a.75.75 0 0 0 0-1.5h-15ZM9 6a.75.75 0 0 0 0 1.5h1.5a.75.75 0 0 0 0-1.5H9Zm-.75 3.75A.75.75 0 0 1 9 9h1.5a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM9 12a.75.75 0 0 0 0 1.5h1.5a.75.75 0 0 0 0-1.5H9Zm3.75-5.25A.75.75 0 0 1 13.5 6H15a.75.75 0 0 1 0 1.5h-1.5a.75.75 0 0 1-.75-.75ZM13.5 9a.75.75 0 0 0 0 1.5H15A.75.75 0 0 0 15 9h-1.5Zm-.75 3.75a.75.75 0 0 1 .75-.75H15a.75.75 0 0 1 0 1.5h-1.5a.75.75 0 0 1-.75-.75ZM9 19.5v-2.25a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 .75.75V19.5H9Z" clip-rule="evenodd" />`,
    },
    briefcase: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M20.25 14.15v4.25c0 1.094-.787 2.036-1.872 2.18-2.087.277-4.216.42-6.378.42s-4.291-.143-6.378-.42c-1.085-.144-1.872-1.086-1.872-2.18v-4.25m16.5 0a2.18 2.18 0 0 0 .75-1.661V8.706c0-1.081-.768-2.015-1.837-2.175a48.114 48.114 0 0 0-3.413-.387m4.5 8.006c-.194.165-.42.295-.673.38A23.978 23.978 0 0 1 12 15.75c-2.648 0-5.195-.429-7.577-1.22a2.016 2.016 0 0 1-.673-.38m0 0A2.18 2.18 0 0 1 3 12.489V8.706c0-1.081.768-2.015 1.837-2.175a48.111 48.111 0 0 1 3.413-.387m7.5 0V5.25A2.25 2.25 0 0 0 13.5 3h-3a2.25 2.25 0 0 0-2.25 2.25v.894m7.5 0a48.667 48.667 0 0 0-7.5 0M12 12.75h.008v.008H12v-.008Z" />`,
        fill: `<path fill-rule="evenodd" d="M7.5 5.25a3 3 0 0 1 3-3h3a3 3 0 0 1 3 3v.205c.933.085 1.857.197 2.774.334 1.454.218 2.476 1.483 2.476 2.917v3.033c0 1.211-.734 2.352-1.936 2.752A24.726 24.726 0 0 1 12 15.75c-2.73 0-5.357-.442-7.814-1.259-1.202-.4-1.936-1.541-1.936-2.752V8.706c0-1.434 1.022-2.7 2.476-2.917A48.814 48.814 0 0 1 7.5 5.455V5.25Zm7.5 0v.09a49.488 49.488 0 0 0-6 0v-.09a1.5 1.5 0 0 1 1.5-1.5h3a1.5 1.5 0 0 1 1.5 1.5Zm-3 8.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clip-rule="evenodd" /><path d="M3 18.4v-2.796a4.3 4.3 0 0 0 .713.31A26.226 26.226 0 0 0 12 17.25c2.892 0 5.68-.468 8.287-1.335.252-.084.49-.189.713-.311V18.4c0 1.452-1.047 2.728-2.523 2.923-2.12.282-4.282.427-6.477.427a49.19 49.19 0 0 1-6.477-.427C4.047 21.128 3 19.852 3 18.4Z" />`,
    },
    calendar: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5" />`,
        fill: `<path fill-rule="evenodd" d="M6.75 2.25A.75.75 0 0 1 7.5 3v1.5h9V3A.75.75 0 0 1 18 3v1.5h.75a3 3 0 0 1 3 3v11.25a3 3 0 0 1-3 3H5.25a3 3 0 0 1-3-3V7.5a3 3 0 0 1 3-3H6V3a.75.75 0 0 1 .75-.75Zm13.5 9a1.5 1.5 0 0 0-1.5-1.5H5.25a1.5 1.5 0 0 0-1.5 1.5v7.5a1.5 1.5 0 0 0 1.5 1.5h13.5a1.5 1.5 0 0 0 1.5-1.5v-7.5Z" clip-rule="evenodd" />`,
    },
    tag: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9.568 3H5.25A2.25 2.25 0 0 0 3 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 0 0 5.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 0 0 9.568 3Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M6 6h.008v.008H6V6Z" />`,
        fill: `<path fill-rule="evenodd" d="M5.25 2.25a3 3 0 0 0-3 3v4.318a3 3 0 0 0 .879 2.121l9.58 9.581c.92.92 2.39.974 3.317.058l4.828-4.829c.933-.932.88-2.438-.04-3.358L11.23 3.56A3 3 0 0 0 9.107 2.68l-3.857-.43Zm1.5 7.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z" clip-rule="evenodd" />`,
    },
    'credit-card': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Z" />`,
        fill: `<path d="M4.5 3.75a3 3 0 0 0-3 3v.75h21v-.75a3 3 0 0 0-3-3h-15Z" /><path fill-rule="evenodd" d="M22.5 9.75h-21v7.5a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3v-7.5Zm-18 3.75a.75.75 0 0 1 .75-.75h6a.75.75 0 0 1 0 1.5h-6a.75.75 0 0 1-.75-.75Zm.75 2.25a.75.75 0 0 0 0 1.5h3a.75.75 0 0 0 0-1.5h-3Z" clip-rule="evenodd" />`,
    },
    // ── UI / Feedback ─────────────────────────────────────────────────────────────
    settings: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.325.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 0 1 1.37.49l1.296 2.247a1.125 1.125 0 0 1-.26 1.431l-1.003.827c-.293.241-.438.613-.43.992a7.723 7.723 0 0 1 0 .255c-.008.378.137.75.43.991l1.004.827c.424.35.534.955.26 1.43l-1.298 2.247a1.125 1.125 0 0 1-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.47 6.47 0 0 1-.22.128c-.331.183-.581.495-.644.869l-.213 1.281c-.09.543-.56.94-1.11.94h-2.594c-.55 0-1.019-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 0 1-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 0 1-1.369-.49l-1.297-2.247a1.125 1.125 0 0 1 .26-1.431l1.004-.827c.292-.24.437-.613.43-.991a6.932 6.932 0 0 1 0-.255c.007-.38-.138-.751-.43-.992l-1.004-.827a1.125 1.125 0 0 1-.26-1.43l1.297-2.247a1.125 1.125 0 0 1 1.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.086.22-.128.332-.183.582-.495.644-.869l.214-1.28Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />`,
        fill: `<path fill-rule="evenodd" d="M11.078 2.25c-.917 0-1.699.663-1.85 1.567L9.05 4.889c-.02.12-.115.26-.297.348a7.493 7.493 0 0 0-.986.57c-.166.115-.334.126-.45.083L6.3 5.508a1.875 1.875 0 0 0-2.282.819l-.922 1.597a1.875 1.875 0 0 0 .432 2.385l.84.692c.095.078.17.229.154.43a7.598 7.598 0 0 0 0 1.139c.015.2-.059.352-.153.43l-.841.692a1.875 1.875 0 0 0-.432 2.385l.922 1.597a1.875 1.875 0 0 0 2.282.818l1.019-.382c.115-.043.283-.031.45.082.312.214.641.405.986.57.182.088.277.228.297.35l.178 1.071c.151.904.933 1.567 1.85 1.567h1.844c.916 0 1.699-.663 1.85-1.567l.178-1.072c.02-.12.114-.26.297-.349.344-.165.673-.356.985-.57.167-.114.335-.125.45-.082l1.02.382a1.875 1.875 0 0 0 2.28-.819l.923-1.597a1.875 1.875 0 0 0-.432-2.385l-.84-.692c-.095-.078-.17-.229-.154-.43a7.614 7.614 0 0 0 0-1.139c-.016-.2.059-.352.153-.43l.84-.692c.708-.582.891-1.59.433-2.385l-.922-1.597a1.875 1.875 0 0 0-2.282-.818l-1.02.382c-.114.043-.282.031-.449-.083a7.49 7.49 0 0 0-.985-.57c-.183-.087-.277-.227-.297-.348l-.179-1.072a1.875 1.875 0 0 0-1.85-1.567h-1.843ZM12 15.75a3.75 3.75 0 1 0 0-7.5 3.75 3.75 0 0 0 0 7.5Z" clip-rule="evenodd" />`,
    },
    bell: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 0 0 5.454-1.31A8.967 8.967 0 0 1 18 9.75V9A6 6 0 0 0 6 9v.75a8.967 8.967 0 0 1-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 0 1-5.714 0m5.714 0a3 3 0 1 1-5.714 0" />`,
        fill: `<path fill-rule="evenodd" d="M5.25 9a6.75 6.75 0 0 1 13.5 0v.75c0 2.123.8 4.057 2.118 5.52a.75.75 0 0 1-.297 1.206c-1.544.57-3.16.99-4.831 1.243a3.75 3.75 0 1 1-7.48 0 24.585 24.585 0 0 1-4.831-1.244.75.75 0 0 1-.298-1.205A8.217 8.217 0 0 0 5.25 9.75V9Zm4.502 8.9a2.25 2.25 0 1 0 4.496 0 25.057 25.057 0 0 1-4.496 0Z" clip-rule="evenodd" />`,
    },
    eye: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />`,
        fill: `<path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" /><path fill-rule="evenodd" d="M1.323 11.447C2.811 6.976 7.028 3.75 12.001 3.75c4.97 0 9.185 3.223 10.675 7.69.12.362.12.752 0 1.113-1.487 4.471-5.705 7.697-10.677 7.697-4.97 0-9.186-3.223-10.675-7.69a1.762 1.762 0 0 1 0-1.113ZM17.25 12a5.25 5.25 0 1 1-10.5 0 5.25 5.25 0 0 1 10.5 0Z" clip-rule="evenodd" />`,
    },
    'message-circle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.35.026.67.21.865.501L12 21l2.755-4.133a1.14 1.14 0 0 1 .865-.501 48.172 48.172 0 0 0 3.423-.379c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z" />`,
        fill: `<path fill-rule="evenodd" d="M4.848 2.771A49.144 49.144 0 0 1 12 2.25c2.43 0 4.817.178 7.152.52 1.978.292 3.348 2.024 3.348 3.97v6.02c0 1.946-1.37 3.678-3.348 3.97a48.901 48.901 0 0 1-3.476.383.39.39 0 0 0-.297.17l-2.755 4.133a.75.75 0 0 1-1.248 0l-2.755-4.133a.39.39 0 0 0-.297-.17 48.9 48.9 0 0 1-3.476-.384c-1.978-.29-3.348-2.024-3.348-3.97V6.741c0-1.946 1.37-3.68 3.348-3.97Z" clip-rule="evenodd" />`,
    },
    'paper-airplane': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6 12 3.269 3.125A59.769 59.769 0 0 1 21.485 12 59.768 59.768 0 0 1 3.27 20.875L5.999 12Zm0 0h7.5" />`,
        fill: `<path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />`,
    },
    'help-circle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 5.25h.008v.008H12v-.008Z" />`,
        fill: `<path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm11.378-3.917c-.89-.777-2.366-.777-3.255 0a.75.75 0 0 1-.988-1.129c1.454-1.272 3.776-1.272 5.23 0 1.513 1.324 1.513 3.518 0 4.842a3.75 3.75 0 0 1-.837.552c-.676.328-1.028.774-1.028 1.152v.75a.75.75 0 0 1-1.5 0v-.75c0-1.279 1.06-2.107 1.875-2.502.182-.088.351-.199.503-.331.83-.727.83-1.857 0-2.584ZM12 18a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clip-rule="evenodd" />`,
    },
    layers: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6.429 9.75 2.25 12l4.179 2.25m0-4.5 5.571 3 5.571-3m-11.142 0L2.25 7.5 12 2.25l9.75 5.25-4.179 2.25m0 0L21.75 12l-4.179 2.25m0 0 4.179 2.25L12 21.75 2.25 16.5l4.179-2.25m11.142 0-5.571 3-5.571-3" />`,
        fill: `<path d="M11.644 1.59a.75.75 0 0 1 .712 0l9.75 5.25a.75.75 0 0 1 0 1.32l-9.75 5.25a.75.75 0 0 1-.712 0l-9.75-5.25a.75.75 0 0 1 0-1.32l9.75-5.25Z" /><path d="m3.265 10.602 7.668 4.129a2.25 2.25 0 0 0 2.134 0l7.668-4.13 1.37.739a.75.75 0 0 1 0 1.32l-9.75 5.25a.75.75 0 0 1-.71 0l-9.75-5.25a.75.75 0 0 1 0-1.32l1.37-.738Z" /><path d="m10.933 19.231-7.668-4.13-1.37.739a.75.75 0 0 0 0 1.32l9.75 5.25c.221.12.489.12.71 0l9.75-5.25a.75.75 0 0 0 0-1.32l-1.37-.738-7.668 4.13a2.25 2.25 0 0 1-2.134-.001Z" />`,
    },
    'bar-chart': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" />`,
        fill: `<path d="M18.375 2.25c-1.035 0-1.875.84-1.875 1.875v15.75c0 1.035.84 1.875 1.875 1.875h.75c1.035 0 1.875-.84 1.875-1.875V4.125c0-1.036-.84-1.875-1.875-1.875h-.75ZM9.75 8.625c0-1.036.84-1.875 1.875-1.875h.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-.75a1.875 1.875 0 0 1-1.875-1.875V8.625ZM3 13.125c0-1.036.84-1.875 1.875-1.875h.75c1.036 0 1.875.84 1.875 1.875v6.75c0 1.035-.84 1.875-1.875 1.875h-.75A1.875 1.875 0 0 1 3 19.875v-6.75Z" />`,
    },
    clipboard: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 0 0 .75-.75 2.25 2.25 0 0 0-.1-.664m-5.8 0A2.251 2.251 0 0 1 13.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25ZM6.75 12h.008v.008H6.75V12Zm0 3h.008v.008H6.75V15Zm0 3h.008v.008H6.75V18Z" />`,
        fill: `<path fill-rule="evenodd" d="M7.502 6h7.128A3.375 3.375 0 0 1 18 9.375v9.375a3 3 0 0 0 3-3V6.108c0-1.505-1.125-2.811-2.664-2.94a48.972 48.972 0 0 0-.673-.05A3 3 0 0 0 15 1.5h-1.5a3 3 0 0 0-2.663 1.618c-.225.015-.45.032-.673.05C8.662 3.295 7.554 4.542 7.502 6ZM13.5 3A1.5 1.5 0 0 0 12 4.5h4.5A1.5 1.5 0 0 0 15 3h-1.5Z" clip-rule="evenodd" /><path fill-rule="evenodd" d="M3 9.375C3 8.339 3.84 7.5 4.875 7.5h9.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-9.75A1.875 1.875 0 0 1 3 20.625V9.375Zm9.586 4.594a.75.75 0 0 0-1.172-.938l-2.476 3.096-.908-.907a.75.75 0 0 0-1.06 1.06l1.5 1.5a.75.75 0 0 0 1.116-.062l3-3.75Z" clip-rule="evenodd" />`,
    },
    'shopping-cart': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />`,
        fill: `<path d="M2.25 2.25a.75.75 0 0 0 0 1.5h1.386c.17 0 .318.114.362.278l2.558 9.592a3.752 3.752 0 0 0-2.806 3.63c0 .414.336.75.75.75h15.75a.75.75 0 0 0 0-1.5H5.378A2.25 2.25 0 0 1 7.5 15h11.218a.75.75 0 0 0 .674-.421 60.358 60.358 0 0 0 2.96-7.228.75.75 0 0 0-.525-.965A60.864 60.864 0 0 0 5.68 4.509l-.232-.867A1.875 1.875 0 0 0 3.636 2.25H2.25ZM3.75 20.25a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0ZM16.5 20.25a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Z" />`,
    },
    // ── Media ────────────────────────────────────────────────────────────────────
    photo: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />`,
        fill: `<path fill-rule="evenodd" d="M1.5 6a2.25 2.25 0 0 1 2.25-2.25h16.5A2.25 2.25 0 0 1 22.5 6v12a2.25 2.25 0 0 1-2.25 2.25H3.75A2.25 2.25 0 0 1 1.5 18V6ZM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0 0 21 18v-1.94l-2.69-2.689a1.5 1.5 0 0 0-2.12 0l-.88.879.97.97a.75.75 0 1 1-1.06 1.06l-5.16-5.159a1.5 1.5 0 0 0-2.12 0L3 16.061Zm10.125-7.81a1.125 1.125 0 1 1 2.25 0 1.125 1.125 0 0 1-2.25 0Z" clip-rule="evenodd" />`,
    },
    'cloud-arrow-up': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 16.5V9.75m0 0 3 3m-3-3-3 3M6.75 19.5a4.5 4.5 0 0 1-1.41-8.775 5.25 5.25 0 0 1 10.233-2.33 3 3 0 0 1 3.758 3.848A3.752 3.752 0 0 1 18 19.5H6.75Z" />`,
        fill: `<path fill-rule="evenodd" d="M10.5 3.75a6 6 0 0 0-5.98 6.496A5.25 5.25 0 0 0 6.75 20.25H18a4.5 4.5 0 0 0 2.206-8.423 3.75 3.75 0 0 0-4.133-4.303A6.001 6.001 0 0 0 10.5 3.75Zm2.03 5.47a.75.75 0 0 0-1.06 0l-3 3a.75.75 0 1 0 1.06 1.06l1.72-1.72v4.94a.75.75 0 0 0 1.5 0v-4.94l1.72 1.72a.75.75 0 1 0 1.06-1.06l-3-3Z" clip-rule="evenodd" />`,
    },
    // ── Misc ─────────────────────────────────────────────────────────────────────
    'ellipsis-vertical': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 6.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5ZM12 12.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5ZM12 18.75a.75.75 0 1 1 0-1.5.75.75 0 0 1 0 1.5Z" />`,
        fill: `<path fill-rule="evenodd" d="M10.5 6a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Zm0 6a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Zm0 6a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Z" clip-rule="evenodd" />`,
    },
    'x-mark': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12" />`,
        fill: `<path fill-rule="evenodd" d="M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z" clip-rule="evenodd" />`,
    },
    clock: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />`,
        fill: `<path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 6a.75.75 0 0 0-1.5 0v6c0 .414.336.75.75.75h4.5a.75.75 0 0 0 0-1.5h-3.75V6Z" clip-rule="evenodd" />`,
    },
    'chevron-up': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m4.5 15.75 7.5-7.5 7.5 7.5" />`,
        fill: `<path fill-rule="evenodd" d="M11.47 7.72a.75.75 0 0 1 1.06 0l7.5 7.5a.75.75 0 1 1-1.06 1.06L12 9.31l-6.97 6.97a.75.75 0 0 1-1.06-1.06l7.5-7.5Z" clip-rule="evenodd" />`,
    },
    'lock-closed': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />`,
        fill: `<path fill-rule="evenodd" d="M12 1.5a5.25 5.25 0 0 0-5.25 5.25v3a3 3 0 0 0-3 3v6.75a3 3 0 0 0 3 3h10.5a3 3 0 0 0 3-3v-6.75a3 3 0 0 0-3-3v-3c0-2.9-2.35-5.25-5.25-5.25Zm3.75 8.25v-3a3.75 3.75 0 1 0-7.5 0v3h7.5Z" clip-rule="evenodd" />`,
    },
    phone: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 4.5v2.25Z" />`,
        fill: `<path fill-rule="evenodd" d="M1.5 4.5a3 3 0 0 1 3-3h1.372c.86 0 1.61.586 1.819 1.42l1.105 4.423a1.875 1.875 0 0 1-.694 1.955l-1.293.97c-.135.101-.164.249-.126.352a11.285 11.285 0 0 0 6.697 6.697c.103.038.25.009.352-.126l.97-1.293a1.875 1.875 0 0 1 1.955-.694l4.423 1.105c.834.209 1.42.959 1.42 1.82V19.5a3 3 0 0 1-3 3h-2.25C8.552 22.5 1.5 15.448 1.5 6.75V4.5Z" clip-rule="evenodd" />`,
    },
    envelope: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />`,
        fill: `<path d="M1.5 8.67v8.58a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3V8.67l-8.928 5.493a3 3 0 0 1-3.144 0L1.5 8.67Z" /><path d="M22.5 6.908V6.75a3 3 0 0 0-3-3h-15a3 3 0 0 0-3 3v.158l9.714 5.978a1.5 1.5 0 0 0 1.572 0L22.5 6.908Z" />`,
    },
    'calendar-days': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 0 1 2.25-2.25h13.5A2.25 2.25 0 0 1 21 7.5v11.25m-18 0A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75m-18 0v-7.5A2.25 2.25 0 0 1 5.25 9h13.5A2.25 2.25 0 0 1 21 11.25v7.5m-9-6h.008v.008H12v-.008ZM12 15h.008v.008H12V15Zm0 2.25h.008v.008H12v-.008ZM9.75 15h.008v.008H9.75V15Zm0 2.25h.008v.008H9.75v-.008ZM7.5 15h.008v.008H7.5V15Zm0 2.25h.008v.008H7.5v-.008Zm6.75-4.5h.008v.008h-.008v-.008Zm0 2.25h.008v.008h-.008V15Zm0 2.25h.008v.008h-.008v-.008Zm2.25-4.5h.008v.008H16.5v-.008Zm0 2.25h.008v.008H16.5V15Z" />`,
        fill: `<path d="M12.75 12.75a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0ZM7.5 15.75a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm.75 2.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm3.75-2.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm.75 2.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm3.75-2.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Zm.75 2.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" /><path fill-rule="evenodd" d="M6.75 2.25A.75.75 0 0 1 7.5 3v1.5h9V3A.75.75 0 0 1 18 3v1.5h.75a3 3 0 0 1 3 3v11.25a3 3 0 0 1-3 3H5.25a3 3 0 0 1-3-3V7.5a3 3 0 0 1 3-3H6V3a.75.75 0 0 1 .75-.75Zm13.5 9a1.5 1.5 0 0 0-1.5-1.5H5.25a1.5 1.5 0 0 0-1.5 1.5v7.5a1.5 1.5 0 0 0 1.5 1.5h13.5a1.5 1.5 0 0 0 1.5-1.5v-7.5Z" clip-rule="evenodd" />`,
    },
    'table-cells': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3.375 19.5h17.25m-17.25 0a1.125 1.125 0 0 1-1.125-1.125M3.375 19.5h1.5C5.496 19.5 6 18.996 6 18.375m-3.75 0V5.625m0 12.75v-1.5c0-.621.504-1.125 1.125-1.125m18.375 2.625V5.625m0 12.75c0 .621-.504 1.125-1.125 1.125h-1.5m1.5-1.125c0-.621-.504-1.125-1.125-1.125M6 18.375V15m0 3.375c0 .621.504 1.125 1.125 1.125h10.5c.621 0 1.125-.504 1.125-1.125m-12.75 0V15m12.75 3.375V15M6 15V9.75m12 5.25V9.75m-12 0V7.125m12 2.625V7.125m0 0H7.5m10.5 0c0-.621-.504-1.125-1.125-1.125h-8.25C7.629 6 7.125 6.504 7.125 7.125m10.5 0V7.5A2.25 2.25 0 0 0 15.375 5.25H8.625A2.25 2.25 0 0 0 6.375 7.5v-.375m0 0H3.375m3 0H21m-3 0v.375m0-.375h-3" />`,
        fill: `<path fill-rule="evenodd" d="M1.5 5.625c0-1.036.84-1.875 1.875-1.875h17.25c1.035 0 1.875.84 1.875 1.875v12.75c0 1.035-.84 1.875-1.875 1.875H3.375A1.875 1.875 0 0 1 1.5 18.375V5.625ZM21 9.375A.375.375 0 0 0 20.625 9h-7.5a.375.375 0 0 0-.375.375v1.5c0 .207.168.375.375.375h7.5A.375.375 0 0 0 21 10.875v-1.5Zm0 3.75a.375.375 0 0 0-.375-.375h-7.5a.375.375 0 0 0-.375.375v1.5c0 .207.168.375.375.375h7.5a.375.375 0 0 0 .375-.375v-1.5Zm0 3.75a.375.375 0 0 0-.375-.375h-7.5a.375.375 0 0 0-.375.375v1.5c0 .207.168.375.375.375h7.5a.375.375 0 0 0 .375-.375v-1.5ZM10.875 18.75a.375.375 0 0 0 .375-.375v-1.5a.375.375 0 0 0-.375-.375h-7.5a.375.375 0 0 0-.375.375v1.5c0 .207.168.375.375.375h7.5ZM3.375 15h7.5a.375.375 0 0 0 .375-.375v-1.5a.375.375 0 0 0-.375-.375h-7.5a.375.375 0 0 0-.375.375v1.5c0 .207.168.375.375.375Zm0-3.75h7.5a.375.375 0 0 0 .375-.375v-1.5A.375.375 0 0 0 10.875 9h-7.5A.375.375 0 0 0 3 9.375v1.5c0 .207.168.375.375.375Z" clip-rule="evenodd" />`,
    },
    pencil: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L6.832 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125" />`,
        fill: `<path d="M21.731 2.269a2.625 2.625 0 0 0-3.712 0l-1.157 1.157 3.712 3.712 1.157-1.157a2.625 2.625 0 0 0 0-3.712ZM19.513 8.199l-3.712-3.712-8.4 8.4a5.25 5.25 0 0 0-1.32 2.214l-.8 2.685a.75.75 0 0 0 .933.933l2.685-.8a5.25 5.25 0 0 0 2.214-1.32l8.4-8.4Z" />`,
    },
    // ── CRM / Vocero — Heroicons v2 (11-a-solercia-ui, PR2) ───────────────────────
    funnel: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 3c2.755 0 5.455.232 8.083.678.533.09.917.556.917 1.096v1.044a2.25 2.25 0 0 1-.659 1.591l-5.432 5.432a2.25 2.25 0 0 0-.659 1.591v2.927a2.25 2.25 0 0 1-1.244 2.013L9.75 21v-6.568a2.25 2.25 0 0 0-.659-1.591L3.659 7.409A2.25 2.25 0 0 1 3 5.818V4.774c0-.54.384-1.006.917-1.096A48.32 48.32 0 0 1 12 3Z" />`,
        fill: `<path fill-rule="evenodd" d="M3.792 2.938A49.069 49.069 0 0 1 12 2.25c2.797 0 5.54.236 8.209.688a1.857 1.857 0 0 1 1.541 1.836v1.044a3 3 0 0 1-.879 2.121l-6.182 6.182a1.5 1.5 0 0 0-.439 1.061v2.927a3 3 0 0 1-1.658 2.684l-1.757.878A.75.75 0 0 1 9.75 21v-5.818a1.5 1.5 0 0 0-.44-1.06L3.13 7.938a3 3 0 0 1-.879-2.121V4.774c0-.897.64-1.683 1.542-1.836Z" clip-rule="evenodd" />`,
    },
    'view-columns': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9 4.5v15m6-15v15m-10.875 0h15.75c.621 0 1.125-.504 1.125-1.125V5.625c0-.621-.504-1.125-1.125-1.125H4.125C3.504 4.5 3 5.004 3 5.625v12.75c0 .621.504 1.125 1.125 1.125Z" />`,
        fill: `<path d="M15 3.75H9v16.5h6V3.75ZM16.5 20.25h3.375c1.035 0 1.875-.84 1.875-1.875V5.625c0-1.036-.84-1.875-1.875-1.875H16.5v16.5ZM4.125 3.75H7.5v16.5H4.125a1.875 1.875 0 0 1-1.875-1.875V5.625c0-1.036.84-1.875 1.875-1.875Z" />`,
    },
    'arrows-up-down': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3 7.5 7.5 3m0 0L12 7.5M7.5 3v13.5m13.5 0L16.5 21m0 0L12 16.5m4.5 4.5V7.5" />`,
        fill: `<path fill-rule="evenodd" d="M6.97 2.47a.75.75 0 0 1 1.06 0l4.5 4.5a.75.75 0 0 1-1.06 1.06L8.25 4.81V16.5a.75.75 0 0 1-1.5 0V4.81L3.53 8.03a.75.75 0 0 1-1.06-1.06l4.5-4.5Zm9.53 4.28a.75.75 0 0 1 .75.75v11.69l3.22-3.22a.75.75 0 1 1 1.06 1.06l-4.5 4.5a.75.75 0 0 1-1.06 0l-4.5-4.5a.75.75 0 1 1 1.06-1.06l3.22 3.22V7.5a.75.75 0 0 1 .75-.75Z" clip-rule="evenodd" />`,
    },
    'arrows-pointing-out': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" />`,
        fill: `<path fill-rule="evenodd" d="M15 3.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-1.5 0V5.56l-3.97 3.97a.75.75 0 1 1-1.06-1.06l3.97-3.97h-2.69a.75.75 0 0 1-.75-.75Zm-12 0A.75.75 0 0 1 3.75 3h4.5a.75.75 0 0 1 0 1.5H5.56l3.97 3.97a.75.75 0 0 1-1.06 1.06L4.5 5.56v2.69a.75.75 0 0 1-1.5 0v-4.5Zm11.47 11.78a.75.75 0 1 1 1.06-1.06l3.97 3.97v-2.69a.75.75 0 0 1 1.5 0v4.5a.75.75 0 0 1-.75.75h-4.5a.75.75 0 0 1 0-1.5h2.69l-3.97-3.97Zm-4.94-1.06a.75.75 0 0 1 0 1.06L5.56 19.5h2.69a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75v-4.5a.75.75 0 0 1 1.5 0v2.69l3.97-3.97a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd" />`,
    },
    'check-circle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />`,
        fill: `<path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm13.36-1.814a.75.75 0 1 0-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 0 0-1.06 1.06l2.25 2.25a.75.75 0 0 0 1.14-.094l3.75-5.25Z" clip-rule="evenodd" />`,
    },
    'x-circle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />`,
        fill: `<path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm-1.72 6.97a.75.75 0 1 0-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 1 0 1.06 1.06L12 13.06l1.72 1.72a.75.75 0 1 0 1.06-1.06L13.06 12l1.72-1.72a.75.75 0 1 0-1.06-1.06L12 10.94l-1.72-1.72Z" clip-rule="evenodd" />`,
    },
    'exclamation-triangle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />`,
        fill: `<path fill-rule="evenodd" d="M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003ZM12 8.25a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 1-1.5 0V9a.75.75 0 0 1 .75-.75Zm0 8.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clip-rule="evenodd" />`,
    },
    'exclamation-circle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z" />`,
        fill: `<path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12ZM12 8.25a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 1-1.5 0V9a.75.75 0 0 1 .75-.75Zm0 8.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clip-rule="evenodd" />`,
    },
    trophy: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M16.5 18.75h-9m9 0a3 3 0 0 1 3 3h-15a3 3 0 0 1 3-3m9 0v-3.375c0-.621-.503-1.125-1.125-1.125h-.871M7.5 18.75v-3.375c0-.621.504-1.125 1.125-1.125h.872m5.007 0H9.497m5.007 0a7.454 7.454 0 0 1-.982-3.172M9.497 14.25a7.454 7.454 0 0 0 .981-3.172M5.25 4.236c-.982.143-1.954.317-2.916.52A6.003 6.003 0 0 0 7.73 9.728M5.25 4.236V4.5c0 2.108.966 3.99 2.48 5.228M5.25 4.236V2.721C7.456 2.41 9.71 2.25 12 2.25c2.291 0 4.545.16 6.75.47v1.516M7.73 9.728a6.726 6.726 0 0 0 2.748 1.35m8.272-6.842V4.5c0 2.108-.966 3.99-2.48 5.228m2.48-5.492a46.32 46.32 0 0 1 2.916.52 6.003 6.003 0 0 1-5.395 4.972m0 0a6.726 6.726 0 0 1-2.749 1.35m0 0a6.772 6.772 0 0 1-3.044 0" />`,
        fill: `<path fill-rule="evenodd" d="M5.166 2.621v.858c-1.035.148-2.059.33-3.071.543a.75.75 0 0 0-.584.859 6.753 6.753 0 0 0 6.138 5.6 6.73 6.73 0 0 0 2.743 1.346A6.707 6.707 0 0 1 9.279 15H8.54c-1.036 0-1.875.84-1.875 1.875V19.5h-.75a2.25 2.25 0 0 0-2.25 2.25c0 .414.336.75.75.75h15a.75.75 0 0 0 .75-.75 2.25 2.25 0 0 0-2.25-2.25h-.75v-2.625c0-1.036-.84-1.875-1.875-1.875h-.739a6.706 6.706 0 0 1-1.112-3.173 6.73 6.73 0 0 0 2.743-1.347 6.753 6.753 0 0 0 6.139-5.6.75.75 0 0 0-.585-.858 47.077 47.077 0 0 0-3.07-.543V2.62a.75.75 0 0 0-.658-.744 49.22 49.22 0 0 0-6.093-.377c-2.063 0-4.096.128-6.093.377a.75.75 0 0 0-.657.744Zm0 2.629c0 1.196.312 2.32.857 3.294A5.266 5.266 0 0 1 3.16 5.337a45.6 45.6 0 0 1 2.006-.343v.256Zm13.5 0v-.256c.674.1 1.343.214 2.006.343a5.265 5.265 0 0 1-2.863 3.207 6.72 6.72 0 0 0 .857-3.294Z" clip-rule="evenodd" />`,
    },
    banknotes: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M2.25 18.75a60.07 60.07 0 0 1 15.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 0 1 3 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 0 0-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 0 1-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 0 0 3 15h-.75M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm3 0h.008v.008H18V10.5Zm-12 0h.008v.008H6V10.5Z" />`,
        fill: `<path d="M12 7.5a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Z" /><path fill-rule="evenodd" d="M1.5 4.875C1.5 3.839 2.34 3 3.375 3h17.25c1.035 0 1.875.84 1.875 1.875v9.75c0 1.036-.84 1.875-1.875 1.875H3.375A1.875 1.875 0 0 1 1.5 14.625v-9.75ZM8.25 9.75a3.75 3.75 0 1 1 7.5 0 3.75 3.75 0 0 1-7.5 0ZM18.75 9a.75.75 0 0 0-.75.75v.008c0 .414.336.75.75.75h.008a.75.75 0 0 0 .75-.75V9.75a.75.75 0 0 0-.75-.75h-.008ZM4.5 9.75A.75.75 0 0 1 5.25 9h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H5.25a.75.75 0 0 1-.75-.75V9.75Z" clip-rule="evenodd" /><path d="M2.25 18a.75.75 0 0 0 0 1.5c5.4 0 10.63.722 15.6 2.075 1.19.324 2.4-.558 2.4-1.82V18.75a.75.75 0 0 0-.75-.75H2.25Z" />`,
    },
    'currency-dollar': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 6v12m-3-2.818.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />`,
        fill: `<path d="M10.464 8.746c.227-.18.497-.311.786-.394v2.795a2.252 2.252 0 0 1-.786-.393c-.394-.313-.546-.681-.546-1.004 0-.323.152-.691.546-1.004ZM12.75 15.662v-2.824c.347.085.664.228.921.421.427.32.579.686.579.991 0 .305-.152.671-.579.991a2.534 2.534 0 0 1-.921.42Z" /><path fill-rule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 6a.75.75 0 0 0-1.5 0v.816a3.836 3.836 0 0 0-1.72.756c-.712.566-1.112 1.35-1.112 2.178 0 .829.4 1.612 1.113 2.178.502.4 1.102.647 1.719.756v2.978a2.536 2.536 0 0 1-.921-.421l-.879-.66a.75.75 0 0 0-.9 1.2l.879.66c.533.4 1.169.645 1.821.75V18a.75.75 0 0 0 1.5 0v-.81a4.124 4.124 0 0 0 1.821-.749c.745-.559 1.179-1.344 1.179-2.191 0-.847-.434-1.632-1.179-2.191a4.122 4.122 0 0 0-1.821-.75V8.354c.29.082.559.213.786.393l.415.33a.75.75 0 0 0 .933-1.175l-.415-.33a3.836 3.836 0 0 0-1.719-.755V6Z" clip-rule="evenodd" />`,
    },
    beaker: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 0 1-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 0 1 4.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0 1 12 15a9.065 9.065 0 0 0-6.23-.693L5 14.5m14.8.8 1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0 1 12 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" />`,
        fill: `<path fill-rule="evenodd" d="M10.5 3.798v5.02a3 3 0 0 1-.879 2.121l-2.377 2.377a9.845 9.845 0 0 1 5.091 1.013 8.315 8.315 0 0 0 5.713.636l.285-.071-3.954-3.955a3 3 0 0 1-.879-2.121v-5.02a23.614 23.614 0 0 0-3 0Zm4.5.138a.75.75 0 0 0 .093-1.495A24.837 24.837 0 0 0 12 2.25a25.048 25.048 0 0 0-3.093.191A.75.75 0 0 0 9 3.936v4.882a1.5 1.5 0 0 1-.44 1.06l-6.293 6.294c-1.62 1.621-.903 4.475 1.471 4.88 2.686.46 5.447.698 8.262.698 2.816 0 5.576-.239 8.262-.697 2.373-.406 3.092-3.26 1.47-4.881L15.44 9.879A1.5 1.5 0 0 1 15 8.818V3.936Z" clip-rule="evenodd" />`,
    },
    play: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347a1.125 1.125 0 0 1-1.667-.986V5.653Z" />`,
        fill: `<path fill-rule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clip-rule="evenodd" />`,
    },
    'play-circle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15.91 11.672a.375.375 0 0 1 0 .656l-5.603 3.113a.375.375 0 0 1-.557-.328V8.887c0-.286.307-.466.557-.327l5.603 3.112Z" />`,
        fill: `<path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm14.024-.983a1.125 1.125 0 0 1 0 1.966l-5.603 3.113A1.125 1.125 0 0 1 9 15.113V8.887c0-.857.921-1.4 1.671-.983l5.603 3.113Z" clip-rule="evenodd" />`,
    },
    'cpu-chip': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-15 3.75H3m18 0h-1.5M8.25 19.5V21M12 3v1.5m0 15V21m3.75-18v1.5m0 15V21m-9-1.5h10.5a2.25 2.25 0 0 0 2.25-2.25V6.75a2.25 2.25 0 0 0-2.25-2.25H6.75A2.25 2.25 0 0 0 4.5 6.75v10.5a2.25 2.25 0 0 0 2.25 2.25Zm.75-12h9v9h-9v-9Z" />`,
        fill: `<path d="M16.5 7.5h-9v9h9v-9Z" /><path fill-rule="evenodd" d="M8.25 2.25A.75.75 0 0 1 9 3v.75h2.25V3a.75.75 0 0 1 1.5 0v.75H15V3a.75.75 0 0 1 1.5 0v.75h.75a3 3 0 0 1 3 3v.75H21A.75.75 0 0 1 21 9h-.75v2.25H21a.75.75 0 0 1 0 1.5h-.75V15H21a.75.75 0 0 1 0 1.5h-.75v.75a3 3 0 0 1-3 3h-.75V21a.75.75 0 0 1-1.5 0v-.75h-2.25V21a.75.75 0 0 1-1.5 0v-.75H9V21a.75.75 0 0 1-1.5 0v-.75h-.75a3 3 0 0 1-3-3v-.75H3A.75.75 0 0 1 3 15h.75v-2.25H3a.75.75 0 0 1 0-1.5h.75V9H3a.75.75 0 0 1 0-1.5h.75v-.75a3 3 0 0 1 3-3h.75V3a.75.75 0 0 1 .75-.75ZM6 6.75A.75.75 0 0 1 6.75 6h10.5a.75.75 0 0 1 .75.75v10.5a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V6.75Z" clip-rule="evenodd" />`,
    },
    'chart-pie': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M10.5 6a7.5 7.5 0 1 0 7.5 7.5h-7.5V6Z" /><path stroke-linecap="round" stroke-linejoin="round" d="M13.5 10.5H21A7.5 7.5 0 0 0 13.5 3v7.5Z" />`,
        fill: `<path fill-rule="evenodd" d="M2.25 13.5a8.25 8.25 0 0 1 8.25-8.25.75.75 0 0 1 .75.75v6.75H18a.75.75 0 0 1 .75.75 8.25 8.25 0 0 1-16.5 0Z" clip-rule="evenodd" /><path fill-rule="evenodd" d="M12.75 3a.75.75 0 0 1 .75-.75 8.25 8.25 0 0 1 8.25 8.25.75.75 0 0 1-.75.75h-7.5a.75.75 0 0 1-.75-.75V3Z" clip-rule="evenodd" />`,
    },
    'adjustments-horizontal': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 1 1-3 0m3 0a1.5 1.5 0 1 0-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m-9.75 0h9.75" />`,
        fill: `<path d="M18.75 12.75h1.5a.75.75 0 0 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM12 6a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 6ZM12 18a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 12 18ZM3.75 6.75h1.5a.75.75 0 1 0 0-1.5h-1.5a.75.75 0 0 0 0 1.5ZM5.25 18.75h-1.5a.75.75 0 0 1 0-1.5h1.5a.75.75 0 0 1 0 1.5ZM3 12a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 3 12ZM9 3.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5ZM12.75 12a2.25 2.25 0 1 1 4.5 0 2.25 2.25 0 0 1-4.5 0ZM9 15.75a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Z" />`,
    },
    'device-phone-mobile': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 0 0 6 3.75v16.5a2.25 2.25 0 0 0 2.25 2.25h7.5A2.25 2.25 0 0 0 18 20.25V3.75a2.25 2.25 0 0 0-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3" />`,
        fill: `<path d="M10.5 18.75a.75.75 0 0 0 0 1.5h3a.75.75 0 0 0 0-1.5h-3Z" /><path fill-rule="evenodd" d="M8.625.75A3.375 3.375 0 0 0 5.25 4.125v15.75a3.375 3.375 0 0 0 3.375 3.375h6.75a3.375 3.375 0 0 0 3.375-3.375V4.125A3.375 3.375 0 0 0 15.375.75h-6.75ZM7.5 4.125C7.5 3.504 8.004 3 8.625 3H9.75v.375c0 .621.504 1.125 1.125 1.125h2.25c.621 0 1.125-.504 1.125-1.125V3h1.125c.621 0 1.125.504 1.125 1.125v15.75c0 .621-.504 1.125-1.125 1.125h-6.75A1.125 1.125 0 0 1 7.5 19.875V4.125Z" clip-rule="evenodd" />`,
    },
    bolt: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z" />`,
        fill: `<path fill-rule="evenodd" d="M14.615 1.595a.75.75 0 0 1 .359.852L12.982 9.75h7.268a.75.75 0 0 1 .548 1.262l-10.5 11.25a.75.75 0 0 1-1.272-.71l1.992-7.302H3.75a.75.75 0 0 1-.548-1.262l10.5-11.25a.75.75 0 0 1 .913-.143Z" clip-rule="evenodd" />`,
    },
    power: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M5.636 5.636a9 9 0 1 0 12.728 0M12 3v9" />`,
        fill: `<path fill-rule="evenodd" d="M12 2.25a.75.75 0 0 1 .75.75v9a.75.75 0 0 1-1.5 0V3a.75.75 0 0 1 .75-.75ZM6.166 5.106a.75.75 0 0 1 0 1.06 8.25 8.25 0 1 0 11.668 0 .75.75 0 1 1 1.06-1.06c3.808 3.807 3.808 9.98 0 13.788-3.807 3.808-9.98 3.808-13.788 0-3.808-3.807-3.808-9.98 0-13.788a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd" />`,
    },
    signal: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9.348 14.652a3.75 3.75 0 0 1 0-5.304m5.304 0a3.75 3.75 0 0 1 0 5.304m-7.425 2.121a6.75 6.75 0 0 1 0-9.546m9.546 0a6.75 6.75 0 0 1 0 9.546M5.106 18.894c-3.808-3.807-3.808-9.98 0-13.788m13.788 0c3.808 3.807 3.808 9.98 0 13.788M12 12h.008v.008H12V12Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />`,
        fill: `<path fill-rule="evenodd" d="M5.636 4.575a.75.75 0 0 1 0 1.061 9 9 0 0 0 0 12.728.75.75 0 1 1-1.06 1.06c-4.101-4.1-4.101-10.748 0-14.849a.75.75 0 0 1 1.06 0Zm12.728 0a.75.75 0 0 1 1.06 0c4.101 4.1 4.101 10.75 0 14.85a.75.75 0 1 1-1.06-1.061 9 9 0 0 0 0-12.728.75.75 0 0 1 0-1.06ZM7.757 6.697a.75.75 0 0 1 0 1.06 6 6 0 0 0 0 8.486.75.75 0 0 1-1.06 1.06 7.5 7.5 0 0 1 0-10.606.75.75 0 0 1 1.06 0Zm8.486 0a.75.75 0 0 1 1.06 0 7.5 7.5 0 0 1 0 10.606.75.75 0 0 1-1.06-1.06 6 6 0 0 0 0-8.486.75.75 0 0 1 0-1.06ZM9.879 8.818a.75.75 0 0 1 0 1.06 3 3 0 0 0 0 4.243.75.75 0 1 1-1.061 1.061 4.5 4.5 0 0 1 0-6.364.75.75 0 0 1 1.06 0Zm4.242 0a.75.75 0 0 1 1.061 0 4.5 4.5 0 0 1 0 6.364.75.75 0 0 1-1.06-1.06 3 3 0 0 0 0-4.243.75.75 0 0 1 0-1.061ZM10.875 12a1.125 1.125 0 1 1 2.25 0 1.125 1.125 0 0 1-2.25 0Z" clip-rule="evenodd" />`,
    },
    'arrow-path-rounded-square': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M19.5 12c0-1.232-.046-2.453-.138-3.662a4.006 4.006 0 0 0-3.7-3.7 48.678 48.678 0 0 0-7.324 0 4.006 4.006 0 0 0-3.7 3.7c-.017.22-.032.441-.046.662M19.5 12l3-3m-3 3-3-3m-12 3c0 1.232.046 2.453.138 3.662a4.006 4.006 0 0 0 3.7 3.7 48.656 48.656 0 0 0 7.324 0 4.006 4.006 0 0 0 3.7-3.7c.017-.22.032-.441.046-.662M4.5 12l3 3m-3-3-3 3" />`,
        fill: `<path fill-rule="evenodd" d="M12 5.25c1.213 0 2.415.046 3.605.135a3.256 3.256 0 0 1 3.01 3.01c.044.583.077 1.17.1 1.759L17.03 8.47a.75.75 0 1 0-1.06 1.06l3 3a.75.75 0 0 0 1.06 0l3-3a.75.75 0 0 0-1.06-1.06l-1.752 1.751c-.023-.65-.06-1.296-.108-1.939a4.756 4.756 0 0 0-4.392-4.392 49.422 49.422 0 0 0-7.436 0A4.756 4.756 0 0 0 3.89 8.282c-.017.224-.033.447-.046.672a.75.75 0 1 0 1.497.092c.013-.217.028-.434.044-.651a3.256 3.256 0 0 1 3.01-3.01c1.19-.09 2.392-.135 3.605-.135Zm-6.97 6.22a.75.75 0 0 0-1.06 0l-3 3a.75.75 0 1 0 1.06 1.06l1.752-1.751c.023.65.06 1.296.108 1.939a4.756 4.756 0 0 0 4.392 4.392 49.413 49.413 0 0 0 7.436 0 4.756 4.756 0 0 0 4.392-4.392c.017-.223.032-.447.046-.672a.75.75 0 0 0-1.497-.092c-.013.217-.028.434-.044.651a3.256 3.256 0 0 1-3.01 3.01 47.953 47.953 0 0 1-7.21 0 3.256 3.256 0 0 1-3.01-3.01 47.759 47.759 0 0 1-.1-1.759L6.97 15.53a.75.75 0 0 0 1.06-1.06l-3-3Z" clip-rule="evenodd" />`,
    },
    'shield-check': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />`,
        fill: `<path fill-rule="evenodd" d="M12.516 2.17a.75.75 0 0 0-1.032 0 11.209 11.209 0 0 1-7.877 3.08.75.75 0 0 0-.722.515A12.74 12.74 0 0 0 2.25 9.75c0 5.942 4.064 10.933 9.563 12.348a.749.749 0 0 0 .374 0c5.499-1.415 9.563-6.406 9.563-12.348 0-1.39-.223-2.73-.635-3.985a.75.75 0 0 0-.722-.516l-.143.001c-2.996 0-5.717-1.17-7.734-3.08Zm3.094 8.016a.75.75 0 1 0-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 0 0-1.06 1.06l2.25 2.25a.75.75 0 0 0 1.14-.094l3.75-5.25Z" clip-rule="evenodd" />`,
    },
    'shield-exclamation': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m0-10.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.75c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.75h-.152c-3.196 0-6.1-1.25-8.25-3.286Zm0 13.036h.008v.008H12v-.008Z" />`,
        fill: `<path fill-rule="evenodd" d="M11.484 2.17a.75.75 0 0 1 1.032 0 11.209 11.209 0 0 0 7.877 3.08.75.75 0 0 1 .722.515 12.74 12.74 0 0 1 .635 3.985c0 5.942-4.064 10.933-9.563 12.348a.749.749 0 0 1-.374 0C6.314 20.683 2.25 15.692 2.25 9.75c0-1.39.223-2.73.635-3.985a.75.75 0 0 1 .722-.516l.143.001c2.996 0 5.718-1.17 7.734-3.08ZM12 8.25a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 1-1.5 0V9a.75.75 0 0 1 .75-.75ZM12 15a.75.75 0 0 0-.75.75v.008c0 .414.336.75.75.75h.008a.75.75 0 0 0 .75-.75v-.008a.75.75 0 0 0-.75-.75H12Z" clip-rule="evenodd" />`,
    },
    key: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 0 1 3 3m3 0a6 6 0 0 1-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1 1 21.75 8.25Z" />`,
        fill: `<path fill-rule="evenodd" d="M15.75 1.5a6.75 6.75 0 0 0-6.651 7.906c.067.39-.032.717-.221.906l-6.5 6.499a3 3 0 0 0-.878 2.121v2.818c0 .414.336.75.75.75H6a.75.75 0 0 0 .75-.75v-1.5h1.5A.75.75 0 0 0 9 19.5V18h1.5a.75.75 0 0 0 .53-.22l2.658-2.658c.19-.189.517-.288.906-.22A6.75 6.75 0 1 0 15.75 1.5Zm0 3a.75.75 0 0 0 0 1.5A2.25 2.25 0 0 1 18 8.25a.75.75 0 0 0 1.5 0 3.75 3.75 0 0 0-3.75-3.75Z" clip-rule="evenodd" />`,
    },
    'lock-open': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M13.5 10.5V6.75a4.5 4.5 0 1 1 9 0v3.75M3.75 21.75h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H3.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />`,
        fill: `<path d="M18 1.5c2.9 0 5.25 2.35 5.25 5.25v3.75a.75.75 0 0 1-1.5 0V6.75a3.75 3.75 0 1 0-7.5 0v3a3 3 0 0 1 3 3v6.75a3 3 0 0 1-3 3H3.75a3 3 0 0 1-3-3v-6.75a3 3 0 0 1 3-3h9v-3c0-2.9 2.35-5.25 5.25-5.25Z" />`,
    },
    share: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M7.217 10.907a2.25 2.25 0 1 0 0 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186 9.566-5.314m-9.566 7.5 9.566 5.314m0 0a2.25 2.25 0 1 0 3.935 2.186 2.25 2.25 0 0 0-3.935-2.186Zm0-12.814a2.25 2.25 0 1 0 3.933-2.185 2.25 2.25 0 0 0-3.933 2.185Z" />`,
        fill: `<path fill-rule="evenodd" d="M15.75 4.5a3 3 0 1 1 .825 2.066l-8.421 4.679a3.002 3.002 0 0 1 0 1.51l8.421 4.679a3 3 0 1 1-.729 1.31l-8.421-4.678a3 3 0 1 1 0-4.132l8.421-4.679a3 3 0 0 1-.096-.755Z" clip-rule="evenodd" />`,
    },
    'rectangle-group': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M2.25 7.125C2.25 6.504 2.754 6 3.375 6h6c.621 0 1.125.504 1.125 1.125v3.75c0 .621-.504 1.125-1.125 1.125h-6a1.125 1.125 0 0 1-1.125-1.125v-3.75ZM14.25 8.625c0-.621.504-1.125 1.125-1.125h5.25c.621 0 1.125.504 1.125 1.125v8.25c0 .621-.504 1.125-1.125 1.125h-5.25a1.125 1.125 0 0 1-1.125-1.125v-8.25ZM3.75 16.125c0-.621.504-1.125 1.125-1.125h5.25c.621 0 1.125.504 1.125 1.125v2.25c0 .621-.504 1.125-1.125 1.125h-5.25a1.125 1.125 0 0 1-1.125-1.125v-2.25Z" />`,
        fill: `<path fill-rule="evenodd" d="M1.5 7.125c0-1.036.84-1.875 1.875-1.875h6c1.036 0 1.875.84 1.875 1.875v3.75c0 1.036-.84 1.875-1.875 1.875h-6A1.875 1.875 0 0 1 1.5 10.875v-3.75Zm12 1.5c0-1.036.84-1.875 1.875-1.875h5.25c1.035 0 1.875.84 1.875 1.875v8.25c0 1.035-.84 1.875-1.875 1.875h-5.25a1.875 1.875 0 0 1-1.875-1.875v-8.25ZM3 16.125c0-1.036.84-1.875 1.875-1.875h5.25c1.036 0 1.875.84 1.875 1.875v2.25c0 1.035-.84 1.875-1.875 1.875h-5.25A1.875 1.875 0 0 1 3 18.375v-2.25Z" clip-rule="evenodd" />`,
    },
    'squares-2x2': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6A2.25 2.25 0 0 1 6 3.75h2.25A2.25 2.25 0 0 1 10.5 6v2.25a2.25 2.25 0 0 1-2.25 2.25H6a2.25 2.25 0 0 1-2.25-2.25V6ZM3.75 15.75A2.25 2.25 0 0 1 6 13.5h2.25a2.25 2.25 0 0 1 2.25 2.25V18a2.25 2.25 0 0 1-2.25 2.25H6A2.25 2.25 0 0 1 3.75 18v-2.25ZM13.5 6a2.25 2.25 0 0 1 2.25-2.25H18A2.25 2.25 0 0 1 20.25 6v2.25A2.25 2.25 0 0 1 18 10.5h-2.25a2.25 2.25 0 0 1-2.25-2.25V6ZM13.5 15.75a2.25 2.25 0 0 1 2.25-2.25H18a2.25 2.25 0 0 1 2.25 2.25V18A2.25 2.25 0 0 1 18 20.25h-2.25A2.25 2.25 0 0 1 13.5 18v-2.25Z" />`,
        fill: `<path fill-rule="evenodd" d="M3 6a3 3 0 0 1 3-3h2.25a3 3 0 0 1 3 3v2.25a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V6Zm9.75 0a3 3 0 0 1 3-3H18a3 3 0 0 1 3 3v2.25a3 3 0 0 1-3 3h-2.25a3 3 0 0 1-3-3V6ZM3 15.75a3 3 0 0 1 3-3h2.25a3 3 0 0 1 3 3V18a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-2.25Zm9.75 0a3 3 0 0 1 3-3H18a3 3 0 0 1 3 3V18a3 3 0 0 1-3 3h-2.25a3 3 0 0 1-3-3v-2.25Z" clip-rule="evenodd" />`,
    },
    'arrows-right-left': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M7.5 21 3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5" />`,
        fill: `<path fill-rule="evenodd" d="M15.97 2.47a.75.75 0 0 1 1.06 0l4.5 4.5a.75.75 0 0 1 0 1.06l-4.5 4.5a.75.75 0 1 1-1.06-1.06l3.22-3.22H7.5a.75.75 0 0 1 0-1.5h11.69l-3.22-3.22a.75.75 0 0 1 0-1.06Zm-7.94 9a.75.75 0 0 1 0 1.06l-3.22 3.22H16.5a.75.75 0 0 1 0 1.5H4.81l3.22 3.22a.75.75 0 1 1-1.06 1.06l-4.5-4.5a.75.75 0 0 1 0-1.06l4.5-4.5a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd" />`,
    },
    document: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />`,
        fill: `<path d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0 0 16.5 9h-1.875a1.875 1.875 0 0 1-1.875-1.875V5.25A3.75 3.75 0 0 0 9 1.5H5.625Z" /><path d="M12.971 1.816A5.23 5.23 0 0 1 14.25 5.25v1.875c0 .207.168.375.375.375H16.5a5.23 5.23 0 0 1 3.434 1.279 9.768 9.768 0 0 0-6.963-6.963Z" />`,
    },
    'document-text': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />`,
        fill: `<path fill-rule="evenodd" d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0 0 16.5 9h-1.875a1.875 1.875 0 0 1-1.875-1.875V5.25A3.75 3.75 0 0 0 9 1.5H5.625ZM7.5 15a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 7.5 15Zm.75 2.25a.75.75 0 0 0 0 1.5H12a.75.75 0 0 0 0-1.5H8.25Z" clip-rule="evenodd" /><path d="M12.971 1.816A5.23 5.23 0 0 1 14.25 5.25v1.875c0 .207.168.375.375.375H16.5a5.23 5.23 0 0 1 3.434 1.279 9.768 9.768 0 0 0-6.963-6.963Z" />`,
    },
    'document-magnifying-glass': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m5.231 13.481L15 17.25m-4.5-15H5.625c-.621 0-1.125.504-1.125 1.125v16.5c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Zm3.75 11.625a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />`,
        fill: `<path d="M11.625 16.5a1.875 1.875 0 1 0 0-3.75 1.875 1.875 0 0 0 0 3.75Z" /><path fill-rule="evenodd" d="M5.625 1.5H9a3.75 3.75 0 0 1 3.75 3.75v1.875c0 1.036.84 1.875 1.875 1.875H16.5a3.75 3.75 0 0 1 3.75 3.75v7.875c0 1.035-.84 1.875-1.875 1.875H5.625a1.875 1.875 0 0 1-1.875-1.875V3.375c0-1.036.84-1.875 1.875-1.875Zm6 16.5c.66 0 1.277-.19 1.797-.518l1.048 1.048a.75.75 0 0 0 1.06-1.06l-1.047-1.048A3.375 3.375 0 1 0 11.625 18Z" clip-rule="evenodd" /><path d="M14.25 5.25a5.23 5.23 0 0 0-1.279-3.434 9.768 9.768 0 0 1 6.963 6.963A5.23 5.23 0 0 0 16.5 7.5h-1.875a.375.375 0 0 1-.375-.375V5.25Z" />`,
    },
    sun: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-4.773-4.227-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" />`,
        fill: `<path d="M12 2.25a.75.75 0 0 1 .75.75v2.25a.75.75 0 0 1-1.5 0V3a.75.75 0 0 1 .75-.75ZM7.5 12a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM18.894 6.166a.75.75 0 0 0-1.06-1.06l-1.591 1.59a.75.75 0 1 0 1.06 1.061l1.591-1.59ZM21.75 12a.75.75 0 0 1-.75.75h-2.25a.75.75 0 0 1 0-1.5H21a.75.75 0 0 1 .75.75ZM17.834 18.894a.75.75 0 0 0 1.06-1.06l-1.59-1.591a.75.75 0 1 0-1.061 1.06l1.59 1.591ZM12 18a.75.75 0 0 1 .75.75V21a.75.75 0 0 1-1.5 0v-2.25A.75.75 0 0 1 12 18ZM7.758 17.303a.75.75 0 0 0-1.061-1.06l-1.591 1.59a.75.75 0 0 0 1.06 1.061l1.591-1.59ZM6 12a.75.75 0 0 1-.75.75H3a.75.75 0 0 1 0-1.5h2.25A.75.75 0 0 1 6 12ZM6.697 7.757a.75.75 0 0 0 1.06-1.06l-1.59-1.591a.75.75 0 0 0-1.061 1.06l1.59 1.591Z" />`,
    },
    moon: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998Z" />`,
        fill: `<path fill-rule="evenodd" d="M9.528 1.718a.75.75 0 0 1 .162.819A8.97 8.97 0 0 0 9 6a9 9 0 0 0 9 9 8.97 8.97 0 0 0 3.463-.69.75.75 0 0 1 .981.98 10.503 10.503 0 0 1-9.694 6.46c-5.799 0-10.5-4.7-10.5-10.5 0-4.368 2.667-8.112 6.46-9.694a.75.75 0 0 1 .818.162Z" clip-rule="evenodd" />`,
    },
    'question-mark-circle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 5.25h.008v.008H12v-.008Z" />`,
        fill: `<path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm11.378-3.917c-.89-.777-2.366-.777-3.255 0a.75.75 0 0 1-.988-1.129c1.454-1.272 3.776-1.272 5.23 0 1.513 1.324 1.513 3.518 0 4.842a3.75 3.75 0 0 1-.837.552c-.676.328-1.028.774-1.028 1.152v.75a.75.75 0 0 1-1.5 0v-.75c0-1.279 1.06-2.107 1.875-2.502.182-.088.351-.199.503-.331.83-.727.83-1.857 0-2.584ZM12 18a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clip-rule="evenodd" />`,
    },
    'ellipsis-horizontal': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6.75 12a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0ZM12.75 12a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0ZM18.75 12a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />`,
        fill: `<path fill-rule="evenodd" d="M4.5 12a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Zm6 0a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Zm6 0a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Z" clip-rule="evenodd" />`,
    },
    'information-circle': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z" />`,
        fill: `<path fill-rule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 0 1 .67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 1 1-.671-1.34l.041-.022ZM12 9a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z" clip-rule="evenodd" />`,
    },
    // ── CRM / Vocero — íconos propios sin equivalente Heroicons (11-a-solercia-ui, PR2) ──
    // Sin licencia MIT de terceros que reproducir: diseño propio, mismo patrón que la
    // sección de rich-editor (trazo stroke-linecap/linejoin round, viewBox 24×24 implícito
    // vía el wrapper de icon.component.ts). Los 7 son OUTLINE-ONLY (`fill: ''`): subpaths
    // abiertos (antena/ojos/boca, aguja, patas/cable, tronco, conector) tendrían área CERO
    // si se intentaran rellenar — `icon.component.ts` degrada `variant="fill"` al trazo
    // outline en vez de romper el ícono (ver comentario de `IconDef.fill` arriba).
    robot: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M7 9a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V9Zm5-2V4m-1-1a1 1 0 1 0 2 0 1 1 0 1 0-2 0M10 12.5v1.5m4-1.5v1.5M9.5 16.5h5" />`,
        fill: '',
    },
    gauge: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M4 16a8 8 0 1 1 16 0M12 16 16 9M10.7 16a1.3 1.3 0 1 0 2.6 0 1.3 1.3 0 1 0-2.6 0" />`,
        fill: '',
    },
    plug: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M10 6V2M14 6V2M7 6h10v7a3 3 0 0 1-3 3h-4a3 3 0 0 1-3-3V6ZM12 16v4" />`,
        fill: '',
    },
    'git-branch': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6 3v12M15 6a3 3 0 1 0 6 0 3 3 0 1 0-6 0M3 18a3 3 0 1 0 6 0 3 3 0 1 0-6 0M18 9a9 9 0 0 1-9 9" />`,
        fill: '',
    },
    webhook: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M8 20v-6a5 5 0 0 1 5-5h3M14 7a2 2 0 1 0 4 0 2 2 0 1 0-4 0" />`,
        fill: '',
    },
    'state-machine': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M1.75 12a3.25 3.25 0 1 0 6.5 0 3.25 3.25 0 1 0-6.5 0M15.75 12a3.25 3.25 0 1 0 6.5 0 3.25 3.25 0 1 0-6.5 0M8.25 12h7.5M14 9.5l1.75 2.5-1.75 2.5" />`,
        fill: '',
    },
    'double-check': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M2 12 7 17 16 6M7 12 12 17 21 6" />`,
        fill: '',
    },
    // ── Editor de texto enriquecido (sol-rich-editor) ─────────────────────────────
    // Glifos de formato de 24×24 pensados para el trazo (variante outline, la única
    // que usa la toolbar). Diseño propio inspirado en iconografía de editores (MIT).
    // OUTLINE-ONLY (`fill: ''`) salvo `image` (silueta sólida real vía evenodd):
    // rellenar el resto con `fill="currentColor"` dejaría sus trazos abiertos
    // (líneas, subrayado, tachado, viñetas, alineación, "H" de heading, cadena de
    // link, tachón de remove-format) con área CERO — ver `IconDef.fill` arriba.
    bold: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M7 5h6a3.5 3.5 0 0 1 0 7h-6z" /><path stroke-linecap="round" stroke-linejoin="round" d="M13 12h1a3.5 3.5 0 0 1 0 7h-7v-7" />`,
        fill: '',
    },
    italic: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M11 5h6M7 19h6M14 5l-4 14" />`,
        fill: '',
    },
    underline: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M7 5v5a5 5 0 0 0 10 0V5M5 19h14" />`,
        fill: '',
    },
    strikethrough: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M5 12h14M15.5 8.5c-.6-1.7-2.3-2.75-4-2.75-2.2 0-3.75 1.3-3.75 3M8.5 15.5c.6 1.7 2.3 2.75 4 2.75 2.2 0 3.75-1.3 3.75-3" />`,
        fill: '',
    },
    'list-bullet': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9 6h11M9 12h11M9 18h11M5 6h.01M5 12h.01M5 18h.01" />`,
        fill: '',
    },
    'list-numbered': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M11 6h9M11 12h9M11 18h9M4 16a2 2 0 1 1 3 1.73L4 20h4M6 10V4L4 6" />`,
        fill: '',
    },
    'align-left': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h10M4 18h14" />`,
        fill: '',
    },
    'align-center': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M8 12h8M6 18h12" />`,
        fill: '',
    },
    'align-right': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M10 12h10M6 18h14" />`,
        fill: '',
    },
    image: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3 6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3z" /><path stroke-linecap="round" stroke-linejoin="round" d="M15 8h.01M3 16l5-5c.93-.89 2.07-.89 3 0l5 5M14 14l1-1c.93-.89 2.07-.89 3 0l3 3" />`,
        fill: `<path fill-rule="evenodd" clip-rule="evenodd" d="M6 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3V6a3 3 0 0 0-3-3zm9.5 3.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3M5 17l4.5-4.5a1.5 1.5 0 0 1 2 0L17 18z" />`,
    },
    table: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M3 15h18M9 3v18M15 3v18" />`,
        fill: '',
    },
    heading: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M6 4v16M18 4v16M6 12h12" />`,
        fill: '',
    },
    'remove-format': {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M7 6V5h11v1M12 5 8.5 19M6 19h6M15.5 14.5l5 5M20.5 14.5l-5 5" />`,
        fill: '',
    },
    link: {
        outline: `<path stroke-linecap="round" stroke-linejoin="round" d="M9 15l6-6M11 6l.46-.54a5 5 0 0 1 7.08 7.08l-.54.46M13 18l-.4.53a5.07 5.07 0 0 1-7.13 0 4.97 4.97 0 0 1 0-7.07l.52-.46" />`,
        fill: '',
    },
};

class SolIconComponent {
    sanitizer = inject(DomSanitizer);
    /** Icon name — must exist in ICON_REGISTRY. */
    name = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    /** Size token. Defaults to 'md' (20 × 20 px). */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Visual variant:
     *   'outline' — stroke paths on transparent background
     *   'fill'    — solid filled shape
     *
     * Outline-only icons (registry entries with `fill === ''`, e.g. `bold`,
     * `robot`) have no solid silhouette — requesting `variant="fill"` on one
     * of them renders its outline stroke instead (never a broken/invisible
     * icon). See `IconDef.fill` in `icon.registry.ts`.
     *
     * Color is controlled via Tailwind's text-* class on the host element.
     * Example: <sol-icon name="edit" variant="fill" class="text-blue-500" />
     */
    variant = input('outline', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    sizeClass = computed(() => `sol-icon sol-icon-${this.size()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sizeClass" }] : /* istanbul ignore next */ []));
    svg = computed(() => {
        const def = ICON_REGISTRY[this.name()];
        // Outline-only icons (`IconDef.fill === ''`) have no solid variant — their
        // path data is open/thin strokes with zero fillable area. Requesting
        // `variant="fill"` on one of them degrades to the outline stroke
        // rendering instead of producing a broken/invisible icon.
        const hasSolidFill = !!def?.fill;
        const renderAsFill = this.variant() === 'fill' && hasSolidFill;
        const paths = def
            ? (renderAsFill ? def.fill : def.outline)
            : '<circle cx="12" cy="12" r="4" />'; // fallback dot for unknown icons
        const markup = renderAsFill
            ? `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
             fill="currentColor" stroke="none"
             aria-hidden="true">${paths}</svg>`
            : `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
             fill="none" stroke="currentColor"
             stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"
             aria-hidden="true">${paths}</svg>`;
        return this.sanitizer.bypassSecurityTrustHtml(markup);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "svg" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolIconComponent, isStandalone: true, selector: "sol-icon", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<span class="sol-icon" [class]="sizeClass()" [innerHTML]="svg()"></span>`, isInline: true, styles: [".sol-icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.sol-icon :deep(svg){width:100%;height:100%}.sol-icon-sm{width:16px;height:16px}.sol-icon-md{width:20px;height:20px}.sol-icon-lg{width:24px;height:24px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `<span class="sol-icon" [class]="sizeClass()" [innerHTML]="svg()"></span>`, styles: [".sol-icon{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.sol-icon :deep(svg){width:100%;height:100%}.sol-icon-sm{width:16px;height:16px}.sol-icon-md{width:20px;height:20px}.sol-icon-lg{width:24px;height:24px}\n"] }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: true }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }] } });

class SolSelectComponent {
    hostEl;
    /** Placeholder text when nothing is selected. */
    placeholder = input('Selecciona...', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /** Label displayed above the select. */
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Error message below. */
    error = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    /** Whether the select is disabled. */
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Enable search filtering. */
    searchable = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchable" }] : /* istanbul ignore next */ []));
    /** Enable multi-selection mode. */
    multiple = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "multiple" }] : /* istanbul ignore next */ []));
    /** Options array — use this instead of ng-content for searchable/multi. */
    options = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    /** Show a "Todos" / clear option in single mode. */
    showAllOption = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showAllOption" }] : /* istanbul ignore next */ []));
    /** Label for the "all" option in single mode. */
    allOptionLabel = input('Todos', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "allOptionLabel" }] : /* istanbul ignore next */ []));
    // ── Internal state ──
    isOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    dropUp = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropUp" }] : /* istanbul ignore next */ []));
    searchTerm = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []));
    singleValue = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "singleValue" }] : /* istanbul ignore next */ []));
    multiValues = signal(new Set(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "multiValues" }] : /* istanbul ignore next */ []));
    searchInput = viewChild('searchInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchInput" }] : /* istanbul ignore next */ []));
    filteredOptions = computed(() => {
        const term = this.searchTerm().toLowerCase();
        const opts = this.options();
        if (!term)
            return opts;
        return opts.filter(o => o.label.toLowerCase().includes(term));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredOptions" }] : /* istanbul ignore next */ []));
    displayText = computed(() => {
        if (this.multiple()) {
            const selected = this.multiValues();
            if (selected.size === 0)
                return '';
            if (selected.size === this.options().length)
                return 'Todos';
            const labels = this.options()
                .filter(o => selected.has(o.value))
                .map(o => o.label);
            return labels.join(', ');
        }
        const val = this.singleValue();
        if (!val)
            return '';
        return this.options().find(o => o.value === val)?.label ?? val;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []));
    triggerClass = computed(() => {
        let cls = 'sol-select__trigger';
        if (this.error())
            cls += ' sol-select__trigger--error';
        if (this.isOpen())
            cls += ' sol-select__trigger--open';
        return cls;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "triggerClass" }] : /* istanbul ignore next */ []));
    onChange = () => { };
    onTouched = () => { };
    onDocumentClick(event) {
        const wrapper = this.__wrapper;
        if (wrapper && !wrapper.contains(event.target)) {
            this.closeDropdown();
        }
    }
    constructor(hostEl) {
        this.hostEl = hostEl;
    }
    toggleDropdown() {
        if (this.disabled())
            return;
        this.isOpen.update(v => !v);
        if (this.isOpen()) {
            this.searchTerm.set('');
            // Detect if dropdown should open upward
            const rect = this.hostEl.nativeElement.getBoundingClientRect();
            const spaceBelow = window.innerHeight - rect.bottom;
            this.dropUp.set(spaceBelow < 300);
            setTimeout(() => this.searchInput()?.nativeElement?.focus(), 50);
        }
    }
    closeDropdown() {
        this.isOpen.set(false);
    }
    onSearchInput(event) {
        this.searchTerm.set(event.target.value);
    }
    isSelected(value) {
        if (this.multiple())
            return this.multiValues().has(value);
        return this.singleValue() === value;
    }
    onOptionClick(value) {
        if (this.multiple()) {
            this.multiValues.update(set => {
                const next = new Set(set);
                next.has(value) ? next.delete(value) : next.add(value);
                return next;
            });
            this.emitMultiValue();
        }
        else {
            this.onSelectSingle(value);
        }
    }
    onSelectSingle(value) {
        this.singleValue.set(value);
        this.onChange(value);
        this.closeDropdown();
    }
    selectAll() {
        const all = new Set(this.options().map(o => o.value));
        this.multiValues.set(all);
        this.emitMultiValue();
    }
    selectNone() {
        this.multiValues.set(new Set());
        this.emitMultiValue();
    }
    onBlur() {
        this.onTouched();
    }
    // ── ControlValueAccessor ──
    writeValue(value) {
        if (this.multiple()) {
            if (Array.isArray(value)) {
                this.multiValues.set(new Set(value.map(String)));
            }
            else {
                this.multiValues.set(new Set());
            }
        }
        else {
            this.singleValue.set(value != null ? String(value) : '');
        }
    }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(_) { }
    emitMultiValue() {
        this.onChange(Array.from(this.multiValues()));
    }
    // Close dropdown when clicking outside
    ngAfterViewInit() {
        this.__wrapper = this.hostEl.nativeElement;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolSelectComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolSelectComponent, isStandalone: true, selector: "sol-select", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, searchable: { classPropertyName: "searchable", publicName: "searchable", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, showAllOption: { classPropertyName: "showAllOption", publicName: "showAllOption", isSignal: true, isRequired: false, transformFunction: null }, allOptionLabel: { classPropertyName: "allOptionLabel", publicName: "allOptionLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SolSelectComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "searchInput", first: true, predicate: ["searchInput"], descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (label()) {
      <label class="sol-select__label">{{ label() }}</label>
    }

    <div class="sol-select__wrapper" #wrapper>
      <!-- Trigger button -->
      <button
        type="button"
        [class]="triggerClass()"
        [disabled]="disabled()"
        (click)="toggleDropdown()"
        (blur)="onBlur()"
      >
        <span class="sol-select__display" [class.sol-select__display--placeholder]="!displayText()">
          {{ displayText() || placeholder() }}
        </span>
        <sol-icon name="chevron-down" variant="fill" class="sol-select__arrow" [class.sol-select__arrow--open]="isOpen()" />
      </button>

      <!-- Dropdown panel -->
      @if (isOpen()) {
        <div class="sol-select__dropdown" [class.sol-select__dropdown--up]="dropUp()">
          <!-- Search -->
          @if (searchable()) {
            <div class="sol-select__search-box">
              <input
                #searchInput
                type="text"
                class="sol-select__search"
                placeholder="Buscar..."
                [value]="searchTerm()"
                (input)="onSearchInput($event)"
                (keydown.escape)="closeDropdown()"
              />
            </div>
          }

          <!-- Select all / none for multi -->
          @if (multiple()) {
            <div class="sol-select__bulk-actions">
              <button type="button" class="sol-select__bulk-btn" (click)="selectAll()">Todos</button>
              <button type="button" class="sol-select__bulk-btn" (click)="selectNone()">Ninguno</button>
            </div>
          }

          <!-- "Todos" option for single mode (acts as empty/clear) -->
          @if (!multiple() && showAllOption()) {
            <div
              class="sol-select__option"
              [class.sol-select__option--active]="!singleValue()"
              (click)="onSelectSingle('')"
            >
              {{ allOptionLabel() }}
            </div>
          }

          <!-- Options -->
          <div class="sol-select__options">
            @for (opt of filteredOptions(); track opt.value) {
              <div
                class="sol-select__option"
                [class.sol-select__option--active]="isSelected(opt.value)"
                (click)="onOptionClick(opt.value)"
              >
                @if (multiple()) {
                  <span class="sol-select__check" [class.sol-select__check--checked]="isSelected(opt.value)">
                    @if (isSelected(opt.value)) { &#10003; }
                  </span>
                }
                {{ opt.label }}
              </div>
            } @empty {
              <div class="sol-select__empty">Sin resultados</div>
            }
          </div>
        </div>
      }
    </div>

    @if (error()) {
      <p class="sol-select__error">{{ error() }}</p>
    }
  `, isInline: true, styles: [":host{display:block;--sol-select-bg: var(--sol-input-bg, var(--sol-bg-surface, #ffffff));--sol-select-text: var(--sol-color-text-primary, #1e293b);--sol-select-placeholder: var(--sol-color-text-muted, #94a3b8);--sol-select-border: var(--sol-border-color-default, #cbd5e1);--sol-select-border-focus: var(--sol-color-primary, #6366f1);--sol-select-error-color: var(--sol-color-danger, #ef4444);--sol-select-label-color: var(--sol-color-text-secondary, #475569);--sol-select-arrow-color: var(--sol-color-text-muted, #94a3b8);--sol-select-disabled-opacity: var(--sol-disabled-opacity, .55);--sol-select-radius: var(--sol-input-radius, var(--sol-border-radius-md, .5rem));--sol-select-border-width: var(--sol-border-width-default, 1px);--sol-select-padding-x: var(--sol-space-sm, .75rem);--sol-select-height: var(--sol-size-input-height, 2.5rem);--sol-select-font-size: var(--sol-font-size-base, .875rem);--sol-select-label-font-size: var(--sol-font-size-sm, .75rem);--sol-select-label-font-weight: var(--sol-font-weight-bold, 600);--sol-select-shadow: var(--sol-input-shadow, var(--sol-shadow-sm, 0 1px 2px rgba(0,0,0,.05)));--sol-select-focus-ring: var(--sol-input-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent));--sol-select-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease);--sol-select-dropdown-bg: var(--sol-bg-surface, #ffffff);--sol-select-option-hover: var(--sol-color-bg-hover, rgba(0,0,0,.04));--sol-select-option-active-bg: color-mix(in srgb, var(--sol-color-primary, #6366f1) 12%, transparent);--sol-select-option-active-text: var(--sol-color-primary, #6366f1)}.sol-select__label{display:block;margin-bottom:.375rem;font-size:var(--sol-select-label-font-size);font-weight:var(--sol-select-label-font-weight);color:var(--sol-select-label-color);line-height:1.4}.sol-select__wrapper{position:relative;display:block}.sol-select__trigger{display:flex;align-items:center;justify-content:space-between;width:100%;height:var(--sol-select-height);padding:0 var(--sol-select-padding-x);font-family:inherit;font-size:var(--sol-select-font-size);color:var(--sol-select-text);background-color:var(--sol-select-bg);border:var(--sol-input-border, var(--sol-select-border-width) solid var(--sol-select-border));border-radius:var(--sol-select-radius);box-shadow:var(--sol-select-shadow);cursor:pointer;transition:border-color var(--sol-select-transition),box-shadow var(--sol-select-transition);text-align:left}.sol-select__trigger:focus{outline:none;border:var(--sol-input-focus-border, var(--sol-select-border-width) solid var(--sol-select-border-focus));box-shadow:var(--sol-select-focus-ring)}.sol-select__trigger:disabled{cursor:not-allowed;opacity:var(--sol-select-disabled-opacity)}.sol-select__trigger--error{border-color:var(--sol-select-error-color)}.sol-select__trigger--open{border:var(--sol-input-focus-border, var(--sol-select-border-width) solid var(--sol-select-border-focus));box-shadow:var(--sol-select-focus-ring)}.sol-select__display{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-select__display--placeholder{color:var(--sol-select-placeholder)}.sol-select__arrow{width:1.25rem;height:1.25rem;flex-shrink:0;color:var(--sol-select-arrow-color);transition:transform var(--sol-select-transition)}.sol-select__arrow--open{transform:rotate(180deg)}.sol-select__dropdown{position:absolute;top:calc(100% + 4px);left:0;right:0;z-index:var(--sol-z-dropdown, 1000);background:var(--sol-select-dropdown-bg);border:var(--sol-select-border-width) solid var(--sol-select-border);border-radius:var(--sol-select-radius);box-shadow:var(--sol-shadow-lg, 0 10px 25px rgba(0,0,0,.15));max-height:280px;display:flex;flex-direction:column;animation:sol-select-fade .12s ease-out}.sol-select__search-box{padding:.5rem;border-bottom:1px solid var(--sol-select-border)}.sol-select__search{width:100%;height:2rem;padding:0 .5rem;font-family:inherit;font-size:var(--sol-select-font-size);color:var(--sol-select-text);background:var(--sol-select-bg);border:var(--sol-select-border-width) solid var(--sol-select-border);border-radius:calc(var(--sol-select-radius) - 2px);outline:none}.sol-select__search:focus{border-color:var(--sol-select-border-focus)}.sol-select__bulk-actions{display:flex;gap:.25rem;padding:.375rem .5rem;border-bottom:1px solid var(--sol-select-border)}.sol-select__bulk-btn{flex:1;padding:.25rem;font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.03em;color:var(--sol-select-option-active-text);background:transparent;border:1px solid var(--sol-select-border);border-radius:calc(var(--sol-select-radius) - 2px);cursor:pointer;transition:background var(--sol-select-transition)}.sol-select__bulk-btn:hover{background:var(--sol-select-option-hover)}.sol-select__options{overflow-y:auto;flex:1;padding:.25rem 0}.sol-select__option{display:flex;align-items:center;gap:.5rem;padding:.5rem .75rem;font-size:var(--sol-select-font-size);color:var(--sol-select-text);cursor:pointer;transition:background var(--sol-select-transition)}.sol-select__option:hover{background:var(--sol-select-option-hover)}.sol-select__option--active{background:var(--sol-select-option-active-bg);color:var(--sol-select-option-active-text);font-weight:500}.sol-select__check{display:inline-flex;align-items:center;justify-content:center;width:1rem;height:1rem;border:2px solid var(--sol-select-border);border-radius:3px;font-size:.65rem;flex-shrink:0}.sol-select__check--checked{background:var(--sol-select-option-active-text);border-color:var(--sol-select-option-active-text);color:#fff}.sol-select__empty{padding:.75rem;text-align:center;color:var(--sol-select-placeholder);font-size:var(--sol-select-font-size)}.sol-select__error{margin:.25rem 0 0;font-size:var(--sol-select-label-font-size);color:var(--sol-select-error-color);line-height:1.4}.sol-select__dropdown--up{top:auto;bottom:calc(100% + 4px);animation:sol-select-fade-up .12s ease-out}@keyframes sol-select-fade{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}@keyframes sol-select-fade-up{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-select', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [SolIconComponent], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SolSelectComponent),
                            multi: true,
                        },
                    ], template: `
    @if (label()) {
      <label class="sol-select__label">{{ label() }}</label>
    }

    <div class="sol-select__wrapper" #wrapper>
      <!-- Trigger button -->
      <button
        type="button"
        [class]="triggerClass()"
        [disabled]="disabled()"
        (click)="toggleDropdown()"
        (blur)="onBlur()"
      >
        <span class="sol-select__display" [class.sol-select__display--placeholder]="!displayText()">
          {{ displayText() || placeholder() }}
        </span>
        <sol-icon name="chevron-down" variant="fill" class="sol-select__arrow" [class.sol-select__arrow--open]="isOpen()" />
      </button>

      <!-- Dropdown panel -->
      @if (isOpen()) {
        <div class="sol-select__dropdown" [class.sol-select__dropdown--up]="dropUp()">
          <!-- Search -->
          @if (searchable()) {
            <div class="sol-select__search-box">
              <input
                #searchInput
                type="text"
                class="sol-select__search"
                placeholder="Buscar..."
                [value]="searchTerm()"
                (input)="onSearchInput($event)"
                (keydown.escape)="closeDropdown()"
              />
            </div>
          }

          <!-- Select all / none for multi -->
          @if (multiple()) {
            <div class="sol-select__bulk-actions">
              <button type="button" class="sol-select__bulk-btn" (click)="selectAll()">Todos</button>
              <button type="button" class="sol-select__bulk-btn" (click)="selectNone()">Ninguno</button>
            </div>
          }

          <!-- "Todos" option for single mode (acts as empty/clear) -->
          @if (!multiple() && showAllOption()) {
            <div
              class="sol-select__option"
              [class.sol-select__option--active]="!singleValue()"
              (click)="onSelectSingle('')"
            >
              {{ allOptionLabel() }}
            </div>
          }

          <!-- Options -->
          <div class="sol-select__options">
            @for (opt of filteredOptions(); track opt.value) {
              <div
                class="sol-select__option"
                [class.sol-select__option--active]="isSelected(opt.value)"
                (click)="onOptionClick(opt.value)"
              >
                @if (multiple()) {
                  <span class="sol-select__check" [class.sol-select__check--checked]="isSelected(opt.value)">
                    @if (isSelected(opt.value)) { &#10003; }
                  </span>
                }
                {{ opt.label }}
              </div>
            } @empty {
              <div class="sol-select__empty">Sin resultados</div>
            }
          </div>
        </div>
      }
    </div>

    @if (error()) {
      <p class="sol-select__error">{{ error() }}</p>
    }
  `, styles: [":host{display:block;--sol-select-bg: var(--sol-input-bg, var(--sol-bg-surface, #ffffff));--sol-select-text: var(--sol-color-text-primary, #1e293b);--sol-select-placeholder: var(--sol-color-text-muted, #94a3b8);--sol-select-border: var(--sol-border-color-default, #cbd5e1);--sol-select-border-focus: var(--sol-color-primary, #6366f1);--sol-select-error-color: var(--sol-color-danger, #ef4444);--sol-select-label-color: var(--sol-color-text-secondary, #475569);--sol-select-arrow-color: var(--sol-color-text-muted, #94a3b8);--sol-select-disabled-opacity: var(--sol-disabled-opacity, .55);--sol-select-radius: var(--sol-input-radius, var(--sol-border-radius-md, .5rem));--sol-select-border-width: var(--sol-border-width-default, 1px);--sol-select-padding-x: var(--sol-space-sm, .75rem);--sol-select-height: var(--sol-size-input-height, 2.5rem);--sol-select-font-size: var(--sol-font-size-base, .875rem);--sol-select-label-font-size: var(--sol-font-size-sm, .75rem);--sol-select-label-font-weight: var(--sol-font-weight-bold, 600);--sol-select-shadow: var(--sol-input-shadow, var(--sol-shadow-sm, 0 1px 2px rgba(0,0,0,.05)));--sol-select-focus-ring: var(--sol-input-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent));--sol-select-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease);--sol-select-dropdown-bg: var(--sol-bg-surface, #ffffff);--sol-select-option-hover: var(--sol-color-bg-hover, rgba(0,0,0,.04));--sol-select-option-active-bg: color-mix(in srgb, var(--sol-color-primary, #6366f1) 12%, transparent);--sol-select-option-active-text: var(--sol-color-primary, #6366f1)}.sol-select__label{display:block;margin-bottom:.375rem;font-size:var(--sol-select-label-font-size);font-weight:var(--sol-select-label-font-weight);color:var(--sol-select-label-color);line-height:1.4}.sol-select__wrapper{position:relative;display:block}.sol-select__trigger{display:flex;align-items:center;justify-content:space-between;width:100%;height:var(--sol-select-height);padding:0 var(--sol-select-padding-x);font-family:inherit;font-size:var(--sol-select-font-size);color:var(--sol-select-text);background-color:var(--sol-select-bg);border:var(--sol-input-border, var(--sol-select-border-width) solid var(--sol-select-border));border-radius:var(--sol-select-radius);box-shadow:var(--sol-select-shadow);cursor:pointer;transition:border-color var(--sol-select-transition),box-shadow var(--sol-select-transition);text-align:left}.sol-select__trigger:focus{outline:none;border:var(--sol-input-focus-border, var(--sol-select-border-width) solid var(--sol-select-border-focus));box-shadow:var(--sol-select-focus-ring)}.sol-select__trigger:disabled{cursor:not-allowed;opacity:var(--sol-select-disabled-opacity)}.sol-select__trigger--error{border-color:var(--sol-select-error-color)}.sol-select__trigger--open{border:var(--sol-input-focus-border, var(--sol-select-border-width) solid var(--sol-select-border-focus));box-shadow:var(--sol-select-focus-ring)}.sol-select__display{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-select__display--placeholder{color:var(--sol-select-placeholder)}.sol-select__arrow{width:1.25rem;height:1.25rem;flex-shrink:0;color:var(--sol-select-arrow-color);transition:transform var(--sol-select-transition)}.sol-select__arrow--open{transform:rotate(180deg)}.sol-select__dropdown{position:absolute;top:calc(100% + 4px);left:0;right:0;z-index:var(--sol-z-dropdown, 1000);background:var(--sol-select-dropdown-bg);border:var(--sol-select-border-width) solid var(--sol-select-border);border-radius:var(--sol-select-radius);box-shadow:var(--sol-shadow-lg, 0 10px 25px rgba(0,0,0,.15));max-height:280px;display:flex;flex-direction:column;animation:sol-select-fade .12s ease-out}.sol-select__search-box{padding:.5rem;border-bottom:1px solid var(--sol-select-border)}.sol-select__search{width:100%;height:2rem;padding:0 .5rem;font-family:inherit;font-size:var(--sol-select-font-size);color:var(--sol-select-text);background:var(--sol-select-bg);border:var(--sol-select-border-width) solid var(--sol-select-border);border-radius:calc(var(--sol-select-radius) - 2px);outline:none}.sol-select__search:focus{border-color:var(--sol-select-border-focus)}.sol-select__bulk-actions{display:flex;gap:.25rem;padding:.375rem .5rem;border-bottom:1px solid var(--sol-select-border)}.sol-select__bulk-btn{flex:1;padding:.25rem;font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.03em;color:var(--sol-select-option-active-text);background:transparent;border:1px solid var(--sol-select-border);border-radius:calc(var(--sol-select-radius) - 2px);cursor:pointer;transition:background var(--sol-select-transition)}.sol-select__bulk-btn:hover{background:var(--sol-select-option-hover)}.sol-select__options{overflow-y:auto;flex:1;padding:.25rem 0}.sol-select__option{display:flex;align-items:center;gap:.5rem;padding:.5rem .75rem;font-size:var(--sol-select-font-size);color:var(--sol-select-text);cursor:pointer;transition:background var(--sol-select-transition)}.sol-select__option:hover{background:var(--sol-select-option-hover)}.sol-select__option--active{background:var(--sol-select-option-active-bg);color:var(--sol-select-option-active-text);font-weight:500}.sol-select__check{display:inline-flex;align-items:center;justify-content:center;width:1rem;height:1rem;border:2px solid var(--sol-select-border);border-radius:3px;font-size:.65rem;flex-shrink:0}.sol-select__check--checked{background:var(--sol-select-option-active-text);border-color:var(--sol-select-option-active-text);color:#fff}.sol-select__empty{padding:.75rem;text-align:center;color:var(--sol-select-placeholder);font-size:var(--sol-select-font-size)}.sol-select__error{margin:.25rem 0 0;font-size:var(--sol-select-label-font-size);color:var(--sol-select-error-color);line-height:1.4}.sol-select__dropdown--up{top:auto;bottom:calc(100% + 4px);animation:sol-select-fade-up .12s ease-out}@keyframes sol-select-fade{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}@keyframes sol-select-fade-up{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], searchable: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchable", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], showAllOption: [{ type: i0.Input, args: [{ isSignal: true, alias: "showAllOption", required: false }] }], allOptionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "allOptionLabel", required: false }] }], searchInput: [{ type: i0.ViewChild, args: ['searchInput', { isSignal: true }] }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class SolTextareaComponent {
    /** Placeholder text for the textarea. */
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /** Label displayed above the textarea. */
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Error message displayed below the textarea. */
    error = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    /** Whether the textarea is disabled. */
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Number of visible text rows. */
    rows = input(3, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    /** Internal value signal. */
    value = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** Computed CSS class string for the textarea element. */
    textareaClass = computed(() => {
        const base = 'sol-textarea__native';
        return this.error() ? `${base} ${base}--error` : base;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "textareaClass" }] : /* istanbul ignore next */ []));
    onChange = () => { };
    onTouched = () => { };
    onInput(event) {
        const target = event.target;
        this.value.set(target.value);
        this.onChange(target.value);
    }
    onBlur() {
        this.onTouched();
    }
    writeValue(value) {
        this.value.set(value ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        // handled via the disabled() input signal;
        // if the form sets disabled state, we reflect it through the template binding
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTextareaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolTextareaComponent, isStandalone: true, selector: "sol-textarea", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SolTextareaComponent),
                multi: true,
            },
        ], ngImport: i0, template: `
    @if (label()) {
      <label class="sol-textarea__label">{{ label() }}</label>
    }

    <textarea
      [class]="textareaClass()"
      [placeholder]="placeholder()"
      [rows]="rows()"
      [disabled]="disabled()"
      [value]="value()"
      (input)="onInput($event)"
      (blur)="onBlur()"
    ></textarea>

    @if (error()) {
      <p class="sol-textarea__error">{{ error() }}</p>
    }
  `, isInline: true, styles: [":host{display:block;--sol-textarea-bg: var(--sol-input-bg, var(--sol-bg-surface, #ffffff));--sol-textarea-text: var(--sol-color-text-primary, #1e293b);--sol-textarea-placeholder: var(--sol-color-text-muted, #94a3b8);--sol-textarea-border: var(--sol-border-color-default, #cbd5e1);--sol-textarea-border-focus: var(--sol-color-primary, #6366f1);--sol-textarea-error-color: var(--sol-color-danger, #ef4444);--sol-textarea-label-color: var(--sol-color-text-secondary, #475569);--sol-textarea-disabled-opacity: var(--sol-disabled-opacity, .55);--sol-textarea-radius: var(--sol-input-radius, var(--sol-border-radius-md, .5rem));--sol-textarea-border-width: var(--sol-border-width-default, 1px);--sol-textarea-padding-x: var(--sol-space-sm, .75rem);--sol-textarea-padding-y: var(--sol-space-xs, .5rem);--sol-textarea-font-size: var(--sol-font-size-base, .875rem);--sol-textarea-label-font-size: var(--sol-font-size-sm, .75rem);--sol-textarea-label-font-weight: var(--sol-font-weight-bold, 600);--sol-textarea-shadow: var(--sol-input-shadow, var(--sol-shadow-sm, 0 1px 2px rgba(0,0,0,.05)));--sol-textarea-focus-ring: var(--sol-input-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent));--sol-textarea-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease)}.sol-textarea__label{display:block;margin-bottom:.375rem;font-size:var(--sol-textarea-label-font-size);font-weight:var(--sol-textarea-label-font-weight);color:var(--sol-textarea-label-color);line-height:1.4}.sol-textarea__native{display:block;width:100%;padding:var(--sol-textarea-padding-y) var(--sol-textarea-padding-x);font-family:inherit;font-size:var(--sol-textarea-font-size);color:var(--sol-textarea-text);background-color:var(--sol-textarea-bg);border:var(--sol-input-border, var(--sol-textarea-border-width) solid var(--sol-textarea-border));border-radius:var(--sol-textarea-radius);box-shadow:var(--sol-textarea-shadow);resize:vertical;transition:border-color var(--sol-textarea-transition),box-shadow var(--sol-textarea-transition)}.sol-textarea__native::placeholder{color:var(--sol-textarea-placeholder)}.sol-textarea__native:focus{outline:none;border:var(--sol-input-focus-border, var(--sol-textarea-border-width) solid var(--sol-textarea-border-focus));box-shadow:var(--sol-textarea-focus-ring)}.sol-textarea__native:disabled{cursor:not-allowed;opacity:var(--sol-textarea-disabled-opacity)}.sol-textarea__native--error{border-color:var(--sol-textarea-error-color)}.sol-textarea__native--error:focus{box-shadow:0 0 0 3px color-mix(in srgb,var(--sol-textarea-error-color) 40%,transparent)}.sol-textarea__error{margin:.25rem 0 0;font-size:var(--sol-textarea-label-font-size);color:var(--sol-textarea-error-color);line-height:1.4}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-textarea', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SolTextareaComponent),
                            multi: true,
                        },
                    ], template: `
    @if (label()) {
      <label class="sol-textarea__label">{{ label() }}</label>
    }

    <textarea
      [class]="textareaClass()"
      [placeholder]="placeholder()"
      [rows]="rows()"
      [disabled]="disabled()"
      [value]="value()"
      (input)="onInput($event)"
      (blur)="onBlur()"
    ></textarea>

    @if (error()) {
      <p class="sol-textarea__error">{{ error() }}</p>
    }
  `, styles: [":host{display:block;--sol-textarea-bg: var(--sol-input-bg, var(--sol-bg-surface, #ffffff));--sol-textarea-text: var(--sol-color-text-primary, #1e293b);--sol-textarea-placeholder: var(--sol-color-text-muted, #94a3b8);--sol-textarea-border: var(--sol-border-color-default, #cbd5e1);--sol-textarea-border-focus: var(--sol-color-primary, #6366f1);--sol-textarea-error-color: var(--sol-color-danger, #ef4444);--sol-textarea-label-color: var(--sol-color-text-secondary, #475569);--sol-textarea-disabled-opacity: var(--sol-disabled-opacity, .55);--sol-textarea-radius: var(--sol-input-radius, var(--sol-border-radius-md, .5rem));--sol-textarea-border-width: var(--sol-border-width-default, 1px);--sol-textarea-padding-x: var(--sol-space-sm, .75rem);--sol-textarea-padding-y: var(--sol-space-xs, .5rem);--sol-textarea-font-size: var(--sol-font-size-base, .875rem);--sol-textarea-label-font-size: var(--sol-font-size-sm, .75rem);--sol-textarea-label-font-weight: var(--sol-font-weight-bold, 600);--sol-textarea-shadow: var(--sol-input-shadow, var(--sol-shadow-sm, 0 1px 2px rgba(0,0,0,.05)));--sol-textarea-focus-ring: var(--sol-input-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent));--sol-textarea-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease)}.sol-textarea__label{display:block;margin-bottom:.375rem;font-size:var(--sol-textarea-label-font-size);font-weight:var(--sol-textarea-label-font-weight);color:var(--sol-textarea-label-color);line-height:1.4}.sol-textarea__native{display:block;width:100%;padding:var(--sol-textarea-padding-y) var(--sol-textarea-padding-x);font-family:inherit;font-size:var(--sol-textarea-font-size);color:var(--sol-textarea-text);background-color:var(--sol-textarea-bg);border:var(--sol-input-border, var(--sol-textarea-border-width) solid var(--sol-textarea-border));border-radius:var(--sol-textarea-radius);box-shadow:var(--sol-textarea-shadow);resize:vertical;transition:border-color var(--sol-textarea-transition),box-shadow var(--sol-textarea-transition)}.sol-textarea__native::placeholder{color:var(--sol-textarea-placeholder)}.sol-textarea__native:focus{outline:none;border:var(--sol-input-focus-border, var(--sol-textarea-border-width) solid var(--sol-textarea-border-focus));box-shadow:var(--sol-textarea-focus-ring)}.sol-textarea__native:disabled{cursor:not-allowed;opacity:var(--sol-textarea-disabled-opacity)}.sol-textarea__native--error{border-color:var(--sol-textarea-error-color)}.sol-textarea__native--error:focus{box-shadow:0 0 0 3px color-mix(in srgb,var(--sol-textarea-error-color) 40%,transparent)}.sol-textarea__error{margin:.25rem 0 0;font-size:var(--sol-textarea-label-font-size);color:var(--sol-textarea-error-color);line-height:1.4}\n"] }]
        }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }] } });

class SolToggleComponent {
    /** Optional label displayed beside the toggle. */
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Whether the toggle is disabled. */
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Size preset: sm or md. */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Internal checked state. */
    checked = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []));
    /** Computed host wrapper class. */
    hostClass = computed(() => {
        const classes = ['sol-toggle', `sol-toggle--${this.size()}`];
        if (this.disabled())
            classes.push('sol-toggle--disabled');
        return classes.join(' ');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClass" }] : /* istanbul ignore next */ []));
    /** Computed track class combining size and on/off state. */
    trackClass = computed(() => {
        const base = 'sol-toggle__track';
        const classes = [base, `${base}--${this.size()}`];
        if (this.checked())
            classes.push(`${base}--on`);
        return classes.join(' ');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trackClass" }] : /* istanbul ignore next */ []));
    /** Computed thumb class combining size and on/off state. */
    thumbClass = computed(() => {
        const s = this.size();
        const base = 'sol-toggle__thumb';
        const classes = [base, `${base}--${s}`];
        if (this.checked())
            classes.push(`${base}--${s}-on`);
        return classes.join(' ');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "thumbClass" }] : /* istanbul ignore next */ []));
    onChange = () => { };
    onTouched = () => { };
    toggle() {
        if (this.disabled())
            return;
        const next = !this.checked();
        this.checked.set(next);
        this.onChange(next);
        this.onTouched();
    }
    writeValue(value) {
        this.checked.set(!!value);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        // handled via the disabled() input signal;
        // if the form sets disabled state, we reflect it through the template binding
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolToggleComponent, isStandalone: true, selector: "sol-toggle", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SolToggleComponent),
                multi: true,
            },
        ], ngImport: i0, template: `
    <label [class]="hostClass()">
      <button
        type="button"
        role="switch"
        [attr.aria-checked]="checked()"
        [class]="trackClass()"
        [disabled]="disabled()"
        (click)="toggle()"
      >
        <span [class]="thumbClass()"></span>
      </button>

      @if (label()) {
        <span class="sol-toggle__label">{{ label() }}</span>
      }
    </label>
  `, isInline: true, styles: [":host{display:inline-block;--sol-toggle-track-off: var(--sol-color-text-muted, #cbd5e1);--sol-toggle-track-on: var(--sol-color-primary, #6366f1);--sol-toggle-thumb: var(--sol-bg-surface, #ffffff);--sol-toggle-label-color: var(--sol-color-text-primary, #1e293b);--sol-toggle-disabled-opacity: var(--sol-disabled-opacity, .55);--sol-toggle-focus-ring: var(--sol-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent));--sol-toggle-transition: var(--sol-transition-fast, .15s ease);--sol-toggle-shadow: var(--sol-shadow-sm, 0 1px 2px rgba(0,0,0,.1));--sol-toggle-md-width: 2.75rem;--sol-toggle-md-height: 1.5rem;--sol-toggle-md-thumb: 1.25rem;--sol-toggle-md-offset: .125rem;--sol-toggle-md-label-font: var(--sol-font-size-base, .875rem);--sol-toggle-sm-width: 2rem;--sol-toggle-sm-height: 1.125rem;--sol-toggle-sm-thumb: .875rem;--sol-toggle-sm-offset: .125rem;--sol-toggle-sm-label-font: var(--sol-font-size-sm, .75rem)}.sol-toggle{display:inline-flex;align-items:center;gap:.5rem;cursor:pointer}.sol-toggle--disabled{cursor:not-allowed;opacity:var(--sol-toggle-disabled-opacity)}.sol-toggle__track{position:relative;display:inline-flex;align-items:center;flex-shrink:0;border:none;padding:0;cursor:pointer;border-radius:9999px;background-color:var(--sol-toggle-track-off);transition:background-color var(--sol-toggle-transition)}.sol-toggle__track:focus-visible{outline:none;box-shadow:var(--sol-toggle-focus-ring)}.sol-toggle__track:disabled{cursor:not-allowed}.sol-toggle__track--on{background-color:var(--sol-toggle-track-on)}.sol-toggle__track--md{width:var(--sol-toggle-md-width);height:var(--sol-toggle-md-height)}.sol-toggle__track--sm{width:var(--sol-toggle-sm-width);height:var(--sol-toggle-sm-height)}.sol-toggle__thumb{display:block;border-radius:9999px;background-color:var(--sol-toggle-thumb);box-shadow:var(--sol-toggle-shadow);transition:transform var(--sol-toggle-transition)}.sol-toggle__thumb--md{width:var(--sol-toggle-md-thumb);height:var(--sol-toggle-md-thumb);transform:translate(var(--sol-toggle-md-offset))}.sol-toggle__thumb--md-on{transform:translate(calc(var(--sol-toggle-md-width) - var(--sol-toggle-md-thumb) - var(--sol-toggle-md-offset)))}.sol-toggle__thumb--sm{width:var(--sol-toggle-sm-thumb);height:var(--sol-toggle-sm-thumb);transform:translate(var(--sol-toggle-sm-offset))}.sol-toggle__thumb--sm-on{transform:translate(calc(var(--sol-toggle-sm-width) - var(--sol-toggle-sm-thumb) - var(--sol-toggle-sm-offset)))}.sol-toggle__label{color:var(--sol-toggle-label-color);-webkit-user-select:none;user-select:none}.sol-toggle--sm .sol-toggle__label{font-size:var(--sol-toggle-sm-label-font)}.sol-toggle--md .sol-toggle__label{font-size:var(--sol-toggle-md-label-font)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-toggle', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SolToggleComponent),
                            multi: true,
                        },
                    ], template: `
    <label [class]="hostClass()">
      <button
        type="button"
        role="switch"
        [attr.aria-checked]="checked()"
        [class]="trackClass()"
        [disabled]="disabled()"
        (click)="toggle()"
      >
        <span [class]="thumbClass()"></span>
      </button>

      @if (label()) {
        <span class="sol-toggle__label">{{ label() }}</span>
      }
    </label>
  `, styles: [":host{display:inline-block;--sol-toggle-track-off: var(--sol-color-text-muted, #cbd5e1);--sol-toggle-track-on: var(--sol-color-primary, #6366f1);--sol-toggle-thumb: var(--sol-bg-surface, #ffffff);--sol-toggle-label-color: var(--sol-color-text-primary, #1e293b);--sol-toggle-disabled-opacity: var(--sol-disabled-opacity, .55);--sol-toggle-focus-ring: var(--sol-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent));--sol-toggle-transition: var(--sol-transition-fast, .15s ease);--sol-toggle-shadow: var(--sol-shadow-sm, 0 1px 2px rgba(0,0,0,.1));--sol-toggle-md-width: 2.75rem;--sol-toggle-md-height: 1.5rem;--sol-toggle-md-thumb: 1.25rem;--sol-toggle-md-offset: .125rem;--sol-toggle-md-label-font: var(--sol-font-size-base, .875rem);--sol-toggle-sm-width: 2rem;--sol-toggle-sm-height: 1.125rem;--sol-toggle-sm-thumb: .875rem;--sol-toggle-sm-offset: .125rem;--sol-toggle-sm-label-font: var(--sol-font-size-sm, .75rem)}.sol-toggle{display:inline-flex;align-items:center;gap:.5rem;cursor:pointer}.sol-toggle--disabled{cursor:not-allowed;opacity:var(--sol-toggle-disabled-opacity)}.sol-toggle__track{position:relative;display:inline-flex;align-items:center;flex-shrink:0;border:none;padding:0;cursor:pointer;border-radius:9999px;background-color:var(--sol-toggle-track-off);transition:background-color var(--sol-toggle-transition)}.sol-toggle__track:focus-visible{outline:none;box-shadow:var(--sol-toggle-focus-ring)}.sol-toggle__track:disabled{cursor:not-allowed}.sol-toggle__track--on{background-color:var(--sol-toggle-track-on)}.sol-toggle__track--md{width:var(--sol-toggle-md-width);height:var(--sol-toggle-md-height)}.sol-toggle__track--sm{width:var(--sol-toggle-sm-width);height:var(--sol-toggle-sm-height)}.sol-toggle__thumb{display:block;border-radius:9999px;background-color:var(--sol-toggle-thumb);box-shadow:var(--sol-toggle-shadow);transition:transform var(--sol-toggle-transition)}.sol-toggle__thumb--md{width:var(--sol-toggle-md-thumb);height:var(--sol-toggle-md-thumb);transform:translate(var(--sol-toggle-md-offset))}.sol-toggle__thumb--md-on{transform:translate(calc(var(--sol-toggle-md-width) - var(--sol-toggle-md-thumb) - var(--sol-toggle-md-offset)))}.sol-toggle__thumb--sm{width:var(--sol-toggle-sm-thumb);height:var(--sol-toggle-sm-thumb);transform:translate(var(--sol-toggle-sm-offset))}.sol-toggle__thumb--sm-on{transform:translate(calc(var(--sol-toggle-sm-width) - var(--sol-toggle-sm-thumb) - var(--sol-toggle-sm-offset)))}.sol-toggle__label{color:var(--sol-toggle-label-color);-webkit-user-select:none;user-select:none}.sol-toggle--sm .sol-toggle__label{font-size:var(--sol-toggle-sm-label-font)}.sol-toggle--md .sol-toggle__label{font-size:var(--sol-toggle-md-label-font)}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }] } });

class SolModalComponent {
    /** Whether the modal is open. */
    open = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    /** Title displayed in the modal header. */
    title = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    /** Width preset for the modal panel. */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Whether the modal can be closed by the user. */
    closeable = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeable" }] : /* istanbul ignore next */ []));
    /** Whether clicking the backdrop closes the modal. */
    closeOnBackdrop = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "closeOnBackdrop" }] : /* istanbul ignore next */ []));
    /** Emitted when the modal requests to be closed. */
    closed = output();
    /** Computed CSS class for the panel size. */
    panelClasses = computed(() => `sol-modal-content sol-modal-${this.size()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelClasses" }] : /* istanbul ignore next */ []));
    onEscapeKey() {
        if (this.open() && this.closeable()) {
            this.close();
        }
    }
    onBackdropClick() {
        if (this.closeable() && this.closeOnBackdrop()) {
            this.close();
        }
    }
    close() {
        this.closed.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolModalComponent, isStandalone: true, selector: "sol-modal", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, closeable: { classPropertyName: "closeable", publicName: "closeable", isSignal: true, isRequired: false, transformFunction: null }, closeOnBackdrop: { classPropertyName: "closeOnBackdrop", publicName: "closeOnBackdrop", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closed" }, host: { listeners: { "document:keydown.escape": "onEscapeKey()" } }, ngImport: i0, template: `
    @if (open()) {
      <div
        class="sol-modal-overlay"
        (click)="onBackdropClick()"
      >
        <div
          class="sol-modal-content"
          [class]="panelClasses()"
          (click)="$event.stopPropagation()"
        >
          <header class="sol-modal-header">
            <h2 class="sol-modal-title">{{ title() }}</h2>
            @if (closeable()) {
              <button
                type="button"
                class="sol-modal-close"
                aria-label="Cerrar"
                (click)="close()"
              >
                <sol-icon name="x" size="md" />
              </button>
            }
          </header>

          <div class="sol-modal-body">
            <ng-content />
          </div>
        </div>
      </div>
    }
  `, isInline: true, styles: [".sol-modal-overlay{position:fixed;inset:0;z-index:var(--sol-z-modal, 1000);display:flex;align-items:center;justify-content:center;background:var(--sol-bg-overlay, rgba(0, 0, 0, .5));backdrop-filter:var(--sol-overlay-blur, blur(3px));-webkit-backdrop-filter:var(--sol-overlay-blur, blur(3px));animation:sol-modal-fade-in .15s ease-out}.sol-modal-content{position:relative;display:flex;flex-direction:column;background:var(--sol-bg-surface, #fff);border-radius:var(--sol-border-radius-lg, 12px);box-shadow:var(--sol-shadow-lg, 0 20px 60px rgba(0, 0, 0, .3));max-height:90vh;overflow:visible;animation:sol-modal-scale-in .2s ease-out}.sol-modal-sm{width:min(24rem,95vw)}.sol-modal-md{width:min(32rem,95vw)}.sol-modal-lg{width:min(48rem,95vw)}.sol-modal-xl{width:min(64rem,95vw)}.sol-modal-header{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.5rem;border-bottom:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-modal-title{margin:0;font-size:1.125rem;font-weight:600;color:var(--sol-color-text-primary, #111827)}.sol-modal-close{display:inline-flex;align-items:center;justify-content:center;width:2rem;height:2rem;border:none;border-radius:var(--sol-border-radius-lg, 8px);background:transparent;color:var(--sol-color-text-secondary, #6b7280);cursor:pointer;transition:background .15s ease,color .15s ease}.sol-modal-close:hover{background:var(--sol-color-bg-hover, rgba(0, 0, 0, .06));color:var(--sol-color-text-primary, #111827)}.sol-modal-body{padding:1.5rem;overflow-y:auto;max-height:calc(90vh - 4rem)}@media(max-width:767px){.sol-modal-sm,.sol-modal-md,.sol-modal-lg,.sol-modal-xl{width:min(430px,calc(100vw - 32px))}.sol-modal-content{max-height:calc(100dvh - 32px)}.sol-modal-body{max-height:calc(100dvh - 32px - 4rem)}}@keyframes sol-modal-fade-in{0%{opacity:0}to{opacity:1}}@keyframes sol-modal-scale-in{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-modal', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [SolIconComponent], template: `
    @if (open()) {
      <div
        class="sol-modal-overlay"
        (click)="onBackdropClick()"
      >
        <div
          class="sol-modal-content"
          [class]="panelClasses()"
          (click)="$event.stopPropagation()"
        >
          <header class="sol-modal-header">
            <h2 class="sol-modal-title">{{ title() }}</h2>
            @if (closeable()) {
              <button
                type="button"
                class="sol-modal-close"
                aria-label="Cerrar"
                (click)="close()"
              >
                <sol-icon name="x" size="md" />
              </button>
            }
          </header>

          <div class="sol-modal-body">
            <ng-content />
          </div>
        </div>
      </div>
    }
  `, styles: [".sol-modal-overlay{position:fixed;inset:0;z-index:var(--sol-z-modal, 1000);display:flex;align-items:center;justify-content:center;background:var(--sol-bg-overlay, rgba(0, 0, 0, .5));backdrop-filter:var(--sol-overlay-blur, blur(3px));-webkit-backdrop-filter:var(--sol-overlay-blur, blur(3px));animation:sol-modal-fade-in .15s ease-out}.sol-modal-content{position:relative;display:flex;flex-direction:column;background:var(--sol-bg-surface, #fff);border-radius:var(--sol-border-radius-lg, 12px);box-shadow:var(--sol-shadow-lg, 0 20px 60px rgba(0, 0, 0, .3));max-height:90vh;overflow:visible;animation:sol-modal-scale-in .2s ease-out}.sol-modal-sm{width:min(24rem,95vw)}.sol-modal-md{width:min(32rem,95vw)}.sol-modal-lg{width:min(48rem,95vw)}.sol-modal-xl{width:min(64rem,95vw)}.sol-modal-header{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.5rem;border-bottom:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-modal-title{margin:0;font-size:1.125rem;font-weight:600;color:var(--sol-color-text-primary, #111827)}.sol-modal-close{display:inline-flex;align-items:center;justify-content:center;width:2rem;height:2rem;border:none;border-radius:var(--sol-border-radius-lg, 8px);background:transparent;color:var(--sol-color-text-secondary, #6b7280);cursor:pointer;transition:background .15s ease,color .15s ease}.sol-modal-close:hover{background:var(--sol-color-bg-hover, rgba(0, 0, 0, .06));color:var(--sol-color-text-primary, #111827)}.sol-modal-body{padding:1.5rem;overflow-y:auto;max-height:calc(90vh - 4rem)}@media(max-width:767px){.sol-modal-sm,.sol-modal-md,.sol-modal-lg,.sol-modal-xl{width:min(430px,calc(100vw - 32px))}.sol-modal-content{max-height:calc(100dvh - 32px)}.sol-modal-body{max-height:calc(100dvh - 32px - 4rem)}}@keyframes sol-modal-fade-in{0%{opacity:0}to{opacity:1}}@keyframes sol-modal-scale-in{0%{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}\n"] }]
        }], propDecorators: { open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], closeable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeable", required: false }] }], closeOnBackdrop: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnBackdrop", required: false }] }], closed: [{ type: i0.Output, args: ["closed"] }], onEscapeKey: [{
                type: HostListener,
                args: ['document:keydown.escape']
            }] } });

class SolBadgeComponent {
    /** Visual variant controlling the badge color. */
    variant = input('neutral', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Size preset for the badge. */
    size = input('sm', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Map from variant to its corresponding CSS variable. */
    variantColorMap = {
        success: 'var(--sol-color-success, #10b981)',
        warning: 'var(--sol-color-warning, #f59e0b)',
        danger: 'var(--sol-color-danger, #ef4444)',
        info: 'var(--sol-color-info, #3b82f6)',
        neutral: 'var(--sol-color-neutral, #6b7280)',
    };
    /** Computed CSS classes combining base, size, and variant. */
    hostClasses = computed(() => `sol-badge sol-badge-${this.size()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    /** Computed inline styles for variant-based coloring using color-mix. */
    hostStyles = computed(() => {
        const color = this.variantColorMap[this.variant()];
        return `background: color-mix(in srgb, ${color} 15%, transparent); color: ${color};`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostStyles" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolBadgeComponent, isStandalone: true, selector: "sol-badge", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <span [class]="hostClasses()" [style]="hostStyles()">
      <ng-content />
    </span>
  `, isInline: true, styles: [":host{display:inline-flex}.sol-badge{display:inline-flex;align-items:center;font-weight:500;white-space:nowrap;border-radius:var(--sol-border-radius-full, 9999px);line-height:1}.sol-badge-sm{padding:.125rem .5rem;font-size:.75rem}.sol-badge-md{padding:.25rem .75rem;font-size:.8125rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolBadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-badge', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <span [class]="hostClasses()" [style]="hostStyles()">
      <ng-content />
    </span>
  `, styles: [":host{display:inline-flex}.sol-badge{display:inline-flex;align-items:center;font-weight:500;white-space:nowrap;border-radius:var(--sol-border-radius-full, 9999px);line-height:1}.sol-badge-sm{padding:.125rem .5rem;font-size:.75rem}.sol-badge-md{padding:.25rem .75rem;font-size:.8125rem}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }] } });

class SolCardComponent {
    /** Whether the card has internal padding. */
    padding = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "padding" }] : /* istanbul ignore next */ []));
    /** Whether the card shows a hover shadow effect. */
    hoverable = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hoverable" }] : /* istanbul ignore next */ []));
    /** Computed CSS classes combining base, padding, and hover states. */
    hostClasses = computed(() => {
        const classes = ['sol-card'];
        if (this.padding()) {
            classes.push('sol-card-padded');
        }
        if (this.hoverable()) {
            classes.push('sol-card-hoverable');
        }
        return classes.join(' ');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolCardComponent, isStandalone: true, selector: "sol-card", inputs: { padding: { classPropertyName: "padding", publicName: "padding", isSignal: true, isRequired: false, transformFunction: null }, hoverable: { classPropertyName: "hoverable", publicName: "hoverable", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div [class]="hostClasses()">
      <ng-content />
    </div>
  `, isInline: true, styles: [".sol-card{background:var(--sol-card-bg, var(--sol-bg-surface, #fff));border:var(--sol-card-border, 1px solid var(--sol-border-color-default, #e5e7eb));border-radius:var(--sol-card-radius, var(--sol-border-radius-lg, 12px));box-shadow:var(--sol-card-shadow, var(--sol-shadow-sm, 0 1px 3px rgba(0, 0, 0, .08)));-webkit-backdrop-filter:var(--sol-card-blur, none);backdrop-filter:var(--sol-card-blur, none);transition:box-shadow var(--sol-dur-base, .24s) var(--sol-ease, ease),transform var(--sol-dur-base, .24s) var(--sol-ease, ease)}.sol-card:hover{transform:translateY(var(--sol-hover-lift, 0px));box-shadow:var(--sol-card-shadow-hover, var(--sol-card-shadow, var(--sol-shadow-sm)))}.sol-card-padded{padding:1.5rem}.sol-card-hoverable{cursor:pointer}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-card', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div [class]="hostClasses()">
      <ng-content />
    </div>
  `, styles: [".sol-card{background:var(--sol-card-bg, var(--sol-bg-surface, #fff));border:var(--sol-card-border, 1px solid var(--sol-border-color-default, #e5e7eb));border-radius:var(--sol-card-radius, var(--sol-border-radius-lg, 12px));box-shadow:var(--sol-card-shadow, var(--sol-shadow-sm, 0 1px 3px rgba(0, 0, 0, .08)));-webkit-backdrop-filter:var(--sol-card-blur, none);backdrop-filter:var(--sol-card-blur, none);transition:box-shadow var(--sol-dur-base, .24s) var(--sol-ease, ease),transform var(--sol-dur-base, .24s) var(--sol-ease, ease)}.sol-card:hover{transform:translateY(var(--sol-hover-lift, 0px));box-shadow:var(--sol-card-shadow-hover, var(--sol-card-shadow, var(--sol-shadow-sm)))}.sol-card-padded{padding:1.5rem}.sol-card-hoverable{cursor:pointer}\n"] }]
        }], propDecorators: { padding: [{ type: i0.Input, args: [{ isSignal: true, alias: "padding", required: false }] }], hoverable: [{ type: i0.Input, args: [{ isSignal: true, alias: "hoverable", required: false }] }] } });

/**
 * Identity fallback used when the host does not provide an implementation.
 * Returns keys unchanged so components fall back to their built-in defaults.
 */
function createIdentitySolI18n() {
    return {
        activeLang: signal('es-CO'),
        translate: (key) => key,
        t: (key) => signal(key),
        tMany: (keys) => signal(keys),
    };
}
/**
 * Injection token for the i18n contract. Defaults to the identity fallback so
 * the library works out of the box; the host overrides it with a real engine.
 */
const SOL_I18N = new InjectionToken('SOL_I18N', {
    providedIn: 'root',
    factory: createIdentitySolI18n,
});

class SolSpinnerComponent {
    i18n = inject(SOL_I18N);
    /** Size preset for the spinner. */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Custom color override. Defaults to var(--sol-color-primary). */
    color = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    /** Computed CSS classes combining base and size. */
    hostClasses = computed(() => `sol-spinner sol-spinner-${this.size()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    /** Computed inline style for color override. */
    hostStyles = computed(() => {
        const c = this.color();
        return `color: ${c || 'var(--sol-color-primary, #3b82f6)'}`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostStyles" }] : /* istanbul ignore next */ []));
    /** Etiqueta accesible traducida (`shared.spinner.loading`), reactiva al idioma activo. */
    ariaLabel = this.i18n.t('shared.spinner.loading');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolSpinnerComponent, isStandalone: true, selector: "sol-spinner", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "status" }, properties: { "attr.aria-label": "ariaLabel()" } }, ngImport: i0, template: `
    <svg
      [class]="hostClasses()"
      [style]="hostStyles()"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle
        class="sol-spinner-track"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        stroke-width="3"
      />
      <path
        class="sol-spinner-arc"
        d="M12 2a10 10 0 0 1 10 10"
        stroke="currentColor"
        stroke-width="3"
        stroke-linecap="round"
      />
    </svg>
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;justify-content:center}.sol-spinner{animation:sol-spin .75s linear infinite}.sol-spinner-sm{width:1rem;height:1rem}.sol-spinner-md{width:1.5rem;height:1.5rem}.sol-spinner-lg{width:2.5rem;height:2.5rem}.sol-spinner-track{opacity:.2}.sol-spinner-arc{opacity:1}@keyframes sol-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-spinner', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        role: 'status',
                        '[attr.aria-label]': 'ariaLabel()',
                    }, template: `
    <svg
      [class]="hostClasses()"
      [style]="hostStyles()"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle
        class="sol-spinner-track"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        stroke-width="3"
      />
      <path
        class="sol-spinner-arc"
        d="M12 2a10 10 0 0 1 10 10"
        stroke="currentColor"
        stroke-width="3"
        stroke-linecap="round"
      />
    </svg>
  `, styles: [":host{display:inline-flex;align-items:center;justify-content:center}.sol-spinner{animation:sol-spin .75s linear infinite}.sol-spinner-sm{width:1rem;height:1rem}.sol-spinner-md{width:1.5rem;height:1.5rem}.sol-spinner-lg{width:2.5rem;height:2.5rem}.sol-spinner-track{opacity:.2}.sol-spinner-arc{opacity:1}@keyframes sol-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }] } });

class SolTabsComponent {
    tabs = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []));
    activeTab = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeTab" }] : /* istanbul ignore next */ []));
    tabChange = output();
    indicatorStyle = computed(() => '', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "indicatorStyle" }] : /* istanbul ignore next */ []));
    selectTab(id) {
        this.tabChange.emit(id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolTabsComponent, isStandalone: true, selector: "sol-tabs", inputs: { tabs: { classPropertyName: "tabs", publicName: "tabs", isSignal: true, isRequired: true, transformFunction: null }, activeTab: { classPropertyName: "activeTab", publicName: "activeTab", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { tabChange: "tabChange" }, ngImport: i0, template: `
    <div class="sol-tabs" role="tablist">
      @for (tab of tabs(); track tab.id) {
        <button
          type="button"
          role="tab"
          class="sol-tabs__tab"
          [class.sol-tabs__tab--active]="activeTab() === tab.id"
          [attr.aria-selected]="activeTab() === tab.id"
          (click)="selectTab(tab.id)"
        >
          {{ tab.label }}
        </button>
      }
      <div class="sol-tabs__indicator" [style]="indicatorStyle()"></div>
    </div>
  `, isInline: true, styles: [".sol-tabs{display:flex;position:relative;border-bottom:1px solid var(--sol-border-color-default, #E2E8F0);gap:0}.sol-tabs__tab{position:relative;padding:10px 16px;border:none;background:transparent;font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, 12px);font-weight:500;color:var(--sol-color-text-secondary, #64748B);cursor:pointer;transition:color .2s ease,background-color .2s ease;white-space:nowrap;z-index:1}.sol-tabs__tab:hover{color:var(--sol-color-primary, #2563EB);background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 5%,transparent)}.sol-tabs__tab--active{color:var(--sol-color-primary, #2563EB);font-weight:600;background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 5%,transparent)}.sol-tabs__tab--active:after{content:\"\";position:absolute;bottom:-1px;left:0;right:0;height:2px;background:var(--sol-color-primary, #2563EB);border-radius:2px 2px 0 0}.sol-tabs__indicator{display:none}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-tabs', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-tabs" role="tablist">
      @for (tab of tabs(); track tab.id) {
        <button
          type="button"
          role="tab"
          class="sol-tabs__tab"
          [class.sol-tabs__tab--active]="activeTab() === tab.id"
          [attr.aria-selected]="activeTab() === tab.id"
          (click)="selectTab(tab.id)"
        >
          {{ tab.label }}
        </button>
      }
      <div class="sol-tabs__indicator" [style]="indicatorStyle()"></div>
    </div>
  `, styles: [".sol-tabs{display:flex;position:relative;border-bottom:1px solid var(--sol-border-color-default, #E2E8F0);gap:0}.sol-tabs__tab{position:relative;padding:10px 16px;border:none;background:transparent;font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, 12px);font-weight:500;color:var(--sol-color-text-secondary, #64748B);cursor:pointer;transition:color .2s ease,background-color .2s ease;white-space:nowrap;z-index:1}.sol-tabs__tab:hover{color:var(--sol-color-primary, #2563EB);background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 5%,transparent)}.sol-tabs__tab--active{color:var(--sol-color-primary, #2563EB);font-weight:600;background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 5%,transparent)}.sol-tabs__tab--active:after{content:\"\";position:absolute;bottom:-1px;left:0;right:0;height:2px;background:var(--sol-color-primary, #2563EB);border-radius:2px 2px 0 0}.sol-tabs__indicator{display:none}\n"] }]
        }], propDecorators: { tabs: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabs", required: true }] }], activeTab: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeTab", required: false }] }], tabChange: [{ type: i0.Output, args: ["tabChange"] }] } });

class SolFormFieldComponent {
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    error = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []));
    hint = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolFormFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolFormFieldComponent, isStandalone: true, selector: "sol-form-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="sol-form-field">
      @if (label()) {
        <label class="sol-form-field__label">{{ label() }}</label>
      }
      <ng-content />
      @if (error()) {
        <span class="sol-form-field__error">{{ error() }}</span>
      }
      @if (hint() && !error()) {
        <span class="sol-form-field__hint">{{ hint() }}</span>
      }
    </div>
  `, isInline: true, styles: [":host{display:block}.sol-form-field{display:flex;flex-direction:column;gap:6px}.sol-form-field__label{font-size:var(--sol-font-size-sm, 12px);font-weight:500;color:var(--sol-color-text-secondary, #64748B);text-transform:uppercase;letter-spacing:.05em;line-height:1}.sol-form-field__error{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-danger, #EF4444);line-height:1.3}.sol-form-field__hint{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-text-muted, #94A3B8);line-height:1.3}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolFormFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-form-field', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-form-field">
      @if (label()) {
        <label class="sol-form-field__label">{{ label() }}</label>
      }
      <ng-content />
      @if (error()) {
        <span class="sol-form-field__error">{{ error() }}</span>
      }
      @if (hint() && !error()) {
        <span class="sol-form-field__hint">{{ hint() }}</span>
      }
    </div>
  `, styles: [":host{display:block}.sol-form-field{display:flex;flex-direction:column;gap:6px}.sol-form-field__label{font-size:var(--sol-font-size-sm, 12px);font-weight:500;color:var(--sol-color-text-secondary, #64748B);text-transform:uppercase;letter-spacing:.05em;line-height:1}.sol-form-field__error{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-danger, #EF4444);line-height:1.3}.sol-form-field__hint{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-text-muted, #94A3B8);line-height:1.3}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }] } });

class SolPaginationComponent {
    totalItems = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalItems" }] : /* istanbul ignore next */ []));
    pageSize = input(10, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []));
    currentPage = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []));
    pageSizeOptions = input([10, 25, 50], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSizeOptions" }] : /* istanbul ignore next */ []));
    pageChanged = output();
    pageSizeChanged = output();
    totalPages = computed(() => Math.max(1, Math.ceil(this.totalItems() / this.pageSize())), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []));
    startItem = computed(() => this.totalItems() === 0 ? 0 : (this.currentPage() - 1) * this.pageSize() + 1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "startItem" }] : /* istanbul ignore next */ []));
    endItem = computed(() => Math.min(this.currentPage() * this.pageSize(), this.totalItems()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "endItem" }] : /* istanbul ignore next */ []));
    pages = computed(() => {
        const total = this.totalPages();
        const current = this.currentPage();
        const pages = [];
        const maxVisible = 5;
        let start = Math.max(1, current - Math.floor(maxVisible / 2));
        const end = Math.min(total, start + maxVisible - 1);
        start = Math.max(1, end - maxVisible + 1);
        for (let i = start; i <= end; i++) {
            pages.push(i);
        }
        return pages;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pages" }] : /* istanbul ignore next */ []));
    onPageChange(page) {
        if (page >= 1 && page <= this.totalPages()) {
            this.pageChanged.emit(page);
        }
    }
    onPageSizeChange(event) {
        const size = Number(event.target.value);
        this.pageSizeChanged.emit(size);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolPaginationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolPaginationComponent, isStandalone: true, selector: "sol-pagination", inputs: { totalItems: { classPropertyName: "totalItems", publicName: "totalItems", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, currentPage: { classPropertyName: "currentPage", publicName: "currentPage", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pageChanged: "pageChanged", pageSizeChanged: "pageSizeChanged" }, ngImport: i0, template: `
    <div class="sol-pagination">
      <div class="sol-pagination__size">
        <label class="sol-pagination__size-label">Mostrar</label>
        <select
          class="sol-pagination__size-select"
          [value]="pageSize()"
          (change)="onPageSizeChange($event)"
        >
          @for (size of pageSizeOptions(); track size) {
            <option [value]="size">{{ size }}</option>
          }
        </select>
        <span class="sol-pagination__size-label">filas</span>
      </div>

      <div class="sol-pagination__nav">
        <span class="sol-pagination__info">
          {{ startItem() }}–{{ endItem() }} de {{ totalItems() }}
        </span>
        <button
          type="button"
          class="sol-pagination__btn"
          [disabled]="currentPage() <= 1"
          (click)="onPageChange(currentPage() - 1)"
        >
          <sol-icon name="chevron-left" size="sm" />
        </button>
        @for (p of pages(); track p) {
          <button
            type="button"
            class="sol-pagination__btn"
            [class.sol-pagination__btn--active]="p === currentPage()"
            (click)="onPageChange(p)"
          >
            {{ p }}
          </button>
        }
        <button
          type="button"
          class="sol-pagination__btn"
          [disabled]="currentPage() >= totalPages()"
          (click)="onPageChange(currentPage() + 1)"
        >
          <sol-icon name="chevron-right" size="sm" />
        </button>
      </div>
    </div>
  `, isInline: true, styles: [".sol-pagination{display:flex;align-items:center;justify-content:space-between;padding:12px 0;gap:16px}.sol-pagination__size{display:flex;align-items:center;gap:6px}.sol-pagination__size-label{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-text-muted, #94A3B8)}.sol-pagination__size-select{padding:6px 28px 6px 10px;border:1px solid var(--sol-border-color-default, #E2E8F0);border-radius:var(--sol-border-radius-sm, 6px);background-color:var(--sol-bg-surface, #fff);background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2364748B' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E\");background-repeat:no-repeat;background-position:right 8px center;color:var(--sol-color-text-primary, #0F172A);font-size:var(--sol-font-size-sm, 12px);font-family:var(--sol-font-family);outline:none;cursor:pointer;appearance:none;-webkit-appearance:none;transition:border-color .15s}.sol-pagination__size-select:focus{border-color:var(--sol-color-primary, #2563EB);box-shadow:0 0 0 2px color-mix(in srgb,var(--sol-color-primary, #2563EB) 15%,transparent)}.sol-pagination__nav{display:flex;align-items:center;gap:4px}.sol-pagination__info{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-text-muted, #94A3B8);margin-right:8px}.sol-pagination__btn{display:inline-flex;align-items:center;justify-content:center;min-width:32px;height:32px;padding:0 8px;border:none;border-radius:var(--sol-border-radius-sm, 6px);background:transparent;color:var(--sol-color-text-secondary, #64748B);font-size:var(--sol-font-size-sm, 12px);font-family:var(--sol-font-family);cursor:pointer;transition:background-color .15s,color .15s}.sol-pagination__btn:hover:not(:disabled){background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 8%,transparent);color:var(--sol-color-primary, #2563EB)}.sol-pagination__btn--active{background:var(--sol-color-primary, #2563EB)!important;color:#fff!important;font-weight:600}.sol-pagination__btn:disabled{opacity:.4;cursor:not-allowed}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolPaginationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-pagination', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [SolIconComponent], template: `
    <div class="sol-pagination">
      <div class="sol-pagination__size">
        <label class="sol-pagination__size-label">Mostrar</label>
        <select
          class="sol-pagination__size-select"
          [value]="pageSize()"
          (change)="onPageSizeChange($event)"
        >
          @for (size of pageSizeOptions(); track size) {
            <option [value]="size">{{ size }}</option>
          }
        </select>
        <span class="sol-pagination__size-label">filas</span>
      </div>

      <div class="sol-pagination__nav">
        <span class="sol-pagination__info">
          {{ startItem() }}–{{ endItem() }} de {{ totalItems() }}
        </span>
        <button
          type="button"
          class="sol-pagination__btn"
          [disabled]="currentPage() <= 1"
          (click)="onPageChange(currentPage() - 1)"
        >
          <sol-icon name="chevron-left" size="sm" />
        </button>
        @for (p of pages(); track p) {
          <button
            type="button"
            class="sol-pagination__btn"
            [class.sol-pagination__btn--active]="p === currentPage()"
            (click)="onPageChange(p)"
          >
            {{ p }}
          </button>
        }
        <button
          type="button"
          class="sol-pagination__btn"
          [disabled]="currentPage() >= totalPages()"
          (click)="onPageChange(currentPage() + 1)"
        >
          <sol-icon name="chevron-right" size="sm" />
        </button>
      </div>
    </div>
  `, styles: [".sol-pagination{display:flex;align-items:center;justify-content:space-between;padding:12px 0;gap:16px}.sol-pagination__size{display:flex;align-items:center;gap:6px}.sol-pagination__size-label{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-text-muted, #94A3B8)}.sol-pagination__size-select{padding:6px 28px 6px 10px;border:1px solid var(--sol-border-color-default, #E2E8F0);border-radius:var(--sol-border-radius-sm, 6px);background-color:var(--sol-bg-surface, #fff);background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2364748B' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E\");background-repeat:no-repeat;background-position:right 8px center;color:var(--sol-color-text-primary, #0F172A);font-size:var(--sol-font-size-sm, 12px);font-family:var(--sol-font-family);outline:none;cursor:pointer;appearance:none;-webkit-appearance:none;transition:border-color .15s}.sol-pagination__size-select:focus{border-color:var(--sol-color-primary, #2563EB);box-shadow:0 0 0 2px color-mix(in srgb,var(--sol-color-primary, #2563EB) 15%,transparent)}.sol-pagination__nav{display:flex;align-items:center;gap:4px}.sol-pagination__info{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-text-muted, #94A3B8);margin-right:8px}.sol-pagination__btn{display:inline-flex;align-items:center;justify-content:center;min-width:32px;height:32px;padding:0 8px;border:none;border-radius:var(--sol-border-radius-sm, 6px);background:transparent;color:var(--sol-color-text-secondary, #64748B);font-size:var(--sol-font-size-sm, 12px);font-family:var(--sol-font-family);cursor:pointer;transition:background-color .15s,color .15s}.sol-pagination__btn:hover:not(:disabled){background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 8%,transparent);color:var(--sol-color-primary, #2563EB)}.sol-pagination__btn--active{background:var(--sol-color-primary, #2563EB)!important;color:#fff!important;font-weight:600}.sol-pagination__btn:disabled{opacity:.4;cursor:not-allowed}\n"] }]
        }], propDecorators: { totalItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalItems", required: false }] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], currentPage: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPage", required: false }] }], pageSizeOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeOptions", required: false }] }], pageChanged: [{ type: i0.Output, args: ["pageChanged"] }], pageSizeChanged: [{ type: i0.Output, args: ["pageSizeChanged"] }] } });

class SolSearchInputComponent {
    placeholder = input('Buscar...', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    searchChange = output();
    value = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    onInput(event) {
        const val = event.target.value;
        this.value.set(val);
        this.searchChange.emit(val);
    }
    onClear() {
        this.value.set('');
        this.searchChange.emit('');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolSearchInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolSearchInputComponent, isStandalone: true, selector: "sol-search-input", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { searchChange: "searchChange" }, ngImport: i0, template: `
    <div class="sol-search-input">
      <sol-icon name="search" size="sm" class="sol-search-input__icon" />
      <input
        class="sol-search-input__field"
        type="text"
        [placeholder]="placeholder()"
        [value]="value()"
        (input)="onInput($event)"
      />
      @if (value()) {
        <button
          type="button"
          class="sol-search-input__clear"
          (click)="onClear()"
          aria-label="Limpiar búsqueda"
        >
          <sol-icon name="x" size="sm" />
        </button>
      }
    </div>
  `, isInline: true, styles: [".sol-search-input{position:relative;display:flex;align-items:center}.sol-search-input__icon{position:absolute;left:10px;color:var(--sol-color-text-muted, #94A3B8);pointer-events:none}.sol-search-input__field{width:100%;height:var(--sol-size-input-height, 36px);padding:0 32px 0 34px;border:1px solid var(--sol-border-color-default, #E2E8F0);border-radius:var(--sol-border-radius-full, 9999px);background:var(--sol-bg-surface, #fff);color:var(--sol-color-text-primary, #0F172A);font-size:var(--sol-font-size-sm, 12px);font-family:var(--sol-font-family);outline:none;transition:border-color .2s,box-shadow .2s}.sol-search-input__field::placeholder{color:var(--sol-color-text-muted, #94A3B8)}.sol-search-input__field:focus{border-color:var(--sol-color-primary, #2563EB);box-shadow:0 0 0 2px color-mix(in srgb,var(--sol-color-primary, #2563EB) 15%,transparent)}.sol-search-input__clear{position:absolute;right:8px;display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border:none;border-radius:50%;background:transparent;color:var(--sol-color-text-muted, #94A3B8);cursor:pointer;transition:color .15s,background .15s}.sol-search-input__clear:hover{color:var(--sol-color-text-primary, #0F172A);background:color-mix(in srgb,var(--sol-color-text-muted, #94A3B8) 15%,transparent)}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolSearchInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-search-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [SolIconComponent], template: `
    <div class="sol-search-input">
      <sol-icon name="search" size="sm" class="sol-search-input__icon" />
      <input
        class="sol-search-input__field"
        type="text"
        [placeholder]="placeholder()"
        [value]="value()"
        (input)="onInput($event)"
      />
      @if (value()) {
        <button
          type="button"
          class="sol-search-input__clear"
          (click)="onClear()"
          aria-label="Limpiar búsqueda"
        >
          <sol-icon name="x" size="sm" />
        </button>
      }
    </div>
  `, styles: [".sol-search-input{position:relative;display:flex;align-items:center}.sol-search-input__icon{position:absolute;left:10px;color:var(--sol-color-text-muted, #94A3B8);pointer-events:none}.sol-search-input__field{width:100%;height:var(--sol-size-input-height, 36px);padding:0 32px 0 34px;border:1px solid var(--sol-border-color-default, #E2E8F0);border-radius:var(--sol-border-radius-full, 9999px);background:var(--sol-bg-surface, #fff);color:var(--sol-color-text-primary, #0F172A);font-size:var(--sol-font-size-sm, 12px);font-family:var(--sol-font-family);outline:none;transition:border-color .2s,box-shadow .2s}.sol-search-input__field::placeholder{color:var(--sol-color-text-muted, #94A3B8)}.sol-search-input__field:focus{border-color:var(--sol-color-primary, #2563EB);box-shadow:0 0 0 2px color-mix(in srgb,var(--sol-color-primary, #2563EB) 15%,transparent)}.sol-search-input__clear{position:absolute;right:8px;display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border:none;border-radius:50%;background:transparent;color:var(--sol-color-text-muted, #94A3B8);cursor:pointer;transition:color .15s,background .15s}.sol-search-input__clear:hover{color:var(--sol-color-text-primary, #0F172A);background:color-mix(in srgb,var(--sol-color-text-muted, #94A3B8) 15%,transparent)}\n"] }]
        }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], searchChange: [{ type: i0.Output, args: ["searchChange"] }] } });

class SolTooltipComponent {
    text = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolTooltipComponent, isStandalone: true, selector: "sol-tooltip", inputs: { text: { classPropertyName: "text", publicName: "text", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    <span class="sol-tooltip-wrapper">
      <ng-content />
      <span class="sol-tooltip-text" role="tooltip">{{ text() }}</span>
    </span>
  `, isInline: true, styles: [".sol-tooltip-wrapper{position:relative;display:inline-flex}.sol-tooltip-text{position:absolute;bottom:calc(100% + 6px);left:50%;transform:translate(-50%);padding:4px 8px;background:var(--sol-color-text-primary, #0F172A);color:#fff;font-size:var(--sol-font-size-sm, 12px);font-family:var(--sol-font-family);border-radius:var(--sol-border-radius-sm, 6px);white-space:nowrap;pointer-events:none;opacity:0;transition:opacity .15s ease;z-index:var(--sol-z-tooltip, 1100)}.sol-tooltip-wrapper:hover .sol-tooltip-text{opacity:1}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-tooltip', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <span class="sol-tooltip-wrapper">
      <ng-content />
      <span class="sol-tooltip-text" role="tooltip">{{ text() }}</span>
    </span>
  `, styles: [".sol-tooltip-wrapper{position:relative;display:inline-flex}.sol-tooltip-text{position:absolute;bottom:calc(100% + 6px);left:50%;transform:translate(-50%);padding:4px 8px;background:var(--sol-color-text-primary, #0F172A);color:#fff;font-size:var(--sol-font-size-sm, 12px);font-family:var(--sol-font-family);border-radius:var(--sol-border-radius-sm, 6px);white-space:nowrap;pointer-events:none;opacity:0;transition:opacity .15s ease;z-index:var(--sol-z-tooltip, 1100)}.sol-tooltip-wrapper:hover .sol-tooltip-text{opacity:1}\n"] }]
        }], propDecorators: { text: [{ type: i0.Input, args: [{ isSignal: true, alias: "text", required: true }] }] } });

class SolCheckboxComponent {
    /** Text label beside the checkbox. */
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Whether the checkbox is disabled. */
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Size preset. */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Color variant. */
    color = input('primary', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    /** Shape of the checkbox box. */
    shape = input('rounded', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []));
    /** Whether to show ripple effect on click. */
    ripple = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ripple" }] : /* istanbul ignore next */ []));
    /** Custom icon: check (default), minus (indeterminate), heart, star. */
    icon = input('check', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    /** Link text shown after the label. */
    linkText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "linkText" }] : /* istanbul ignore next */ []));
    /** Link href. */
    linkHref = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "linkHref" }] : /* istanbul ignore next */ []));
    /** Emits when checked state changes (for template-driven usage). */
    changed = output();
    /** Internal checked state. */
    checked = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []));
    /** Ripple animation state. */
    rippleActive = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rippleActive" }] : /* istanbul ignore next */ []));
    onChange = () => { };
    onTouched = () => { };
    iconViewBox = computed(() => '0 0 24 24', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconViewBox" }] : /* istanbul ignore next */ []));
    colorVar = computed(() => {
        const map = {
            primary: 'var(--sol-cb-primary)',
            secondary: 'var(--sol-cb-secondary)',
            success: 'var(--sol-cb-success)',
            danger: 'var(--sol-cb-danger)',
            amber: 'var(--sol-cb-amber)',
            teal: 'var(--sol-cb-teal)',
            indigo: 'var(--sol-cb-indigo)',
            purple: 'var(--sol-cb-purple)',
            pink: 'var(--sol-cb-pink)',
        };
        return map[this.color()] ?? map['primary'];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "colorVar" }] : /* istanbul ignore next */ []));
    hostClass = computed(() => {
        const classes = ['sol-checkbox', `sol-checkbox--${this.size()}`];
        if (this.disabled())
            classes.push('sol-checkbox--disabled');
        return classes.join(' ');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClass" }] : /* istanbul ignore next */ []));
    boxWrapperClass = computed(() => `sol-checkbox__box-wrapper sol-checkbox__box-wrapper--${this.size()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "boxWrapperClass" }] : /* istanbul ignore next */ []));
    boxClass = computed(() => {
        const s = this.size();
        const classes = [
            'sol-checkbox__box',
            `sol-checkbox__box--${s}`,
            `sol-checkbox__box--${this.shape()}`,
        ];
        if (this.checked())
            classes.push('sol-checkbox__box--checked');
        return classes.join(' ');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "boxClass" }] : /* istanbul ignore next */ []));
    onToggle() {
        if (this.disabled())
            return;
        const next = !this.checked();
        this.checked.set(next);
        this.onChange(next);
        this.changed.emit(next);
        if (this.ripple()) {
            this.rippleActive.set(true);
            setTimeout(() => this.rippleActive.set(false), 300);
        }
    }
    // ── ControlValueAccessor ──
    writeValue(value) {
        this.checked.set(!!value);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        // Handled via disabled() input binding from reactive forms
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolCheckboxComponent, isStandalone: true, selector: "sol-checkbox", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, shape: { classPropertyName: "shape", publicName: "shape", isSignal: true, isRequired: false, transformFunction: null }, ripple: { classPropertyName: "ripple", publicName: "ripple", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, linkText: { classPropertyName: "linkText", publicName: "linkText", isSignal: true, isRequired: false, transformFunction: null }, linkHref: { classPropertyName: "linkHref", publicName: "linkHref", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { changed: "changed" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SolCheckboxComponent),
                multi: true,
            },
        ], ngImport: i0, template: `
    <label [class]="hostClass()" [style.--_cb-color]="colorVar()" (click)="$event.stopPropagation()">
      <span [class]="boxWrapperClass()">
        <input
          type="checkbox"
          class="sol-checkbox__native"
          [checked]="checked()"
          [disabled]="disabled()"
          (change)="onToggle()"
          (blur)="onTouched()"
        />
        <span [class]="boxClass()">
          @if (checked()) {
            <svg
              [class]="'sol-checkbox__icon sol-checkbox__icon--' + size()"
              [attr.viewBox]="iconViewBox()"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              stroke="currentColor"
              stroke-width="3"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              @switch (icon()) {
                @case ('check') {
                  <polyline points="20 6 9 17 4 12" />
                }
                @case ('minus') {
                  <line x1="5" y1="12" x2="19" y2="12" />
                }
                @case ('heart') {
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" fill="currentColor" stroke="none" />
                }
                @case ('star') {
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="currentColor" stroke="none" />
                }
                @default {
                  <polyline points="20 6 9 17 4 12" />
                }
              }
            </svg>
          }
        </span>
        @if (ripple()) {
          <span class="sol-checkbox__ripple" [class.sol-checkbox__ripple--active]="rippleActive()"></span>
        }
      </span>

      @if (label()) {
        <span class="sol-checkbox__label">
          {{ label() }}
          @if (linkText() && linkHref()) {
            <a [href]="linkHref()" class="sol-checkbox__link" target="_blank" rel="noopener" (click)="$event.stopPropagation()">{{ linkText() }}</a>
          }
        </span>
      }
    </label>
  `, isInline: true, styles: [":host{display:inline-block;--sol-cb-primary: var(--sol-color-primary, #2563eb);--sol-cb-secondary: var(--sol-color-secondary, #64748b);--sol-cb-success: var(--sol-color-success, #16a34a);--sol-cb-danger: var(--sol-color-danger, #dc2626);--sol-cb-amber: #d97706;--sol-cb-teal: #0d9488;--sol-cb-indigo: #4f46e5;--sol-cb-purple: #7c3aed;--sol-cb-pink: #db2777;--sol-cb-border: var(--sol-border-color-default, #94a3b8);--sol-cb-label: var(--sol-color-text-primary, #1e293b);--sol-cb-t: var(--sol-transition-fast, .15s ease)}.sol-checkbox{display:inline-flex;align-items:center;gap:8px;cursor:pointer;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}.sol-checkbox--disabled{cursor:not-allowed;opacity:.45}.sol-checkbox__native{position:absolute;width:1px;height:1px;margin:-1px;padding:0;border:0;clip:rect(0 0 0 0);overflow:hidden}.sol-checkbox__box-wrapper{position:relative;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.sol-checkbox__box{display:inline-flex;align-items:center;justify-content:center;border:2px solid var(--sol-cb-border);background:transparent;transition:background-color var(--sol-cb-t),border-color var(--sol-cb-t),box-shadow var(--sol-cb-t);position:relative;z-index:1}.sol-checkbox__box--sm{width:16px;height:16px;--_r: 3px}.sol-checkbox__box--md{width:20px;height:20px;--_r: 4px}.sol-checkbox__box--lg{width:24px;height:24px;--_r: 5px}.sol-checkbox__box--rounded{border-radius:var(--_r)}.sol-checkbox__box--square{border-radius:2px}.sol-checkbox__box--circle{border-radius:50%}.sol-checkbox__box--checked{background-color:var(--_cb-color);border-color:var(--_cb-color)}.sol-checkbox__native:focus-visible~.sol-checkbox__box{box-shadow:0 0 0 3px color-mix(in srgb,var(--_cb-color) 30%,transparent)}.sol-checkbox__icon{color:#fff;display:block}.sol-checkbox__icon--sm{width:10px;height:10px}.sol-checkbox__icon--md{width:13px;height:13px}.sol-checkbox__icon--lg{width:16px;height:16px}.sol-checkbox__ripple{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) scale(0);width:250%;height:250%;border-radius:50%;background:color-mix(in srgb,var(--_cb-color) 15%,transparent);transition:transform .3s cubic-bezier(.4,0,.2,1),opacity .3s ease;opacity:0;z-index:0;pointer-events:none}.sol-checkbox__ripple--active{transform:translate(-50%,-50%) scale(1);opacity:1}.sol-checkbox:not(.sol-checkbox--disabled) .sol-checkbox__box-wrapper:hover .sol-checkbox__ripple{transform:translate(-50%,-50%) scale(1);opacity:.6}.sol-checkbox__label{color:var(--sol-cb-label);line-height:1.4}.sol-checkbox--sm .sol-checkbox__label{font-size:var(--sol-font-size-sm, 12px)}.sol-checkbox--md .sol-checkbox__label,.sol-checkbox--lg .sol-checkbox__label{font-size:var(--sol-font-size-base, 14px)}.sol-checkbox__link{color:var(--_cb-color);text-decoration:underline;text-underline-offset:2px;font-weight:500;transition:opacity var(--sol-cb-t)}.sol-checkbox__link:hover{opacity:.8}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-checkbox', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SolCheckboxComponent),
                            multi: true,
                        },
                    ], template: `
    <label [class]="hostClass()" [style.--_cb-color]="colorVar()" (click)="$event.stopPropagation()">
      <span [class]="boxWrapperClass()">
        <input
          type="checkbox"
          class="sol-checkbox__native"
          [checked]="checked()"
          [disabled]="disabled()"
          (change)="onToggle()"
          (blur)="onTouched()"
        />
        <span [class]="boxClass()">
          @if (checked()) {
            <svg
              [class]="'sol-checkbox__icon sol-checkbox__icon--' + size()"
              [attr.viewBox]="iconViewBox()"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              stroke="currentColor"
              stroke-width="3"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              @switch (icon()) {
                @case ('check') {
                  <polyline points="20 6 9 17 4 12" />
                }
                @case ('minus') {
                  <line x1="5" y1="12" x2="19" y2="12" />
                }
                @case ('heart') {
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" fill="currentColor" stroke="none" />
                }
                @case ('star') {
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="currentColor" stroke="none" />
                }
                @default {
                  <polyline points="20 6 9 17 4 12" />
                }
              }
            </svg>
          }
        </span>
        @if (ripple()) {
          <span class="sol-checkbox__ripple" [class.sol-checkbox__ripple--active]="rippleActive()"></span>
        }
      </span>

      @if (label()) {
        <span class="sol-checkbox__label">
          {{ label() }}
          @if (linkText() && linkHref()) {
            <a [href]="linkHref()" class="sol-checkbox__link" target="_blank" rel="noopener" (click)="$event.stopPropagation()">{{ linkText() }}</a>
          }
        </span>
      }
    </label>
  `, styles: [":host{display:inline-block;--sol-cb-primary: var(--sol-color-primary, #2563eb);--sol-cb-secondary: var(--sol-color-secondary, #64748b);--sol-cb-success: var(--sol-color-success, #16a34a);--sol-cb-danger: var(--sol-color-danger, #dc2626);--sol-cb-amber: #d97706;--sol-cb-teal: #0d9488;--sol-cb-indigo: #4f46e5;--sol-cb-purple: #7c3aed;--sol-cb-pink: #db2777;--sol-cb-border: var(--sol-border-color-default, #94a3b8);--sol-cb-label: var(--sol-color-text-primary, #1e293b);--sol-cb-t: var(--sol-transition-fast, .15s ease)}.sol-checkbox{display:inline-flex;align-items:center;gap:8px;cursor:pointer;-webkit-user-select:none;user-select:none;-webkit-tap-highlight-color:transparent}.sol-checkbox--disabled{cursor:not-allowed;opacity:.45}.sol-checkbox__native{position:absolute;width:1px;height:1px;margin:-1px;padding:0;border:0;clip:rect(0 0 0 0);overflow:hidden}.sol-checkbox__box-wrapper{position:relative;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.sol-checkbox__box{display:inline-flex;align-items:center;justify-content:center;border:2px solid var(--sol-cb-border);background:transparent;transition:background-color var(--sol-cb-t),border-color var(--sol-cb-t),box-shadow var(--sol-cb-t);position:relative;z-index:1}.sol-checkbox__box--sm{width:16px;height:16px;--_r: 3px}.sol-checkbox__box--md{width:20px;height:20px;--_r: 4px}.sol-checkbox__box--lg{width:24px;height:24px;--_r: 5px}.sol-checkbox__box--rounded{border-radius:var(--_r)}.sol-checkbox__box--square{border-radius:2px}.sol-checkbox__box--circle{border-radius:50%}.sol-checkbox__box--checked{background-color:var(--_cb-color);border-color:var(--_cb-color)}.sol-checkbox__native:focus-visible~.sol-checkbox__box{box-shadow:0 0 0 3px color-mix(in srgb,var(--_cb-color) 30%,transparent)}.sol-checkbox__icon{color:#fff;display:block}.sol-checkbox__icon--sm{width:10px;height:10px}.sol-checkbox__icon--md{width:13px;height:13px}.sol-checkbox__icon--lg{width:16px;height:16px}.sol-checkbox__ripple{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) scale(0);width:250%;height:250%;border-radius:50%;background:color-mix(in srgb,var(--_cb-color) 15%,transparent);transition:transform .3s cubic-bezier(.4,0,.2,1),opacity .3s ease;opacity:0;z-index:0;pointer-events:none}.sol-checkbox__ripple--active{transform:translate(-50%,-50%) scale(1);opacity:1}.sol-checkbox:not(.sol-checkbox--disabled) .sol-checkbox__box-wrapper:hover .sol-checkbox__ripple{transform:translate(-50%,-50%) scale(1);opacity:.6}.sol-checkbox__label{color:var(--sol-cb-label);line-height:1.4}.sol-checkbox--sm .sol-checkbox__label{font-size:var(--sol-font-size-sm, 12px)}.sol-checkbox--md .sol-checkbox__label,.sol-checkbox--lg .sol-checkbox__label{font-size:var(--sol-font-size-base, 14px)}.sol-checkbox__link{color:var(--_cb-color);text-decoration:underline;text-underline-offset:2px;font-weight:500;transition:opacity var(--sol-cb-t)}.sol-checkbox__link:hover{opacity:.8}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }], shape: [{ type: i0.Input, args: [{ isSignal: true, alias: "shape", required: false }] }], ripple: [{ type: i0.Input, args: [{ isSignal: true, alias: "ripple", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], linkText: [{ type: i0.Input, args: [{ isSignal: true, alias: "linkText", required: false }] }], linkHref: [{ type: i0.Input, args: [{ isSignal: true, alias: "linkHref", required: false }] }], changed: [{ type: i0.Output, args: ["changed"] }] } });

/**
 * Placeholder de carga tokenizado: el estado de carga también es de marca.
 * La forma sale por completo de los tokens del tema — en un tema plano y
 * recto el skeleton es plano y recto; en uno redondeado y suave, también —
 * sin ninguna lógica por tenant:
 * - Fondo: `--sol-bg-sunken` (superficie hundida del tema).
 * - Radio: `--sol-card-radius` para bloques, `--sol-border-radius-sm` para
 *   líneas y filas, 50% para círculos.
 * - Shimmer: keyframe global `solShimmer` (styles.css) con duración derivada
 *   de `--sol-dur-slow`, así hereda el escalado por intensidad de motion y
 *   por prefers-reduced-motion que aplica el ThemeService a los tokens.
 *
 * Accesibilidad: el host va `aria-hidden` (es decoración); el `aria-busy`
 * del contenedor que carga lo declara el consumidor.
 */
class SolSkeletonComponent {
    variant = input('rounded', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Override opcional del ancho (los defaults salen de la variante). */
    width = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    /** Override opcional del alto (los defaults salen de la variante). */
    height = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    aspectRatio = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "aspectRatio" }] : /* istanbul ignore next */ []));
    /** Cantidad de bloques a repetir (p. ej. filas de una tabla). */
    count = input(1, { ...(ngDevMode ? { debugName: "count" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    cssClass = computed(() => `skeleton skeleton--${this.variant()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cssClass" }] : /* istanbul ignore next */ []));
    /** Índices a iterar; count inválido o menor a 1 pinta un solo bloque. */
    blocks = computed(() => {
        const total = Number.isFinite(this.count()) ? Math.max(1, Math.floor(this.count())) : 1;
        return Array.from({ length: total }, (_, index) => index);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "blocks" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolSkeletonComponent, isStandalone: true, selector: "sol-skeleton", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, aspectRatio: { classPropertyName: "aspectRatio", publicName: "aspectRatio", isSignal: true, isRequired: false, transformFunction: null }, count: { classPropertyName: "count", publicName: "count", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "aria-hidden": "true", "role": "presentation" } }, ngImport: i0, template: `
    @for (i of blocks(); track i) {
      <div
        [class]="cssClass()"
        [style.width]="width()"
        [style.height]="height()"
        [style.aspect-ratio]="aspectRatio()"
      ></div>
    }
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;gap:var(--sol-space-xs, 8px)}.skeleton{position:relative;overflow:hidden;background:var(--sol-bg-sunken, var(--sol-bg-page, #e2e8f0));border-radius:var(--sol-card-radius, var(--sol-border-radius-lg, 12px))}.skeleton:after{content:\"\";position:absolute;inset:0;background-image:linear-gradient(90deg,transparent 0%,color-mix(in srgb,var(--sol-bg-surface, #ffffff) 45%,transparent) 50%,transparent 100%);background-size:200% 100%;background-repeat:no-repeat;animation:solShimmer calc(var(--sol-dur-slow, .48s) * 3) ease-in-out infinite}@media(prefers-reduced-motion:reduce){.skeleton:after{animation:none}}.skeleton--text{height:14px;border-radius:var(--sol-border-radius-sm, 6px)}.skeleton--title{height:24px;width:45%;border-radius:var(--sol-border-radius-sm, 6px)}.skeleton--row{height:44px;border-radius:var(--sol-border-radius-sm, 6px)}.skeleton--stat{height:88px}.skeleton--card{height:300px}.skeleton--circle{width:40px;height:40px;border-radius:50%;flex:none}.skeleton--square{border-radius:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolSkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-skeleton', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'aria-hidden': 'true',
                        role: 'presentation',
                    }, template: `
    @for (i of blocks(); track i) {
      <div
        [class]="cssClass()"
        [style.width]="width()"
        [style.height]="height()"
        [style.aspect-ratio]="aspectRatio()"
      ></div>
    }
  `, styles: [":host{display:flex;flex-direction:column;gap:var(--sol-space-xs, 8px)}.skeleton{position:relative;overflow:hidden;background:var(--sol-bg-sunken, var(--sol-bg-page, #e2e8f0));border-radius:var(--sol-card-radius, var(--sol-border-radius-lg, 12px))}.skeleton:after{content:\"\";position:absolute;inset:0;background-image:linear-gradient(90deg,transparent 0%,color-mix(in srgb,var(--sol-bg-surface, #ffffff) 45%,transparent) 50%,transparent 100%);background-size:200% 100%;background-repeat:no-repeat;animation:solShimmer calc(var(--sol-dur-slow, .48s) * 3) ease-in-out infinite}@media(prefers-reduced-motion:reduce){.skeleton:after{animation:none}}.skeleton--text{height:14px;border-radius:var(--sol-border-radius-sm, 6px)}.skeleton--title{height:24px;width:45%;border-radius:var(--sol-border-radius-sm, 6px)}.skeleton--row{height:44px;border-radius:var(--sol-border-radius-sm, 6px)}.skeleton--stat{height:88px}.skeleton--card{height:300px}.skeleton--circle{width:40px;height:40px;border-radius:50%;flex:none}.skeleton--square{border-radius:0}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], aspectRatio: [{ type: i0.Input, args: [{ isSignal: true, alias: "aspectRatio", required: false }] }], count: [{ type: i0.Input, args: [{ isSignal: true, alias: "count", required: false }] }] } });

const DEFAULT_ACCEPT = 'image/jpeg,image/png,image/webp,image/gif';
const DEFAULT_MAX_SIZE = 5 * 1024 * 1024; // 5 MB
class SolFileUploadComponent {
    accept = input(DEFAULT_ACCEPT, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []));
    maxSizeBytes = input(DEFAULT_MAX_SIZE, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxSizeBytes" }] : /* istanbul ignore next */ []));
    label = input('Arrastra o haz clic para subir', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    hint = input('JPG, PNG, WEBP o GIF · máx. 5 MB', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []));
    fileSelected = output();
    previewReady = output();
    fileError = output();
    fileRemoved = output();
    isDragOver = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDragOver" }] : /* istanbul ignore next */ []));
    isDragInvalid = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDragInvalid" }] : /* istanbul ignore next */ []));
    previewUrl = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previewUrl" }] : /* istanbul ignore next */ []));
    fileName = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fileName" }] : /* istanbul ignore next */ []));
    errorMessage = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []));
    onDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        const items = event.dataTransfer?.items;
        if (items && items.length > 0) {
            const item = items[0];
            if (item.kind === 'file' && item.type && !this.isAcceptedType(item.type)) {
                this.isDragInvalid.set(true);
                this.isDragOver.set(false);
                return;
            }
        }
        this.isDragOver.set(true);
        this.isDragInvalid.set(false);
    }
    onDragLeave() {
        this.isDragOver.set(false);
        this.isDragInvalid.set(false);
    }
    onDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragOver.set(false);
        this.isDragInvalid.set(false);
        const file = event.dataTransfer?.files[0];
        if (file)
            this.processFile(file);
    }
    onInputChange(event) {
        const input = event.target;
        const file = input.files?.[0];
        if (file)
            this.processFile(file);
        input.value = '';
    }
    removeImage(event) {
        event.preventDefault();
        event.stopPropagation();
        this.reset();
        this.fileRemoved.emit();
    }
    processFile(file) {
        this.errorMessage.set(null);
        if (!this.isAcceptedType(file.type)) {
            const types = this.getReadableTypes();
            const msg = `Formato no válido. Solo se permiten: ${types}`;
            this.errorMessage.set(msg);
            this.fileError.emit(msg);
            return;
        }
        const maxSize = this.maxSizeBytes();
        if (maxSize > 0 && file.size > maxSize) {
            const maxMB = (maxSize / (1024 * 1024)).toFixed(0);
            const fileMB = (file.size / (1024 * 1024)).toFixed(1);
            const msg = `La imagen pesa ${fileMB} MB y supera el máximo de ${maxMB} MB`;
            this.errorMessage.set(msg);
            this.fileError.emit(msg);
            return;
        }
        this.fileName.set(file.name);
        this.fileSelected.emit(file);
        const reader = new FileReader();
        reader.onload = (e) => {
            const url = e.target?.result;
            this.previewUrl.set(url);
            this.previewReady.emit(url);
        };
        reader.readAsDataURL(file);
    }
    isAcceptedType(mimeType) {
        const accepted = this.accept().split(',').map(t => t.trim()).filter(Boolean);
        if (accepted.length === 0)
            return true;
        return accepted.includes(mimeType);
    }
    getReadableTypes() {
        return this.accept()
            .split(',')
            .map(t => t.trim().split('/')[1]?.toUpperCase())
            .filter(Boolean)
            .join(', ');
    }
    /** Permite resetear el componente desde el exterior */
    reset() {
        this.previewUrl.set(null);
        this.fileName.set(null);
        this.errorMessage.set(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolFileUploadComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolFileUploadComponent, isStandalone: true, selector: "sol-file-upload", inputs: { accept: { classPropertyName: "accept", publicName: "accept", isSignal: true, isRequired: false, transformFunction: null }, maxSizeBytes: { classPropertyName: "maxSizeBytes", publicName: "maxSizeBytes", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { fileSelected: "fileSelected", previewReady: "previewReady", fileError: "fileError", fileRemoved: "fileRemoved" }, ngImport: i0, template: `
    <label
      class="sol-file-upload"
      [class.sol-file-upload--dragover]="isDragOver()"
      [class.sol-file-upload--drag-invalid]="isDragInvalid()"
      [class.sol-file-upload--has-preview]="previewUrl()"
      [class.sol-file-upload--has-error]="errorMessage()"
      (dragover)="onDragOver($event)"
      (dragleave)="onDragLeave()"
      (drop)="onDrop($event)"
    >
      <input
        type="file"
        [accept]="accept()"
        class="sol-file-upload__input"
        (change)="onInputChange($event)"
      />

      @if (previewUrl()) {
        <img [src]="previewUrl()!" [alt]="fileName() || 'Vista previa'" class="sol-file-upload__preview" />
        <div class="sol-file-upload__overlay">
          <button type="button" class="sol-file-upload__remove" (click)="removeImage($event)" title="Quitar imagen">
            <sol-icon name="x" size="sm" />
          </button>
          <sol-icon name="photo" size="md" class="sol-file-upload__overlay-icon" />
          <span class="sol-file-upload__overlay-text">Cambiar imagen</span>
        </div>
      } @else {
        <div class="sol-file-upload__placeholder">
          <sol-icon name="cloud-arrow-up" size="lg" class="sol-file-upload__icon" />
          <span class="sol-file-upload__hint-primary">{{ label() }}</span>
          <span class="sol-file-upload__hint-secondary">{{ hint() }}</span>
        </div>
      }
    </label>

    @if (errorMessage()) {
      <p class="sol-file-upload__error">{{ errorMessage() }}</p>
    } @else if (fileName() && !previewUrl()) {
      <p class="sol-file-upload__filename">{{ fileName() }}</p>
    }
  `, isInline: true, styles: [".sol-file-upload{position:relative;display:flex;align-items:center;justify-content:center;width:100%;min-height:140px;border:2px dashed var(--sol-border-color-default, #E2E8F0);border-radius:var(--sol-border-radius-md, 8px);background:var(--sol-bg-page, #F8FAFC);cursor:pointer;transition:border-color .2s ease,background .2s ease;overflow:hidden;-webkit-user-select:none;user-select:none}.sol-file-upload:hover,.sol-file-upload--dragover{border-color:var(--sol-color-primary, #2563EB);background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 4%,var(--sol-bg-page, #F8FAFC))}.sol-file-upload--dragover{border-style:solid}.sol-file-upload--drag-invalid{border-color:var(--sol-color-danger, #DC2626)!important;border-style:solid;background:color-mix(in srgb,var(--sol-color-danger, #DC2626) 4%,var(--sol-bg-page, #F8FAFC))!important}.sol-file-upload--has-error{border-color:var(--sol-color-danger, #DC2626)}.sol-file-upload__input{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.sol-file-upload__placeholder{display:flex;flex-direction:column;align-items:center;gap:8px;padding:24px 16px;text-align:center;pointer-events:none}.sol-file-upload__icon{color:var(--sol-color-text-muted, #94A3B8);transition:color .2s}.sol-file-upload:hover .sol-file-upload__icon,.sol-file-upload--dragover .sol-file-upload__icon{color:var(--sol-color-primary, #2563EB)}.sol-file-upload__hint-primary{font-size:var(--sol-font-size-sm, 13px);font-weight:500;color:var(--sol-color-text-secondary, #64748B)}.sol-file-upload__hint-secondary{font-size:var(--sol-font-size-xs, 11px);color:var(--sol-color-text-muted, #94A3B8)}.sol-file-upload__preview{width:100%;height:100%;min-height:140px;object-fit:cover;display:block}.sol-file-upload__overlay{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;background:#00000073;opacity:0;transition:opacity .2s ease;pointer-events:none}.sol-file-upload:hover .sol-file-upload__overlay{opacity:1}.sol-file-upload__remove{pointer-events:auto;position:absolute;top:8px;right:8px;background:#00000080;border:none;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:#fff;transition:background .15s;z-index:1}.sol-file-upload__remove:hover{background:#dc2626cc}.sol-file-upload__overlay-icon{color:#fff}.sol-file-upload__overlay-text{font-size:var(--sol-font-size-sm, 13px);font-weight:500;color:#fff}.sol-file-upload__filename{margin:6px 0 0;font-size:var(--sol-font-size-xs, 11px);color:var(--sol-color-text-muted, #94A3B8);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-file-upload__error{margin:6px 0 0;font-size:var(--sol-font-size-xs, 11px);color:var(--sol-color-danger, #DC2626);font-weight:500}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolFileUploadComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-file-upload', standalone: true, imports: [SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <label
      class="sol-file-upload"
      [class.sol-file-upload--dragover]="isDragOver()"
      [class.sol-file-upload--drag-invalid]="isDragInvalid()"
      [class.sol-file-upload--has-preview]="previewUrl()"
      [class.sol-file-upload--has-error]="errorMessage()"
      (dragover)="onDragOver($event)"
      (dragleave)="onDragLeave()"
      (drop)="onDrop($event)"
    >
      <input
        type="file"
        [accept]="accept()"
        class="sol-file-upload__input"
        (change)="onInputChange($event)"
      />

      @if (previewUrl()) {
        <img [src]="previewUrl()!" [alt]="fileName() || 'Vista previa'" class="sol-file-upload__preview" />
        <div class="sol-file-upload__overlay">
          <button type="button" class="sol-file-upload__remove" (click)="removeImage($event)" title="Quitar imagen">
            <sol-icon name="x" size="sm" />
          </button>
          <sol-icon name="photo" size="md" class="sol-file-upload__overlay-icon" />
          <span class="sol-file-upload__overlay-text">Cambiar imagen</span>
        </div>
      } @else {
        <div class="sol-file-upload__placeholder">
          <sol-icon name="cloud-arrow-up" size="lg" class="sol-file-upload__icon" />
          <span class="sol-file-upload__hint-primary">{{ label() }}</span>
          <span class="sol-file-upload__hint-secondary">{{ hint() }}</span>
        </div>
      }
    </label>

    @if (errorMessage()) {
      <p class="sol-file-upload__error">{{ errorMessage() }}</p>
    } @else if (fileName() && !previewUrl()) {
      <p class="sol-file-upload__filename">{{ fileName() }}</p>
    }
  `, styles: [".sol-file-upload{position:relative;display:flex;align-items:center;justify-content:center;width:100%;min-height:140px;border:2px dashed var(--sol-border-color-default, #E2E8F0);border-radius:var(--sol-border-radius-md, 8px);background:var(--sol-bg-page, #F8FAFC);cursor:pointer;transition:border-color .2s ease,background .2s ease;overflow:hidden;-webkit-user-select:none;user-select:none}.sol-file-upload:hover,.sol-file-upload--dragover{border-color:var(--sol-color-primary, #2563EB);background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 4%,var(--sol-bg-page, #F8FAFC))}.sol-file-upload--dragover{border-style:solid}.sol-file-upload--drag-invalid{border-color:var(--sol-color-danger, #DC2626)!important;border-style:solid;background:color-mix(in srgb,var(--sol-color-danger, #DC2626) 4%,var(--sol-bg-page, #F8FAFC))!important}.sol-file-upload--has-error{border-color:var(--sol-color-danger, #DC2626)}.sol-file-upload__input{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.sol-file-upload__placeholder{display:flex;flex-direction:column;align-items:center;gap:8px;padding:24px 16px;text-align:center;pointer-events:none}.sol-file-upload__icon{color:var(--sol-color-text-muted, #94A3B8);transition:color .2s}.sol-file-upload:hover .sol-file-upload__icon,.sol-file-upload--dragover .sol-file-upload__icon{color:var(--sol-color-primary, #2563EB)}.sol-file-upload__hint-primary{font-size:var(--sol-font-size-sm, 13px);font-weight:500;color:var(--sol-color-text-secondary, #64748B)}.sol-file-upload__hint-secondary{font-size:var(--sol-font-size-xs, 11px);color:var(--sol-color-text-muted, #94A3B8)}.sol-file-upload__preview{width:100%;height:100%;min-height:140px;object-fit:cover;display:block}.sol-file-upload__overlay{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;background:#00000073;opacity:0;transition:opacity .2s ease;pointer-events:none}.sol-file-upload:hover .sol-file-upload__overlay{opacity:1}.sol-file-upload__remove{pointer-events:auto;position:absolute;top:8px;right:8px;background:#00000080;border:none;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:#fff;transition:background .15s;z-index:1}.sol-file-upload__remove:hover{background:#dc2626cc}.sol-file-upload__overlay-icon{color:#fff}.sol-file-upload__overlay-text{font-size:var(--sol-font-size-sm, 13px);font-weight:500;color:#fff}.sol-file-upload__filename{margin:6px 0 0;font-size:var(--sol-font-size-xs, 11px);color:var(--sol-color-text-muted, #94A3B8);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-file-upload__error{margin:6px 0 0;font-size:var(--sol-font-size-xs, 11px);color:var(--sol-color-danger, #DC2626);font-weight:500}\n"] }]
        }], propDecorators: { accept: [{ type: i0.Input, args: [{ isSignal: true, alias: "accept", required: false }] }], maxSizeBytes: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxSizeBytes", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], fileSelected: [{ type: i0.Output, args: ["fileSelected"] }], previewReady: [{ type: i0.Output, args: ["previewReady"] }], fileError: [{ type: i0.Output, args: ["fileError"] }], fileRemoved: [{ type: i0.Output, args: ["fileRemoved"] }] } });

class SolDayPickerComponent {
    days = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "days" }] : /* istanbul ignore next */ []));
    selectedDate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedDate" }] : /* istanbul ignore next */ []));
    dateSelected = output();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolDayPickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolDayPickerComponent, isStandalone: true, selector: "sol-day-picker", inputs: { days: { classPropertyName: "days", publicName: "days", isSignal: true, isRequired: true, transformFunction: null }, selectedDate: { classPropertyName: "selectedDate", publicName: "selectedDate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dateSelected: "dateSelected" }, ngImport: i0, template: `
    <div class="sol-day-picker">
      @for (day of days(); track day.dateStr) {
        <button
          type="button"
          class="sol-day-picker__item"
          [class.sol-day-picker__item--selected]="selectedDate() === day.dateStr"
          [class.sol-day-picker__item--today]="day.isToday"
          [disabled]="day.isPast"
          (click)="dateSelected.emit(day.dateStr)">
          <span class="sol-day-picker__name">{{ day.dayName }}</span>
          <span class="sol-day-picker__number">{{ day.dayNumber }}</span>
        </button>
      }
    </div>
  `, isInline: true, styles: [".sol-day-picker{display:flex;gap:8px;overflow-x:auto;padding-bottom:2px}.sol-day-picker__item{width:56px;height:56px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;border:2px solid var(--sol-border-color-default, #E2E8F0);background-color:var(--sol-bg-surface, #fff);gap:2px;flex-shrink:0;transition:border-color .15s,background-color .15s,color .15s}.sol-day-picker__item:hover:not(:disabled){border-color:var(--sol-color-primary, #2563EB)}.sol-day-picker__item--selected{background-color:var(--sol-color-primary, #2563EB)!important;border-color:var(--sol-color-primary, #2563EB)!important;color:#fff!important}.sol-day-picker__item--today:not(.sol-day-picker__item--selected){border-color:var(--sol-color-primary, #2563EB)}.sol-day-picker__item:disabled{opacity:.35;cursor:not-allowed}.sol-day-picker__name{font-size:var(--sol-font-size-xs, 11px);font-weight:500;color:var(--sol-color-text-muted, #94A3B8)}.sol-day-picker__item--selected .sol-day-picker__name{color:#ffffffd9}.sol-day-picker__number{font-size:var(--sol-font-size-sm, 13px);font-weight:600;color:var(--sol-color-text-primary, #1E293B)}.sol-day-picker__item--selected .sol-day-picker__number{color:#fff}.sol-day-picker__item:disabled .sol-day-picker__name,.sol-day-picker__item:disabled .sol-day-picker__number{color:var(--sol-color-text-muted, #94A3B8)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolDayPickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-day-picker', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-day-picker">
      @for (day of days(); track day.dateStr) {
        <button
          type="button"
          class="sol-day-picker__item"
          [class.sol-day-picker__item--selected]="selectedDate() === day.dateStr"
          [class.sol-day-picker__item--today]="day.isToday"
          [disabled]="day.isPast"
          (click)="dateSelected.emit(day.dateStr)">
          <span class="sol-day-picker__name">{{ day.dayName }}</span>
          <span class="sol-day-picker__number">{{ day.dayNumber }}</span>
        </button>
      }
    </div>
  `, styles: [".sol-day-picker{display:flex;gap:8px;overflow-x:auto;padding-bottom:2px}.sol-day-picker__item{width:56px;height:56px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;border:2px solid var(--sol-border-color-default, #E2E8F0);background-color:var(--sol-bg-surface, #fff);gap:2px;flex-shrink:0;transition:border-color .15s,background-color .15s,color .15s}.sol-day-picker__item:hover:not(:disabled){border-color:var(--sol-color-primary, #2563EB)}.sol-day-picker__item--selected{background-color:var(--sol-color-primary, #2563EB)!important;border-color:var(--sol-color-primary, #2563EB)!important;color:#fff!important}.sol-day-picker__item--today:not(.sol-day-picker__item--selected){border-color:var(--sol-color-primary, #2563EB)}.sol-day-picker__item:disabled{opacity:.35;cursor:not-allowed}.sol-day-picker__name{font-size:var(--sol-font-size-xs, 11px);font-weight:500;color:var(--sol-color-text-muted, #94A3B8)}.sol-day-picker__item--selected .sol-day-picker__name{color:#ffffffd9}.sol-day-picker__number{font-size:var(--sol-font-size-sm, 13px);font-weight:600;color:var(--sol-color-text-primary, #1E293B)}.sol-day-picker__item--selected .sol-day-picker__number{color:#fff}.sol-day-picker__item:disabled .sol-day-picker__name,.sol-day-picker__item:disabled .sol-day-picker__number{color:var(--sol-color-text-muted, #94A3B8)}\n"] }]
        }], propDecorators: { days: [{ type: i0.Input, args: [{ isSignal: true, alias: "days", required: true }] }], selectedDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedDate", required: false }] }], dateSelected: [{ type: i0.Output, args: ["dateSelected"] }] } });

// ── Helpers de fecha PUROS (calendario 100% propio, sin librerías) ──
// El picker trabaja con fechas LOCALES a medianoche y emite `yyyy-MM-dd`,
// el mismo formato date-only que boki-api y `@shared/lib` usan en tránsito,
// para nunca cruzar UTC (jamás `toISOString()`, que corre el día).
/** Fecha local a medianoche (descarta la hora). */
function midnight(d) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
/** Primer día del mes de `d`, a medianoche. */
function startOfMonth(d) {
    return new Date(d.getFullYear(), d.getMonth(), 1);
}
/** `d` desplazada `n` días (n puede ser negativo). */
function addDays(d, n) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
}
/** `d` desplazada `n` meses, apuntando al día 1. */
function addMonths(d, n) {
    return new Date(d.getFullYear(), d.getMonth() + n, 1);
}
/** `Date` local → `yyyy-MM-dd` sin pasar por UTC. */
function isoOf(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
}
/** Igualdad a nivel de día (ignora la hora). */
function sameDay(a, b) {
    return (!!a &&
        !!b &&
        a.getFullYear() === b.getFullYear() &&
        a.getMonth() === b.getMonth() &&
        a.getDate() === b.getDate());
}
/** Primera letra en mayúscula (los nombres de Intl vienen en minúscula). */
function capitalize(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}
/**
 * Normaliza el valor recibido (`Date`, `yyyy-MM-dd` u otras cadenas ISO,
 * `null`/`undefined`) a una fecha local a medianoche, o `null` si es vacío
 * o inválido.
 */
function parseInput(value) {
    if (value == null || value === '')
        return null;
    if (value instanceof Date) {
        return Number.isNaN(value.getTime()) ? null : midnight(value);
    }
    // Cadena: se toma la parte de fecha antes de una posible 'T' (ISO completo).
    const datePart = value.split('T')[0];
    const parts = datePart.split('-').map(Number);
    if (parts.length === 3 && parts.every(n => Number.isFinite(n))) {
        const [y, m, d] = parts;
        return new Date(y, m - 1, d);
    }
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? null : midnight(parsed);
}
// Dimensiones aproximadas del popover para el cálculo manual de viewport.
const POPOVER_HEIGHT = 340;
const POPOVER_WIDTH$1 = 300;
/**
 * `sol-date-picker` — calendario propio del design system, tematizado con
 * tokens `--sol-*` (light/dark) y con tres vistas navegables:
 *
 *  1. DÍAS  — grilla del mes (semana lunes→domingo, convención es-CO), con
 *     desborde atenuado del mes anterior/siguiente; hoy marcado, seleccionado
 *     con fondo primario. El encabezado "Mes AAAA" promueve a la vista MESES.
 *  2. MESES — grilla 3×4 del año; el encabezado "AAAA" promueve a la vista AÑOS.
 *  3. AÑOS  — grilla de la década (12 años); elegir un año vuelve a MESES.
 *
 * Presentación: un campo de texto de solo lectura con ícono de calendario que,
 * al enfocar o hacer clic, abre un popover con posicionamiento manual (arriba
 * o abajo según el viewport), que cierra con clic-fuera o Escape.
 *
 * API dual: funciona como componente controlado (`value` + `valueChange`) y
 * como `ControlValueAccessor` (ngModel / reactive forms). Emite siempre
 * `yyyy-MM-dd` (fecha local, sin conversión de zona horaria), el mismo formato
 * date-only que usa el resto de la plataforma.
 *
 * NOTA: es un componente DISTINTO de `sol-day-picker` (tira horizontal de días
 * del flujo de reserva). Ambos conviven en el design system.
 */
class SolDatePickerComponent {
    i18n = inject(SOL_I18N);
    hostEl = inject(ElementRef);
    // ── API pública ──
    /** Valor seleccionado. Acepta `Date`, `yyyy-MM-dd`/ISO o `null`. */
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /** Cota inferior seleccionable (fuera de rango queda deshabilitado). */
    min = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "min" }] : /* istanbul ignore next */ []));
    /** Cota superior seleccionable (fuera de rango queda deshabilitado). */
    max = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "max" }] : /* istanbul ignore next */ []));
    /** Placeholder del campo cuando no hay fecha; por defecto usa la clave i18n. */
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /** Deshabilita el campo (también lo hace `setDisabledState` de formularios). */
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Tamaño del campo disparador. */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Emite la fecha elegida como `yyyy-MM-dd` (fecha local, sin UTC). */
    valueChange = output();
    // ── Estado interno ──
    triggerRef = viewChild('trigger', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "triggerRef" }] : /* istanbul ignore next */ []));
    /** Fecha seleccionada canónica (fuente de verdad del display). */
    selected = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    /** Deshabilitado impuesto por el formulario (CVA). */
    formDisabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "formDisabled" }] : /* istanbul ignore next */ []));
    /** Mes/año que se está mostrando en la grilla. */
    viewDate = signal(startOfMonth(new Date()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewDate" }] : /* istanbul ignore next */ []));
    /** Día con foco de teclado dentro de la vista DÍAS. */
    focusedDate = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedDate" }] : /* istanbul ignore next */ []));
    view = signal('days', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []));
    isOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    dropUp = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropUp" }] : /* istanbul ignore next */ []));
    alignEnd = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "alignEnd" }] : /* istanbul ignore next */ []));
    /** Suprime la apertura por foco al devolver el foco tras cerrar el popover. */
    suppressFocusOpen = false;
    /** Hoy a medianoche, fijo durante la vida del componente. */
    today = midnight(new Date());
    // ── i18n (textos estáticos; nombres de mes/día vienen de Intl) ──
    placeholderKey = this.i18n.t('shared.datePicker.placeholder');
    triggerAriaKey = this.i18n.t('shared.datePicker.trigger');
    dialogAriaKey = this.i18n.t('shared.datePicker.dialog');
    prevAriaKey = this.i18n.t('shared.datePicker.prev');
    nextAriaKey = this.i18n.t('shared.datePicker.next');
    titleAriaKey = this.i18n.t('shared.datePicker.chooseView');
    placeholderText = computed(() => this.placeholder() || this.placeholderKey(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholderText" }] : /* istanbul ignore next */ []));
    triggerAria = this.triggerAriaKey;
    dialogAria = this.dialogAriaKey;
    prevAria = this.prevAriaKey;
    nextAria = this.nextAriaKey;
    titleAria = this.titleAriaKey;
    // ── Callbacks de ControlValueAccessor ──
    onChange = () => { };
    onTouched = () => { };
    constructor() {
        // Sincroniza el input `value` → estado interno SOLO cuando está enlazado
        // (undefined = no enlazado, p. ej. en modo reactive forms donde manda CVA).
        effect(() => {
            const v = this.value();
            if (v === undefined)
                return;
            this.selected.set(parseInput(v));
        });
    }
    // ── Derivados ──
    /** Locale efectivo (reactivo al idioma activo); es-CO por defecto. */
    locale = computed(() => this.i18n.activeLang() || 'es-CO', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "locale" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => this.disabled() || this.formDisabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    minDate = computed(() => parseInput(this.min()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minDate" }] : /* istanbul ignore next */ []));
    maxDate = computed(() => parseInput(this.max()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxDate" }] : /* istanbul ignore next */ []));
    /** Texto del campo: fecha seleccionada formateada (dd/mm/aaaa) o vacío. */
    displayText = computed(() => {
        const d = this.selected();
        if (!d)
            return '';
        return new Intl.DateTimeFormat(this.locale(), {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
        }).format(d);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []));
    /** Nombres cortos de los 7 días, empezando en lunes (convención es-CO). */
    weekdayLabels = computed(() => {
        const fmt = new Intl.DateTimeFormat(this.locale(), { weekday: 'short' });
        // 2023-01-02 es lunes: se recorre una semana completa desde ahí.
        return Array.from({ length: 7 }, (_, i) => {
            const label = fmt.format(new Date(2023, 0, 2 + i)).replace(/\.$/, '');
            return capitalize(label);
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "weekdayLabels" }] : /* istanbul ignore next */ []));
    /** Etiqueta del encabezado según la vista activa. */
    headerLabel = computed(() => {
        const view = this.view();
        const vd = this.viewDate();
        if (view === 'days') {
            const month = new Intl.DateTimeFormat(this.locale(), { month: 'long' }).format(vd);
            return `${capitalize(month)} ${vd.getFullYear()}`;
        }
        if (view === 'months') {
            return `${vd.getFullYear()}`;
        }
        const base = Math.floor(vd.getFullYear() / 10) * 10;
        return `${base} – ${base + 9}`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerLabel" }] : /* istanbul ignore next */ []));
    /** 42 celdas de día (6 semanas), agrupadas en filas de 7. */
    weeks = computed(() => {
        const vd = this.viewDate();
        const sel = this.selected();
        const focus = this.focusedDate();
        const min = this.minDate();
        const max = this.maxDate();
        const ariaFmt = new Intl.DateTimeFormat(this.locale(), {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric',
        });
        const first = startOfMonth(vd);
        // Desplazamiento hasta el lunes de la primera semana visible.
        const offsetToMonday = (first.getDay() + 6) % 7;
        const gridStart = addDays(first, -offsetToMonday);
        const rows = [];
        for (let week = 0; week < 6; week++) {
            const row = [];
            for (let d = 0; d < 7; d++) {
                const date = addDays(gridStart, week * 7 + d);
                row.push({
                    date,
                    iso: isoOf(date),
                    day: date.getDate(),
                    inMonth: date.getMonth() === vd.getMonth(),
                    isToday: sameDay(date, this.today),
                    isSelected: sameDay(date, sel),
                    isFocused: sameDay(date, focus),
                    disabled: this.outOfRange(date, min, max),
                    aria: capitalize(ariaFmt.format(date)),
                });
            }
            rows.push(row);
        }
        return rows;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "weeks" }] : /* istanbul ignore next */ []));
    /** 12 meses del año en curso de la vista. */
    months = computed(() => {
        const vd = this.viewDate();
        const sel = this.selected();
        const min = this.minDate();
        const max = this.maxDate();
        const year = vd.getFullYear();
        const fmt = new Intl.DateTimeFormat(this.locale(), { month: 'short' });
        return Array.from({ length: 12 }, (_, index) => {
            const monthStart = new Date(year, index, 1);
            const monthEnd = new Date(year, index + 1, 0);
            return {
                index,
                label: capitalize(fmt.format(monthStart).replace(/\.$/, '')),
                isCurrent: year === this.today.getFullYear() && index === this.today.getMonth(),
                isSelected: !!sel && sel.getFullYear() === year && sel.getMonth() === index,
                // Deshabilitado si el mes completo queda fuera del rango permitido.
                disabled: (!!max && monthStart > max) || (!!min && monthEnd < min),
            };
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "months" }] : /* istanbul ignore next */ []));
    /** 12 años: la década más un año antes y otro después (atenuados). */
    years = computed(() => {
        const vd = this.viewDate();
        const sel = this.selected();
        const min = this.minDate();
        const max = this.maxDate();
        const base = Math.floor(vd.getFullYear() / 10) * 10;
        return Array.from({ length: 12 }, (_, i) => {
            const year = base - 1 + i;
            const yearStart = new Date(year, 0, 1);
            const yearEnd = new Date(year, 11, 31);
            return {
                year,
                inDecade: year >= base && year <= base + 9,
                isCurrent: year === this.today.getFullYear(),
                isSelected: !!sel && sel.getFullYear() === year,
                disabled: (!!max && yearStart > max) || (!!min && yearEnd < min),
            };
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "years" }] : /* istanbul ignore next */ []));
    // ── Apertura / cierre ──
    toggle() {
        if (this.isDisabled())
            return;
        this.isOpen() ? this.close() : this.open();
    }
    /** Abre por foco, salvo cuando el foco proviene de un cierre programático. */
    onTriggerFocus() {
        if (this.suppressFocusOpen) {
            this.suppressFocusOpen = false;
            return;
        }
        this.open();
    }
    open() {
        if (this.isDisabled() || this.isOpen())
            return;
        this.isOpen.set(true);
        this.view.set('days');
        const base = this.selected() ?? this.clampToRange(this.today);
        this.viewDate.set(startOfMonth(base));
        this.focusedDate.set(this.clampToRange(base));
        this.positionPopover();
        this.focusActiveCellSoon();
    }
    close() {
        if (!this.isOpen())
            return;
        this.isOpen.set(false);
        this.onTouched();
    }
    /** Cierra al hacer clic fuera del componente. */
    onDocumentClick(event) {
        if (this.isOpen() && !this.hostEl.nativeElement.contains(event.target)) {
            this.close();
        }
    }
    /** Calcula manualmente si el popover abre hacia arriba/derecha (viewport). */
    positionPopover() {
        const rect = this.hostEl.nativeElement.getBoundingClientRect();
        const spaceBelow = window.innerHeight - rect.bottom;
        this.dropUp.set(spaceBelow < POPOVER_HEIGHT && rect.top > POPOVER_HEIGHT);
        this.alignEnd.set(rect.left + POPOVER_WIDTH$1 > window.innerWidth);
    }
    // ── Navegación del encabezado ──
    goPrev() {
        const view = this.view();
        if (view === 'days')
            this.viewDate.update(d => addMonths(d, -1));
        else if (view === 'months')
            this.viewDate.update(d => new Date(d.getFullYear() - 1, d.getMonth(), 1));
        else
            this.viewDate.update(d => new Date(d.getFullYear() - 10, d.getMonth(), 1));
    }
    goNext() {
        const view = this.view();
        if (view === 'days')
            this.viewDate.update(d => addMonths(d, 1));
        else if (view === 'months')
            this.viewDate.update(d => new Date(d.getFullYear() + 1, d.getMonth(), 1));
        else
            this.viewDate.update(d => new Date(d.getFullYear() + 10, d.getMonth(), 1));
    }
    /** Promueve la vista: días → meses → años. */
    promoteView() {
        const view = this.view();
        if (view === 'days')
            this.view.set('months');
        else if (view === 'months')
            this.view.set('years');
    }
    // ── Selección ──
    pickDay(date) {
        if (this.outOfRange(date, this.minDate(), this.maxDate()))
            return;
        this.selected.set(midnight(date));
        this.viewDate.set(startOfMonth(date));
        const iso = isoOf(date);
        this.onChange(iso);
        this.valueChange.emit(iso);
        this.onTouched();
        this.close();
        this.focusTrigger();
    }
    pickMonth(index) {
        this.viewDate.update(d => new Date(d.getFullYear(), index, 1));
        this.view.set('days');
        this.focusedDate.set(this.clampToRange(this.viewDate()));
        this.focusActiveCellSoon();
    }
    pickYear(year) {
        this.viewDate.update(d => new Date(year, d.getMonth(), 1));
        this.view.set('months');
    }
    // ── Teclado ──
    onTriggerKeydown(event) {
        if (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.open();
        }
    }
    onPopoverKeydown(event) {
        if (event.key === 'Escape') {
            event.preventDefault();
            this.close();
            this.focusTrigger();
            return;
        }
        // La navegación por flechas aplica a la vista DÍAS.
        if (this.view() !== 'days')
            return;
        const current = this.focusedDate() ?? this.clampToRange(this.today);
        let next = null;
        switch (event.key) {
            case 'ArrowLeft':
                next = addDays(current, -1);
                break;
            case 'ArrowRight':
                next = addDays(current, 1);
                break;
            case 'ArrowUp':
                next = addDays(current, -7);
                break;
            case 'ArrowDown':
                next = addDays(current, 7);
                break;
            case 'Home':
                next = addDays(current, -((current.getDay() + 6) % 7));
                break; // lunes
            case 'End':
                next = addDays(current, 6 - ((current.getDay() + 6) % 7));
                break; // domingo
            case 'PageUp':
                next = addMonths(current, -1);
                break;
            case 'PageDown':
                next = addMonths(current, 1);
                break;
            case 'Enter':
            case ' ':
                event.preventDefault();
                this.pickDay(current);
                return;
            default:
                return;
        }
        event.preventDefault();
        this.focusedDate.set(next);
        // Sigue el foco si cruza el mes visible.
        if (next.getMonth() !== this.viewDate().getMonth() || next.getFullYear() !== this.viewDate().getFullYear()) {
            this.viewDate.set(startOfMonth(next));
        }
        this.focusActiveCellSoon();
    }
    // ── ControlValueAccessor ──
    writeValue(value) {
        this.selected.set(parseInput(value));
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.formDisabled.set(isDisabled);
    }
    // ── Utilidades internas ──
    /** True si `date` está fuera del rango `[min, max]` (comparación por día). */
    outOfRange(date, min, max) {
        const d = midnight(date).getTime();
        if (min && d < min.getTime())
            return true;
        if (max && d > max.getTime())
            return true;
        return false;
    }
    /** Ajusta `date` dentro de `[min, max]` para arrancar el foco en un día válido. */
    clampToRange(date) {
        const min = this.minDate();
        const max = this.maxDate();
        if (min && midnight(date) < min)
            return midnight(min);
        if (max && midnight(date) > max)
            return midnight(max);
        return midnight(date);
    }
    /** Devuelve el foco al campo sin re-disparar la apertura por foco. */
    focusTrigger() {
        this.suppressFocusOpen = true;
        this.triggerRef()?.nativeElement?.focus();
        this.suppressFocusOpen = false;
    }
    /** Enfoca la celda con foco tras el próximo render (roving tabindex). */
    focusActiveCellSoon() {
        setTimeout(() => {
            const cell = this.hostEl.nativeElement.querySelector('.sol-date-picker__day.is-focused');
            cell?.focus();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolDatePickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolDatePickerComponent, isStandalone: true, selector: "sol-date-picker", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SolDatePickerComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "triggerRef", first: true, predicate: ["trigger"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="sol-date-picker" [class.sol-date-picker--sm]="size() === 'sm'">
      <!-- Campo disparador -->
      <div
        class="sol-date-picker__field"
        [class.sol-date-picker__field--open]="isOpen()"
        [class.sol-date-picker__field--disabled]="isDisabled()"
      >
        <input
          #trigger
          type="text"
          class="sol-date-picker__input"
          readonly
          [value]="displayText()"
          [attr.placeholder]="placeholderText()"
          [attr.aria-label]="triggerAria()"
          aria-haspopup="dialog"
          [attr.aria-expanded]="isOpen()"
          [disabled]="isDisabled()"
          (click)="open()"
          (focus)="onTriggerFocus()"
          (keydown)="onTriggerKeydown($event)"
          (blur)="onTouched()"
        />
        <button
          type="button"
          class="sol-date-picker__trigger-btn"
          tabindex="-1"
          [disabled]="isDisabled()"
          [attr.aria-label]="triggerAria()"
          (mousedown)="$event.preventDefault()"
          (click)="toggle()"
        >
          <sol-icon name="calendar" size="sm" />
        </button>
      </div>

      <!-- Popover -->
      @if (isOpen()) {
        <div
          class="sol-date-picker__pop"
          [class.sol-date-picker__pop--up]="dropUp()"
          [class.sol-date-picker__pop--end]="alignEnd()"
          role="dialog"
          [attr.aria-label]="dialogAria()"
          (keydown)="onPopoverKeydown($event)"
        >
          <!-- Encabezado con navegación -->
          <div class="sol-date-picker__header">
            <button
              type="button"
              class="sol-date-picker__nav"
              [attr.aria-label]="prevAria()"
              (click)="goPrev()"
            >
              <sol-icon name="chevron-left" size="sm" />
            </button>

            <button
              type="button"
              class="sol-date-picker__title"
              [disabled]="view() === 'years'"
              [attr.aria-label]="titleAria()"
              (click)="promoteView()"
            >
              {{ headerLabel() }}
            </button>

            <button
              type="button"
              class="sol-date-picker__nav"
              [attr.aria-label]="nextAria()"
              (click)="goNext()"
            >
              <sol-icon name="chevron-right" size="sm" />
            </button>
          </div>

          <!-- Vista DÍAS -->
          @if (view() === 'days') {
            <div class="sol-date-picker__weekdays" aria-hidden="true">
              @for (w of weekdayLabels(); track $index) {
                <span class="sol-date-picker__weekday">{{ w }}</span>
              }
            </div>
            <div class="sol-date-picker__grid" role="grid">
              @for (week of weeks(); track $index) {
                <div class="sol-date-picker__row" role="row">
                  @for (cell of week; track cell.iso) {
                    <button
                      type="button"
                      role="gridcell"
                      class="sol-date-picker__day"
                      [class.is-outside]="!cell.inMonth"
                      [class.is-today]="cell.isToday"
                      [class.is-selected]="cell.isSelected"
                      [class.is-focused]="cell.isFocused"
                      [attr.aria-selected]="cell.isSelected"
                      [attr.aria-label]="cell.aria"
                      [attr.tabindex]="cell.isFocused ? 0 : -1"
                      [disabled]="cell.disabled"
                      (click)="pickDay(cell.date)"
                    >
                      {{ cell.day }}
                    </button>
                  }
                </div>
              }
            </div>
          }

          <!-- Vista MESES -->
          @if (view() === 'months') {
            <div class="sol-date-picker__cells" role="grid">
              @for (m of months(); track m.index) {
                <button
                  type="button"
                  role="gridcell"
                  class="sol-date-picker__cell"
                  [class.is-today]="m.isCurrent"
                  [class.is-selected]="m.isSelected"
                  [attr.aria-selected]="m.isSelected"
                  [disabled]="m.disabled"
                  (click)="pickMonth(m.index)"
                >
                  {{ m.label }}
                </button>
              }
            </div>
          }

          <!-- Vista AÑOS (década) -->
          @if (view() === 'years') {
            <div class="sol-date-picker__cells" role="grid">
              @for (y of years(); track y.year) {
                <button
                  type="button"
                  role="gridcell"
                  class="sol-date-picker__cell"
                  [class.is-outside]="!y.inDecade"
                  [class.is-today]="y.isCurrent"
                  [class.is-selected]="y.isSelected"
                  [attr.aria-selected]="y.isSelected"
                  [disabled]="y.disabled"
                  (click)="pickYear(y.year)"
                >
                  {{ y.year }}
                </button>
              }
            </div>
          }
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;--sol-dp-bg: var(--sol-input-bg, var(--sol-bg-surface, #ffffff));--sol-dp-text: var(--sol-color-text-primary, #1e293b);--sol-dp-placeholder: var(--sol-color-text-muted, #94a3b8);--sol-dp-border: var(--sol-border-color-default, #cbd5e1);--sol-dp-border-focus: var(--sol-color-primary, #2563eb);--sol-dp-radius: var(--sol-input-radius, var(--sol-border-radius-md, .5rem));--sol-dp-border-width: var(--sol-border-width-default, 1px);--sol-dp-height: var(--sol-size-input-height, 2.5rem);--sol-dp-font-size: var(--sol-font-size-base, .875rem);--sol-dp-shadow: var(--sol-input-shadow, var(--sol-shadow-sm, 0 1px 2px rgba(0, 0, 0, .05)));--sol-dp-focus-ring: var(--sol-input-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #2563eb) 40%, transparent));--sol-dp-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease);--sol-dp-disabled-opacity: var(--sol-disabled-opacity, .55);--sol-dp-pop-bg: var(--sol-card-bg, var(--sol-bg-surface, #ffffff));--sol-dp-pop-radius: var(--sol-card-radius, var(--sol-border-radius-lg, .75rem));--sol-dp-pop-shadow: var(--sol-card-shadow, var(--sol-shadow-lg, 0 10px 25px rgba(0, 0, 0, .15)));--sol-dp-primary: var(--sol-color-primary, #2563eb);--sol-dp-hover: var(--sol-color-bg-hover, rgba(0, 0, 0, .04));--sol-dp-muted: var(--sol-color-text-muted, #94a3b8)}.sol-date-picker{position:relative;display:block}.sol-date-picker__field{display:flex;align-items:center;width:100%;height:var(--sol-dp-height);background:var(--sol-dp-bg);border:var(--sol-input-border, var(--sol-dp-border-width) solid var(--sol-dp-border));border-radius:var(--sol-dp-radius);box-shadow:var(--sol-dp-shadow);transition:border-color var(--sol-dp-transition),box-shadow var(--sol-dp-transition)}.sol-date-picker--sm .sol-date-picker__field{height:2rem}.sol-date-picker__field--open,.sol-date-picker__field:focus-within{border:var(--sol-input-focus-border, var(--sol-dp-border-width) solid var(--sol-dp-border-focus));box-shadow:var(--sol-dp-focus-ring)}.sol-date-picker__field--disabled{cursor:not-allowed;opacity:var(--sol-dp-disabled-opacity)}.sol-date-picker__input{flex:1;min-width:0;height:100%;padding:0 .5rem 0 var(--sol-space-sm, .75rem);border:none;background:transparent;color:var(--sol-dp-text);font-family:inherit;font-size:var(--sol-dp-font-size);cursor:pointer;outline:none}.sol-date-picker--sm .sol-date-picker__input{font-size:var(--sol-font-size-sm, .8125rem)}.sol-date-picker__input::placeholder{color:var(--sol-dp-placeholder)}.sol-date-picker__input:disabled{cursor:not-allowed}.sol-date-picker__trigger-btn{display:inline-flex;align-items:center;justify-content:center;height:100%;padding:0 .5rem;border:none;background:transparent;color:var(--sol-dp-muted);cursor:pointer}.sol-date-picker__trigger-btn:disabled{cursor:not-allowed}.sol-date-picker__pop{position:absolute;top:calc(100% + 4px);left:0;z-index:var(--sol-z-dropdown, 1000);width:300px;max-width:calc(100vw - 24px);padding:.625rem;background:var(--sol-dp-pop-bg);border:var(--sol-dp-border-width) solid var(--sol-dp-border);border-radius:var(--sol-dp-pop-radius);box-shadow:var(--sol-dp-pop-shadow);animation:sol-dp-fade var(--sol-dur-fast, .15s) var(--sol-ease, ease-out)}.sol-date-picker__pop--up{top:auto;bottom:calc(100% + 4px)}.sol-date-picker__pop--end{left:auto;right:0}.sol-date-picker__header{display:flex;align-items:center;justify-content:space-between;gap:.25rem;margin-bottom:.5rem}.sol-date-picker__nav{display:inline-flex;align-items:center;justify-content:center;width:2rem;height:2rem;border:none;border-radius:var(--sol-border-radius-md, .5rem);background:transparent;color:var(--sol-dp-text);cursor:pointer;transition:background var(--sol-dp-transition)}.sol-date-picker__nav:hover{background:var(--sol-dp-hover)}.sol-date-picker__title{flex:1;height:2rem;border:none;border-radius:var(--sol-border-radius-md, .5rem);background:transparent;color:var(--sol-dp-text);font-family:inherit;font-size:var(--sol-dp-font-size);font-weight:var(--sol-font-weight-bold, 600);cursor:pointer;transition:background var(--sol-dp-transition)}.sol-date-picker__title:hover:not(:disabled){background:var(--sol-dp-hover)}.sol-date-picker__title:disabled{cursor:default}.sol-date-picker__weekdays{display:grid;grid-template-columns:repeat(7,1fr);margin-bottom:.25rem}.sol-date-picker__weekday{text-align:center;font-size:var(--sol-font-size-sm, .75rem);font-weight:500;color:var(--sol-dp-muted);padding:.25rem 0}.sol-date-picker__grid{display:flex;flex-direction:column;gap:2px}.sol-date-picker__row{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}.sol-date-picker__day{display:inline-flex;align-items:center;justify-content:center;aspect-ratio:1 / 1;width:100%;border:1px solid transparent;border-radius:var(--sol-border-radius-md, .5rem);background:transparent;color:var(--sol-dp-text);font-family:inherit;font-size:var(--sol-dp-font-size);cursor:pointer;transition:background var(--sol-dp-transition),color var(--sol-dp-transition),border-color var(--sol-dp-transition)}.sol-date-picker__day:hover:not(:disabled):not(.is-selected){background:var(--sol-dp-hover)}.sol-date-picker__day.is-outside{color:var(--sol-dp-muted);opacity:.6}.sol-date-picker__day.is-today:not(.is-selected){border-color:var(--sol-dp-primary);font-weight:600}.sol-date-picker__day.is-selected{background:var(--sol-dp-primary);border-color:var(--sol-dp-primary);color:#fff;font-weight:600}.sol-date-picker__day.is-focused:not(.is-selected){outline:2px solid var(--sol-dp-primary);outline-offset:-2px}.sol-date-picker__day:disabled{opacity:.3;cursor:not-allowed}.sol-date-picker__cells{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}.sol-date-picker__cell{display:inline-flex;align-items:center;justify-content:center;height:3rem;border:1px solid transparent;border-radius:var(--sol-border-radius-md, .5rem);background:transparent;color:var(--sol-dp-text);font-family:inherit;font-size:var(--sol-dp-font-size);cursor:pointer;transition:background var(--sol-dp-transition),color var(--sol-dp-transition),border-color var(--sol-dp-transition)}.sol-date-picker__cell:hover:not(:disabled):not(.is-selected){background:var(--sol-dp-hover)}.sol-date-picker__cell.is-outside{color:var(--sol-dp-muted);opacity:.6}.sol-date-picker__cell.is-today:not(.is-selected){border-color:var(--sol-dp-primary);font-weight:600}.sol-date-picker__cell.is-selected{background:var(--sol-dp-primary);border-color:var(--sol-dp-primary);color:#fff;font-weight:600}.sol-date-picker__cell:disabled{opacity:.3;cursor:not-allowed}@keyframes sol-dp-fade{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.sol-date-picker__pop--up{animation-name:sol-dp-fade-up}@keyframes sol-dp-fade-up{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){.sol-date-picker__pop{animation:none}}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolDatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-date-picker', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [SolIconComponent], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SolDatePickerComponent),
                            multi: true,
                        },
                    ], template: `
    <div class="sol-date-picker" [class.sol-date-picker--sm]="size() === 'sm'">
      <!-- Campo disparador -->
      <div
        class="sol-date-picker__field"
        [class.sol-date-picker__field--open]="isOpen()"
        [class.sol-date-picker__field--disabled]="isDisabled()"
      >
        <input
          #trigger
          type="text"
          class="sol-date-picker__input"
          readonly
          [value]="displayText()"
          [attr.placeholder]="placeholderText()"
          [attr.aria-label]="triggerAria()"
          aria-haspopup="dialog"
          [attr.aria-expanded]="isOpen()"
          [disabled]="isDisabled()"
          (click)="open()"
          (focus)="onTriggerFocus()"
          (keydown)="onTriggerKeydown($event)"
          (blur)="onTouched()"
        />
        <button
          type="button"
          class="sol-date-picker__trigger-btn"
          tabindex="-1"
          [disabled]="isDisabled()"
          [attr.aria-label]="triggerAria()"
          (mousedown)="$event.preventDefault()"
          (click)="toggle()"
        >
          <sol-icon name="calendar" size="sm" />
        </button>
      </div>

      <!-- Popover -->
      @if (isOpen()) {
        <div
          class="sol-date-picker__pop"
          [class.sol-date-picker__pop--up]="dropUp()"
          [class.sol-date-picker__pop--end]="alignEnd()"
          role="dialog"
          [attr.aria-label]="dialogAria()"
          (keydown)="onPopoverKeydown($event)"
        >
          <!-- Encabezado con navegación -->
          <div class="sol-date-picker__header">
            <button
              type="button"
              class="sol-date-picker__nav"
              [attr.aria-label]="prevAria()"
              (click)="goPrev()"
            >
              <sol-icon name="chevron-left" size="sm" />
            </button>

            <button
              type="button"
              class="sol-date-picker__title"
              [disabled]="view() === 'years'"
              [attr.aria-label]="titleAria()"
              (click)="promoteView()"
            >
              {{ headerLabel() }}
            </button>

            <button
              type="button"
              class="sol-date-picker__nav"
              [attr.aria-label]="nextAria()"
              (click)="goNext()"
            >
              <sol-icon name="chevron-right" size="sm" />
            </button>
          </div>

          <!-- Vista DÍAS -->
          @if (view() === 'days') {
            <div class="sol-date-picker__weekdays" aria-hidden="true">
              @for (w of weekdayLabels(); track $index) {
                <span class="sol-date-picker__weekday">{{ w }}</span>
              }
            </div>
            <div class="sol-date-picker__grid" role="grid">
              @for (week of weeks(); track $index) {
                <div class="sol-date-picker__row" role="row">
                  @for (cell of week; track cell.iso) {
                    <button
                      type="button"
                      role="gridcell"
                      class="sol-date-picker__day"
                      [class.is-outside]="!cell.inMonth"
                      [class.is-today]="cell.isToday"
                      [class.is-selected]="cell.isSelected"
                      [class.is-focused]="cell.isFocused"
                      [attr.aria-selected]="cell.isSelected"
                      [attr.aria-label]="cell.aria"
                      [attr.tabindex]="cell.isFocused ? 0 : -1"
                      [disabled]="cell.disabled"
                      (click)="pickDay(cell.date)"
                    >
                      {{ cell.day }}
                    </button>
                  }
                </div>
              }
            </div>
          }

          <!-- Vista MESES -->
          @if (view() === 'months') {
            <div class="sol-date-picker__cells" role="grid">
              @for (m of months(); track m.index) {
                <button
                  type="button"
                  role="gridcell"
                  class="sol-date-picker__cell"
                  [class.is-today]="m.isCurrent"
                  [class.is-selected]="m.isSelected"
                  [attr.aria-selected]="m.isSelected"
                  [disabled]="m.disabled"
                  (click)="pickMonth(m.index)"
                >
                  {{ m.label }}
                </button>
              }
            </div>
          }

          <!-- Vista AÑOS (década) -->
          @if (view() === 'years') {
            <div class="sol-date-picker__cells" role="grid">
              @for (y of years(); track y.year) {
                <button
                  type="button"
                  role="gridcell"
                  class="sol-date-picker__cell"
                  [class.is-outside]="!y.inDecade"
                  [class.is-today]="y.isCurrent"
                  [class.is-selected]="y.isSelected"
                  [attr.aria-selected]="y.isSelected"
                  [disabled]="y.disabled"
                  (click)="pickYear(y.year)"
                >
                  {{ y.year }}
                </button>
              }
            </div>
          }
        </div>
      }
    </div>
  `, styles: [":host{display:block;--sol-dp-bg: var(--sol-input-bg, var(--sol-bg-surface, #ffffff));--sol-dp-text: var(--sol-color-text-primary, #1e293b);--sol-dp-placeholder: var(--sol-color-text-muted, #94a3b8);--sol-dp-border: var(--sol-border-color-default, #cbd5e1);--sol-dp-border-focus: var(--sol-color-primary, #2563eb);--sol-dp-radius: var(--sol-input-radius, var(--sol-border-radius-md, .5rem));--sol-dp-border-width: var(--sol-border-width-default, 1px);--sol-dp-height: var(--sol-size-input-height, 2.5rem);--sol-dp-font-size: var(--sol-font-size-base, .875rem);--sol-dp-shadow: var(--sol-input-shadow, var(--sol-shadow-sm, 0 1px 2px rgba(0, 0, 0, .05)));--sol-dp-focus-ring: var(--sol-input-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #2563eb) 40%, transparent));--sol-dp-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease);--sol-dp-disabled-opacity: var(--sol-disabled-opacity, .55);--sol-dp-pop-bg: var(--sol-card-bg, var(--sol-bg-surface, #ffffff));--sol-dp-pop-radius: var(--sol-card-radius, var(--sol-border-radius-lg, .75rem));--sol-dp-pop-shadow: var(--sol-card-shadow, var(--sol-shadow-lg, 0 10px 25px rgba(0, 0, 0, .15)));--sol-dp-primary: var(--sol-color-primary, #2563eb);--sol-dp-hover: var(--sol-color-bg-hover, rgba(0, 0, 0, .04));--sol-dp-muted: var(--sol-color-text-muted, #94a3b8)}.sol-date-picker{position:relative;display:block}.sol-date-picker__field{display:flex;align-items:center;width:100%;height:var(--sol-dp-height);background:var(--sol-dp-bg);border:var(--sol-input-border, var(--sol-dp-border-width) solid var(--sol-dp-border));border-radius:var(--sol-dp-radius);box-shadow:var(--sol-dp-shadow);transition:border-color var(--sol-dp-transition),box-shadow var(--sol-dp-transition)}.sol-date-picker--sm .sol-date-picker__field{height:2rem}.sol-date-picker__field--open,.sol-date-picker__field:focus-within{border:var(--sol-input-focus-border, var(--sol-dp-border-width) solid var(--sol-dp-border-focus));box-shadow:var(--sol-dp-focus-ring)}.sol-date-picker__field--disabled{cursor:not-allowed;opacity:var(--sol-dp-disabled-opacity)}.sol-date-picker__input{flex:1;min-width:0;height:100%;padding:0 .5rem 0 var(--sol-space-sm, .75rem);border:none;background:transparent;color:var(--sol-dp-text);font-family:inherit;font-size:var(--sol-dp-font-size);cursor:pointer;outline:none}.sol-date-picker--sm .sol-date-picker__input{font-size:var(--sol-font-size-sm, .8125rem)}.sol-date-picker__input::placeholder{color:var(--sol-dp-placeholder)}.sol-date-picker__input:disabled{cursor:not-allowed}.sol-date-picker__trigger-btn{display:inline-flex;align-items:center;justify-content:center;height:100%;padding:0 .5rem;border:none;background:transparent;color:var(--sol-dp-muted);cursor:pointer}.sol-date-picker__trigger-btn:disabled{cursor:not-allowed}.sol-date-picker__pop{position:absolute;top:calc(100% + 4px);left:0;z-index:var(--sol-z-dropdown, 1000);width:300px;max-width:calc(100vw - 24px);padding:.625rem;background:var(--sol-dp-pop-bg);border:var(--sol-dp-border-width) solid var(--sol-dp-border);border-radius:var(--sol-dp-pop-radius);box-shadow:var(--sol-dp-pop-shadow);animation:sol-dp-fade var(--sol-dur-fast, .15s) var(--sol-ease, ease-out)}.sol-date-picker__pop--up{top:auto;bottom:calc(100% + 4px)}.sol-date-picker__pop--end{left:auto;right:0}.sol-date-picker__header{display:flex;align-items:center;justify-content:space-between;gap:.25rem;margin-bottom:.5rem}.sol-date-picker__nav{display:inline-flex;align-items:center;justify-content:center;width:2rem;height:2rem;border:none;border-radius:var(--sol-border-radius-md, .5rem);background:transparent;color:var(--sol-dp-text);cursor:pointer;transition:background var(--sol-dp-transition)}.sol-date-picker__nav:hover{background:var(--sol-dp-hover)}.sol-date-picker__title{flex:1;height:2rem;border:none;border-radius:var(--sol-border-radius-md, .5rem);background:transparent;color:var(--sol-dp-text);font-family:inherit;font-size:var(--sol-dp-font-size);font-weight:var(--sol-font-weight-bold, 600);cursor:pointer;transition:background var(--sol-dp-transition)}.sol-date-picker__title:hover:not(:disabled){background:var(--sol-dp-hover)}.sol-date-picker__title:disabled{cursor:default}.sol-date-picker__weekdays{display:grid;grid-template-columns:repeat(7,1fr);margin-bottom:.25rem}.sol-date-picker__weekday{text-align:center;font-size:var(--sol-font-size-sm, .75rem);font-weight:500;color:var(--sol-dp-muted);padding:.25rem 0}.sol-date-picker__grid{display:flex;flex-direction:column;gap:2px}.sol-date-picker__row{display:grid;grid-template-columns:repeat(7,1fr);gap:2px}.sol-date-picker__day{display:inline-flex;align-items:center;justify-content:center;aspect-ratio:1 / 1;width:100%;border:1px solid transparent;border-radius:var(--sol-border-radius-md, .5rem);background:transparent;color:var(--sol-dp-text);font-family:inherit;font-size:var(--sol-dp-font-size);cursor:pointer;transition:background var(--sol-dp-transition),color var(--sol-dp-transition),border-color var(--sol-dp-transition)}.sol-date-picker__day:hover:not(:disabled):not(.is-selected){background:var(--sol-dp-hover)}.sol-date-picker__day.is-outside{color:var(--sol-dp-muted);opacity:.6}.sol-date-picker__day.is-today:not(.is-selected){border-color:var(--sol-dp-primary);font-weight:600}.sol-date-picker__day.is-selected{background:var(--sol-dp-primary);border-color:var(--sol-dp-primary);color:#fff;font-weight:600}.sol-date-picker__day.is-focused:not(.is-selected){outline:2px solid var(--sol-dp-primary);outline-offset:-2px}.sol-date-picker__day:disabled{opacity:.3;cursor:not-allowed}.sol-date-picker__cells{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}.sol-date-picker__cell{display:inline-flex;align-items:center;justify-content:center;height:3rem;border:1px solid transparent;border-radius:var(--sol-border-radius-md, .5rem);background:transparent;color:var(--sol-dp-text);font-family:inherit;font-size:var(--sol-dp-font-size);cursor:pointer;transition:background var(--sol-dp-transition),color var(--sol-dp-transition),border-color var(--sol-dp-transition)}.sol-date-picker__cell:hover:not(:disabled):not(.is-selected){background:var(--sol-dp-hover)}.sol-date-picker__cell.is-outside{color:var(--sol-dp-muted);opacity:.6}.sol-date-picker__cell.is-today:not(.is-selected){border-color:var(--sol-dp-primary);font-weight:600}.sol-date-picker__cell.is-selected{background:var(--sol-dp-primary);border-color:var(--sol-dp-primary);color:#fff;font-weight:600}.sol-date-picker__cell:disabled{opacity:.3;cursor:not-allowed}@keyframes sol-dp-fade{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.sol-date-picker__pop--up{animation-name:sol-dp-fade-up}@keyframes sol-dp-fade-up{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){.sol-date-picker__pop{animation:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], triggerRef: [{ type: i0.ViewChild, args: ['trigger', { isSignal: true }] }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class SolViewToggleComponent {
    options = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    value = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    valueChange = output();
    onSelect(value) {
        this.valueChange.emit(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolViewToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolViewToggleComponent, isStandalone: true, selector: "sol-view-toggle", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: `
    <div class="sol-view-toggle">
      @for (option of options(); track option.value) {
        <button
          type="button"
          class="sol-view-toggle__btn"
          [class.sol-view-toggle__btn--active]="option.value === value()"
          (click)="onSelect(option.value)"
        >
          @if (option.icon) {
            <sol-icon [name]="option.icon" size="sm" />
          }
          {{ option.label }}
        </button>
      }
    </div>
  `, isInline: true, styles: [":host{display:inline-flex}.sol-view-toggle{display:inline-flex;align-items:center;background:var(--sol-bg-page, #F1F5F9);border:1px solid var(--sol-border-color-default, #E2E8F0);border-radius:var(--sol-border-radius-full, 9999px);padding:3px;gap:2px}.sol-view-toggle__btn{display:inline-flex;align-items:center;gap:5px;padding:5px 14px;border:none;border-radius:var(--sol-border-radius-full, 9999px);background:transparent;color:var(--sol-color-text-muted, #64748B);font-size:var(--sol-font-size-sm, 13px);font-family:var(--sol-font-family);font-weight:500;cursor:pointer;transition:background .15s,color .15s,box-shadow .15s;white-space:nowrap}.sol-view-toggle__btn:hover:not(.sol-view-toggle__btn--active){color:var(--sol-color-text-primary, #0F172A)}.sol-view-toggle__btn--active{background:var(--sol-color-primary, #2563EB);color:#fff;box-shadow:0 1px 3px #0003}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolViewToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-view-toggle', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [SolIconComponent], template: `
    <div class="sol-view-toggle">
      @for (option of options(); track option.value) {
        <button
          type="button"
          class="sol-view-toggle__btn"
          [class.sol-view-toggle__btn--active]="option.value === value()"
          (click)="onSelect(option.value)"
        >
          @if (option.icon) {
            <sol-icon [name]="option.icon" size="sm" />
          }
          {{ option.label }}
        </button>
      }
    </div>
  `, styles: [":host{display:inline-flex}.sol-view-toggle{display:inline-flex;align-items:center;background:var(--sol-bg-page, #F1F5F9);border:1px solid var(--sol-border-color-default, #E2E8F0);border-radius:var(--sol-border-radius-full, 9999px);padding:3px;gap:2px}.sol-view-toggle__btn{display:inline-flex;align-items:center;gap:5px;padding:5px 14px;border:none;border-radius:var(--sol-border-radius-full, 9999px);background:transparent;color:var(--sol-color-text-muted, #64748B);font-size:var(--sol-font-size-sm, 13px);font-family:var(--sol-font-family);font-weight:500;cursor:pointer;transition:background .15s,color .15s,box-shadow .15s;white-space:nowrap}.sol-view-toggle__btn:hover:not(.sol-view-toggle__btn--active){color:var(--sol-color-text-primary, #0F172A)}.sol-view-toggle__btn--active{background:var(--sol-color-primary, #2563EB);color:#fff;box-shadow:0 1px 3px #0003}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }] } });

/**
 * Estado vacío estándar del design system (E2): ícono + título +
 * descripción opcional + slot para una acción. Recibe CLAVES i18n (no
 * texto) y las resuelve vía I18nService, reactivo al idioma activo.
 *
 * Uso:
 * ```html
 * <sol-empty-state icon="building" titleKey="pages.x.empty.title" descriptionKey="pages.x.empty.description">
 *   <sol-button (clicked)="crear()">…</sol-button>
 * </sol-empty-state>
 * ```
 */
class SolEmptyStateComponent {
    i18n = inject(SOL_I18N);
    /** Ícono del registry a mostrar. */
    icon = input('list', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    /** Clave i18n del título (obligatoria). */
    titleKey = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "titleKey" }] : /* istanbul ignore next */ []));
    /** Clave i18n de la descripción (opcional). */
    descriptionKey = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "descriptionKey" }] : /* istanbul ignore next */ []));
    /**
     * Las claves son inputs (dinámicas), así que no se puede usar `i18n.t()`
     * directo: se lee `activeLang` dentro del computed para recalcular la
     * traducción cuando cambia el idioma.
     */
    title = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate(this.titleKey());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    description = computed(() => {
        this.i18n.activeLang();
        const key = this.descriptionKey();
        return key ? this.i18n.translate(key) : '';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolEmptyStateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolEmptyStateComponent, isStandalone: true, selector: "sol-empty-state", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, titleKey: { classPropertyName: "titleKey", publicName: "titleKey", isSignal: true, isRequired: true, transformFunction: null }, descriptionKey: { classPropertyName: "descriptionKey", publicName: "descriptionKey", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="sol-empty-state" role="status">
      <div class="sol-empty-state__icon">
        <sol-icon [name]="icon()" size="lg" />
      </div>
      <h3 class="sol-empty-state__title">{{ title() }}</h3>
      @if (description()) {
        <p class="sol-empty-state__description">{{ description() }}</p>
      }
      <div class="sol-empty-state__action">
        <ng-content />
      </div>
    </div>
  `, isInline: true, styles: [".sol-empty-state{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:var(--sol-space-xl, 3rem) var(--sol-space-md, 1rem);background:var(--sol-bg-surface, #fff);border:1px dashed var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-lg, 12px)}.sol-empty-state__icon{display:flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:50%;background:color-mix(in srgb,var(--sol-color-primary, #2563eb) 8%,transparent);color:var(--sol-color-primary, #2563eb);margin-bottom:var(--sol-space-md, 1rem)}.sol-empty-state__title{font-size:var(--sol-font-size-md, 15px);font-weight:600;color:var(--sol-color-text-primary, #0f172a);margin:0}.sol-empty-state__description{font-size:var(--sol-font-size-sm, 13px);color:var(--sol-color-text-muted, #64748b);margin:6px 0 0;max-width:420px}.sol-empty-state__action{margin-top:var(--sol-space-md, 1rem)}.sol-empty-state__action:empty{display:none}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolEmptyStateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-empty-state', standalone: true, imports: [SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-empty-state" role="status">
      <div class="sol-empty-state__icon">
        <sol-icon [name]="icon()" size="lg" />
      </div>
      <h3 class="sol-empty-state__title">{{ title() }}</h3>
      @if (description()) {
        <p class="sol-empty-state__description">{{ description() }}</p>
      }
      <div class="sol-empty-state__action">
        <ng-content />
      </div>
    </div>
  `, styles: [".sol-empty-state{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:var(--sol-space-xl, 3rem) var(--sol-space-md, 1rem);background:var(--sol-bg-surface, #fff);border:1px dashed var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-lg, 12px)}.sol-empty-state__icon{display:flex;align-items:center;justify-content:center;width:56px;height:56px;border-radius:50%;background:color-mix(in srgb,var(--sol-color-primary, #2563eb) 8%,transparent);color:var(--sol-color-primary, #2563eb);margin-bottom:var(--sol-space-md, 1rem)}.sol-empty-state__title{font-size:var(--sol-font-size-md, 15px);font-weight:600;color:var(--sol-color-text-primary, #0f172a);margin:0}.sol-empty-state__description{font-size:var(--sol-font-size-sm, 13px);color:var(--sol-color-text-muted, #64748b);margin:6px 0 0;max-width:420px}.sol-empty-state__action{margin-top:var(--sol-space-md, 1rem)}.sol-empty-state__action:empty{display:none}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], titleKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "titleKey", required: true }] }], descriptionKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "descriptionKey", required: false }] }] } });

/**
 * `sol-stepper` — átomo del design system (E4, primer consumidor:
 * onboarding v2).
 *
 * - Estados DERIVADOS del índice activo y de la frontera alcanzada
 *   (`furthestIndex`): activo → actual, cualquier paso hasta la frontera →
 *   completado, más allá → pendiente; `step.error` prevalece.
 * - A11y: lista con `aria-orientation`, `aria-current="step"` en el paso
 *   actual, `aria-disabled` en los no navegables y roving tabindex con
 *   navegación por flechas/Home/End cuando es interactivo.
 * - Interactivo: los pasos ya alcanzados (índice ≤ `furthestIndex`) son
 *   navegables en AMBOS sentidos; los futuros jamás emiten. Sin
 *   `furthestIndex` la frontera es el propio `activeIndex` → wizard lineal
 *   clásico (solo hacia atrás), preservando el comportamiento previo.
 * - `navigation` (D7, 11-a-solercia-ui): `'linear'` (default) es EXACTAMENTE
 *   el comportamiento anterior; `'free'` habilita el pipeline accionable —
 *   cualquier paso, visitado o no, es navegable. Extensión OCP pura: un
 *   input nuevo, cero cambios en la API 0.1.x.
 * - Light/dark vía tokens `--sol-*` con fallbacks, como todo átomo.
 */
class SolStepperComponent {
    i18n = inject(SOL_I18N);
    host = inject((ElementRef));
    /** Pasos a renderizar, en orden. */
    steps = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []));
    /** Índice (base 0) del paso actual. */
    activeIndex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    /**
     * Índice máximo ya alcanzado (frontera). Los pasos hasta aquí se muestran
     * completados y son navegables en ambos sentidos. Si es `null` (default),
     * la frontera es el propio `activeIndex` → wizard lineal clásico.
     */
    furthestIndex = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "furthestIndex" }] : /* istanbul ignore next */ []));
    orientation = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /**
     * `true` permite navegar a pasos YA alcanzados (clic/teclado), atrás o
     * adelante hasta `furthestIndex`. Los pasos futuros nunca son navegables.
     */
    interactive = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "interactive" }] : /* istanbul ignore next */ []));
    /**
     * `'linear'` (default) preserva la API 0.1.x sin cambios de comportamiento.
     * `'free'` habilita el pipeline accionable: con `interactive=true`,
     * CUALQUIER paso (incluso uno no alcanzado) es navegable — ver
     * {@link SolStepperNavigation}.
     */
    navigation = input('linear', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "navigation" }] : /* istanbul ignore next */ []));
    /** Clave i18n del nombre accesible de la lista de pasos. */
    ariaLabelKey = input('shared.stepper.aria', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelKey" }] : /* istanbul ignore next */ []));
    /** Índice del paso visitado al que el usuario quiere volver. */
    stepSelected = output();
    /** Claves dinámicas → traducción reactiva al idioma (patrón sol-empty-state). */
    labels = computed(() => {
        this.i18n.activeLang();
        return this.steps().map(step => this.i18n.translate(step.labelKey));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []));
    descriptions = computed(() => {
        this.i18n.activeLang();
        return this.steps().map(step => step.descriptionKey ? this.i18n.translate(step.descriptionKey) : '');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "descriptions" }] : /* istanbul ignore next */ []));
    ariaLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate(this.ariaLabelKey());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Texto solo-lector-de-pantalla del estado de cada paso. */
    stateLabels = computed(() => {
        this.i18n.activeLang();
        return {
            completed: this.i18n.translate('shared.stepper.state.completed'),
            current: this.i18n.translate('shared.stepper.state.current'),
            pending: this.i18n.translate('shared.stepper.state.pending'),
            error: this.i18n.translate('shared.stepper.state.error'),
        };
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stateLabels" }] : /* istanbul ignore next */ []));
    /**
     * Frontera efectiva: `furthestIndex` si se proporcionó, si no el propio
     * `activeIndex` (wizard lineal). Nunca por debajo del activo.
     */
    effectiveFurthest = computed(() => Math.max(this.activeIndex(), this.furthestIndex() ?? this.activeIndex()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveFurthest" }] : /* istanbul ignore next */ []));
    stateOf(index) {
        if (this.steps()[index]?.error)
            return 'error';
        if (index === this.activeIndex())
            return 'current';
        // Todo paso hasta la frontera alcanzada cuenta como completado, aunque
        // esté por delante del paso visible (el usuario retrocedió a revisarlo).
        if (index <= this.effectiveFurthest())
            return 'completed';
        return 'pending';
    }
    /**
     * Navegable = interactivo y distinto del actual. En `navigation:'linear'`
     * (default) además exige estar dentro de la frontera alcanzada — igual
     * que antes de D7. En `navigation:'free'` cualquier paso califica (pipeline
     * accionable): el estado visual sigue siendo el mismo, solo cambia qué
     * acepta clic/teclado.
     */
    isNavigable(index) {
        if (!this.interactive() || index === this.activeIndex())
            return false;
        if (this.navigation() === 'free')
            return true;
        return index <= this.effectiveFurthest();
    }
    /** `aria-disabled` solo aplica en modo interactivo; en visual puro no hay semántica de botón. */
    ariaDisabledOf(index) {
        if (!this.interactive())
            return null;
        return this.isNavigable(index) ? 'false' : 'true';
    }
    /** Roving tabindex: único tab-stop en el paso actual cuando es interactivo. */
    tabIndexOf(index) {
        if (!this.interactive())
            return -1;
        return index === this.activeIndex() ? 0 : -1;
    }
    onStepClick(index) {
        if (!this.isNavigable(index))
            return;
        this.stepSelected.emit(index);
    }
    onKeydown(event) {
        if (!this.interactive())
            return;
        const forward = event.key === 'ArrowRight' || event.key === 'ArrowDown';
        const backward = event.key === 'ArrowLeft' || event.key === 'ArrowUp';
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (!forward && !backward && !home && !end)
            return;
        const buttons = Array.from(this.host.nativeElement.querySelectorAll('.sol-stepper__step'));
        // Focos válidos: en 'free' TODOS los pasos; en 'linear' (default) solo
        // hasta la frontera alcanzada (los futuros no) — comportamiento 0.1.x.
        const focusable = this.navigation() === 'free' ? buttons : buttons.slice(0, this.effectiveFurthest() + 1);
        if (focusable.length === 0)
            return;
        const currentFocus = focusable.indexOf(document.activeElement);
        let next;
        if (home)
            next = 0;
        else if (end)
            next = focusable.length - 1;
        else if (currentFocus === -1)
            next = focusable.length - 1;
        else if (forward)
            next = Math.min(currentFocus + 1, focusable.length - 1);
        else
            next = Math.max(currentFocus - 1, 0);
        event.preventDefault();
        focusable[next].focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolStepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolStepperComponent, isStandalone: true, selector: "sol-stepper", inputs: { steps: { classPropertyName: "steps", publicName: "steps", isSignal: true, isRequired: true, transformFunction: null }, activeIndex: { classPropertyName: "activeIndex", publicName: "activeIndex", isSignal: true, isRequired: false, transformFunction: null }, furthestIndex: { classPropertyName: "furthestIndex", publicName: "furthestIndex", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, interactive: { classPropertyName: "interactive", publicName: "interactive", isSignal: true, isRequired: false, transformFunction: null }, navigation: { classPropertyName: "navigation", publicName: "navigation", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelKey: { classPropertyName: "ariaLabelKey", publicName: "ariaLabelKey", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { stepSelected: "stepSelected" }, ngImport: i0, template: `
    <ol
      class="sol-stepper"
      [class.sol-stepper--horizontal]="orientation() === 'horizontal'"
      [class.sol-stepper--vertical]="orientation() === 'vertical'"
      [attr.aria-orientation]="orientation()"
      [attr.aria-label]="ariaLabel()"
      (keydown)="onKeydown($event)"
    >
      @for (step of steps(); track step.id; let i = $index; let last = $last) {
        <li class="sol-stepper__item">
          <button
            type="button"
            class="sol-stepper__step"
            [class.sol-stepper__step--completed]="stateOf(i) === 'completed'"
            [class.sol-stepper__step--current]="stateOf(i) === 'current'"
            [class.sol-stepper__step--pending]="stateOf(i) === 'pending'"
            [class.sol-stepper__step--error]="stateOf(i) === 'error'"
            [attr.aria-current]="stateOf(i) === 'current' ? 'step' : null"
            [attr.aria-disabled]="ariaDisabledOf(i)"
            [attr.tabindex]="tabIndexOf(i)"
            (click)="onStepClick(i)"
          >
            <span class="sol-stepper__indicator" aria-hidden="true">
              @if (stateOf(i) === 'completed') {
                <sol-icon name="check" size="sm" />
              } @else if (stateOf(i) === 'error') {
                <span class="sol-stepper__error-mark">!</span>
              } @else {
                <span>{{ i + 1 }}</span>
              }
            </span>
            <span class="sol-stepper__texts">
              <span class="sol-stepper__label">{{ labels()[i] }}</span>
              @if (descriptions()[i]) {
                <span class="sol-stepper__description">{{ descriptions()[i] }}</span>
              }
              <span class="sol-stepper__sr">{{ stateLabels()[stateOf(i)] }}</span>
            </span>
          </button>
          @if (!last) {
            <span
              class="sol-stepper__connector"
              [class.sol-stepper__connector--done]="i < effectiveFurthest()"
              aria-hidden="true"
            ></span>
          }
        </li>
      }
    </ol>
  `, isInline: true, styles: [":host{display:block;width:100%}.sol-stepper{display:flex;list-style:none;margin:0;padding:var(--sol-space-sm, .5rem) 0}.sol-stepper--horizontal{flex-direction:row;align-items:flex-start;justify-content:center}.sol-stepper--vertical{flex-direction:column}.sol-stepper__item{display:flex;flex:0 1 auto;min-width:0}.sol-stepper--horizontal .sol-stepper__item{flex-direction:row;align-items:flex-start}.sol-stepper--vertical .sol-stepper__item{flex-direction:column}.sol-stepper__step{display:flex;align-items:center;gap:var(--sol-space-sm, .5rem);background:none;border:none;padding:4px;border-radius:var(--sol-border-radius-md, 8px);cursor:default;font-family:var(--sol-font-family);text-align:left}.sol-stepper--horizontal .sol-stepper__step{flex-direction:column;align-items:center;text-align:center;max-width:8rem}.sol-stepper__step:not([aria-disabled=true])[tabindex]{cursor:pointer}.sol-stepper__step:focus-visible{outline:2px solid var(--sol-color-primary, #2563eb);outline-offset:2px}.sol-stepper__indicator{display:flex;align-items:center;justify-content:center;flex-shrink:0;width:2.25rem;height:2.25rem;border-radius:50%;border:2px solid var(--sol-border-color-default, #cbd5e1);background:var(--sol-bg-surface, #ffffff);color:var(--sol-color-text-muted, #94a3b8);font-size:var(--sol-font-size-sm, .875rem);font-weight:600;transition:border-color .2s ease,background-color .2s ease,color .2s ease}.sol-stepper__step--current .sol-stepper__indicator{border-color:var(--sol-color-primary, #6366f1);background:var(--sol-color-primary, #6366f1);color:var(--sol-color-primary-contrast, #ffffff)}.sol-stepper__step--completed .sol-stepper__indicator{border-color:var(--sol-color-success, #22c55e);background:var(--sol-color-success, #22c55e);color:#fff}.sol-stepper__step--error .sol-stepper__indicator{border-color:var(--sol-color-danger, #ef4444);background:var(--sol-color-danger, #ef4444);color:#fff}.sol-stepper__texts{display:flex;flex-direction:column;gap:2px;min-width:0}.sol-stepper__label{font-size:var(--sol-font-size-xs, .75rem);color:var(--sol-color-text-muted, #94a3b8);line-height:1.2;transition:color .2s ease}.sol-stepper__step--current .sol-stepper__label{color:var(--sol-color-primary, #6366f1);font-weight:600}.sol-stepper__step--completed .sol-stepper__label{color:var(--sol-color-success, #22c55e);font-weight:500}.sol-stepper__step--error .sol-stepper__label{color:var(--sol-color-danger, #ef4444);font-weight:600}.sol-stepper__description{font-size:var(--sol-font-size-xs, .7rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-stepper__connector{flex:1;background:var(--sol-border-color-default, #cbd5e1);transition:background-color .2s ease}.sol-stepper--horizontal .sol-stepper__connector{height:2px;min-width:1.5rem;margin-top:calc(4px + 1.125rem)}.sol-stepper--vertical .sol-stepper__connector{width:2px;min-height:1.25rem;margin-left:calc(4px + 1.125rem)}.sol-stepper__connector--done{background:var(--sol-color-success, #22c55e)}.sol-stepper__error-mark{font-weight:700}.sol-stepper__sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:480px){.sol-stepper__indicator{width:1.75rem;height:1.75rem;font-size:.75rem}.sol-stepper--horizontal .sol-stepper__connector{margin-top:calc(4px + .875rem)}}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolStepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-stepper', standalone: true, imports: [SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <ol
      class="sol-stepper"
      [class.sol-stepper--horizontal]="orientation() === 'horizontal'"
      [class.sol-stepper--vertical]="orientation() === 'vertical'"
      [attr.aria-orientation]="orientation()"
      [attr.aria-label]="ariaLabel()"
      (keydown)="onKeydown($event)"
    >
      @for (step of steps(); track step.id; let i = $index; let last = $last) {
        <li class="sol-stepper__item">
          <button
            type="button"
            class="sol-stepper__step"
            [class.sol-stepper__step--completed]="stateOf(i) === 'completed'"
            [class.sol-stepper__step--current]="stateOf(i) === 'current'"
            [class.sol-stepper__step--pending]="stateOf(i) === 'pending'"
            [class.sol-stepper__step--error]="stateOf(i) === 'error'"
            [attr.aria-current]="stateOf(i) === 'current' ? 'step' : null"
            [attr.aria-disabled]="ariaDisabledOf(i)"
            [attr.tabindex]="tabIndexOf(i)"
            (click)="onStepClick(i)"
          >
            <span class="sol-stepper__indicator" aria-hidden="true">
              @if (stateOf(i) === 'completed') {
                <sol-icon name="check" size="sm" />
              } @else if (stateOf(i) === 'error') {
                <span class="sol-stepper__error-mark">!</span>
              } @else {
                <span>{{ i + 1 }}</span>
              }
            </span>
            <span class="sol-stepper__texts">
              <span class="sol-stepper__label">{{ labels()[i] }}</span>
              @if (descriptions()[i]) {
                <span class="sol-stepper__description">{{ descriptions()[i] }}</span>
              }
              <span class="sol-stepper__sr">{{ stateLabels()[stateOf(i)] }}</span>
            </span>
          </button>
          @if (!last) {
            <span
              class="sol-stepper__connector"
              [class.sol-stepper__connector--done]="i < effectiveFurthest()"
              aria-hidden="true"
            ></span>
          }
        </li>
      }
    </ol>
  `, styles: [":host{display:block;width:100%}.sol-stepper{display:flex;list-style:none;margin:0;padding:var(--sol-space-sm, .5rem) 0}.sol-stepper--horizontal{flex-direction:row;align-items:flex-start;justify-content:center}.sol-stepper--vertical{flex-direction:column}.sol-stepper__item{display:flex;flex:0 1 auto;min-width:0}.sol-stepper--horizontal .sol-stepper__item{flex-direction:row;align-items:flex-start}.sol-stepper--vertical .sol-stepper__item{flex-direction:column}.sol-stepper__step{display:flex;align-items:center;gap:var(--sol-space-sm, .5rem);background:none;border:none;padding:4px;border-radius:var(--sol-border-radius-md, 8px);cursor:default;font-family:var(--sol-font-family);text-align:left}.sol-stepper--horizontal .sol-stepper__step{flex-direction:column;align-items:center;text-align:center;max-width:8rem}.sol-stepper__step:not([aria-disabled=true])[tabindex]{cursor:pointer}.sol-stepper__step:focus-visible{outline:2px solid var(--sol-color-primary, #2563eb);outline-offset:2px}.sol-stepper__indicator{display:flex;align-items:center;justify-content:center;flex-shrink:0;width:2.25rem;height:2.25rem;border-radius:50%;border:2px solid var(--sol-border-color-default, #cbd5e1);background:var(--sol-bg-surface, #ffffff);color:var(--sol-color-text-muted, #94a3b8);font-size:var(--sol-font-size-sm, .875rem);font-weight:600;transition:border-color .2s ease,background-color .2s ease,color .2s ease}.sol-stepper__step--current .sol-stepper__indicator{border-color:var(--sol-color-primary, #6366f1);background:var(--sol-color-primary, #6366f1);color:var(--sol-color-primary-contrast, #ffffff)}.sol-stepper__step--completed .sol-stepper__indicator{border-color:var(--sol-color-success, #22c55e);background:var(--sol-color-success, #22c55e);color:#fff}.sol-stepper__step--error .sol-stepper__indicator{border-color:var(--sol-color-danger, #ef4444);background:var(--sol-color-danger, #ef4444);color:#fff}.sol-stepper__texts{display:flex;flex-direction:column;gap:2px;min-width:0}.sol-stepper__label{font-size:var(--sol-font-size-xs, .75rem);color:var(--sol-color-text-muted, #94a3b8);line-height:1.2;transition:color .2s ease}.sol-stepper__step--current .sol-stepper__label{color:var(--sol-color-primary, #6366f1);font-weight:600}.sol-stepper__step--completed .sol-stepper__label{color:var(--sol-color-success, #22c55e);font-weight:500}.sol-stepper__step--error .sol-stepper__label{color:var(--sol-color-danger, #ef4444);font-weight:600}.sol-stepper__description{font-size:var(--sol-font-size-xs, .7rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-stepper__connector{flex:1;background:var(--sol-border-color-default, #cbd5e1);transition:background-color .2s ease}.sol-stepper--horizontal .sol-stepper__connector{height:2px;min-width:1.5rem;margin-top:calc(4px + 1.125rem)}.sol-stepper--vertical .sol-stepper__connector{width:2px;min-height:1.25rem;margin-left:calc(4px + 1.125rem)}.sol-stepper__connector--done{background:var(--sol-color-success, #22c55e)}.sol-stepper__error-mark{font-weight:700}.sol-stepper__sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:480px){.sol-stepper__indicator{width:1.75rem;height:1.75rem;font-size:.75rem}.sol-stepper--horizontal .sol-stepper__connector{margin-top:calc(4px + .875rem)}}\n"] }]
        }], propDecorators: { steps: [{ type: i0.Input, args: [{ isSignal: true, alias: "steps", required: true }] }], activeIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeIndex", required: false }] }], furthestIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "furthestIndex", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], interactive: [{ type: i0.Input, args: [{ isSignal: true, alias: "interactive", required: false }] }], navigation: [{ type: i0.Input, args: [{ isSignal: true, alias: "navigation", required: false }] }], ariaLabelKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelKey", required: false }] }], stepSelected: [{ type: i0.Output, args: ["stepSelected"] }] } });

/**
 * `sol-progress-bar` — átomo del design system.
 *
 * Dos modos:
 *  - `continuous`: una barra que se llena según `value` (0..`max`).
 *  - `segmented`: N segmentos (`steps`); los que están hasta `current`
 *    (incluido) se pintan con el color de la variante, el resto quedan en
 *    el track (`--sol-bg-sunken`). Ideal como indicador de fase de un wizard.
 *
 * Tematizado 100% con `var(--sol-*)` (light/dark). Accesible: expone
 * `role="progressbar"` con `aria-valuenow/min/max` y `aria-valuetext`
 * (el texto legible: "50 %" o "Paso 2 de 4"), aunque la etiqueta visible
 * (`showLabel`) esté oculta.
 */
class SolProgressBarComponent {
    i18n = inject(SOL_I18N);
    /** `continuous` (value/max) o `segmented` (steps/current). */
    mode = input('continuous', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    /** Valor actual del modo continuo (se recorta a `[0, max]`). */
    value = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** Valor máximo del modo continuo. */
    max = input(100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    /** Número total de segmentos (modo segmentado). */
    steps = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []));
    /** Índice (base 0) del segmento actual; `0..current` se pintan activos. */
    current = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []));
    /** Altura de la barra. */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Color por estado. */
    variant = input('primary', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Muestra la etiqueta visible ("50 %" o "Paso X de N"). */
    showLabel = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showLabel" }] : /* istanbul ignore next */ []));
    /** Override del texto de la etiqueta; si se deja vacío se deriva del modo. */
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    /** Override del nombre accesible; si se deja vacío usa la clave i18n por defecto. */
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    rootClass = computed(() => `sol-progress--${this.size()} sol-progress--${this.variant()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rootClass" }] : /* istanbul ignore next */ []));
    /** Segmentos como arreglo de índices para el `@for`. */
    segments = computed(() => Array.from({ length: Math.max(0, Math.floor(this.steps())) }, (_, i) => i), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "segments" }] : /* istanbul ignore next */ []));
    /** Valor recortado del modo continuo. */
    clampedValue = computed(() => Math.min(Math.max(this.value(), 0), this.max()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clampedValue" }] : /* istanbul ignore next */ []));
    /** Porcentaje de llenado (0..100). */
    percent = computed(() => {
        if (this.mode() === 'segmented') {
            const total = Math.max(1, this.steps());
            const done = Math.min(this.current() + 1, total);
            return (done / total) * 100;
        }
        const max = this.max();
        if (max <= 0)
            return 0;
        return (this.clampedValue() / max) * 100;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "percent" }] : /* istanbul ignore next */ []));
    /** `aria-valuenow`. */
    ariaNow = computed(() => this.mode() === 'segmented'
        ? Math.min(this.current() + 1, this.steps())
        : Math.round(this.clampedValue()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaNow" }] : /* istanbul ignore next */ []));
    /** `aria-valuemax` del modo segmentado. */
    ariaMax = computed(() => Math.max(0, Math.floor(this.steps())), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaMax" }] : /* istanbul ignore next */ []));
    /** Texto legible de la etiqueta (visible y para `aria-valuetext`). */
    labelText = computed(() => {
        // Reaccionar al cambio de idioma.
        this.i18n.activeLang();
        const override = this.label().trim();
        if (override)
            return override;
        if (this.mode() === 'segmented') {
            const params = { current: this.current() + 1, total: this.steps() };
            const key = 'shared.progressBar.stepOf';
            const t = this.i18n.translate(key, params);
            return t && t !== key ? t : `Paso ${params.current} de ${params.total}`;
        }
        return `${Math.round(this.percent())} %`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labelText" }] : /* istanbul ignore next */ []));
    /** Nombre accesible del control. */
    ariaLabelText = computed(() => {
        this.i18n.activeLang();
        const override = this.ariaLabel().trim();
        if (override)
            return override;
        const key = 'shared.progressBar.aria';
        const t = this.i18n.translate(key);
        return t && t !== key ? t : 'Progreso';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelText" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolProgressBarComponent, isStandalone: true, selector: "sol-progress-bar", inputs: { mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, steps: { classPropertyName: "steps", publicName: "steps", isSignal: true, isRequired: false, transformFunction: null }, current: { classPropertyName: "current", publicName: "current", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, showLabel: { classPropertyName: "showLabel", publicName: "showLabel", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="sol-progress" [class]="rootClass()">
      @if (showLabel()) {
        <div class="sol-progress__label">{{ labelText() }}</div>
      }

      @if (mode() === 'segmented') {
        <div
          class="sol-progress__segments"
          role="progressbar"
          [attr.aria-label]="ariaLabelText()"
          [attr.aria-valuemin]="0"
          [attr.aria-valuemax]="ariaMax()"
          [attr.aria-valuenow]="ariaNow()"
          [attr.aria-valuetext]="labelText()"
        >
          @for (i of segments(); track i) {
            <span
              class="sol-progress__segment"
              [class.is-active]="i <= current()"
              aria-hidden="true"
            ></span>
          }
        </div>
      } @else {
        <div
          class="sol-progress__track"
          role="progressbar"
          [attr.aria-label]="ariaLabelText()"
          [attr.aria-valuemin]="0"
          [attr.aria-valuemax]="max()"
          [attr.aria-valuenow]="ariaNow()"
          [attr.aria-valuetext]="labelText()"
        >
          <div class="sol-progress__fill" [style.width.%]="percent()"></div>
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;width:100%}.sol-progress{--sol-progress-color: var(--sol-color-primary, #6366f1);display:flex;flex-direction:column;gap:var(--sol-space-xs, .25rem);width:100%}.sol-progress--success{--sol-progress-color: var(--sol-color-success, #22c55e)}.sol-progress--warning{--sol-progress-color: var(--sol-color-warning, #f59e0b)}.sol-progress--danger{--sol-progress-color: var(--sol-color-danger, #ef4444)}.sol-progress__label{font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, .75rem);color:var(--sol-color-text-muted, #94a3b8);line-height:1.2}.sol-progress__track{width:100%;background:var(--sol-bg-sunken, #e2e8f0);border-radius:var(--sol-border-radius-full, 9999px);overflow:hidden}.sol-progress__fill{height:100%;background:var(--sol-progress-color);border-radius:inherit;transition:width var(--sol-dur-base, .3s) var(--sol-ease, ease)}.sol-progress__segments{display:flex;gap:var(--sol-space-xs, .25rem);width:100%}.sol-progress__segment{flex:1 1 0;background:var(--sol-bg-sunken, #e2e8f0);border-radius:var(--sol-border-radius-full, 9999px);transition:background-color var(--sol-dur-base, .3s) var(--sol-ease, ease)}.sol-progress__segment.is-active{background:var(--sol-progress-color)}.sol-progress--sm .sol-progress__track,.sol-progress--sm .sol-progress__segment{height:4px}.sol-progress--md .sol-progress__track,.sol-progress--md .sol-progress__segment{height:8px}.sol-progress--lg .sol-progress__track,.sol-progress--lg .sol-progress__segment{height:12px}@media(prefers-reduced-motion:reduce){.sol-progress__fill,.sol-progress__segment{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolProgressBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-progress-bar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-progress" [class]="rootClass()">
      @if (showLabel()) {
        <div class="sol-progress__label">{{ labelText() }}</div>
      }

      @if (mode() === 'segmented') {
        <div
          class="sol-progress__segments"
          role="progressbar"
          [attr.aria-label]="ariaLabelText()"
          [attr.aria-valuemin]="0"
          [attr.aria-valuemax]="ariaMax()"
          [attr.aria-valuenow]="ariaNow()"
          [attr.aria-valuetext]="labelText()"
        >
          @for (i of segments(); track i) {
            <span
              class="sol-progress__segment"
              [class.is-active]="i <= current()"
              aria-hidden="true"
            ></span>
          }
        </div>
      } @else {
        <div
          class="sol-progress__track"
          role="progressbar"
          [attr.aria-label]="ariaLabelText()"
          [attr.aria-valuemin]="0"
          [attr.aria-valuemax]="max()"
          [attr.aria-valuenow]="ariaNow()"
          [attr.aria-valuetext]="labelText()"
        >
          <div class="sol-progress__fill" [style.width.%]="percent()"></div>
        </div>
      }
    </div>
  `, styles: [":host{display:block;width:100%}.sol-progress{--sol-progress-color: var(--sol-color-primary, #6366f1);display:flex;flex-direction:column;gap:var(--sol-space-xs, .25rem);width:100%}.sol-progress--success{--sol-progress-color: var(--sol-color-success, #22c55e)}.sol-progress--warning{--sol-progress-color: var(--sol-color-warning, #f59e0b)}.sol-progress--danger{--sol-progress-color: var(--sol-color-danger, #ef4444)}.sol-progress__label{font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, .75rem);color:var(--sol-color-text-muted, #94a3b8);line-height:1.2}.sol-progress__track{width:100%;background:var(--sol-bg-sunken, #e2e8f0);border-radius:var(--sol-border-radius-full, 9999px);overflow:hidden}.sol-progress__fill{height:100%;background:var(--sol-progress-color);border-radius:inherit;transition:width var(--sol-dur-base, .3s) var(--sol-ease, ease)}.sol-progress__segments{display:flex;gap:var(--sol-space-xs, .25rem);width:100%}.sol-progress__segment{flex:1 1 0;background:var(--sol-bg-sunken, #e2e8f0);border-radius:var(--sol-border-radius-full, 9999px);transition:background-color var(--sol-dur-base, .3s) var(--sol-ease, ease)}.sol-progress__segment.is-active{background:var(--sol-progress-color)}.sol-progress--sm .sol-progress__track,.sol-progress--sm .sol-progress__segment{height:4px}.sol-progress--md .sol-progress__track,.sol-progress--md .sol-progress__segment{height:8px}.sol-progress--lg .sol-progress__track,.sol-progress--lg .sol-progress__segment{height:12px}@media(prefers-reduced-motion:reduce){.sol-progress__fill,.sol-progress__segment{transition:none}}\n"] }]
        }], propDecorators: { mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], steps: [{ type: i0.Input, args: [{ isSignal: true, alias: "steps", required: false }] }], current: [{ type: i0.Input, args: [{ isSignal: true, alias: "current", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], showLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLabel", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }] } });

/**
 * Marca un `<ng-template>`/`<ng-container *solWizardStep>` como el cuerpo de
 * un paso. El wizard renderiza SOLO la plantilla cuyo orden posicional
 * coincide con el paso actual. Debe ser hijo directo de `<sol-wizard>`.
 *
 * ```html
 * <sol-wizard [steps]="steps" [(current)]="current" (finish)="guardar()">
 *   <ng-container *solWizardStep>...contenido paso 1...</ng-container>
 *   <ng-container *solWizardStep>...contenido paso 2...</ng-container>
 * </sol-wizard>
 * ```
 */
class SolWizardStepDirective {
    template = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolWizardStepDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.0.6", type: SolWizardStepDirective, isStandalone: true, selector: "[solWizardStep]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolWizardStepDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[solWizardStep]',
                    standalone: true,
                }]
        }] });
/**
 * `sol-wizard` — asistente por pasos tipo pills/card del design system.
 *
 * Composición (no reimplementa piezas existentes):
 *  - HEADER: `sol-progress-bar` segmentado (N fases = N pasos, el actual y
 *    los previos coloreados) + `sol-stepper` interactivo para las pills
 *    (número → ✓ al completar, conector, retroceso a pasos ya visitados,
 *    a11y y teclado ya resueltos por el átomo).
 *  - CUERPO: proyección por paso vía `*solWizardStep` (patrón recomendado);
 *    si no hay plantillas, cae a un `<ng-content>` único que el consumidor
 *    controla con el `current` enlazado en dos vías.
 *  - FOOTER: "Anterior" (ghost) y "Siguiente" (primary) con `sol-button`;
 *    en el último paso "Siguiente" pasa a "Finalizar" y emite `finish`.
 *
 * `current` es un `model` (two-way `[(current)]`). Además emite `next`,
 * `previous`, `stepChange` y `finish`. `canAdvance` (bool o predicado)
 * deshabilita el avance. Texto por i18n `es-CO` con override por input.
 */
class SolWizardComponent {
    i18n = inject(SOL_I18N);
    /** Pasos a renderizar, en orden. */
    steps = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []));
    /** Índice (base 0) del paso actual — enlazable en dos vías `[(current)]`. */
    current = model(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []));
    /** Muestra la barra de fases segmentada en el header. */
    showProgressBar = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showProgressBar" }] : /* istanbul ignore next */ []));
    /** Oculta "Anterior" en el primer paso; si es `false`, lo muestra deshabilitado. */
    hidePreviousOnFirst = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hidePreviousOnFirst" }] : /* istanbul ignore next */ []));
    /** Permite/impide avanzar (bool o predicado del índice actual). */
    canAdvance = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canAdvance" }] : /* istanbul ignore next */ []));
    /** Overrides de texto (si se dejan vacíos usan la clave i18n / el default es-CO). */
    previousLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousLabel" }] : /* istanbul ignore next */ []));
    nextLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextLabel" }] : /* istanbul ignore next */ []));
    finishLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "finishLabel" }] : /* istanbul ignore next */ []));
    /** Se emite al avanzar (paso no final). */
    next = output();
    /** Se emite al retroceder con "Anterior". */
    previous = output();
    /** Se emite con el nuevo índice cada vez que cambia el paso. */
    stepChange = output();
    /** Se emite al confirmar el último paso. */
    finish = output();
    /** Plantillas de paso proyectadas (orden posicional = orden de `steps`). */
    stepTemplatesQuery = contentChildren(SolWizardStepDirective, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stepTemplatesQuery" }] : /* istanbul ignore next */ []));
    stepTemplates = computed(() => this.stepTemplatesQuery(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stepTemplates" }] : /* istanbul ignore next */ []));
    currentTemplate = computed(() => this.stepTemplates()[this.current()]?.template ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentTemplate" }] : /* istanbul ignore next */ []));
    /** Frontera máxima alcanzada (para el retroceso por pills del stepper). */
    furthest = linkedSignal({ ...(ngDevMode ? { debugName: "furthest" } : /* istanbul ignore next */ {}), source: this.current,
        computation: (current, previous) => Math.max(current, previous?.value ?? current) });
    stepCount = computed(() => this.steps().length, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stepCount" }] : /* istanbul ignore next */ []));
    isFirst = computed(() => this.current() <= 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isFirst" }] : /* istanbul ignore next */ []));
    isLast = computed(() => this.current() >= this.stepCount() - 1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isLast" }] : /* istanbul ignore next */ []));
    activeStep = computed(() => this.steps()[this.current()], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeStep" }] : /* istanbul ignore next */ []));
    /** Mapea los pasos del wizard al contrato de `sol-stepper` (labelKey). */
    stepperSteps = computed(() => this.steps().map(step => ({
        id: step.id,
        // Un literal pasa "tal cual": `translate('Servicios')` cae al propio
        // texto (fallback seguro de Transloco), así el stepper lo muestra bien.
        labelKey: step.label ?? step.labelKey ?? '',
    })), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stepperSteps" }] : /* istanbul ignore next */ []));
    canAdvanceNow = computed(() => {
        const rule = this.canAdvance();
        return typeof rule === 'function' ? rule(this.current()) : rule;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canAdvanceNow" }] : /* istanbul ignore next */ []));
    activeLabel = computed(() => {
        this.i18n.activeLang();
        const step = this.activeStep();
        if (!step)
            return '';
        if (step.label)
            return step.label;
        if (step.labelKey)
            return this.i18n.translate(step.labelKey);
        return '';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeLabel" }] : /* istanbul ignore next */ []));
    previousText = computed(() => this.text(this.previousLabel(), 'shared.wizard.previous', 'Anterior'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousText" }] : /* istanbul ignore next */ []));
    nextText = computed(() => this.text(this.nextLabel(), 'shared.wizard.next', 'Siguiente'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextText" }] : /* istanbul ignore next */ []));
    finishText = computed(() => this.text(this.finishLabel(), 'shared.wizard.finish', 'Finalizar'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "finishText" }] : /* istanbul ignore next */ []));
    /** Resuelve texto: override → clave i18n (si existe) → default es-CO. */
    text(override, key, fallback) {
        this.i18n.activeLang();
        const value = override.trim();
        if (value)
            return value;
        const translated = this.i18n.translate(key);
        return translated && translated !== key ? translated : fallback;
    }
    /** Navega a un paso ya visitado (pills del stepper). */
    goTo(index) {
        if (index === this.current())
            return;
        this.current.set(index);
        this.stepChange.emit(index);
    }
    goPrevious() {
        if (this.isFirst())
            return;
        const target = this.current() - 1;
        this.current.set(target);
        this.previous.emit();
        this.stepChange.emit(target);
    }
    goNext() {
        if (!this.canAdvanceNow())
            return;
        if (this.isLast()) {
            this.finish.emit();
            return;
        }
        const target = this.current() + 1;
        this.current.set(target);
        this.next.emit();
        this.stepChange.emit(target);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolWizardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolWizardComponent, isStandalone: true, selector: "sol-wizard", inputs: { steps: { classPropertyName: "steps", publicName: "steps", isSignal: true, isRequired: true, transformFunction: null }, current: { classPropertyName: "current", publicName: "current", isSignal: true, isRequired: false, transformFunction: null }, showProgressBar: { classPropertyName: "showProgressBar", publicName: "showProgressBar", isSignal: true, isRequired: false, transformFunction: null }, hidePreviousOnFirst: { classPropertyName: "hidePreviousOnFirst", publicName: "hidePreviousOnFirst", isSignal: true, isRequired: false, transformFunction: null }, canAdvance: { classPropertyName: "canAdvance", publicName: "canAdvance", isSignal: true, isRequired: false, transformFunction: null }, previousLabel: { classPropertyName: "previousLabel", publicName: "previousLabel", isSignal: true, isRequired: false, transformFunction: null }, nextLabel: { classPropertyName: "nextLabel", publicName: "nextLabel", isSignal: true, isRequired: false, transformFunction: null }, finishLabel: { classPropertyName: "finishLabel", publicName: "finishLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { current: "currentChange", next: "next", previous: "previous", stepChange: "stepChange", finish: "finish" }, queries: [{ propertyName: "stepTemplatesQuery", predicate: SolWizardStepDirective, isSignal: true }], ngImport: i0, template: `
    <section class="sol-wizard">
      <!-- HEADER: fases + pills -->
      <header class="sol-wizard__header">
        @if (showProgressBar()) {
          <sol-progress-bar
            mode="segmented"
            size="sm"
            [steps]="stepCount()"
            [current]="current()"
          />
        }

        <sol-stepper
          [steps]="stepperSteps()"
          [activeIndex]="current()"
          [furthestIndex]="furthest()"
          [interactive]="true"
          (stepSelected)="goTo($event)"
        />
      </header>

      <!-- CUERPO: encabezado opcional del paso + contenido proyectado -->
      <div class="sol-wizard__body">
        @if (activeStep(); as step) {
          @if (step.icon) {
            <div class="sol-wizard__step-heading">
              <sol-icon [name]="step.icon" size="md" />
              <span>{{ activeLabel() }}</span>
            </div>
          }
        }

        @if (stepTemplates().length > 0) {
          @for (key of [current()]; track key) {
            <div class="sol-wizard__panel">
              @if (currentTemplate(); as tpl) {
                <ng-container [ngTemplateOutlet]="tpl" />
              }
            </div>
          }
        } @else {
          <ng-content />
        }
      </div>

      <!-- FOOTER: navegación -->
      <footer class="sol-wizard__footer">
        @if (!isFirst() || !hidePreviousOnFirst()) {
          <sol-button
            class="sol-wizard__prev"
            variant="ghost"
            [disabled]="isFirst()"
            (clicked)="goPrevious()"
          >
            <sol-icon name="chevron-left" size="sm" />
            {{ previousText() }}
          </sol-button>
        }

        <sol-button
          class="sol-wizard__next"
          variant="primary"
          [disabled]="!canAdvanceNow()"
          (clicked)="goNext()"
        >
          {{ isLast() ? finishText() : nextText() }}
          @if (isLast()) {
            <sol-icon name="check" size="sm" />
          } @else {
            <sol-icon name="chevron-right" size="sm" />
          }
        </sol-button>
      </footer>
    </section>
  `, isInline: true, styles: [":host{display:block;width:100%}.sol-wizard{display:flex;flex-direction:column;gap:var(--sol-space-lg, 1.5rem);font-family:var(--sol-font-family)}.sol-wizard__header{display:flex;flex-direction:column;gap:var(--sol-space-md, 1rem)}.sol-wizard__step-heading{display:flex;align-items:center;gap:var(--sol-space-sm, .5rem);margin-bottom:var(--sol-space-md, 1rem);color:var(--sol-color-text-primary, #1e293b);font-size:var(--sol-font-size-lg, 1rem);font-weight:var(--sol-font-weight-bold, 600)}.sol-wizard__body{min-height:2rem}.sol-wizard__panel{animation:sol-wizard-reveal var(--sol-dur-base, .3s) var(--sol-ease, ease)}@keyframes sol-wizard-reveal{0%{opacity:0;transform:translate(var(--sol-reveal-dist, 8px))}to{opacity:1;transform:none}}.sol-wizard__footer{display:flex;justify-content:flex-end;align-items:center;gap:var(--sol-space-sm, .5rem);padding-top:var(--sol-space-md, 1rem);border-top:var(--sol-border-width-default, 1px) solid var(--sol-border-color-default, #e2e8f0)}.sol-wizard__prev{margin-right:auto}@media(prefers-reduced-motion:reduce){.sol-wizard__panel{animation:none}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SolStepperComponent, selector: "sol-stepper", inputs: ["steps", "activeIndex", "furthestIndex", "orientation", "interactive", "navigation", "ariaLabelKey"], outputs: ["stepSelected"] }, { kind: "component", type: SolButtonComponent, selector: "sol-button", inputs: ["variant", "size", "disabled", "type", "loading"], outputs: ["clicked"] }, { kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }, { kind: "component", type: SolProgressBarComponent, selector: "sol-progress-bar", inputs: ["mode", "value", "max", "steps", "current", "size", "variant", "showLabel", "label", "ariaLabel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolWizardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-wizard', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgTemplateOutlet,
                        SolStepperComponent,
                        SolButtonComponent,
                        SolIconComponent,
                        SolProgressBarComponent,
                    ], template: `
    <section class="sol-wizard">
      <!-- HEADER: fases + pills -->
      <header class="sol-wizard__header">
        @if (showProgressBar()) {
          <sol-progress-bar
            mode="segmented"
            size="sm"
            [steps]="stepCount()"
            [current]="current()"
          />
        }

        <sol-stepper
          [steps]="stepperSteps()"
          [activeIndex]="current()"
          [furthestIndex]="furthest()"
          [interactive]="true"
          (stepSelected)="goTo($event)"
        />
      </header>

      <!-- CUERPO: encabezado opcional del paso + contenido proyectado -->
      <div class="sol-wizard__body">
        @if (activeStep(); as step) {
          @if (step.icon) {
            <div class="sol-wizard__step-heading">
              <sol-icon [name]="step.icon" size="md" />
              <span>{{ activeLabel() }}</span>
            </div>
          }
        }

        @if (stepTemplates().length > 0) {
          @for (key of [current()]; track key) {
            <div class="sol-wizard__panel">
              @if (currentTemplate(); as tpl) {
                <ng-container [ngTemplateOutlet]="tpl" />
              }
            </div>
          }
        } @else {
          <ng-content />
        }
      </div>

      <!-- FOOTER: navegación -->
      <footer class="sol-wizard__footer">
        @if (!isFirst() || !hidePreviousOnFirst()) {
          <sol-button
            class="sol-wizard__prev"
            variant="ghost"
            [disabled]="isFirst()"
            (clicked)="goPrevious()"
          >
            <sol-icon name="chevron-left" size="sm" />
            {{ previousText() }}
          </sol-button>
        }

        <sol-button
          class="sol-wizard__next"
          variant="primary"
          [disabled]="!canAdvanceNow()"
          (clicked)="goNext()"
        >
          {{ isLast() ? finishText() : nextText() }}
          @if (isLast()) {
            <sol-icon name="check" size="sm" />
          } @else {
            <sol-icon name="chevron-right" size="sm" />
          }
        </sol-button>
      </footer>
    </section>
  `, styles: [":host{display:block;width:100%}.sol-wizard{display:flex;flex-direction:column;gap:var(--sol-space-lg, 1.5rem);font-family:var(--sol-font-family)}.sol-wizard__header{display:flex;flex-direction:column;gap:var(--sol-space-md, 1rem)}.sol-wizard__step-heading{display:flex;align-items:center;gap:var(--sol-space-sm, .5rem);margin-bottom:var(--sol-space-md, 1rem);color:var(--sol-color-text-primary, #1e293b);font-size:var(--sol-font-size-lg, 1rem);font-weight:var(--sol-font-weight-bold, 600)}.sol-wizard__body{min-height:2rem}.sol-wizard__panel{animation:sol-wizard-reveal var(--sol-dur-base, .3s) var(--sol-ease, ease)}@keyframes sol-wizard-reveal{0%{opacity:0;transform:translate(var(--sol-reveal-dist, 8px))}to{opacity:1;transform:none}}.sol-wizard__footer{display:flex;justify-content:flex-end;align-items:center;gap:var(--sol-space-sm, .5rem);padding-top:var(--sol-space-md, 1rem);border-top:var(--sol-border-width-default, 1px) solid var(--sol-border-color-default, #e2e8f0)}.sol-wizard__prev{margin-right:auto}@media(prefers-reduced-motion:reduce){.sol-wizard__panel{animation:none}}\n"] }]
        }], propDecorators: { steps: [{ type: i0.Input, args: [{ isSignal: true, alias: "steps", required: true }] }], current: [{ type: i0.Input, args: [{ isSignal: true, alias: "current", required: false }] }, { type: i0.Output, args: ["currentChange"] }], showProgressBar: [{ type: i0.Input, args: [{ isSignal: true, alias: "showProgressBar", required: false }] }], hidePreviousOnFirst: [{ type: i0.Input, args: [{ isSignal: true, alias: "hidePreviousOnFirst", required: false }] }], canAdvance: [{ type: i0.Input, args: [{ isSignal: true, alias: "canAdvance", required: false }] }], previousLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousLabel", required: false }] }], nextLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextLabel", required: false }] }], finishLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "finishLabel", required: false }] }], next: [{ type: i0.Output, args: ["next"] }], previous: [{ type: i0.Output, args: ["previous"] }], stepChange: [{ type: i0.Output, args: ["stepChange"] }], finish: [{ type: i0.Output, args: ["finish"] }], stepTemplatesQuery: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SolWizardStepDirective), { isSignal: true }] }] } });

/**
 * Matemática PURA de `sol-virtual-scroll` (E5) — sin DOM, sin Angular.
 *
 * El componente delega aquí todo el cálculo: resolución de alturas
 * (estimada + medida), offsets por prefix-sums, búsqueda binaria del primer
 * ítem visible, ventana renderizada con buffer, detección de "estar al
 * fondo" (anclaje tipo chat) y clasificación de cambios de lista
 * (append/prepend/reset) que gobiernan el anclaje y el chip
 * "mensajes nuevos".
 */
/**
 * Altura por ítem: la MEDIDA (por clave) manda; si no existe o no es
 * positiva (jsdom, elementos ocultos), cae a la estimada.
 */
function resolveHeights(count, estimatedHeight, measured, keyAt = i => i) {
    const heights = new Array(count);
    for (let i = 0; i < count; i++) {
        const m = measured.get(keyAt(i));
        heights[i] = m !== undefined && m > 0 ? m : estimatedHeight;
    }
    return heights;
}
/**
 * Prefix-sums de alturas: `offsets[i]` es el borde superior del ítem `i`
 * y `offsets[count]` es la altura total. Longitud SIEMPRE count+1.
 */
function buildOffsets(heights) {
    const offsets = new Array(heights.length + 1);
    offsets[0] = 0;
    for (let i = 0; i < heights.length; i++) {
        offsets[i + 1] = offsets[i] + heights[i];
    }
    return offsets;
}
/**
 * Índice del ítem que contiene la coordenada vertical `y` (búsqueda
 * binaria sobre los offsets). Clampa a [0, count-1]; con lista vacía
 * devuelve 0.
 */
function findIndexAt(offsets, y) {
    const count = offsets.length - 1;
    if (count <= 0)
        return 0;
    if (y <= 0)
        return 0;
    if (y >= offsets[count])
        return count - 1;
    let lo = 0;
    let hi = count - 1;
    while (lo < hi) {
        const mid = (lo + hi + 1) >> 1;
        if (offsets[mid] <= y) {
            lo = mid;
        }
        else {
            hi = mid - 1;
        }
    }
    return lo;
}
/**
 * Ventana a renderizar: ítems que intersectan `[scrollTop - buffer,
 * scrollTop + viewportHeight + buffer]`, con espaciadores que mantienen el
 * alto total (invariante: padTop + renderizado + padBottom = totalHeight
 * cuando todas las alturas son exactas).
 */
function computeWindow(offsets, scrollTop, viewportHeight, bufferPx) {
    const count = offsets.length - 1;
    const totalHeight = count > 0 ? offsets[count] : 0;
    if (count <= 0) {
        return { start: 0, end: 0, padTop: 0, padBottom: 0, totalHeight: 0 };
    }
    const rangeTop = Math.max(0, scrollTop - bufferPx);
    const rangeBottom = Math.min(totalHeight, scrollTop + viewportHeight + bufferPx);
    const start = findIndexAt(offsets, rangeTop);
    // Último ítem cuyo borde superior queda ANTES del límite inferior.
    const end = Math.min(count, findIndexAt(offsets, Math.max(rangeBottom - 1, 0)) + 1);
    return {
        start,
        end,
        padTop: offsets[start],
        padBottom: totalHeight - offsets[end],
        totalHeight,
    };
}
/**
 * ¿El usuario está (visualmente) al fondo? Regla del anclaje tipo chat:
 * si el contenido no desborda el viewport, siempre está al fondo.
 */
function isAtBottom(scrollTop, viewportHeight, totalHeight, thresholdPx = 32) {
    if (totalHeight <= viewportHeight)
        return true;
    return scrollTop + viewportHeight >= totalHeight - thresholdPx;
}
/**
 * Clasifica el cambio de la lista comparando claves estables:
 * - `reset`: lista previa vacía, reemplazada o mutada en el medio.
 * - `prepended`: ítems agregados arriba (paginación hacia atrás).
 * - `appended`: ítems agregados abajo (mensajes nuevos).
 * Soporta prepend + append simultáneos (paginación + evento en el mismo
 * tick). Ante cualquier ambigüedad clasifica como reset (conservador).
 */
function classifyItemsChange(prev, next) {
    const none = { reset: false, prepended: 0, appended: 0 };
    const reset = { reset: true, prepended: 0, appended: 0 };
    if (prev.length === 0)
        return reset;
    if (prev.length === next.length && prev[0] === next[0] && prev[prev.length - 1] === next[next.length - 1]) {
        return none;
    }
    const k = next.indexOf(prev[0]);
    if (k === -1)
        return reset;
    const lastIdx = k + prev.length - 1;
    // La lista previa debe seguir contigua dentro de la nueva.
    if (lastIdx >= next.length || next[lastIdx] !== prev[prev.length - 1]) {
        return reset;
    }
    return {
        reset: false,
        prepended: k,
        appended: next.length - 1 - lastIdx,
    };
}

/**
 * `sol-virtual-scroll` — virtual scroll PROPIO del design system (E5), sin
 * CDK ni librerías: renderiza solo los ítems visibles + buffer con
 * espaciadores que preservan el alto total.
 *
 * - **Altura variable**: cada ítem arranca con `estimatedItemHeight` y se
 *   corrige con la altura REAL medida tras el render (por clave estable,
 *   así la medición sobrevive a prepends). La matemática vive en
 *   `virtual-window.ts` (funciones puras con spec propia).
 * - **Anclaje al fondo (patrón chat)**: con `followOutput` activo, los
 *   ítems nuevos al final empujan el scroll al fondo SOLO si el usuario ya
 *   estaba al fondo; si scrolleó hacia arriba, el scroll no se arrastra y
 *   aparece el chip "mensajes nuevos" con el conteo.
 * - **Paginación hacia atrás**: emite `nearTop` al acercarse al inicio y
 *   compensa el scroll cuando se prepende una página de ítems antiguos
 *   (sin salto visual).
 *
 * Uso:
 * ```html
 * <sol-virtual-scroll [items]="messages()" [itemKey]="byId" [estimatedItemHeight]="64" (nearTop)="loadOlder()">
 *   <ng-template let-msg let-index="index">…</ng-template>
 * </sol-virtual-scroll>
 * ```
 * El host debe darle altura (ocupa el 100% de su contenedor).
 */
class SolVirtualScrollComponent {
    i18n = inject(SOL_I18N);
    /** Lista completa de ítems (el componente solo renderiza la ventana). */
    items = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    /**
     * Clave ESTABLE por ítem (ej. id del mensaje). Gobierna el track del
     * render, el mapa de alturas medidas y la detección append/prepend.
     * Por defecto usa el índice (suficiente para listas append-only).
     */
    itemKey = input((_, i) => i, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemKey" }] : /* istanbul ignore next */ []));
    /** Altura estimada por ítem mientras no exista medición real. */
    estimatedItemHeight = input(56, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "estimatedItemHeight" }] : /* istanbul ignore next */ []));
    /** Buffer en px renderizado por fuera del viewport (arriba y abajo). */
    bufferPx = input(240, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "bufferPx" }] : /* istanbul ignore next */ []));
    /** Anclaje al fondo tipo chat (nuevos ítems empujan si ya estabas al fondo). */
    followOutput = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "followOutput" }] : /* istanbul ignore next */ []));
    /** Distancia al inicio (px) que dispara `nearTop` (paginación hacia atrás). */
    nearTopThreshold = input(120, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nearTopThreshold" }] : /* istanbul ignore next */ []));
    /** Se acerca al inicio de la lista: cargar página anterior. */
    nearTop = output();
    /** Cambió el estado "está al fondo" (ej. para ocultar acciones). */
    atBottomChange = output();
    /** Template del ítem, proyectado por el consumidor. */
    itemTemplate = contentChild.required((TemplateRef), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    viewportRef = viewChild.required('viewport', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewportRef" }] : /* istanbul ignore next */ []));
    // ── Estado interno ──
    scrollTop = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollTop" }] : /* istanbul ignore next */ []));
    viewportHeight = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewportHeight" }] : /* istanbul ignore next */ []));
    measured = signal(new Map(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "measured" }] : /* istanbul ignore next */ []));
    _atBottom = signal(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_atBottom" }] : /* istanbul ignore next */ []));
    _newItemsCount = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_newItemsCount" }] : /* istanbul ignore next */ []));
    /** ¿El usuario está al fondo del hilo? */
    atBottom = this._atBottom.asReadonly();
    /** Ítems nuevos llegados mientras el usuario estaba scrolleado arriba. */
    newItemsCount = this._newItemsCount.asReadonly();
    chipLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.virtualScroll.newMessages');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "chipLabel" }] : /* istanbul ignore next */ []));
    // ── Derivados de ventana (matemática pura) ──
    keys = computed(() => {
        const key = this.itemKey();
        return this.items().map((item, i) => key(item, i));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "keys" }] : /* istanbul ignore next */ []));
    offsets = computed(() => {
        const items = this.items();
        const keys = this.keys();
        const heights = resolveHeights(items.length, this.estimatedItemHeight(), this.measured(), i => keys[i]);
        return buildOffsets(heights);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "offsets" }] : /* istanbul ignore next */ []));
    window = computed(() => computeWindow(this.offsets(), this.scrollTop(), this.viewportHeight(), this.bufferPx()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "window" }] : /* istanbul ignore next */ []));
    visibleRows = computed(() => {
        const { start, end } = this.window();
        const items = this.items();
        const keys = this.keys();
        const rows = [];
        for (let i = start; i < end; i++) {
            rows.push({ item: items[i], index: i, key: keys[i] });
        }
        return rows;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleRows" }] : /* istanbul ignore next */ []));
    // ── Reacciones a cambios de lista (anclaje / chip / compensación) ──
    prevKeys = [];
    pendingScrollToBottom = false;
    pendingPrependCount = 0;
    nearTopArmed = true;
    lastEmittedAtBottom = null;
    constructor() {
        effect(() => {
            const nextKeys = this.keys();
            untracked(() => this.onItemsChanged(nextKeys));
        });
    }
    ngAfterViewChecked() {
        const el = this.viewportRef().nativeElement;
        // 1. Alto real del viewport (0 en jsdom → la ventana usa solo el buffer).
        const clientHeight = el.clientHeight;
        if (clientHeight !== this.viewportHeight()) {
            this.viewportHeight.set(clientHeight);
        }
        // 2. Medición de alturas reales de las filas renderizadas (por clave).
        this.measureRenderedRows(el);
        // 3. Compensación de prepend: mantener la posición visual.
        if (this.pendingPrependCount > 0) {
            const delta = this.offsets()[this.pendingPrependCount] ?? 0;
            this.pendingPrependCount = 0;
            if (delta > 0) {
                el.scrollTop = el.scrollTop + delta;
                this.syncFromViewport(el);
            }
        }
        // 4. Anclaje al fondo pendiente (carga inicial, mensaje propio, chip).
        if (this.pendingScrollToBottom) {
            this.pendingScrollToBottom = false;
            this.applyScrollToBottom(el);
        }
        else if (this.followOutput() && this._atBottom()) {
            // Corrección de deriva: si estamos anclados y una medición tardía
            // cambió el alto total, re-pegar al fondo.
            const target = this.window().totalHeight - this.viewportHeight();
            if (target > 0 && el.scrollTop < target) {
                this.applyScrollToBottom(el);
            }
        }
    }
    onScroll() {
        const el = this.viewportRef().nativeElement;
        this.syncFromViewport(el);
        const st = this.scrollTop();
        const threshold = this.nearTopThreshold();
        if (st <= threshold && this.nearTopArmed && this.items().length > 0) {
            this.nearTopArmed = false;
            this.nearTop.emit();
        }
        else if (st > threshold) {
            this.nearTopArmed = true;
        }
    }
    /** Salta al fondo del hilo y limpia el chip de mensajes nuevos. */
    scrollToBottom() {
        this._newItemsCount.set(0);
        this._atBottom.set(true);
        this.pendingScrollToBottom = true;
        this.applyScrollToBottom(this.viewportRef().nativeElement);
    }
    jumpToBottom() {
        this.scrollToBottom();
    }
    // ── Privados ──
    onItemsChanged(nextKeys) {
        const change = classifyItemsChange(this.prevKeys, nextKeys);
        this.prevKeys = nextKeys;
        if (change.reset) {
            this.measured.set(new Map());
            this._newItemsCount.set(0);
            this.nearTopArmed = true;
            if (this.followOutput()) {
                this._atBottom.set(true);
                this.pendingScrollToBottom = true;
            }
            return;
        }
        if (change.prepended > 0) {
            this.pendingPrependCount = change.prepended;
            this.nearTopArmed = true;
        }
        if (change.appended > 0) {
            if (this.followOutput() && this._atBottom()) {
                this.pendingScrollToBottom = true;
            }
            else {
                this._newItemsCount.update(n => n + change.appended);
            }
        }
    }
    measureRenderedRows(viewport) {
        const rows = this.visibleRows();
        if (rows.length === 0)
            return;
        const els = viewport.querySelectorAll('.sol-virtual-scroll__item');
        let changes = null;
        const current = this.measured();
        els.forEach((rowEl, i) => {
            const row = rows[i];
            if (!row)
                return;
            const height = rowEl.offsetHeight;
            // jsdom/elementos ocultos miden 0: se ignoran (queda la estimada).
            if (height <= 0)
                return;
            if (current.get(row.key) === height && !changes?.has(row.key))
                return;
            changes ??= new Map(current);
            changes.set(row.key, height);
        });
        if (changes) {
            this.measured.set(changes);
        }
    }
    applyScrollToBottom(el) {
        const target = Math.max(0, this.window().totalHeight - this.viewportHeight());
        el.scrollTop = target;
        this.syncFromViewport(el);
    }
    syncFromViewport(el) {
        this.scrollTop.set(el.scrollTop);
        const bottom = isAtBottom(el.scrollTop, this.viewportHeight(), this.window().totalHeight);
        if (bottom !== this._atBottom()) {
            this._atBottom.set(bottom);
        }
        if (bottom) {
            this._newItemsCount.set(0);
        }
        if (bottom !== this.lastEmittedAtBottom) {
            this.lastEmittedAtBottom = bottom;
            this.atBottomChange.emit(bottom);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolVirtualScrollComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolVirtualScrollComponent, isStandalone: true, selector: "sol-virtual-scroll", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, itemKey: { classPropertyName: "itemKey", publicName: "itemKey", isSignal: true, isRequired: false, transformFunction: null }, estimatedItemHeight: { classPropertyName: "estimatedItemHeight", publicName: "estimatedItemHeight", isSignal: true, isRequired: false, transformFunction: null }, bufferPx: { classPropertyName: "bufferPx", publicName: "bufferPx", isSignal: true, isRequired: false, transformFunction: null }, followOutput: { classPropertyName: "followOutput", publicName: "followOutput", isSignal: true, isRequired: false, transformFunction: null }, nearTopThreshold: { classPropertyName: "nearTopThreshold", publicName: "nearTopThreshold", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { nearTop: "nearTop", atBottomChange: "atBottomChange" }, queries: [{ propertyName: "itemTemplate", first: true, predicate: (TemplateRef), descendants: true, isSignal: true }], viewQueries: [{ propertyName: "viewportRef", first: true, predicate: ["viewport"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div #viewport class="sol-virtual-scroll__viewport" (scroll)="onScroll()">
      <div
        class="sol-virtual-scroll__spacer"
        [style.height.px]="window().padTop"
        aria-hidden="true"
      ></div>
      @for (row of visibleRows(); track row.key) {
        <div class="sol-virtual-scroll__item">
          <ng-container
            [ngTemplateOutlet]="itemTemplate()"
            [ngTemplateOutletContext]="{ $implicit: row.item, index: row.index }"
          />
        </div>
      }
      <div
        class="sol-virtual-scroll__spacer"
        [style.height.px]="window().padBottom"
        aria-hidden="true"
      ></div>
    </div>

    @if (newItemsCount() > 0) {
      <button
        type="button"
        class="sol-virtual-scroll__chip"
        data-testid="chip-mensajes-nuevos"
        (click)="jumpToBottom()"
      >
        <sol-icon name="chevron-down" size="sm" />
        <span class="sol-virtual-scroll__chip-count">{{ newItemsCount() }}</span>
        <span>{{ chipLabel() }}</span>
      </button>
    }
  `, isInline: true, styles: [":host{position:relative;display:block;height:100%;min-height:0}.sol-virtual-scroll__viewport{height:100%;overflow-y:auto;overscroll-behavior:contain}.sol-virtual-scroll__chip{position:absolute;bottom:var(--sol-space-md, 1rem);left:50%;transform:translate(-50%);display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border:1px solid var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-full, 999px);background:var(--sol-bg-surface, #ffffff);color:var(--sol-color-primary, #2563eb);font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, 13px);font-weight:600;box-shadow:var(--sol-shadow-md, 0 4px 12px rgba(0, 0, 0, .15));cursor:pointer;transition:filter var(--sol-transition-fast, .15s ease)}.sol-virtual-scroll__chip:hover{filter:brightness(.97)}.sol-virtual-scroll__chip-count{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:var(--sol-border-radius-full, 999px);background:var(--sol-color-primary, #2563eb);color:var(--sol-color-primary-contrast, #ffffff);font-size:var(--sol-font-size-xs, 11px)}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolVirtualScrollComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-virtual-scroll', standalone: true, imports: [NgTemplateOutlet, SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div #viewport class="sol-virtual-scroll__viewport" (scroll)="onScroll()">
      <div
        class="sol-virtual-scroll__spacer"
        [style.height.px]="window().padTop"
        aria-hidden="true"
      ></div>
      @for (row of visibleRows(); track row.key) {
        <div class="sol-virtual-scroll__item">
          <ng-container
            [ngTemplateOutlet]="itemTemplate()"
            [ngTemplateOutletContext]="{ $implicit: row.item, index: row.index }"
          />
        </div>
      }
      <div
        class="sol-virtual-scroll__spacer"
        [style.height.px]="window().padBottom"
        aria-hidden="true"
      ></div>
    </div>

    @if (newItemsCount() > 0) {
      <button
        type="button"
        class="sol-virtual-scroll__chip"
        data-testid="chip-mensajes-nuevos"
        (click)="jumpToBottom()"
      >
        <sol-icon name="chevron-down" size="sm" />
        <span class="sol-virtual-scroll__chip-count">{{ newItemsCount() }}</span>
        <span>{{ chipLabel() }}</span>
      </button>
    }
  `, styles: [":host{position:relative;display:block;height:100%;min-height:0}.sol-virtual-scroll__viewport{height:100%;overflow-y:auto;overscroll-behavior:contain}.sol-virtual-scroll__chip{position:absolute;bottom:var(--sol-space-md, 1rem);left:50%;transform:translate(-50%);display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border:1px solid var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-full, 999px);background:var(--sol-bg-surface, #ffffff);color:var(--sol-color-primary, #2563eb);font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, 13px);font-weight:600;box-shadow:var(--sol-shadow-md, 0 4px 12px rgba(0, 0, 0, .15));cursor:pointer;transition:filter var(--sol-transition-fast, .15s ease)}.sol-virtual-scroll__chip:hover{filter:brightness(.97)}.sol-virtual-scroll__chip-count{display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:20px;padding:0 6px;border-radius:var(--sol-border-radius-full, 999px);background:var(--sol-color-primary, #2563eb);color:var(--sol-color-primary-contrast, #ffffff);font-size:var(--sol-font-size-xs, 11px)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], itemKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemKey", required: false }] }], estimatedItemHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "estimatedItemHeight", required: false }] }], bufferPx: [{ type: i0.Input, args: [{ isSignal: true, alias: "bufferPx", required: false }] }], followOutput: [{ type: i0.Input, args: [{ isSignal: true, alias: "followOutput", required: false }] }], nearTopThreshold: [{ type: i0.Input, args: [{ isSignal: true, alias: "nearTopThreshold", required: false }] }], nearTop: [{ type: i0.Output, args: ["nearTop"] }], atBottomChange: [{ type: i0.Output, args: ["atBottomChange"] }], itemTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => TemplateRef), { isSignal: true }] }], viewportRef: [{ type: i0.ViewChild, args: ['viewport', { isSignal: true }] }] } });

var meta = {
	tenant: "solercia",
	logo: {
		url: "/assets/logos/boki-logo.svg",
		urlDark: "/assets/logos/boki-logo-dark.svg",
		altText: "Solercia Solutions",
		width: 120
	},
	tagline: "Automatiza. Agenda. Escala.",
	fonts: [
		{
			family: "Space Grotesk",
			provider: "google",
			weights: [
				400,
				500,
				600,
				700
			]
		},
		{
			family: "JetBrains Mono",
			provider: "google",
			weights: [
				400,
				500
			]
		}
	]
};
var primitives = {
	color: {
		blue: {
			"300": "#8DA2FF",
			"400": "#5B78FF",
			"500": "#3D5EFF",
			"600": "#2C4BFF"
		},
		teal: {
			"400": "#0FD3B0",
			"500": "#00B899"
		},
		ink: {
			"50": "#F3F5F8",
			"100": "#EBEEF3",
			"200": "#DCE1EA",
			"400": "#93A0B8",
			"500": "#54607A",
			"800": "#0D121D",
			"900": "#0B0F1A",
			"950": "#070A12"
		},
		red: {
			"400": "#F26669",
			"500": "#E5484D"
		},
		amber: {
			"500": "#E8A33D"
		},
		white: "#FFFFFF"
	},
	font: {
		family: {
			sans: "'Space Grotesk', system-ui, sans-serif",
			display: "'Space Grotesk', system-ui, sans-serif",
			mono: "'JetBrains Mono', monospace"
		},
		size: {
			sm: "12px",
			base: "13.5px",
			lg: "15px",
			xl: "19px"
		},
		weight: {
			normal: 400,
			bold: 600
		},
		lineHeight: {
			base: "1.5"
		}
	},
	radius: {
		sm: "2px",
		md: "4px",
		lg: "8px",
		full: "9999px"
	},
	space: {
		xs: "4px",
		sm: "8px",
		md: "14px",
		lg: "22px",
		xl: "30px"
	},
	size: {
		control: {
			sm: "30px",
			md: "34px",
			lg: "38px"
		}
	},
	z: {
		"1000": 1000,
		"1050": 1050,
		"1100": 1100
	},
	borderWidth: {
		thin: "1px"
	},
	motion: {
		duration: {
			fast: "90ms",
			base: "160ms",
			slow: "260ms"
		},
		easing: {
			standard: "cubic-bezier(0.2, 0, 0, 1)",
			entrance: "cubic-bezier(0.2, 0, 0, 1)"
		}
	}
};
var modes = {
	light: {
		semantic: {
			color: {
				primary: "{color.blue.600}",
				secondary: "{color.ink.500}",
				accent: "{color.teal.500}",
				success: "{color.teal.500}",
				warning: "{color.amber.500}",
				danger: "{color.red.500}",
				info: "{color.blue.500}"
			},
			text: {
				primary: "#0C1220",
				secondary: "{color.ink.500}",
				muted: "{color.ink.400}"
			},
			surface: {
				page: "{color.ink.50}",
				surface: "{color.white}",
				overlay: "rgba(7,10,18,0.55)",
				sunken: "{color.ink.100}",
				texture: "repeating-linear-gradient(0deg, rgba(15,23,42,0.025) 0 1px, transparent 1px 56px), repeating-linear-gradient(90deg, rgba(15,23,42,0.025) 0 1px, transparent 1px 56px)"
			},
			border: {
				color: "{color.ink.200}",
				width: "{borderWidth.thin}"
			},
			layer: {
				dropdown: "{z.1000}",
				modal: "{z.1050}",
				tooltip: "{z.1100}"
			},
			shadow: {
				sm: "none",
				md: "0 6px 16px -8px rgba(12,18,32,0.12)",
				lg: "0 16px 40px -16px rgba(12,18,32,0.18)"
			}
		},
		component: {
			control: {
				inputHeight: "{size.control.md}",
				buttonHeight: "{size.control.md}"
			},
			layout: {
				sidebarWidth: "224px",
				headerHeight: "52px"
			},
			shadow: {
				card: "none"
			},
			alerts: {
				borderRadius: "{radius.md}",
				showIcon: false,
				position: "top-right",
				duration: 4000
			},
			typography: {
				displayWeight: 600,
				displayTracking: "-0.02em",
				displayTransform: "none",
				numericFamily: "'JetBrains Mono', monospace"
			},
			card: {
				bg: "{color.white}",
				border: "1px solid {color.ink.200}",
				radius: "{radius.lg}",
				shadow: "none",
				shadowHover: "0 6px 16px -8px rgba(12,18,32,0.14)",
				blur: "none",
				hoverLift: "0px"
			},
			input: {
				variant: "underline",
				bg: "transparent",
				border: "1px solid transparent",
				radius: "0px",
				shadow: "inset 0 -1px 0 {color.ink.200}",
				focusBorder: "1px solid transparent",
				focusRing: "inset 0 -2px 0 {color.blue.600}"
			},
			button: {
				radius: "{radius.md}",
				shadow: "none",
				weight: 500,
				transform: "none"
			},
			sidebar: {
				bg: "{color.ink.900}",
				text: "#8B96AC",
				activeBg: "rgba(44,75,255,0.16)",
				activeText: "{color.white}",
				itemRadius: "{radius.md}",
				indicator: "inset 2px 0 0 {color.blue.600}"
			},
			header: {
				bg: "rgba(243,245,248,0.85)",
				blur: "blur(8px)"
			},
			auth: {
				layout: "centered",
				heroBg: "radial-gradient(700px 420px at 50% -10%, rgba(44,75,255,0.12), transparent 60%)"
			},
			chart: {
				palette: [
					"#2C4BFF",
					"#00B899",
					"#93A0B8",
					"#0C1220",
					"#5B78FF"
				]
			},
			motion: {
				intensity: "subtle",
				revealStyle: "fade",
				revealDistance: "10px",
				pressScale: 0.99
			}
		}
	},
	dark: {
		semantic: {
			color: {
				primary: "{color.blue.400}",
				secondary: "{color.ink.400}",
				accent: "{color.teal.400}",
				success: "{color.teal.400}",
				warning: "{color.amber.500}",
				danger: "{color.red.400}",
				info: "{color.blue.300}"
			},
			text: {
				primary: "#E8EDF6",
				secondary: "{color.ink.400}",
				muted: "#5A6478"
			},
			surface: {
				page: "{color.ink.950}",
				surface: "{color.ink.800}",
				overlay: "rgba(0,0,0,0.70)",
				sunken: "#131926",
				texture: "repeating-linear-gradient(0deg, rgba(148,163,184,0.045) 0 1px, transparent 1px 56px), repeating-linear-gradient(90deg, rgba(148,163,184,0.045) 0 1px, transparent 1px 56px)"
			},
			border: {
				color: "#1C2434",
				width: "{borderWidth.thin}"
			},
			layer: {
				dropdown: "{z.1000}",
				modal: "{z.1050}",
				tooltip: "{z.1100}"
			},
			shadow: {
				sm: "none",
				md: "0 6px 16px -8px rgba(0,0,0,0.4)",
				lg: "0 16px 40px -16px rgba(0,0,0,0.5)"
			}
		},
		component: {
			control: {
				inputHeight: "{size.control.md}",
				buttonHeight: "{size.control.md}"
			},
			layout: {
				sidebarWidth: "224px",
				headerHeight: "52px"
			},
			shadow: {
				card: "none"
			},
			alerts: {
				borderRadius: "{radius.md}",
				showIcon: false,
				position: "top-right",
				duration: 4000
			},
			typography: {
				displayWeight: 600,
				displayTracking: "-0.02em",
				displayTransform: "none",
				numericFamily: "'JetBrains Mono', monospace"
			},
			card: {
				bg: "{color.ink.800}",
				border: "1px solid #1C2434",
				radius: "{radius.lg}",
				shadow: "none",
				shadowHover: "0 0 0 1px rgba(91,120,255,0.35)",
				blur: "none",
				hoverLift: "0px"
			},
			input: {
				variant: "underline",
				bg: "transparent",
				border: "1px solid transparent",
				radius: "0px",
				shadow: "inset 0 -1px 0 #1C2434",
				focusBorder: "1px solid transparent",
				focusRing: "inset 0 -2px 0 {color.blue.400}"
			},
			button: {
				radius: "{radius.md}",
				shadow: "none",
				weight: 500,
				transform: "none"
			},
			sidebar: {
				bg: "{color.ink.950}",
				text: "#8B96AC",
				activeBg: "rgba(91,120,255,0.14)",
				activeText: "{color.white}",
				itemRadius: "{radius.md}",
				indicator: "inset 2px 0 0 {color.blue.400}"
			},
			header: {
				bg: "rgba(7,10,18,0.80)",
				blur: "blur(8px)"
			},
			auth: {
				layout: "centered",
				heroBg: "radial-gradient(700px 420px at 50% -10%, rgba(91,120,255,0.16), transparent 60%)"
			},
			chart: {
				palette: [
					"#5B78FF",
					"#0FD3B0",
					"#54607A",
					"#E8EDF6",
					"#8DA2FF"
				]
			},
			motion: {
				intensity: "subtle",
				revealStyle: "fade",
				revealDistance: "10px",
				pressScale: 0.99
			}
		}
	}
};
var defaultTheme = {
	meta: meta,
	primitives: primitives,
	modes: modes
};

const SOL_TENANT_RESOLVER = new InjectionToken('SOL_TENANT_RESOLVER');
const THEME_SOURCE = new InjectionToken('THEME_SOURCE', {
    providedIn: 'root',
    // Null-object: no host adapter → no tenant theme → default is used.
    factory: () => ({ async loadTheme() { return null; } }),
});
/**
 * The theme the library ships with and applies when there is no tenant theme.
 * Defaults to the bundled "Vértice" theme (a full ThemeFile that mirrors the
 * `jsonb` stored per company in the database). The host may override it with
 * its own brand default:
 *
 *   { provide: SOL_DEFAULT_THEME, useValue: myBrandTheme }
 */
const SOL_DEFAULT_THEME = new InjectionToken('SOL_DEFAULT_THEME', {
    providedIn: 'root',
    factory: () => defaultTheme,
});

/**
 * Sanitización de URLs de assets de branding por tenant (E6).
 *
 * El logo del ThemeFile llega del API en RUNTIME (dato no confiable) y se
 * aplica en `<img [src]>` y en el favicon vía `setAttribute` — esta última
 * ruta queda FUERA del sanitizer de plantillas de Angular, por eso la
 * validación explícita: solo http/https/relativas; `javascript:`, `data:` y
 * cualquier otro esquema se descartan (mejor sin logo que con un vector XSS).
 */
/** Esquema explícito al inicio de la URL (RFC 3986: ALPHA *( ALPHA / DIGIT / "+" / "-" / "." ) ":"). */
const SCHEME_PATTERN = /^[a-z][a-z0-9+.-]*:/i;
/** Caracteres de control (U+0000–U+001F, U+007F) o espacios embebidos: ofuscan esquemas ("java\tscript:"). */
const UNSAFE_CHARS = new RegExp('[\\u0000-\\u001F\\u007F\\s]');
/**
 * Devuelve la URL si es segura para un asset (http:, https: o relativa al
 * origen); `null` en cualquier otro caso. Nunca lanza.
 */
function sanitizeAssetUrl(url) {
    const trimmed = (url ?? '').trim();
    if (trimmed === '' || UNSAFE_CHARS.test(trimmed))
        return null;
    const scheme = SCHEME_PATTERN.exec(trimmed)?.[0].toLowerCase();
    if (scheme && scheme !== 'http:' && scheme !== 'https:')
        return null;
    return trimmed;
}

const THEME_PREF_KEY = 'sol-dark-mode';
/** Atajo para defaults v2 que copian otra ruta ya resuelta del contrato (respeta el modo). */
const sameAs = (path) => (ctx) => ctx.resolve(path);
/**
 * Tabla única de "qué variables existen": 95 filas (47 v1 obligatorias + 48 v2
 * con default). Cada fila es [nombreCssVar, rutaDelToken, defaultV1?]; la ruta
 * apunta dentro de `{ primitives, semantic, component }` (ver `resolveCssVars`).
 * Agregar/quitar una fila cambia el conjunto emitido — por eso el test de tokens
 * fija el conteo total y el de filas v1.
 */
const EMIT_TABLE = [
    // Colors
    ['--sol-color-primary', 'semantic.color.primary'],
    ['--sol-color-secondary', 'semantic.color.secondary'],
    ['--sol-color-accent', 'semantic.color.accent'],
    ['--sol-color-success', 'semantic.color.success'],
    ['--sol-color-warning', 'semantic.color.warning'],
    ['--sol-color-danger', 'semantic.color.danger'],
    ['--sol-color-info', 'semantic.color.info'],
    ['--sol-color-text-primary', 'semantic.text.primary'],
    ['--sol-color-text-secondary', 'semantic.text.secondary'],
    ['--sol-color-text-muted', 'semantic.text.muted'],
    // Typography
    ['--sol-font-family', 'primitives.font.family.sans'],
    ['--sol-font-family-mono', 'primitives.font.family.mono'],
    ['--sol-font-size-base', 'primitives.font.size.base'],
    ['--sol-font-size-sm', 'primitives.font.size.sm'],
    ['--sol-font-size-lg', 'primitives.font.size.lg'],
    ['--sol-font-size-xl', 'primitives.font.size.xl'],
    ['--sol-font-weight-normal', 'primitives.font.weight.normal'],
    ['--sol-font-weight-bold', 'primitives.font.weight.bold'],
    ['--sol-line-height', 'primitives.font.lineHeight.base'],
    // Borders
    ['--sol-border-radius-sm', 'primitives.radius.sm'],
    ['--sol-border-radius-md', 'primitives.radius.md'],
    ['--sol-border-radius-lg', 'primitives.radius.lg'],
    ['--sol-border-radius-full', 'primitives.radius.full'],
    ['--sol-border-width-default', 'semantic.border.width'],
    ['--sol-border-color-default', 'semantic.border.color'],
    // Sizing
    ['--sol-size-input-height', 'component.control.inputHeight'],
    ['--sol-size-button-height', 'component.control.buttonHeight'],
    ['--sol-size-component-sm', 'primitives.size.control.sm'],
    ['--sol-size-component-md', 'primitives.size.control.md'],
    ['--sol-size-component-lg', 'primitives.size.control.lg'],
    ['--sol-size-sidebar-width', 'component.layout.sidebarWidth'],
    ['--sol-size-header-height', 'component.layout.headerHeight'],
    // Spacing
    ['--sol-space-xs', 'primitives.space.xs'],
    ['--sol-space-sm', 'primitives.space.sm'],
    ['--sol-space-md', 'primitives.space.md'],
    ['--sol-space-lg', 'primitives.space.lg'],
    ['--sol-space-xl', 'primitives.space.xl'],
    // Shadows
    ['--sol-shadow-sm', 'semantic.shadow.sm'],
    ['--sol-shadow-md', 'semantic.shadow.md'],
    ['--sol-shadow-lg', 'semantic.shadow.lg'],
    ['--sol-shadow-card', 'component.shadow.card'],
    // Z-Index
    ['--sol-z-dropdown', 'semantic.layer.dropdown'],
    ['--sol-z-modal', 'semantic.layer.modal'],
    ['--sol-z-tooltip', 'semantic.layer.tooltip'],
    // Backgrounds
    ['--sol-bg-page', 'semantic.surface.page'],
    ['--sol-bg-surface', 'semantic.surface.surface'],
    ['--sol-bg-overlay', 'semantic.surface.overlay'],
    // ——— v2 (opcionales, con default = look del default.json actual) ———
    // Superficie v2
    ['--sol-bg-sunken', 'semantic.surface.sunken', sameAs('semantic.surface.page')],
    ['--sol-bg-page-texture', 'semantic.surface.texture', 'none'],
    // Tipografía v2 (titulares + cifras)
    ['--sol-font-display', 'primitives.font.family.display', sameAs('primitives.font.family.sans')],
    ['--sol-display-weight', 'component.typography.displayWeight', sameAs('primitives.font.weight.bold')],
    ['--sol-display-tracking', 'component.typography.displayTracking', '0em'],
    ['--sol-display-transform', 'component.typography.displayTransform', 'none'],
    ['--sol-font-numeric', 'component.typography.numericFamily', sameAs('primitives.font.family.sans')],
    // Card
    ['--sol-card-bg', 'component.card.bg', sameAs('semantic.surface.surface')],
    ['--sol-card-border', 'component.card.border',
        ctx => `${ctx.resolve('semantic.border.width')} solid ${ctx.resolve('semantic.border.color')}`],
    ['--sol-card-radius', 'component.card.radius', sameAs('primitives.radius.lg')],
    ['--sol-card-shadow', 'component.card.shadow', sameAs('component.shadow.card')],
    // v1 no cambia la sombra al hover: el default de shadowHover es la misma sombra base.
    ['--sol-card-shadow-hover', 'component.card.shadowHover', sameAs('component.shadow.card')],
    ['--sol-card-blur', 'component.card.blur', 'none'],
    ['--sol-hover-lift', 'component.card.hoverLift', '0px'],
    // Input (defaults = estilos actuales de sol-input)
    ['--sol-input-bg', 'component.input.bg', sameAs('semantic.surface.surface')],
    ['--sol-input-border', 'component.input.border',
        ctx => `${ctx.resolve('semantic.border.width')} solid ${ctx.resolve('semantic.border.color')}`],
    ['--sol-input-radius', 'component.input.radius', sameAs('primitives.radius.md')],
    ['--sol-input-shadow', 'component.input.shadow', 'none'],
    ['--sol-input-focus-border', 'component.input.focusBorder',
        ctx => `${ctx.resolve('semantic.border.width')} solid ${ctx.resolve('semantic.color.primary')}`],
    ['--sol-input-focus-ring', 'component.input.focusRing',
        ctx => `0 0 0 2px color-mix(in srgb, ${ctx.resolve('semantic.color.primary')} 20%, transparent)`],
    // Botón (defaults = estilos actuales de sol-button)
    ['--sol-button-radius', 'component.button.radius', sameAs('primitives.radius.md')],
    ['--sol-button-shadow', 'component.button.shadow', 'none'],
    ['--sol-button-weight', 'component.button.weight', '500'],
    ['--sol-button-transform', 'component.button.transform', 'none'],
    // Sidebar (defaults = estilos actuales del widget sidebar; bg/texto siguen el modo)
    ['--sol-sidebar-bg', 'component.sidebar.bg', sameAs('semantic.surface.surface')],
    ['--sol-sidebar-text', 'component.sidebar.text', sameAs('semantic.text.secondary')],
    ['--sol-sidebar-active-bg', 'component.sidebar.activeBg',
        ctx => `color-mix(in srgb, ${ctx.resolve('semantic.color.primary')} 10%, transparent)`],
    ['--sol-sidebar-active-text', 'component.sidebar.activeText', sameAs('semantic.color.primary')],
    ['--sol-sidebar-item-radius', 'component.sidebar.itemRadius', sameAs('primitives.radius.md')],
    // v1 marca el item activo con barra izquierda de 3px — como box-shadow inset.
    ['--sol-sidebar-indicator', 'component.sidebar.indicator',
        ctx => `inset 3px 0 0 ${ctx.resolve('semantic.color.primary')}`],
    // Header
    ['--sol-header-bg', 'component.header.bg', sameAs('semantic.surface.surface')],
    ['--sol-header-blur', 'component.header.blur', 'none'],
    // Auth (heroBg se sanitiza: SOLO gradients o "none")
    ['--sol-auth-hero-bg', 'component.auth.heroBg', 'none'],
    // Motion (duraciones/distancia se escalan por `component.motion.intensity` antes de emitir)
    ['--sol-dur-fast', 'primitives.motion.duration.fast', '120ms'],
    ['--sol-dur-base', 'primitives.motion.duration.base', '240ms'],
    ['--sol-dur-slow', 'primitives.motion.duration.slow', '480ms'],
    ['--sol-ease', 'primitives.motion.easing.standard', 'cubic-bezier(0.2, 0, 0, 1)'],
    ['--sol-ease-entrance', 'primitives.motion.easing.entrance', 'cubic-bezier(0.2, 0, 0, 1)'],
    ['--sol-reveal-dist', 'component.motion.revealDistance', '12px'],
    ['--sol-press-scale', 'component.motion.pressScale', '0.98'],
    // Derivada: revealStyle → nombre del keyframe (los keyframes llegan en el Paso 3).
    ['--sol-reveal-name', 'component.motion.revealStyle', 'solRevealFade'],
    // Chart (defaults = paleta actual de sol-chart: primary, info, success, warning, danger, secondary)
    ['--sol-chart-1', 'component.chart.palette.0', sameAs('semantic.color.primary')],
    ['--sol-chart-2', 'component.chart.palette.1', sameAs('semantic.color.info')],
    ['--sol-chart-3', 'component.chart.palette.2', sameAs('semantic.color.success')],
    ['--sol-chart-4', 'component.chart.palette.3', sameAs('semantic.color.warning')],
    ['--sol-chart-5', 'component.chart.palette.4', sameAs('semantic.color.danger')],
    ['--sol-chart-6', 'component.chart.palette.5', sameAs('semantic.color.secondary')],
    // Overlay de diálogos: desenfoque del fondo (frosted glass detrás de todo
    // modal/confirm). Default con blur visible — pedido del fundador para que TODO
    // cuadro de diálogo lo lleve por defecto; un tema puede subirlo (glass) o
    // anularlo ("none", p. ej. skins planos/brutalistas).
    ['--sol-overlay-blur', 'component.overlay.blur', 'blur(3px)'],
];
/**
 * Referencias `{ruta}` — GLOBAL: los temas v2 embeben refs dentro de shorthands
 * ("2px solid {color.ink.900}", "inset 0 -1px 0 {color.ink.200}"); una ref que
 * ocupa todo el valor se comporta igual que en v1.
 */
const REF_PATTERN = /\{([^}]+)\}/g;
/** Variante NO lanzante de `getIn`: `undefined` cuando la ruta no existe (filas v2). */
function tryGetIn(source, path) {
    let acc = source;
    for (const key of path.split('.')) {
        if (acc !== null && typeof acc === 'object' && key in acc) {
            acc = acc[key];
        }
        else {
            return undefined;
        }
    }
    return acc;
}
function getIn(source, path) {
    const value = tryGetIn(source, path);
    if (value === undefined) {
        throw new Error(`resolveCssVars: ruta de token no encontrada "${path}"`);
    }
    return value;
}
/** Interpola TODAS las refs `{ruta}` de un valor (completas o embebidas) contra `primitives`. */
function interpolateRefs(value, primitives) {
    return value.replace(REF_PATTERN, (_match, refPath) => String(getIn(primitives, refPath)));
}
/** Puro: resuelve un valor del contrato — refs contra `primitives`, literales intactos. Lanza si falta. */
function resolveToken(ctx, path) {
    const raw = getIn(ctx, path);
    if (raw === null) {
        throw new Error(`resolveCssVars: valor sin resolver para "${path}"`);
    }
    return interpolateRefs(String(raw), ctx.primitives);
}
/** Multiplicador global de movimiento por intensidad. Sin bloque motion ⇒ 1 (look v1 intacto). */
const MOTION_INTENSITY_SCALE = {
    none: 0.01,
    subtle: 0.6,
    smooth: 1.0,
    expressive: 1.4,
};
/** Variables afectadas por el multiplicador (duraciones + distancia de reveal; pressScale NO se escala). */
const MOTION_SCALED_VARS = new Set([
    '--sol-dur-fast',
    '--sol-dur-base',
    '--sol-dur-slow',
    '--sol-reveal-dist',
]);
/** Variables de background-image sanitizadas: SOLO gradients o "none" (jamás `url(`). */
const GRADIENT_GUARDED_VARS = new Set([
    '--sol-bg-page-texture',
    '--sol-auth-hero-bg',
]);
const SAFE_GRADIENT_START = /^(?:linear-gradient|radial-gradient|repeating-linear-gradient|repeating-radial-gradient)\s*\(/i;
/**
 * Un background-image del tenant es seguro si es "none" o comienza con un
 * gradient permitido y NO contiene `url(` en ninguna posición (tolera varios
 * gradients separados por coma). Caso contrario se emite el default.
 */
function isSafeBackgroundImage(value) {
    const trimmed = value.trim();
    if (/^none$/i.test(trimmed))
        return true;
    if (/url\s*\(/i.test(trimmed))
        return false;
    return SAFE_GRADIENT_START.test(trimmed);
}
/** Mapa revealStyle → keyframe (los keyframes viven en `styles.css`). */
const REVEAL_KEYFRAME_BY_STYLE = {
    rise: 'solRevealRise',
    fade: 'solRevealFade',
    pop: 'solRevealPop',
    slide: 'solRevealSlide',
    zoom: 'solRevealZoom',
};
/** Escala del multiplicador de motion. `prefers-reduced-motion: reduce` fuerza "none" (0.01x). */
function motionScaleFor(component, reducedMotion) {
    if (reducedMotion)
        return MOTION_INTENSITY_SCALE['none'];
    const intensity = component.motion?.intensity;
    return (intensity !== undefined ? MOTION_INTENSITY_SCALE[intensity] : undefined) ?? 1;
}
const SCALABLE_VALUE = /^(-?\d+(?:\.\d+)?)(ms|s|px|rem|em)$/;
/** Multiplica un valor CSS `<número><unidad>` conservando la unidad; valores compuestos quedan intactos. */
function scaleMotionValue(value, scale) {
    if (scale === 1)
        return value;
    const match = SCALABLE_VALUE.exec(value.trim());
    if (!match)
        return value;
    const scaled = Number.parseFloat((Number.parseFloat(match[1]) * scale).toFixed(2));
    return `${scaled}${match[2]}`;
}
/**
 * Normaliza el bloque `chart` del componente: la paleta del tenant (3-6 colores)
 * se expande CÍCLICAMENTE o se recorta a exactamente 6 entradas para que las
 * filas `--sol-chart-1..6` resuelvan uniformemente. Paleta inválida o vacía ⇒
 * se ignora el bloque y aplican los defaults.
 */
function normalizeComponent(component) {
    const palette = component.chart?.palette;
    if (!Array.isArray(palette) || palette.length === 0) {
        if (component.chart === undefined)
            return component;
        const withoutChart = { ...component };
        delete withoutChart.chart;
        return withoutChart;
    }
    const six = Array.from({ length: 6 }, (_, i) => String(palette[i % palette.length]));
    return { ...component, chart: { palette: six } };
}
/**
 * Puro y exportado: aplana los 3 niveles (primitivos→semántico→componente) del
 * `ThemeFile` para un modo dado hacia el mapa plano nombre→valor de las
 * variables `--sol-*` de la EMIT_TABLE. Filas v1 son obligatorias (lanzan si
 * faltan); filas v2 ausentes emiten su default — un tema v1 emite el conjunto
 * completo. Es el núcleo testeable del sistema de tokens.
 */
function resolveCssVars(file, mode, options = {}) {
    const modeConfig = file.modes[mode];
    const ctx = {
        primitives: file.primitives,
        semantic: modeConfig.semantic,
        component: normalizeComponent(modeConfig.component),
    };
    const defaultCtx = { mode, resolve: path => resolveToken(ctx, path) };
    const applyDefault = (d) => (typeof d === 'string' ? d : d(defaultCtx));
    const motionScale = motionScaleFor(ctx.component, options.reducedMotion === true);
    const out = new Map();
    for (const [name, path, defaultV1] of EMIT_TABLE) {
        let value;
        if (defaultV1 === undefined) {
            // Fila v1: obligatoria — ruta ausente o ref rota lanza (tema no renderizable).
            value = resolveToken(ctx, path);
        }
        else {
            const raw = tryGetIn(ctx, path);
            if (raw === undefined || raw === null) {
                value = applyDefault(defaultV1);
            }
            else if (name === '--sol-reveal-name') {
                // Derivada: revealStyle → keyframe; estilo desconocido cae al default.
                value = REVEAL_KEYFRAME_BY_STYLE[String(raw)] ?? applyDefault(defaultV1);
            }
            else {
                value = interpolateRefs(String(raw), ctx.primitives);
                if (GRADIENT_GUARDED_VARS.has(name) && !isSafeBackgroundImage(value)) {
                    console.warn(`ThemeService: valor rechazado para ${name} (solo gradients o "none", sin "url("); se emite el default.`);
                    value = applyDefault(defaultV1);
                }
            }
        }
        if (MOTION_SCALED_VARS.has(name)) {
            value = scaleMotionValue(value, motionScale);
        }
        out.set(name, value);
    }
    return out;
}
/**
 * Construye la URL de Google Fonts EXCLUSIVAMENTE con `family` + `weights`
 * (sanitización por construcción: jamás se usa una URL cruda del tenant).
 * Entradas con `provider !== "google"` se ignoran. `null` = sin fuentes.
 */
function buildGoogleFontsUrl(fonts) {
    const families = (fonts ?? [])
        .filter(f => f?.provider === 'google' && typeof f.family === 'string' && f.family.trim() !== '')
        .map(f => {
        const weights = [...new Set((f.weights ?? []).filter(w => Number.isFinite(w)))].sort((a, b) => a - b);
        const family = encodeURIComponent(f.family.trim());
        return weights.length > 0 ? `family=${family}:wght@${weights.join(';')}` : `family=${family}`;
    });
    if (families.length === 0)
        return null;
    return `https://fonts.googleapis.com/css2?${families.join('&')}&display=swap`;
}
/**
 * Validación previa a aplicar un ThemeFile llegado en RUNTIME (asset o API):
 * un tema es renderizable si TODAS sus variables resuelven en AMBOS modos
 * (las v1 desde el tema; las v2 desde el tema o su default). Referencias
 * rotas, niveles ausentes o valores nulos lo descartan — el llamador cae al
 * tema anterior/default en vez de dejar el `:root` a medias.
 */
function isRenderableTheme(file) {
    if (!file || typeof file !== 'object' || !file.modes)
        return false;
    try {
        resolveCssVars(file, 'light');
        resolveCssVars(file, 'dark');
        return true;
    }
    catch {
        return false;
    }
}
/**
 * ThemeService — runtime de theming white-label, AGNÓSTICO del host.
 *
 * Emite los 95 tokens `--sol-*` sobre `:root` a partir de un `ThemeFile` y
 * reacciona a tres entradas: el tema del tenant (cargado por el puerto
 * `THEME_SOURCE` que provee el host), el default empaquetado
 * (`SOL_DEFAULT_THEME`) y el toggle light/dark. NO conoce el ORIGEN del tema
 * (HTTP, archivo, mock…): eso vive en el adaptador `ThemeSource` del host.
 *
 * RED DE FALLBACKS (de mejor a peor):
 * 1. tema del tenant (vía `THEME_SOURCE`),
 * 2. default empaquetado (`SOL_DEFAULT_THEME`),
 * 3. variables inline de `:root` (styles.css del host, red final).
 * Un source que falla / devuelve `null`, un `ThemeFile` de tenant inválido, o
 * un `SOL_DEFAULT_THEME` malformado degradan al siguiente nivel con un log,
 * sin dejar la app sin tema.
 *
 * ANTI-RACE: si el tenant activo cambia mientras su tema viaja, la respuesta
 * tardía se descarta (`isStaleResponse`).
 *
 * BRANDING: `logo` (URL SANITIZADA — solo http/https/relativas, jamás
 * `javascript:`), `brandName` y favicon del tenant (restaurado al volver al
 * default). Logo DUAL: `meta.logo.urlDark` es la variante para modo oscuro;
 * `logo()` expone la URL efectiva del modo actual y el favicon la sigue al
 * togglear. `activeTheme` expone el tema efectivo para consumidores reactivos
 * (ej. `sol-chart` re-renderiza al cambiar de tenant).
 */
class ThemeService {
    /** Puerto de carga del tema por tenant (lo provee el host; null-object por defecto → sin tema de tenant). */
    source = inject(THEME_SOURCE);
    /** Opcional: sin resolver (specs/otros hosts) el servicio se comporta como single-theme (solo default). */
    tenantResolver = inject(SOL_TENANT_RESOLVER, { optional: true });
    rawDefault = inject(SOL_DEFAULT_THEME);
    /**
     * Default empaquetado EN la librería (Vértice por defecto; el host puede
     * sobreescribir SOL_DEFAULT_THEME). VALIDADO como cualquier tema: un default
     * malformado cae a `null` → se activa la 3ª red (CSS inline de `:root`), sin
     * dejar la app rota (misma garantía que `tenantTheme`).
     */
    defaultTheme = signal(isRenderableTheme(this.rawDefault) ? this.rawDefault : null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "defaultTheme" }] : /* istanbul ignore next */ []));
    /** Tema del tenant activo, ya validado. `null` = usar el default. */
    tenantTheme = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tenantTheme" }] : /* istanbul ignore next */ []));
    _isDark = signal(this.loadDarkPreference(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_isDark" }] : /* istanbul ignore next */ []));
    /** Tema EFECTIVO aplicado sobre `:root` (tenant → default → null = red de styles.css). */
    activeTheme = computed(() => this.tenantTheme() ?? this.defaultTheme(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeTheme" }] : /* istanbul ignore next */ []));
    isDark = this._isDark.asReadonly();
    /**
     * Logo EFECTIVO del tema con URL sanitizada. URL insegura → sin logo (jamás
     * javascript:). Logo dual: en modo dark `url` expone la variante `urlDark`
     * si existe y es segura; sin `urlDark` (o insegura), `url` sirve en ambos
     * modos. Depende de `_isDark`, así que reacciona al toggle en runtime.
     */
    logo = computed(() => {
        const meta = this.activeTheme()?.meta;
        if (!meta?.logo)
            return null;
        const url = sanitizeAssetUrl(meta.logo.url);
        if (!url)
            return null;
        const urlDark = sanitizeAssetUrl(meta.logo.urlDark) ?? undefined;
        const effectiveUrl = this._isDark() && urlDark ? urlDark : url;
        return { ...meta.logo, url: effectiveUrl, urlDark };
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "logo" }] : /* istanbul ignore next */ []));
    /** Nombre de marca del tenant (branding runtime): altText del logo o el slug del tenant. */
    brandName = computed(() => {
        const meta = this.activeTheme()?.meta;
        if (!meta)
            return null;
        return meta.logo?.altText?.trim() || meta.tenant || null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "brandName" }] : /* istanbul ignore next */ []));
    /** href original del favicon empaquetado (index.html); se captura una sola vez. */
    faviconOriginalHref = null;
    faviconCaptured = false;
    constructor() {
        if (this.defaultTheme() === null) {
            console.warn('ThemeService: SOL_DEFAULT_THEME es inválido; se usa la red final (CSS inline de :root).');
        }
        effect(() => {
            const file = this.activeTheme();
            const mode = this._isDark() ? 'dark' : 'light';
            if (file) {
                this.applyCssVariables(file, mode);
            }
            else {
                // Sin tema aplicable: se retiran las vars inline para que gobierne
                // la red final — el bloque :root de styles.css.
                this.clearCssVariables();
                this.applyDarkClass(this._isDark());
            }
        });
        // Favicon: SOLO el tema del tenant rebrandea; el default restaura el de
        // index.html. `logo()` ya es la variante efectiva del modo actual (logo
        // dual), así que el favicon reacciona también al toggle light/dark.
        effect(() => {
            const tenantLogo = this.tenantTheme() ? this.logo() : null;
            this.applyFavicon(tenantLogo?.url ?? null);
        });
        // Fuentes web por tenant (v2): un ÚNICO <link> a Google Fonts construido
        // por código (family + weights). Cambiar de tema reemplaza el link; un
        // tema sin `meta.fonts` lo retira.
        effect(() => {
            this.applyFonts(this.activeTheme()?.meta?.fonts);
        });
        if (this.tenantResolver) {
            const resolver = this.tenantResolver;
            effect(() => {
                const tenantId = resolver.activeTenantId();
                untracked(() => void this.onTenantChange(tenantId));
            });
        }
    }
    /**
     * Aplica directamente un ThemeFile de tenant (enfoque PUSH: el host lo empuja
     * en vez de que la librería tire vía THEME_SOURCE). Validado como cualquier
     * tema: uno inválido cae al default. Útil para hosts que ya tienen el tema en
     * memoria (SSR, caché) o que no quieren implementar un ThemeSource.
     */
    setTenantTheme(theme) {
        this.tenantTheme.set(isRenderableTheme(theme) ? theme : null);
    }
    toggleMode() {
        const newValue = !this._isDark();
        this._isDark.set(newValue);
        localStorage.setItem(THEME_PREF_KEY, String(newValue));
        this.applyDarkClass(newValue);
    }
    /**
     * Fuerza la recarga del tema del tenant activo (Theme Studio: tras el PUT
     * de `:id/theme` el tema recién persistido debe verse sin re-login ni
     * cambio de empresa). Re-lanza la misma petición del cambio de tenant —
     * hereda el anti-race y la red de fallbacks. Sin resolver o sin tenant
     * activo no hace nada (sigue el default).
     */
    refresh() {
        const tenantId = this.tenantResolver?.activeTenantId() ?? null;
        if (tenantId !== null) {
            void this.onTenantChange(tenantId);
        }
    }
    /**
     * Reacción al cambio de tenant (login, cambio de empresa activa, logout).
     * `null` (pre-login/logout) limpia el tema de tenant → vuelve el default.
     */
    async onTenantChange(companyId) {
        if (companyId === null) {
            this.tenantTheme.set(null);
            return;
        }
        try {
            // La librería NO sabe de dónde viene el tema: se lo pide al puerto que
            // el host proveyó (HTTP, archivo, mock…). Sin adaptador → null → default.
            const file = await this.source.loadTheme(companyId);
            if (this.isStaleResponse(companyId))
                return;
            if (isRenderableTheme(file)) {
                this.tenantTheme.set(file);
            }
            else {
                console.warn(`ThemeService: el tema de la empresa ${companyId} llegó inválido o vacío; se aplica el tema por defecto.`);
                this.tenantTheme.set(null);
            }
        }
        catch {
            if (this.isStaleResponse(companyId))
                return;
            // Cualquier fallo de carga (red, 404, 403, permisos…) degrada en
            // silencio al default: el theming nunca deja la app sin tema.
            console.warn(`ThemeService: tema del tenant ${companyId} no disponible; se aplica el tema por defecto.`);
            this.tenantTheme.set(null);
        }
    }
    /** Anti-race: la respuesta pertenece a un tenant que ya no es el activo. */
    isStaleResponse(companyId) {
        return companyId !== (this.tenantResolver?.activeTenantId() ?? null);
    }
    loadDarkPreference() {
        const stored = localStorage.getItem(THEME_PREF_KEY);
        if (stored !== null)
            return stored === 'true';
        // matchMedia no existe en jsdom — sin señal del sistema, modo claro.
        return typeof window.matchMedia === 'function'
            ? window.matchMedia('(prefers-color-scheme: dark)').matches
            : false;
    }
    applyDarkClass(dark) {
        const html = document.documentElement;
        if (dark) {
            html.classList.add('dark');
            document.body.classList.add('dark');
        }
        else {
            html.classList.remove('dark');
            document.body.classList.remove('dark');
        }
    }
    applyCssVariables(file, mode) {
        const root = document.documentElement.style;
        const reducedMotion = this.prefersReducedMotion();
        for (const [name, value] of resolveCssVars(file, mode, { reducedMotion })) {
            root.setProperty(name, value);
        }
        this.applyDarkClass(this._isDark());
    }
    /** `prefers-reduced-motion: reduce` del sistema fuerza la intensidad "none" al emitir. */
    prefersReducedMotion() {
        // matchMedia no existe en jsdom — sin señal del sistema, motion normal.
        return (typeof window.matchMedia === 'function' &&
            window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    }
    /** Inyecta/reemplaza/retira el único <link> de fuentes del tenant (v2). */
    applyFonts(fonts) {
        const href = buildGoogleFontsUrl(fonts);
        let link = document.head.querySelector('link[data-sol-tenant-fonts]');
        if (href === null) {
            link?.remove();
            return;
        }
        if (!link) {
            link = document.createElement('link');
            link.setAttribute('rel', 'stylesheet');
            link.setAttribute('data-sol-tenant-fonts', '');
            document.head.appendChild(link);
        }
        if (link.getAttribute('href') !== href) {
            link.setAttribute('href', href);
        }
    }
    clearCssVariables() {
        const root = document.documentElement.style;
        for (const [name] of EMIT_TABLE) {
            root.removeProperty(name);
        }
    }
    /** Aplica el favicon del tenant o restaura el empaquetado (`url === null`). */
    applyFavicon(url) {
        let link = document.querySelector('link[rel="icon"]');
        if (!this.faviconCaptured) {
            this.faviconOriginalHref = link?.getAttribute('href') ?? null;
            this.faviconCaptured = true;
        }
        if (url === null) {
            if (!link)
                return;
            if (this.faviconOriginalHref === null) {
                // El link lo creó este servicio (no venía en index.html): se retira.
                link.remove();
            }
            else {
                link.setAttribute('href', this.faviconOriginalHref);
            }
            return;
        }
        if (!link) {
            link = document.createElement('link');
            link.setAttribute('rel', 'icon');
            document.head.appendChild(link);
        }
        link.setAttribute('href', url);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: ThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: ThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: ThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/**
 * Registers the theming runtime. Instantiating ThemeService eagerly starts its
 * effects: it applies {@link SOL_DEFAULT_THEME} immediately and, if the host
 * wired SOL_TENANT_RESOLVER + THEME_SOURCE, begins reacting to tenant changes.
 *
 * The default theme is bundled in the library (no asset fetch required), so a
 * host that provides nothing still renders with a valid theme.
 */
function provideTheme() {
    return provideAppInitializer(() => {
        inject(ThemeService);
    });
}

/**
 * Variables `--sol-*` que alimentan el chart y su fallback (valores del modo
 * light de `styles.css`). El fallback solo aplica si la variable no resuelve
 * (ej. specs en jsdom); en la app, ThemeService ya las dejó en `:root`.
 */
const CHART_TOKEN_FALLBACKS = [
    ['--sol-font-family', "'Inter', system-ui, -apple-system, sans-serif"],
    ['--sol-font-size-sm', '12px'],
    ['--sol-color-text-secondary', '#64748B'],
    ['--sol-color-text-muted', '#94A3B8'],
    ['--sol-border-color-default', '#E2E8F0'],
    ['--sol-bg-surface', '#FFFFFF'],
    // Paleta v2 del tema (`component.chart.palette` → --sol-chart-1..6). Los
    // fallbacks replican los defaults de la EMIT_TABLE (primary, info, success,
    // warning, danger, secondary del modo light de default.json).
    ['--sol-chart-1', '#2563EB'],
    ['--sol-chart-2', '#3B82F6'],
    ['--sol-chart-3', '#10B981'],
    ['--sol-chart-4', '#F59E0B'],
    ['--sol-chart-5', '#EF4444'],
    ['--sol-chart-6', '#7C3AED'],
    // Motion v2: duración de entrada (el default replica la EMIT_TABLE).
    ['--sol-dur-slow', '480ms'],
];
/**
 * Resuelve los tokens del tema ACTIVO a valores concretos. Recibe el lector
 * de variables como función (`getVar`) para mantenerse pura: el componente
 * pasa `getComputedStyle(document.documentElement)`, los specs un mapa fijo.
 */
function readChartTheme(getVar) {
    const resolved = new Map();
    for (const [name, fallback] of CHART_TOKEN_FALLBACKS) {
        const raw = (getVar(name) ?? '').trim();
        resolved.set(name, raw !== '' ? raw : fallback);
    }
    const get = (name) => resolved.get(name);
    return {
        fontFamily: get('--sol-font-family'),
        fontSize: parsePx(get('--sol-font-size-sm'), 12),
        textColor: get('--sol-color-text-secondary'),
        mutedColor: get('--sol-color-text-muted'),
        gridColor: get('--sol-border-color-default'),
        surfaceColor: get('--sol-bg-surface'),
        palette: [
            get('--sol-chart-1'),
            get('--sol-chart-2'),
            get('--sol-chart-3'),
            get('--sol-chart-4'),
            get('--sol-chart-5'),
            get('--sol-chart-6'),
        ],
        animationMs: parseMs(get('--sol-dur-slow'), 480),
    };
}
/** `'12px'` → `12`. Si no parsea, devuelve el fallback. */
function parsePx(value, fallback) {
    const parsed = Number.parseFloat(value);
    return Number.isFinite(parsed) ? parsed : fallback;
}
/** `'480ms'` → `480`, `'0.5s'` → `500`. Si no parsea, devuelve el fallback. */
function parseMs(value, fallback) {
    const trimmed = value.trim();
    const parsed = Number.parseFloat(trimmed);
    if (!Number.isFinite(parsed))
        return fallback;
    const isSeconds = /s$/i.test(trimmed) && !/ms$/i.test(trimmed);
    return isSeconds ? parsed * 1000 : parsed;
}
/**
 * Agrega alpha a un color hex (`#RGB` o `#RRGGBB`) → `rgba(...)`. El canvas
 * NO soporta `color-mix()`, así que la translucidez se calcula aquí. Colores
 * no-hex (rgb(), nombres) se devuelven intactos (sin alpha) — mejor color
 * sólido correcto que un valor inválido.
 */
function withAlpha(color, alpha) {
    const hex = color.trim();
    const match = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(hex);
    if (!match)
        return hex;
    let value = match[1];
    if (value.length === 3) {
        value = value.split('').map(c => c + c).join('');
    }
    const r = Number.parseInt(value.slice(0, 2), 16);
    const g = Number.parseInt(value.slice(2, 4), 16);
    const b = Number.parseInt(value.slice(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
/** Color efectivo de la serie `i`: explícito o cíclico de la paleta. */
function seriesColor(series, index, theme) {
    return series.color ?? theme.palette[index % theme.palette.length];
}
/**
 * Núcleo del adapter: datos declarativos + tokens → `ChartConfiguration`.
 * Pura y determinista: misma entrada, misma configuración.
 */
function buildChartConfig(type, data, theme, options = {}) {
    const engineType = type === 'doughnut' ? 'doughnut' : type === 'bar' ? 'bar' : 'line';
    const datasets = data.series.map((s, i) => buildDataset(type, s, i, theme));
    return {
        type: engineType,
        data: { labels: [...data.labels], datasets },
        options: buildEngineOptions(type, data, theme, options),
    };
}
function buildDataset(type, series, index, theme) {
    const color = seriesColor(series, index, theme);
    const base = { label: series.label, data: [...series.data] };
    switch (type) {
        case 'doughnut':
            // En la dona cada PUNTO es un segmento: paleta por punto, no por serie.
            return {
                ...base,
                backgroundColor: series.data.map((_, i) => theme.palette[i % theme.palette.length]),
                borderColor: theme.surfaceColor,
                borderWidth: 2,
                hoverOffset: 6,
            };
        case 'bar':
            return {
                ...base,
                backgroundColor: color,
                borderRadius: 4,
                maxBarThickness: 36,
            };
        case 'sparkline':
            return {
                ...base,
                borderColor: color,
                backgroundColor: withAlpha(color, 0.12),
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                borderWidth: 2,
            };
        case 'line':
            return {
                ...base,
                borderColor: color,
                backgroundColor: withAlpha(color, 0.15),
                fill: false,
                tension: 0.35,
                pointRadius: 3,
                pointBackgroundColor: color,
                borderWidth: 2,
            };
    }
}
/**
 * Animación de entrada nativa de Chart.js con motion del tema (v2):
 * - Duración: `--sol-dur-slow` (ya escalada por intensity/reduced-motion).
 * - Easing: `easeOutQuart` — Chart.js solo acepta easings con nombre (no
 *   `cubic-bezier`), y es la aproximación nativa más cercana a
 *   `--sol-ease-entrance`.
 * - Barras/líneas: delay por índice de dato (opción nativa `animation.delay`
 *   del sample "delayed" de Chart.js). Las barras crecen desde la base de
 *   forma escalonada y las líneas se revelan de izquierda a derecha (trazo
 *   progresivo). El stagger total ≈ una duración extra, proporcional al
 *   número de puntos, así que también colapsa con motion "none".
 * - Doughnut: la rotación nativa de entrada anima todos los segmentos como
 *   conjunto — un delay por segmento la rompería.
 */
function buildEntranceAnimation(type, data, theme) {
    const duration = theme.animationMs;
    const animation = {
        duration,
        easing: 'easeOutQuart',
    };
    if (type !== 'doughnut') {
        const delayUnit = duration / Math.max(data.labels.length, 1);
        animation.delay = context => context.type === 'data' && context.mode === 'default' ? context.dataIndex * delayUnit : 0;
    }
    return animation;
}
function buildEngineOptions(type, data, theme, options) {
    const font = { family: theme.fontFamily, size: theme.fontSize };
    const isSparkline = type === 'sparkline';
    const showLegend = options.legend ?? (type === 'doughnut' || (!isSparkline && data.series.length > 1));
    const engineOptions = {
        responsive: true,
        maintainAspectRatio: false,
        animation: buildEntranceAnimation(type, data, theme),
        plugins: {
            legend: {
                display: showLegend,
                position: type === 'doughnut' ? 'bottom' : 'top',
                labels: {
                    color: theme.textColor,
                    font,
                    boxWidth: 12,
                    boxHeight: 12,
                    usePointStyle: true,
                },
            },
            tooltip: isSparkline
                ? { enabled: false }
                : {
                    enabled: true,
                    backgroundColor: theme.surfaceColor,
                    titleColor: theme.textColor,
                    bodyColor: theme.mutedColor,
                    borderColor: theme.gridColor,
                    borderWidth: 1,
                    titleFont: font,
                    bodyFont: font,
                    padding: 10,
                    displayColors: true,
                    boxPadding: 4,
                },
        },
    };
    if (type === 'doughnut') {
        engineOptions.cutout = '68%';
        return engineOptions;
    }
    engineOptions.scales = {
        x: {
            display: !isSparkline,
            grid: { display: false },
            ticks: { color: theme.mutedColor, font, maxRotation: 45 },
            border: { color: theme.gridColor },
        },
        y: {
            display: !isSparkline,
            beginAtZero: true,
            ...(options.yMax !== undefined ? { max: options.yMax } : {}),
            grid: { color: theme.gridColor },
            ticks: { color: theme.mutedColor, font, precision: 0 },
            border: { display: false },
        },
    };
    return engineOptions;
}

// Registro tree-shakeable: SOLO los controladores/elementos/plugins que los 4
// tipos declarativos necesitan (nada de chart.js/auto, que arrastra todo).
Chart.register(LineController, BarController, DoughnutController, LineElement, PointElement, BarElement, ArcElement, CategoryScale, LinearScale, Legend, Tooltip, Filler);
/**
 * Punto ÚNICO de acople con Chart.js: la fábrica por defecto instancia
 * `new Chart(...)`. Los specs la sustituyen para probar el componente sin
 * canvas real; un eventual cambio de motor se resuelve aquí y en el adapter.
 */
const SOL_CHART_ENGINE = new InjectionToken('SOL_CHART_ENGINE', {
    factory: () => (canvas, config) => new Chart(canvas, config),
});
/**
 * `sol-chart` (E3): envoltura propia de Chart.js con API declarativa.
 *
 * - Las vistas declaran `type` + `data` (+ `options` mínimas) y NUNCA
 *   importan Chart.js — regla del proyecto (theming por tenant y cambio de
 *   motor centralizados).
 * - Los colores/fuentes/grid salen de las variables `--sol-*` del tema
 *   ACTIVO, leídas en runtime con getComputedStyle; al alternar light/dark
 *   (`ThemeService.isDark`) el chart se re-renderiza solo.
 * - A11y: el canvas expone `role="img"` + `aria-label` resuelto por clave
 *   i18n (`ariaLabelKey`), reactivo al idioma activo.
 *
 * Uso:
 * ```html
 * <sol-chart
 *   type="doughnut"
 *   [data]="{ labels: estados(), series: [{ label: citasLabel(), data: conteos() }] }"
 *   ariaLabelKey="pages.dashboard.charts.byState.aria"
 * />
 * ```
 */
class SolChartComponent {
    themeService = inject(ThemeService);
    i18n = inject(SOL_I18N);
    engineFactory = inject(SOL_CHART_ENGINE);
    destroyRef = inject(DestroyRef);
    canvasRef = viewChild('canvas', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "canvasRef" }] : /* istanbul ignore next */ []));
    /** Tipo declarativo de la gráfica. */
    type = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /** Etiquetas + series. Los textos llegan YA resueltos por i18n. */
    data = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    /** Configuración mínima opcional (leyenda, tope del eje Y). */
    options = input({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    /** Clave i18n del `aria-label` del canvas (obligatoria — a11y). */
    ariaLabelKey = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabelKey" }] : /* istanbul ignore next */ []));
    /** Alto del contenedor (el canvas es responsive dentro de él). */
    height = input('260px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    /** La clave es un input dinámico: se recalcula al cambiar el idioma activo. */
    ariaLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate(this.ariaLabelKey());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    chart = null;
    constructor() {
        // Re-render declarativo: cualquier cambio de tipo/datos/opciones, el
        // toggle light/dark (isDark) o un CAMBIO DE TEMA DE TENANT (E6:
        // activeTheme cambia cuando el tema del tenant carga/cambia en runtime
        // con el MISMO modo) destruye y recrea la instancia con los tokens del
        // tema vigente. Volúmenes de dashboard: recrear es más simple y seguro
        // que mutar la config del motor en sitio.
        effect(() => {
            const canvas = this.canvasRef()?.nativeElement;
            this.themeService.isDark(); // tracking explícito del modo
            this.themeService.activeTheme(); // tracking del tema efectivo (tenant/default)
            const type = this.type();
            const data = this.data();
            const options = this.options();
            if (!canvas)
                return;
            untracked(() => this.render(canvas, type, data, options));
        });
        this.destroyRef.onDestroy(() => {
            this.chart?.destroy();
            this.chart = null;
        });
    }
    render(canvas, type, data, options) {
        this.chart?.destroy();
        // Lectura en runtime del tema ACTIVO: ThemeService ya aplicó las --sol-*
        // del modo vigente en :root cuando este effect corre.
        const style = getComputedStyle(document.documentElement);
        const theme = readChartTheme(name => style.getPropertyValue(name));
        this.chart = this.engineFactory(canvas, buildChartConfig(type, data, theme, options));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolChartComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.0.6", type: SolChartComponent, isStandalone: true, selector: "sol-chart", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: true, transformFunction: null }, data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelKey: { classPropertyName: "ariaLabelKey", publicName: "ariaLabelKey", isSignal: true, isRequired: true, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "canvasRef", first: true, predicate: ["canvas"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="sol-chart" [style.height]="height()">
      <canvas #canvas role="img" [attr.aria-label]="ariaLabel()"></canvas>
    </div>
  `, isInline: true, styles: [":host{display:block}.sol-chart{position:relative;width:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolChartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-chart', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-chart" [style.height]="height()">
      <canvas #canvas role="img" [attr.aria-label]="ariaLabel()"></canvas>
    </div>
  `, styles: [":host{display:block}.sol-chart{position:relative;width:100%}\n"] }]
        }], ctorParameters: () => [], propDecorators: { canvasRef: [{ type: i0.ViewChild, args: ['canvas', { isSignal: true }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: true }] }], data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: true }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], ariaLabelKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelKey", required: true }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }] } });

/**
 * Serializador HTML "limpio" para `sol-rich-editor`.
 *
 * NÚCLEO DEL VALOR: recorre el DOM del área editable (o un HTML pegado) y
 * produce HTML SEMÁNTICO CANÓNICO apto para generar PDFs con TCPDF (Laravel).
 * TCPDF tiene un parser HTML muy limitado: rompe con `<div>`/`<span>` con
 * estilos inline arbitrarios, clases desconocidas y —sobre todo— tablas
 * anidadas. Este serializador garantiza una salida acotada y predecible.
 *
 * ── Allowlist de TAGS de salida ──────────────────────────────────────────
 *   Bloque:  <p> <h1> <h2> <h3> <ul> <ol> <li> <table><tbody><tr><td> <br>
 *   Inline:  <strong> <em> <u> <s> <a> <img>
 *   Chip:    <span data-mention-id="…"> / <span data-task-key="…">  (OPT-IN)
 *   Nada más. Todo lo demás se desanida (unwrap), se convierte o se descarta.
 *
 * ── Chips de mención (@) y enlace de tarea (#) — OPT-IN ───────────────────
 *   Un `<span>` se PRESERVA en la salida SOLO si porta `data-mention-id` o
 *   `data-task-key`. En ese caso se emite un span canónico con EXACTAMENTE ese
 *   único atributo data-* (valor escapado) y su texto; cualquier otro atributo
 *   del span de entrada (class, style, on*, contenteditable, href…) se DESCARTA
 *   —no hay passthrough—. Un `<span>` normal (sin data de chip) se desanida
 *   como siempre. Esto no abre XSS: solo el atributo data-* controlado y el
 *   texto escapado sobreviven; el span nunca lleva estilos ni handlers.
 *
 * ── Conversión de tags de entrada ────────────────────────────────────────
 *   <b>/<strong>       → <strong>
 *   <i>/<em>           → <em>
 *   <u>/<ins>          → <u>
 *   <s>/<strike>/<del> → <s>
 *   <div>              → <p>   (o se desanida si contiene bloques)
 *   <h4..h6>           → <h3>  (se acota la jerarquía)
 *   <span>/<font>      → se desanida; sus estilos (negrita/cursiva/subrayado/
 *                        tachado) se traducen a los tags semánticos anteriores.
 *   <thead>/<tbody>/<tfoot> → se aplanan dentro de <tbody>.
 *
 * ── Allowlist de PROPIEDADES CSS de ENTRADA ──────────────────────────────
 *   Solo se INSPECCIONAN estas cuatro; el resto de estilos inline se descarta:
 *     - font-weight       → se convierte a <strong>
 *     - font-style        → se convierte a <em>
 *     - text-decoration   → se convierte a <u> y/o <s>
 *     - text-align        → se conserva como style="text-align:…" en el bloque
 *   IMPORTANTE: los estilos NO se copian tal cual a la salida. El serializador
 *   DESCARTA todos los estilos de entrada y RE-GENERA solo los canónicos que
 *   él controla:
 *     - `style="text-align:center|right|justify"` en bloques (p/h1-3/celda)
 *     - `style="display:block;margin:0 auto"` en imágenes centradas
 *   Por eso el `style` de las imágenes centradas no viola la allowlist: no es
 *   un passthrough del usuario, es salida canónica autogenerada.
 *
 * ── Tablas anidadas ──────────────────────────────────────────────────────
 *   TCPDF rompe con tablas dentro de celdas. Cuando una <table> aparece dentro
 *   de una celda, se APLANA: sus celdas se serializan como texto inline
 *   separado por <br> dentro de la celda contenedora (nunca se emiten tags de
 *   tabla anidados). Igual criterio para bloques/listas dentro de celdas: se
 *   convierten a inline + <br> para mantener las celdas TCPDF-safe.
 *
 * ── Seguridad (anti-XSS) ─────────────────────────────────────────────────
 *   `sanitizeHtmlToTcpdf` parsea el HTML no confiable con DOMParser (documento
 *   INERTE: no ejecuta scripts, no dispara handlers, no carga recursos) y luego
 *   serializa por allowlist. `<script>`, `<style>`, `<iframe>`, handlers `on*`,
 *   `href="javascript:"` y `src` no permitidos se descartan.
 */
/**
 * Tags permitidos en la salida (para documentación/validación externa).
 * `span` SOLO se emite para chips de mención/tarea (`data-mention-id` /
 * `data-task-key`); un `<span>` normal se sigue desanidando.
 */
const TCPDF_ALLOWED_TAGS = [
    'p', 'h1', 'h2', 'h3', 'strong', 'em', 'u', 's',
    'ul', 'ol', 'li', 'table', 'tbody', 'tr', 'td', 'a', 'img', 'br', 'span',
];
/**
 * Propiedades CSS de ENTRADA que el serializador inspecciona. `text-align` se
 * conserva como estilo canónico en bloques; las otras tres se traducen a tags
 * semánticos (no se emiten como `style`).
 */
const TCPDF_ALLOWED_STYLE_PROPERTIES = [
    'text-align', 'font-weight', 'font-style', 'text-decoration',
];
const ELEMENT_NODE = 1;
const TEXT_NODE = 3;
/** Orden estable de apertura de marcas (determinista). */
const MARK_ORDER = ['strong', 'em', 'u', 's'];
/** Tags que se descartan por completo (contenido incluido). */
const DROP_TAGS = new Set([
    'script', 'style', 'noscript', 'head', 'title', 'meta', 'link', 'base',
    'object', 'embed', 'iframe', 'applet', 'param', 'svg', 'math', 'canvas',
    'video', 'audio', 'source', 'track', 'input', 'textarea', 'select',
    'option', 'button', 'template',
]);
/** Tags de nivel bloque reconocidos en la ENTRADA (para agrupar/desanidar). */
const BLOCK_TAGS = new Set([
    'div', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li',
    'table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th', 'caption',
    'blockquote', 'section', 'article', 'header', 'footer', 'main', 'aside',
    'nav', 'figure', 'figcaption', 'dl', 'dd', 'dt', 'form', 'fieldset',
    'address', 'pre', 'hr',
]);
// ── Utilidades de texto ──────────────────────────────────────────────────
function escapeText(value) {
    return value
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}
function escapeAttr(value) {
    return value
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}
/** Colapsa espacios en blanco (incl. `&nbsp;`) a un único espacio. */
function collapseWs(value) {
    return value.replace(/ /g, ' ').replace(/[\s]+/g, ' ');
}
// ── Utilidades de estilo / atributos ─────────────────────────────────────
function readAlign(el) {
    const style = el.style;
    const styleAlign = (style?.textAlign ?? '').toLowerCase();
    const attrAlign = (el.getAttribute('align') ?? '').toLowerCase();
    const align = styleAlign || attrAlign;
    if (align === 'center')
        return 'center';
    if (align === 'right' || align === 'end')
        return 'right';
    if (align === 'justify')
        return 'justify';
    return '';
}
/** Devuelve ` style="text-align:…"` para bloques alineados (izquierda → ''). */
function alignAttr(el) {
    const align = readAlign(el);
    return align ? ` style="text-align:${align}"` : '';
}
/** Marcas inline derivadas de los estilos permitidos de un elemento. */
function styleMarks(el) {
    const style = el.style;
    if (!style)
        return [];
    const marks = [];
    const weight = (style.fontWeight ?? '').toLowerCase();
    if (weight === 'bold' || weight === 'bolder' || (/^\d+$/.test(weight) && Number(weight) >= 600)) {
        marks.push('strong');
    }
    const fontStyle = (style.fontStyle ?? '').toLowerCase();
    if (fontStyle === 'italic' || fontStyle === 'oblique') {
        marks.push('em');
    }
    const decoration = `${style.textDecorationLine ?? ''} ${style.textDecoration ?? ''}`.toLowerCase();
    if (decoration.includes('underline'))
        marks.push('u');
    if (decoration.includes('line-through'))
        marks.push('s');
    return marks;
}
/** Marcas inline derivadas del NOMBRE del tag. */
function tagMarks(tag) {
    switch (tag) {
        case 'b':
        case 'strong': return ['strong'];
        case 'i':
        case 'em': return ['em'];
        case 'u':
        case 'ins': return ['u'];
        case 's':
        case 'strike':
        case 'del': return ['s'];
        default: return [];
    }
}
/** `href` seguro: solo esquemas de navegación conocidos (nunca `javascript:`). */
function sanitizeHref(raw) {
    const href = (raw ?? '').trim();
    if (!href)
        return '';
    return /^(https?:|mailto:|tel:|#)/i.test(href) ? href : '';
}
/** `src` de imagen seguro: solo `data:image/*` en base64 o http(s). */
function isSafeImgSrc(src) {
    return (/^data:image\/(png|jpe?g|gif|webp|bmp|svg\+xml);base64,/i.test(src) ||
        /^https?:\/\//i.test(src));
}
/** Ancho/alto numérico (atributo o `style` en px), 0 si no aplica. */
function intSize(el, name) {
    const attr = el.getAttribute(name);
    if (attr && /^\d+$/.test(attr))
        return Number(attr);
    const styleValue = (el.style?.[name] ?? '').toString();
    const match = /^(\d+)(?:px)?$/.exec(styleValue);
    return match ? Number(match[1]) : 0;
}
/** Detecta si una imagen debe centrarse (margin auto / align / bloque padre). */
function isImgCentered(el) {
    const style = el.style;
    if (style) {
        const margin = (style.margin ?? '').toLowerCase();
        const marginLeft = (style.marginLeft ?? '').toLowerCase();
        const marginRight = (style.marginRight ?? '').toLowerCase();
        if (margin.includes('auto') || (marginLeft === 'auto' && marginRight === 'auto')) {
            return true;
        }
    }
    const align = (el.getAttribute('align') ?? '').toLowerCase();
    if (align === 'middle' || align === 'center')
        return true;
    const parent = el.parentElement;
    return !!parent && readAlign(parent) === 'center';
}
function isElement(node) {
    return node.nodeType === ELEMENT_NODE;
}
function isBlockLevel(node) {
    return isElement(node) && BLOCK_TAGS.has(node.localName);
}
function hasBlockChild(el) {
    return Array.from(el.children).some((child) => BLOCK_TAGS.has(child.localName) && !DROP_TAGS.has(child.localName));
}
// ── Serialización inline ─────────────────────────────────────────────────
/**
 * Chip OPT-IN de mención (@) o enlace de tarea (#).
 *
 * Devuelve el span canónico con EXACTAMENTE un atributo data-* (escapado) y el
 * texto escapado; descarta cualquier otro atributo (class, style, on*, …). Un
 * span con el data de chip pero sin texto se descarta (''). Un span SIN data de
 * chip devuelve `null` para que el recorrido lo desanide como span normal.
 */
function serializeMentionChip(el) {
    const mentionId = (el.getAttribute('data-mention-id') ?? '').trim();
    if (mentionId) {
        const text = escapeText(collapseWs(el.textContent ?? '')).trim();
        return text ? `<span data-mention-id="${escapeAttr(mentionId)}">${text}</span>` : '';
    }
    const taskKey = (el.getAttribute('data-task-key') ?? '').trim();
    if (taskKey) {
        const text = escapeText(collapseWs(el.textContent ?? '')).trim();
        return text ? `<span data-task-key="${escapeAttr(taskKey)}">${text}</span>` : '';
    }
    return null;
}
function serializeImg(el) {
    const src = (el.getAttribute('src') ?? '').trim();
    if (!isSafeImgSrc(src))
        return '';
    const parts = [`<img src="${escapeAttr(src)}"`, `alt="${escapeAttr(el.getAttribute('alt') ?? '')}"`];
    const width = intSize(el, 'width');
    if (width)
        parts.push(`width="${width}"`);
    const height = intSize(el, 'height');
    if (height)
        parts.push(`height="${height}"`);
    // Estilo canónico de centrado (autogenerado, no passthrough del usuario).
    if (isImgCentered(el))
        parts.push('style="display:block;margin:0 auto"');
    return `${parts.join(' ')} />`;
}
function serializeInline(node, ctx) {
    if (node.nodeType === TEXT_NODE) {
        return escapeText(collapseWs(node.textContent ?? ''));
    }
    if (!isElement(node))
        return '';
    const el = node;
    const tag = el.localName;
    if (DROP_TAGS.has(tag))
        return '';
    if (tag === 'br')
        return '<br />';
    if (tag === 'img')
        return serializeImg(el);
    // Chip de mención/tarea (opt-in): se preserva; un span normal → null (unwrap).
    if (tag === 'span') {
        const chip = serializeMentionChip(el);
        if (chip !== null)
            return chip;
    }
    if (tag === 'a') {
        const inner = serializeInlineChildren(el, { ...ctx, marks: new Set(ctx.marks) });
        if (!inner)
            return '';
        const href = sanitizeHref(el.getAttribute('href'));
        return href ? `<a href="${escapeAttr(href)}">${inner}</a>` : inner;
    }
    // Marcas semánticas nuevas (por tag o por estilo) que aún no están activas.
    const wanted = new Set([...tagMarks(tag), ...styleMarks(el)]);
    const toOpen = MARK_ORDER.filter((mark) => wanted.has(mark) && !ctx.marks.has(mark));
    const nextMarks = new Set(ctx.marks);
    toOpen.forEach((mark) => nextMarks.add(mark));
    const inner = serializeInlineChildren(el, { ...ctx, marks: nextMarks });
    if (!inner)
        return '';
    const open = toOpen.map((mark) => `<${mark}>`).join('');
    const close = [...toOpen].reverse().map((mark) => `</${mark}>`).join('');
    return open + inner + close;
}
function serializeInlineChildren(parent, ctx) {
    let out = '';
    parent.childNodes.forEach((child) => {
        out += serializeInline(child, ctx);
    });
    return out;
}
// ── Serialización de celdas (modo aplanado) ──────────────────────────────
/** Aplana una tabla a texto: celdas por fila unidas, filas separadas por <br>. */
function flattenTable(tableEl) {
    const rows = Array.from(tableEl.querySelectorAll('tr')).filter((tr) => tr.closest('table') === tableEl);
    const lines = rows.map((tr) => Array.from(tr.children)
        .filter((cell) => cell.localName === 'td' || cell.localName === 'th')
        .map((cell) => serializeCellContent(cell))
        .filter(Boolean)
        .join(' '));
    return lines.filter(Boolean).join('<br />');
}
/** Aplana una lista a texto: cada ítem con viñeta, separados por <br>. */
function flattenList(listEl) {
    return Array.from(listEl.children)
        .filter((child) => child.localName === 'li')
        .map((li) => {
        const text = serializeInlineChildren(li, { inCell: true, marks: new Set() }).trim();
        return text ? `&#8226; ${text}` : '';
    })
        .filter(Boolean)
        .join('<br />');
}
/** Contenido TCPDF-safe de una celda: todo se aplana a inline + <br>. */
function serializeCellContent(cell) {
    const ctx = { inCell: true, marks: new Set() };
    let out = '';
    const addBlockBreak = () => {
        if (out && !out.endsWith('<br />'))
            out += '<br />';
    };
    cell.childNodes.forEach((child) => {
        if (child.nodeType === TEXT_NODE) {
            out += escapeText(collapseWs(child.textContent ?? ''));
            return;
        }
        if (!isElement(child))
            return;
        const tag = child.localName;
        if (DROP_TAGS.has(tag))
            return;
        if (tag === 'br') {
            out += '<br />';
            return;
        }
        if (tag === 'table') {
            const flat = flattenTable(child);
            if (flat) {
                addBlockBreak();
                out += flat;
            }
            return;
        }
        if (tag === 'ul' || tag === 'ol') {
            const flat = flattenList(child);
            if (flat) {
                addBlockBreak();
                out += flat;
            }
            return;
        }
        if (BLOCK_TAGS.has(tag)) {
            const inner = serializeInlineChildren(child, ctx).trim();
            if (inner) {
                addBlockBreak();
                out += inner;
            }
            return;
        }
        out += serializeInline(child, ctx);
    });
    // Sin <br> sobrantes en los extremos.
    return out.replace(/^(?:<br \/>)+/, '').replace(/(?:<br \/>)+$/, '');
}
// ── Serialización de bloques ─────────────────────────────────────────────
function serializeHeading(el, tag) {
    const inner = serializeInlineChildren(el, { inCell: false, marks: new Set() }).trim();
    return inner ? `<${tag}${alignAttr(el)}>${inner}</${tag}>` : '';
}
function serializeParagraph(el) {
    const inner = serializeInlineChildren(el, { inCell: false, marks: new Set() }).trim();
    return inner ? `<p${alignAttr(el)}>${inner}</p>` : '';
}
function serializeListItem(li) {
    let inline = '';
    let nested = '';
    li.childNodes.forEach((child) => {
        if (isElement(child) && (child.localName === 'ul' || child.localName === 'ol')) {
            nested += serializeList(child, child.localName);
        }
        else {
            inline += serializeInline(child, { inCell: false, marks: new Set() });
        }
    });
    const text = inline.trim();
    if (!text && !nested)
        return '';
    return `<li>${text}${nested}</li>`;
}
function serializeList(el, tag) {
    const items = Array.from(el.children)
        .filter((child) => child.localName === 'li')
        .map((li) => serializeListItem(li))
        .filter(Boolean)
        .join('');
    return items ? `<${tag}>${items}</${tag}>` : '';
}
function serializeTable(el) {
    const rows = Array.from(el.querySelectorAll('tr')).filter((tr) => tr.closest('table') === el);
    let body = '';
    for (const tr of rows) {
        const cells = Array.from(tr.children).filter((cell) => cell.localName === 'td' || cell.localName === 'th');
        let rowHtml = '';
        for (const cell of cells) {
            rowHtml += `<td>${serializeCellContent(cell)}</td>`;
        }
        if (rowHtml)
            body += `<tr>${rowHtml}</tr>`;
    }
    return body
        ? `<table border="1" cellpadding="4" cellspacing="0"><tbody>${body}</tbody></table>`
        : '';
}
function serializeBlock(el, ctx) {
    const tag = el.localName;
    if (DROP_TAGS.has(tag))
        return '';
    switch (tag) {
        case 'h1': return serializeHeading(el, 'h1');
        case 'h2': return serializeHeading(el, 'h2');
        case 'h3':
        case 'h4':
        case 'h5':
        case 'h6': return serializeHeading(el, 'h3');
        case 'ul': return serializeList(el, 'ul');
        case 'ol': return serializeList(el, 'ol');
        case 'table': return ctx.inCell ? flattenTable(el) : serializeTable(el);
        case 'hr': return '';
        // Contenedores de tabla huérfanos → se desanidan.
        case 'thead':
        case 'tbody':
        case 'tfoot':
        case 'tr':
        case 'td':
        case 'th':
        case 'caption':
            return serializeBlockList(el, ctx);
        default:
            // p, div, blockquote, section, li huérfano, etc.
            return hasBlockChild(el) ? serializeBlockList(el, ctx) : serializeParagraph(el);
    }
}
/**
 * Recorre los hijos de un contenedor a nivel BLOQUE, agrupando el contenido
 * inline suelto en `<p>` y delegando los bloques a `serializeBlock`. Las
 * imágenes sueltas (hijas directas del bloque) obtienen su propio párrafo,
 * centrado si corresponde.
 */
function serializeBlockList(parent, ctx) {
    let out = '';
    let inline = '';
    const flush = () => {
        const text = inline.trim();
        if (text)
            out += `<p>${text}</p>`;
        inline = '';
    };
    parent.childNodes.forEach((child) => {
        if (child.nodeType === TEXT_NODE) {
            inline += escapeText(collapseWs(child.textContent ?? ''));
            return;
        }
        if (!isElement(child))
            return;
        const tag = child.localName;
        // Imagen suelta → párrafo propio (centrado si aplica).
        if (tag === 'img') {
            const img = serializeImg(child);
            if (img) {
                flush();
                const centered = isImgCentered(child);
                out += `<p${centered ? ' style="text-align:center"' : ''}>${img}</p>`;
            }
            return;
        }
        if (isBlockLevel(child)) {
            flush();
            out += serializeBlock(child, ctx);
        }
        else {
            inline += serializeInline(child, { ...ctx, marks: new Set() });
        }
    });
    flush();
    return out;
}
// ── API pública ──────────────────────────────────────────────────────────
/**
 * Serializa el contenido de un elemento (típicamente el `contenteditable`) a
 * HTML canónico TCPDF-safe. Función PURA: no muta el DOM recibido.
 */
function serializeElementToTcpdfHtml(root) {
    return serializeBlockList(root, { inCell: false, marks: new Set() });
}
/**
 * Sanea un HTML NO CONFIABLE (pegado, o valor externo del formulario) a HTML
 * canónico TCPDF-safe. Parsea con DOMParser (documento inerte: sin ejecución
 * de scripts ni carga de recursos) y aplica la allowlist. Devuelve '' si no hay
 * DOMParser disponible (p. ej. SSR).
 */
function sanitizeHtmlToTcpdf(rawHtml) {
    if (!rawHtml)
        return '';
    if (typeof DOMParser === 'undefined')
        return '';
    const doc = new DOMParser().parseFromString(rawHtml, 'text/html');
    return serializeElementToTcpdfHtml(doc.body);
}

const EMPTY_FORMATS = {
    bold: false, italic: false, underline: false, strike: false,
    bulletList: false, numberedList: false,
    alignLeft: false, alignCenter: false, alignRight: false,
};
/** Tamaño máximo de la rejilla del selector de tablas. */
const TABLE_GRID_MAX = 8;
/** Máximo de resultados listados en el popover de menciones/tareas. */
const MENTION_MAX_RESULTS = 8;
/** Longitud máxima de la consulta tras `@`/`#` antes de descartar el trigger. */
const MENTION_QUERY_MAX = 30;
/** Ancho de referencia del popover (px) para acotar su posición horizontal. */
const POPOVER_WIDTH = 208;
/**
 * `sol-rich-editor` — editor de texto enriquecido PROPIO del design system.
 *
 * - `ControlValueAccessor`: funciona con `ngModel`/reactive forms. El value
 *   NUNCA es el `innerHTML` crudo del área editable: es SIEMPRE el HTML limpio
 *   serializado por `serializeElementToTcpdfHtml` (canónico, apto para TCPDF).
 *   El DOM vivo del `contenteditable` es efímero; el value se deriva de él.
 * - Comandos: enfoque HÍBRIDO. Los comandos de formato inline, listas,
 *   encabezados y alineación usan `document.execCommand` (robusto para el
 *   manejo del cursor/selección entre navegadores, aunque esté deprecado); la
 *   inserción de imágenes, tablas y enlaces usa la API `Selection`/`Range`
 *   propia. La "suciedad" que produce `execCommand` (p. ej. `<font>`, spans con
 *   estilo) es irrelevante: el serializador normaliza toda la salida.
 * - Pegado: SIEMPRE saneado por el mismo serializador (allowlist) antes de
 *   tocar el DOM. Las imágenes del portapapeles se insertan como data URL (o
 *   vía el hook `imageUpload`).
 * - Theming: adopta los tokens `var(--sol-*)` (bordes, foco, tipografía) y
 *   soporta light/dark como todo átomo del sistema.
 */
class SolRichEditorComponent {
    i18n = inject(SOL_I18N);
    destroyRef = inject(DestroyRef);
    // ── Inputs ──────────────────────────────────────────────────────────
    /** Texto guía cuando el editor está vacío. */
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /** Altura mínima del área editable (cualquier unidad CSS). */
    minHeight = input('12rem', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "minHeight" }] : /* istanbul ignore next */ []));
    /** Altura máxima opcional (scroll interno al superarla). */
    maxHeight = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxHeight" }] : /* istanbul ignore next */ []));
    /** Etiqueta accesible del área editable (fallback: clave i18n por defecto). */
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Deshabilita el editor (además del estado del formulario). */
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Tamaño máximo en bytes de una imagen pegada/insertada (default 5 MB). */
    imageMaxBytes = input(5 * 1024 * 1024, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageMaxBytes" }] : /* istanbul ignore next */ []));
    /** Hook opcional para subir la imagen y usar su URL en vez del data URL. */
    imageUpload = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageUpload" }] : /* istanbul ignore next */ []));
    /**
     * Usuarios mencionables con `@` (opt-in). Vacío ⇒ menciones DESACTIVADAS:
     * el editor se comporta exactamente igual que sin esta capacidad.
     */
    mentionableUsers = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mentionableUsers" }] : /* istanbul ignore next */ []));
    /**
     * Tareas enlazables con `#` (opt-in). Vacío ⇒ enlaces DESACTIVADOS: el
     * editor se comporta exactamente igual que sin esta capacidad.
     */
    linkableTasks = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "linkableTasks" }] : /* istanbul ignore next */ []));
    // ── Outputs ─────────────────────────────────────────────────────────
    /** Emite el HTML limpio en cada cambio (además del flujo CVA). */
    valueChange = output();
    /** IDs únicos (orden de documento) de los usuarios mencionados en el contenido. */
    mentionsChange = output();
    /** Keys únicas (orden de documento) de las tareas enlazadas en el contenido. */
    taskLinksChange = output();
    // ── Referencias del template ────────────────────────────────────────
    editable = viewChild.required('editable', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "editable" }] : /* istanbul ignore next */ []));
    fileInput = viewChild.required('fileInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fileInput" }] : /* istanbul ignore next */ []));
    linkInput = viewChild('linkInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "linkInput" }] : /* istanbul ignore next */ []));
    // ── Estado interno ──────────────────────────────────────────────────
    _value = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    _disabledByForm = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_disabledByForm" }] : /* istanbul ignore next */ []));
    active = signal({ ...EMPTY_FORMATS }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    showHeadingMenu = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showHeadingMenu" }] : /* istanbul ignore next */ []));
    showTableMenu = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTableMenu" }] : /* istanbul ignore next */ []));
    showLinkMenu = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showLinkMenu" }] : /* istanbul ignore next */ []));
    tableRows = signal(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableRows" }] : /* istanbul ignore next */ []));
    tableCols = signal(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableCols" }] : /* istanbul ignore next */ []));
    linkUrl = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "linkUrl" }] : /* istanbul ignore next */ []));
    imageError = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageError" }] : /* istanbul ignore next */ []));
    // ── Estado de menciones (@) / tareas (#) — opt-in ───────────────────
    showMentionPopover = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showMentionPopover" }] : /* istanbul ignore next */ []));
    showTaskPopover = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTaskPopover" }] : /* istanbul ignore next */ []));
    activeIndex = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []));
    popoverTop = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "popoverTop" }] : /* istanbul ignore next */ []));
    popoverLeft = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "popoverLeft" }] : /* istanbul ignore next */ []));
    mentionQuery = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mentionQuery" }] : /* istanbul ignore next */ []));
    taskQuery = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "taskQuery" }] : /* istanbul ignore next */ []));
    /** Rango que abarca `@query`/`#query`; se reemplaza por el chip al elegir. */
    triggerRange = null;
    /** Menciones activas solo si hay usuarios; si no, el trigger `@` se ignora. */
    mentionsEnabled = computed(() => this.mentionableUsers().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mentionsEnabled" }] : /* istanbul ignore next */ []));
    /** Enlaces activos solo si hay tareas; si no, el trigger `#` se ignora. */
    tasksEnabled = computed(() => this.linkableTasks().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tasksEnabled" }] : /* istanbul ignore next */ []));
    filteredUsers = computed(() => {
        const query = this.mentionQuery().toLowerCase();
        return this.mentionableUsers()
            .filter((user) => !query || user.name.toLowerCase().includes(query))
            .slice(0, MENTION_MAX_RESULTS);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredUsers" }] : /* istanbul ignore next */ []));
    filteredTasks = computed(() => {
        const query = this.taskQuery().toLowerCase();
        return this.linkableTasks()
            .filter((task) => !query ||
            task.key.toLowerCase().includes(query) ||
            task.title.toLowerCase().includes(query))
            .slice(0, MENTION_MAX_RESULTS);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredTasks" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => this.disabled() || this._disabledByForm(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    isEmpty = computed(() => this._value().trim().length === 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isEmpty" }] : /* istanbul ignore next */ []));
    editorAriaLabel = computed(() => this.ariaLabel() || this.labels().editorAria, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "editorAriaLabel" }] : /* istanbul ignore next */ []));
    /** Rango fijo para la rejilla del selector de tablas. */
    gridRange = computed(() => Array.from({ length: TABLE_GRID_MAX }, (_, i) => i + 1), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "gridRange" }] : /* istanbul ignore next */ []));
    /** Etiquetas i18n reactivas al idioma (patrón sol-stepper). */
    labels = computed(() => {
        this.i18n.activeLang();
        const t = (key) => this.i18n.translate(`shared.richEditor.${key}`);
        return {
            toolbar: t('toolbar'),
            bold: t('bold'), italic: t('italic'), underline: t('underline'), strike: t('strike'),
            heading: t('heading'), paragraph: t('paragraph'),
            heading1: t('heading1'), heading2: t('heading2'), heading3: t('heading3'),
            bulletList: t('bulletList'), numberedList: t('numberedList'),
            alignLeft: t('alignLeft'), alignCenter: t('alignCenter'), alignRight: t('alignRight'),
            insertImage: t('insertImage'), insertTable: t('insertTable'),
            insertLink: t('insertLink'), removeLink: t('removeLink'), removeFormat: t('removeFormat'),
            tablePicker: t('tablePicker'),
            linkPlaceholder: t('linkPlaceholder'), linkConfirm: t('linkConfirm'),
            editorAria: t('editorAria'), imageTooLarge: t('imageTooLarge'),
            mentionList: t('mentionList'), taskList: t('taskList'),
        };
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []));
    /** Selección guardada al abrir menús que roban el foco (enlace/imagen). */
    savedRange = null;
    /** Valor pendiente de aplicar al DOM (antes de que la vista esté lista). */
    pendingValue = '';
    viewReady = false;
    activeUpdateHandle = null;
    errorHandle = null;
    // ── CVA callbacks ───────────────────────────────────────────────────
    onChange = () => { };
    onTouched = () => { };
    // ── Ciclo de vida ───────────────────────────────────────────────────
    ngAfterViewInit() {
        this.viewReady = true;
        this.applyPending();
        // Actualiza el resaltado de la toolbar cuando cambia la selección.
        const onSelectionChange = () => {
            if (this.selectionInsideEditor())
                this.updateActiveFormats();
        };
        document.addEventListener('selectionchange', onSelectionChange);
        // Cierra los menús y popovers al hacer clic fuera del componente.
        const onDocClick = (event) => {
            const host = this.editable().nativeElement.closest('.sol-rich-editor');
            if (host && !host.contains(event.target)) {
                this.closeMenus();
                this.closePopovers();
            }
        };
        document.addEventListener('click', onDocClick);
        this.destroyRef.onDestroy(() => {
            document.removeEventListener('selectionchange', onSelectionChange);
            document.removeEventListener('click', onDocClick);
            if (this.activeUpdateHandle)
                clearTimeout(this.activeUpdateHandle);
            if (this.errorHandle)
                clearTimeout(this.errorHandle);
        });
    }
    // ── ControlValueAccessor ────────────────────────────────────────────
    writeValue(value) {
        this.pendingValue = value ?? '';
        this.applyPending();
    }
    registerOnChange(fn) { this.onChange = fn; }
    registerOnTouched(fn) { this.onTouched = fn; }
    setDisabledState(isDisabled) { this._disabledByForm.set(isDisabled); }
    /** Devuelve el HTML limpio (canónico TCPDF-safe) actual. */
    getHtml() { return this._value(); }
    // ── Manejo de eventos del área editable ─────────────────────────────
    onInput() {
        if (this.mentionsEnabled() || this.tasksEnabled())
            this.detectAutocomplete();
        this.emitChange();
        this.scheduleActiveUpdate();
    }
    onBlur() { this.onTouched(); }
    /** Navegación del popover de menciones/tareas (solo cuando está abierto). */
    onKeyDown(event) {
        if (!this.showMentionPopover() && !this.showTaskPopover())
            return;
        const length = this.showMentionPopover()
            ? this.filteredUsers().length
            : this.filteredTasks().length;
        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                this.activeIndex.update((i) => Math.min(i + 1, length - 1));
                break;
            case 'ArrowUp':
                event.preventDefault();
                this.activeIndex.update((i) => Math.max(i - 1, 0));
                break;
            case 'Enter':
                event.preventDefault();
                if (this.showMentionPopover())
                    this.selectMention(null, this.activeIndex());
                else
                    this.selectTask(null, this.activeIndex());
                break;
            case 'Escape':
                event.preventDefault();
                this.closePopovers();
                break;
        }
    }
    /** Inicial en mayúscula para el avatar del popover de menciones. */
    initial(name) {
        return (name.trim().charAt(0) || '?').toUpperCase();
    }
    /** Recalcula el estado de la toolbar de forma diferida (tras el DOM). */
    scheduleActiveUpdate() {
        if (this.activeUpdateHandle)
            clearTimeout(this.activeUpdateHandle);
        this.activeUpdateHandle = setTimeout(() => this.updateActiveFormats(), 0);
    }
    // ── Comandos de formato (execCommand + normalización por serializador) ─
    cmd(command) {
        this.exec(command);
    }
    applyHeading(tag) {
        this.exec('formatBlock', `<${tag}>`);
        this.closeMenus();
    }
    align(direction) {
        const command = direction === 'left' ? 'justifyLeft'
            : direction === 'center' ? 'justifyCenter' : 'justifyRight';
        this.focusEditable();
        this.safeExec(command);
        // Si el objetivo es una imagen, refleja el alineado en su propio estilo
        // (además del bloque) para que el serializador lo detecte con fiabilidad.
        const img = this.selectedImage();
        if (img) {
            if (direction === 'center') {
                img.style.display = 'block';
                img.style.marginLeft = 'auto';
                img.style.marginRight = 'auto';
            }
            else {
                img.style.display = '';
                img.style.margin = '';
            }
        }
        this.emitChange();
        this.updateActiveFormats();
    }
    removeFormat() {
        this.focusEditable();
        this.safeExec('removeFormat');
        this.safeExec('formatBlock', '<p>');
        this.emitChange();
        this.updateActiveFormats();
    }
    // ── Menús ───────────────────────────────────────────────────────────
    toggleMenu(which) {
        const isOpen = which === 'heading' ? this.showHeadingMenu()
            : which === 'table' ? this.showTableMenu() : this.showLinkMenu();
        this.closeMenus();
        if (isOpen)
            return;
        if (which === 'heading')
            this.showHeadingMenu.set(true);
        if (which === 'table') {
            this.tableRows.set(1);
            this.tableCols.set(1);
            this.showTableMenu.set(true);
        }
        if (which === 'link') {
            this.linkUrl.set('');
            this.showLinkMenu.set(true);
            // Enfoca el input tras el render.
            setTimeout(() => this.linkInput()?.nativeElement.focus(), 0);
        }
    }
    closeMenus() {
        this.showHeadingMenu.set(false);
        this.showTableMenu.set(false);
        this.showLinkMenu.set(false);
    }
    // ── Tabla ───────────────────────────────────────────────────────────
    hoverTable(rows, cols) {
        this.tableRows.set(rows);
        this.tableCols.set(cols);
    }
    insertTable(rows, cols) {
        const table = document.createElement('table');
        table.setAttribute('border', '1');
        const tbody = document.createElement('tbody');
        for (let r = 0; r < rows; r++) {
            const tr = document.createElement('tr');
            for (let c = 0; c < cols; c++) {
                const td = document.createElement('td');
                td.appendChild(document.createElement('br'));
                tr.appendChild(td);
            }
            tbody.appendChild(tr);
        }
        table.appendChild(tbody);
        this.insertNodeAtCaret(table);
        this.closeMenus();
    }
    // ── Enlace ──────────────────────────────────────────────────────────
    confirmLink() {
        const url = this.linkUrl().trim();
        if (!url) {
            this.closeMenus();
            return;
        }
        const href = /^(https?:|mailto:|tel:|#)/i.test(url) ? url : `https://${url}`;
        this.restoreSelection();
        const selection = document.getSelection();
        if (selection && !selection.isCollapsed) {
            this.focusEditable();
            this.safeExec('createLink', href);
        }
        else {
            const anchor = document.createElement('a');
            anchor.href = href;
            anchor.textContent = url;
            this.insertNodeAtCaret(anchor);
        }
        this.emitChange();
        this.closeMenus();
    }
    removeLink() {
        this.focusEditable();
        this.restoreSelection();
        this.safeExec('unlink');
        this.emitChange();
        this.closeMenus();
    }
    // ── Imágenes ────────────────────────────────────────────────────────
    pickImage() {
        this.saveSelection();
        this.fileInput().nativeElement.click();
    }
    onFileSelected(event) {
        const input = event.target;
        const file = input.files?.[0];
        if (file)
            this.handleImageFile(file);
        input.value = ''; // permite volver a elegir el mismo archivo
    }
    handleImageFile(file) {
        if (!file.type.startsWith('image/'))
            return;
        if (file.size > this.imageMaxBytes()) {
            this.showImageError();
            return;
        }
        const uploader = this.imageUpload();
        if (uploader) {
            uploader(file)
                .then((url) => this.insertImage(url))
                .catch(() => this.showImageError());
            return;
        }
        const reader = new FileReader();
        reader.onload = () => this.insertImage(String(reader.result ?? ''));
        reader.readAsDataURL(file);
    }
    insertImage(url) {
        if (!url)
            return;
        const img = document.createElement('img');
        img.src = url;
        img.alt = '';
        this.insertNodeAtCaret(img);
    }
    showImageError() {
        this.imageError.set(this.labels().imageTooLarge);
        if (this.errorHandle)
            clearTimeout(this.errorHandle);
        this.errorHandle = setTimeout(() => this.imageError.set(''), 4000);
    }
    // ── Menciones (@) / tareas (#) — opt-in ─────────────────────────────
    /**
     * Analiza el texto anterior al cursor: si hay un trigger `@`/`#` activo (al
     * inicio o precedido por espacio) y su lista está habilitada, abre el popover
     * respectivo; si no, lo cierra.
     */
    detectAutocomplete() {
        const found = this.getQueryBeforeCursor();
        if (!found) {
            this.closePopovers();
            return;
        }
        const { trigger, query, range } = found;
        if (trigger === '@' && !this.mentionsEnabled()) {
            this.closePopovers();
            return;
        }
        if (trigger === '#' && !this.tasksEnabled()) {
            this.closePopovers();
            return;
        }
        this.triggerRange = range;
        this.activeIndex.set(0);
        if (trigger === '@') {
            this.mentionQuery.set(query);
            this.showMentionPopover.set(true);
            this.showTaskPopover.set(false);
        }
        else {
            this.taskQuery.set(query);
            this.showTaskPopover.set(true);
            this.showMentionPopover.set(false);
        }
        this.positionPopover();
    }
    /** Trigger + consulta inmediatamente antes del cursor colapsado (o null). */
    getQueryBeforeCursor() {
        const selection = document.getSelection();
        if (!selection || selection.rangeCount === 0)
            return null;
        const range = selection.getRangeAt(0);
        if (!range.collapsed)
            return null;
        const container = range.startContainer;
        if (container.nodeType !== Node.TEXT_NODE)
            return null;
        if (!this.editable().nativeElement.contains(container))
            return null;
        const text = container.textContent ?? '';
        const offset = range.startOffset;
        const before = text.slice(0, offset);
        let triggerIdx = -1;
        let trigger = null;
        for (let i = before.length - 1; i >= 0; i--) {
            const ch = before[i];
            if (ch === '@' || ch === '#') {
                if (i === 0 || /\s/.test(before[i - 1])) {
                    triggerIdx = i;
                    trigger = ch;
                }
                break;
            }
            if (/\s/.test(ch))
                break; // espacio antes del trigger ⇒ no hay match
        }
        if (triggerIdx === -1 || !trigger)
            return null;
        const query = before.slice(triggerIdx + 1);
        if (query.length > MENTION_QUERY_MAX)
            return null;
        const triggerRange = document.createRange();
        triggerRange.setStart(container, triggerIdx);
        triggerRange.setEnd(container, offset);
        return { trigger, query, range: triggerRange };
    }
    /** Ubica el popover bajo el caret (cálculo manual; sin librerías de posición). */
    positionPopover() {
        const selection = document.getSelection();
        if (!selection || selection.rangeCount === 0)
            return;
        const host = this.editable().nativeElement.closest('.sol-rich-editor');
        if (!host || typeof host.getBoundingClientRect !== 'function')
            return;
        const caret = selection.getRangeAt(0).cloneRange();
        caret.collapse(true);
        // `Range.getBoundingClientRect` no existe en jsdom (tests): sin medidas de
        // viewport se conserva la posición por defecto (0,0) sin romper el flujo.
        if (typeof caret.getBoundingClientRect !== 'function')
            return;
        const caretRect = caret.getBoundingClientRect();
        const hostRect = host.getBoundingClientRect();
        const count = this.showMentionPopover()
            ? this.filteredUsers().length
            : this.filteredTasks().length;
        const estHeight = Math.min(count, 6) * 36 + 8;
        const below = caretRect.bottom - hostRect.top + 4;
        const roomBelow = hostRect.bottom - caretRect.bottom;
        // Si no cabe abajo pero sí arriba, se abre hacia arriba (flip).
        const top = roomBelow < estHeight && caretRect.top - hostRect.top > estHeight
            ? caretRect.top - hostRect.top - estHeight - 4
            : below;
        const left = Math.max(0, Math.min(caretRect.left - hostRect.left, hostRect.width - POPOVER_WIDTH));
        this.popoverTop.set(Math.max(0, top));
        this.popoverLeft.set(left);
    }
    closePopovers() {
        this.showMentionPopover.set(false);
        this.showTaskPopover.set(false);
        this.triggerRange = null;
    }
    selectMention(event, index) {
        event?.preventDefault();
        const user = this.filteredUsers()[index];
        if (!user)
            return;
        this.insertChip(`@${user.name}`, 'data-mention-id', user.id);
        this.closePopovers();
        this.emitChange();
    }
    selectTask(event, index) {
        event?.preventDefault();
        const task = this.filteredTasks()[index];
        if (!task)
            return;
        this.insertChip(task.key, 'data-task-key', task.key);
        this.closePopovers();
        this.emitChange();
    }
    /**
     * Reemplaza el rango `@query`/`#query` por un chip `<span>` no editable con
     * el atributo data-* dado, y deja el cursor tras él con un espacio.
     */
    insertChip(label, attr, value) {
        if (!this.triggerRange)
            return;
        const selection = document.getSelection();
        if (!selection)
            return;
        const chip = document.createElement('span');
        chip.setAttribute('contenteditable', 'false');
        chip.textContent = label;
        chip.setAttribute(attr, value);
        this.triggerRange.deleteContents();
        this.triggerRange.insertNode(chip);
        const after = document.createRange();
        after.setStartAfter(chip);
        after.collapse(true);
        selection.removeAllRanges();
        selection.addRange(after);
        // Espacio para poder seguir escribiendo fuera del chip.
        this.safeExec('insertText', ' ');
        this.triggerRange = null;
    }
    /** Marca los chips como no editables tras (re)pintar el contenido. */
    hardenChips() {
        this.editable()
            .nativeElement.querySelectorAll('[data-mention-id],[data-task-key]')
            .forEach((el) => { el.setAttribute('contenteditable', 'false'); });
    }
    /** IDs/keys únicos (orden de documento) de los chips presentes en el DOM. */
    collectChipValues(attr) {
        const seen = new Set();
        this.editable()
            .nativeElement.querySelectorAll(`[${attr}]`)
            .forEach((el) => {
            const value = el.getAttribute(attr)?.trim();
            if (value)
                seen.add(value);
        });
        return [...seen];
    }
    // ── Pegado (saneado SIEMPRE por el serializador) ────────────────────
    onPaste(event) {
        const data = event.clipboardData;
        if (!data)
            return;
        // 1) Imágenes en el portapapeles.
        const imageFiles = Array.from(data.items ?? [])
            .filter((item) => item.kind === 'file' && item.type.startsWith('image/'))
            .map((item) => item.getAsFile())
            .filter((file) => file != null);
        const directFiles = Array.from(data.files ?? []).filter((f) => f.type.startsWith('image/'));
        const images = imageFiles.length ? imageFiles : directFiles;
        if (images.length) {
            event.preventDefault();
            images.forEach((file) => this.handleImageFile(file));
            return;
        }
        // 2) HTML enriquecido → saneado por allowlist antes de tocar el DOM.
        const html = data.getData('text/html');
        if (html) {
            event.preventDefault();
            const clean = sanitizeHtmlToTcpdf(html);
            if (clean)
                this.insertHtmlAtCaret(clean);
            return;
        }
        // 3) Texto plano.
        const text = data.getData('text/plain');
        if (text) {
            event.preventDefault();
            this.insertTextAtCaret(text);
        }
    }
    // ── Utilidades de selección / inserción ─────────────────────────────
    preventSteal(event) {
        event.preventDefault();
    }
    onTriggerMousedown(event) {
        event.preventDefault();
        this.saveSelection();
    }
    focusEditable() {
        this.editable().nativeElement.focus();
    }
    selectionInsideEditor() {
        const selection = document.getSelection();
        if (!selection || selection.rangeCount === 0)
            return false;
        const node = selection.anchorNode;
        return !!node && this.editable().nativeElement.contains(node);
    }
    saveSelection() {
        const selection = document.getSelection();
        if (selection && selection.rangeCount > 0 && this.selectionInsideEditor()) {
            this.savedRange = selection.getRangeAt(0).cloneRange();
        }
    }
    restoreSelection() {
        if (!this.savedRange)
            return;
        this.focusEditable();
        const selection = document.getSelection();
        if (selection) {
            selection.removeAllRanges();
            selection.addRange(this.savedRange);
        }
    }
    insertNodeAtCaret(node) {
        this.focusEditable();
        this.restoreSelection();
        const selection = document.getSelection();
        const editable = this.editable().nativeElement;
        if (selection && selection.rangeCount > 0 && this.selectionInsideEditor()) {
            const range = selection.getRangeAt(0);
            // Un DocumentFragment se vacía al insertarse (sus hijos pasan al DOM); hay
            // que capturar el último hijo ANTES para poder recolocar el cursor tras él.
            const isFragment = node.nodeType === 11; // DOCUMENT_FRAGMENT_NODE
            const marker = isFragment ? node.lastChild : node;
            range.deleteContents();
            range.insertNode(node);
            if (marker) {
                range.setStartAfter(marker);
                range.collapse(true);
                selection.removeAllRanges();
                selection.addRange(range);
            }
        }
        else {
            editable.appendChild(node);
        }
        this.savedRange = null;
        this.emitChange();
    }
    insertHtmlAtCaret(cleanHtml) {
        const template = document.createElement('template');
        template.innerHTML = cleanHtml; // ya saneado: seguro
        this.insertNodeAtCaret(template.content.cloneNode(true));
    }
    insertTextAtCaret(text) {
        this.insertNodeAtCaret(document.createTextNode(text));
    }
    exec(command, value) {
        this.focusEditable();
        this.safeExec(command, value);
        this.emitChange();
        this.updateActiveFormats();
    }
    safeExec(command, value) {
        try {
            document.execCommand(command, false, value);
        }
        catch {
            // execCommand está deprecado y puede no existir (SSR/tests): la salida
            // se garantiza limpia igualmente vía el serializador.
        }
    }
    emitChange() {
        const clean = serializeElementToTcpdfHtml(this.editable().nativeElement);
        this._value.set(clean);
        this.onChange(clean);
        this.valueChange.emit(clean);
        this.mentionsChange.emit(this.collectChipValues('data-mention-id'));
        this.taskLinksChange.emit(this.collectChipValues('data-task-key'));
    }
    applyPending() {
        if (!this.viewReady)
            return;
        const clean = sanitizeHtmlToTcpdf(this.pendingValue);
        const editable = this.editable().nativeElement;
        if (editable.innerHTML !== clean)
            editable.innerHTML = clean;
        this.hardenChips();
        this._value.set(clean);
    }
    updateActiveFormats() {
        if (!this.selectionInsideEditor())
            return;
        const state = (command) => {
            try {
                return document.queryCommandState(command);
            }
            catch {
                return false;
            }
        };
        this.active.set({
            bold: state('bold'),
            italic: state('italic'),
            underline: state('underline'),
            strike: state('strikeThrough'),
            bulletList: state('insertUnorderedList'),
            numberedList: state('insertOrderedList'),
            alignLeft: state('justifyLeft'),
            alignCenter: state('justifyCenter'),
            alignRight: state('justifyRight'),
        });
    }
    selectedImage() {
        const selection = document.getSelection();
        if (!selection || selection.rangeCount === 0)
            return null;
        const range = selection.getRangeAt(0);
        // Imagen exactamente seleccionada.
        const single = range.startContainer.childNodes[range.startOffset];
        if (single instanceof HTMLImageElement)
            return single;
        // Imagen contenedora del ancla.
        let node = selection.anchorNode;
        while (node && node !== this.editable().nativeElement) {
            if (node instanceof HTMLImageElement)
                return node;
            node = node.parentNode;
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolRichEditorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolRichEditorComponent, isStandalone: true, selector: "sol-rich-editor", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, minHeight: { classPropertyName: "minHeight", publicName: "minHeight", isSignal: true, isRequired: false, transformFunction: null }, maxHeight: { classPropertyName: "maxHeight", publicName: "maxHeight", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, imageMaxBytes: { classPropertyName: "imageMaxBytes", publicName: "imageMaxBytes", isSignal: true, isRequired: false, transformFunction: null }, imageUpload: { classPropertyName: "imageUpload", publicName: "imageUpload", isSignal: true, isRequired: false, transformFunction: null }, mentionableUsers: { classPropertyName: "mentionableUsers", publicName: "mentionableUsers", isSignal: true, isRequired: false, transformFunction: null }, linkableTasks: { classPropertyName: "linkableTasks", publicName: "linkableTasks", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange", mentionsChange: "mentionsChange", taskLinksChange: "taskLinksChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SolRichEditorComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "editable", first: true, predicate: ["editable"], descendants: true, isSignal: true }, { propertyName: "fileInput", first: true, predicate: ["fileInput"], descendants: true, isSignal: true }, { propertyName: "linkInput", first: true, predicate: ["linkInput"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="sol-rich-editor" [class.sol-rich-editor--disabled]="isDisabled()">
      <!-- ── Toolbar ─────────────────────────────────────────────────── -->
      <div class="sol-rich-editor__toolbar" role="toolbar" [attr.aria-label]="labels().toolbar">
        <!-- Formato inline -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().bold" [disabled]="isDisabled()"
            [attr.aria-label]="labels().bold" [attr.title]="labels().bold" [attr.aria-pressed]="active().bold"
            (mousedown)="preventSteal($event)" (click)="cmd('bold')"
          ><sol-icon name="bold" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().italic" [disabled]="isDisabled()"
            [attr.aria-label]="labels().italic" [attr.title]="labels().italic" [attr.aria-pressed]="active().italic"
            (mousedown)="preventSteal($event)" (click)="cmd('italic')"
          ><sol-icon name="italic" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().underline" [disabled]="isDisabled()"
            [attr.aria-label]="labels().underline" [attr.title]="labels().underline" [attr.aria-pressed]="active().underline"
            (mousedown)="preventSteal($event)" (click)="cmd('underline')"
          ><sol-icon name="underline" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().strike" [disabled]="isDisabled()"
            [attr.aria-label]="labels().strike" [attr.title]="labels().strike" [attr.aria-pressed]="active().strike"
            (mousedown)="preventSteal($event)" (click)="cmd('strikeThrough')"
          ><sol-icon name="strikethrough" size="sm" /></button>
        </div>

        <span class="sol-rich-editor__sep" aria-hidden="true"></span>

        <!-- Encabezados -->
        <div class="sol-rich-editor__group sol-rich-editor__group--menu">
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="showHeadingMenu()" [disabled]="isDisabled()"
            [attr.aria-label]="labels().heading" [attr.title]="labels().heading"
            [attr.aria-expanded]="showHeadingMenu()"
            (mousedown)="onTriggerMousedown($event)" (click)="toggleMenu('heading')"
          ><sol-icon name="heading" size="sm" /></button>
          @if (showHeadingMenu()) {
            <div class="sol-rich-editor__menu" role="menu">
              <button type="button" role="menuitem" class="sol-rich-editor__menu-item"
                (mousedown)="preventSteal($event)" (click)="applyHeading('p')">{{ labels().paragraph }}</button>
              <button type="button" role="menuitem" class="sol-rich-editor__menu-item sol-rich-editor__menu-item--h1"
                (mousedown)="preventSteal($event)" (click)="applyHeading('h1')">{{ labels().heading1 }}</button>
              <button type="button" role="menuitem" class="sol-rich-editor__menu-item sol-rich-editor__menu-item--h2"
                (mousedown)="preventSteal($event)" (click)="applyHeading('h2')">{{ labels().heading2 }}</button>
              <button type="button" role="menuitem" class="sol-rich-editor__menu-item sol-rich-editor__menu-item--h3"
                (mousedown)="preventSteal($event)" (click)="applyHeading('h3')">{{ labels().heading3 }}</button>
            </div>
          }
        </div>

        <!-- Listas -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().bulletList" [disabled]="isDisabled()"
            [attr.aria-label]="labels().bulletList" [attr.title]="labels().bulletList" [attr.aria-pressed]="active().bulletList"
            (mousedown)="preventSteal($event)" (click)="cmd('insertUnorderedList')"
          ><sol-icon name="list-bullet" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().numberedList" [disabled]="isDisabled()"
            [attr.aria-label]="labels().numberedList" [attr.title]="labels().numberedList" [attr.aria-pressed]="active().numberedList"
            (mousedown)="preventSteal($event)" (click)="cmd('insertOrderedList')"
          ><sol-icon name="list-numbered" size="sm" /></button>
        </div>

        <span class="sol-rich-editor__sep" aria-hidden="true"></span>

        <!-- Alineación -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().alignLeft" [disabled]="isDisabled()"
            [attr.aria-label]="labels().alignLeft" [attr.title]="labels().alignLeft" [attr.aria-pressed]="active().alignLeft"
            (mousedown)="preventSteal($event)" (click)="align('left')"
          ><sol-icon name="align-left" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().alignCenter" [disabled]="isDisabled()"
            [attr.aria-label]="labels().alignCenter" [attr.title]="labels().alignCenter" [attr.aria-pressed]="active().alignCenter"
            (mousedown)="preventSteal($event)" (click)="align('center')"
          ><sol-icon name="align-center" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().alignRight" [disabled]="isDisabled()"
            [attr.aria-label]="labels().alignRight" [attr.title]="labels().alignRight" [attr.aria-pressed]="active().alignRight"
            (mousedown)="preventSteal($event)" (click)="align('right')"
          ><sol-icon name="align-right" size="sm" /></button>
        </div>

        <span class="sol-rich-editor__sep" aria-hidden="true"></span>

        <!-- Inserción: imagen, tabla, enlace -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn" [disabled]="isDisabled()"
            [attr.aria-label]="labels().insertImage" [attr.title]="labels().insertImage"
            (mousedown)="onTriggerMousedown($event)" (click)="pickImage()"
          ><sol-icon name="image" size="sm" /></button>

          <!-- Tabla (selector de rejilla) -->
          <div class="sol-rich-editor__group--menu">
            <button
              type="button" class="sol-rich-editor__btn"
              [class.is-active]="showTableMenu()" [disabled]="isDisabled()"
              [attr.aria-label]="labels().insertTable" [attr.title]="labels().insertTable"
              [attr.aria-expanded]="showTableMenu()"
              (mousedown)="onTriggerMousedown($event)" (click)="toggleMenu('table')"
            ><sol-icon name="table" size="sm" /></button>
            @if (showTableMenu()) {
              <div class="sol-rich-editor__menu sol-rich-editor__menu--table" role="menu"
                   [attr.aria-label]="labels().tablePicker">
                <div class="sol-rich-editor__grid">
                  @for (row of gridRange(); track row) {
                    <div class="sol-rich-editor__grid-row">
                      @for (col of gridRange(); track col) {
                        <button
                          type="button" class="sol-rich-editor__grid-cell"
                          [class.is-on]="row <= tableRows() && col <= tableCols()"
                          (mousedown)="preventSteal($event)"
                          (mouseenter)="hoverTable(row, col)"
                          (click)="insertTable(row, col)"
                        ></button>
                      }
                    </div>
                  }
                </div>
                <div class="sol-rich-editor__grid-label">{{ tableRows() }} × {{ tableCols() }}</div>
              </div>
            }
          </div>

          <!-- Enlace -->
          <div class="sol-rich-editor__group--menu">
            <button
              type="button" class="sol-rich-editor__btn"
              [class.is-active]="showLinkMenu()" [disabled]="isDisabled()"
              [attr.aria-label]="labels().insertLink" [attr.title]="labels().insertLink"
              [attr.aria-expanded]="showLinkMenu()"
              (mousedown)="onTriggerMousedown($event)" (click)="toggleMenu('link')"
            ><sol-icon name="link" size="sm" /></button>
            @if (showLinkMenu()) {
              <div class="sol-rich-editor__menu sol-rich-editor__menu--link" role="menu">
                <input
                  #linkInput type="url" class="sol-rich-editor__link-input"
                  [placeholder]="labels().linkPlaceholder" [attr.aria-label]="labels().linkPlaceholder"
                  [value]="linkUrl()" (input)="linkUrl.set($any($event.target).value)"
                  (keydown.enter)="confirmLink()" (keydown.escape)="closeMenus()"
                />
                <div class="sol-rich-editor__link-actions">
                  <button type="button" class="sol-rich-editor__link-btn sol-rich-editor__link-btn--primary"
                    (mousedown)="preventSteal($event)" (click)="confirmLink()">{{ labels().linkConfirm }}</button>
                  <button type="button" class="sol-rich-editor__link-btn"
                    (mousedown)="preventSteal($event)" (click)="removeLink()">{{ labels().removeLink }}</button>
                </div>
              </div>
            }
          </div>
        </div>

        <span class="sol-rich-editor__sep" aria-hidden="true"></span>

        <!-- Quitar formato -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn" [disabled]="isDisabled()"
            [attr.aria-label]="labels().removeFormat" [attr.title]="labels().removeFormat"
            (mousedown)="preventSteal($event)" (click)="removeFormat()"
          ><sol-icon name="remove-format" size="sm" /></button>
        </div>
      </div>

      <!-- ── Área editable ───────────────────────────────────────────── -->
      <div
        #editable
        class="sol-rich-editor__content"
        [class.is-empty]="isEmpty()"
        [attr.contenteditable]="isDisabled() ? 'false' : 'true'"
        [attr.data-placeholder]="placeholder()"
        [attr.aria-label]="editorAriaLabel()"
        [attr.aria-multiline]="'true'"
        role="textbox"
        [style.min-height]="minHeight()"
        [style.max-height]="maxHeight() || null"
        (input)="onInput()"
        (blur)="onBlur()"
        (keydown)="onKeyDown($event)"
        (keyup)="scheduleActiveUpdate()"
        (mouseup)="scheduleActiveUpdate()"
        (paste)="onPaste($event)"
      ></div>

      <!-- ── Popover de menciones (@) — opt-in ──────────────────────────── -->
      @if (showMentionPopover() && filteredUsers().length > 0) {
        <div
          class="sol-rich-editor__popover" role="listbox"
          [attr.aria-label]="labels().mentionList"
          [style.top.px]="popoverTop()" [style.left.px]="popoverLeft()"
        >
          @for (user of filteredUsers(); track user.id; let i = $index) {
            <button
              type="button" role="option" class="sol-rich-editor__popover-item"
              [class.is-active]="i === activeIndex()" [attr.aria-selected]="i === activeIndex()"
              (mousedown)="selectMention($event, i)" (mouseenter)="activeIndex.set(i)"
            >
              <span class="sol-rich-editor__avatar" aria-hidden="true">{{ initial(user.name) }}</span>
              <span class="sol-rich-editor__popover-label">{{ user.name }}</span>
            </button>
          }
        </div>
      }

      <!-- ── Popover de tareas (#) — opt-in ─────────────────────────────── -->
      @if (showTaskPopover() && filteredTasks().length > 0) {
        <div
          class="sol-rich-editor__popover sol-rich-editor__popover--task" role="listbox"
          [attr.aria-label]="labels().taskList"
          [style.top.px]="popoverTop()" [style.left.px]="popoverLeft()"
        >
          @for (task of filteredTasks(); track task.key; let i = $index) {
            <button
              type="button" role="option" class="sol-rich-editor__popover-item"
              [class.is-active]="i === activeIndex()" [attr.aria-selected]="i === activeIndex()"
              (mousedown)="selectTask($event, i)" (mouseenter)="activeIndex.set(i)"
            >
              <span class="sol-rich-editor__task-key" aria-hidden="true">{{ task.key }}</span>
              <span class="sol-rich-editor__popover-label sol-rich-editor__popover-label--truncate">{{ task.title }}</span>
            </button>
          }
        </div>
      }

      @if (imageError()) {
        <p class="sol-rich-editor__error" role="alert">{{ imageError() }}</p>
      }

      <!-- Selector de archivo oculto para insertar imágenes locales -->
      <input
        #fileInput type="file" accept="image/*" class="sol-rich-editor__file"
        (change)="onFileSelected($event)" tabindex="-1" aria-hidden="true"
      />
    </div>
  `, isInline: true, styles: [":host{display:block;--sre-bg: var(--sol-input-bg, var(--sol-bg-surface, #ffffff));--sre-text: var(--sol-color-text-primary, #1e293b);--sre-muted: var(--sol-color-text-muted, #94a3b8);--sre-border: var(--sol-border-color-default, #cbd5e1);--sre-border-focus: var(--sol-color-primary, #6366f1);--sre-radius: var(--sol-input-radius, var(--sol-border-radius-md, .5rem));--sre-toolbar-bg: var(--sol-bg-sunken, var(--sol-bg-page, #f8fafc));--sre-btn-hover: color-mix(in srgb, var(--sol-color-primary, #6366f1) 12%, transparent);--sre-btn-active: color-mix(in srgb, var(--sol-color-primary, #6366f1) 18%, transparent);--sre-focus-ring: var(--sol-input-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 30%, transparent));--sre-font: var(--sol-font-family, system-ui, sans-serif);--sre-font-size: var(--sol-font-size-base, .9375rem);--sre-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease)}.sol-rich-editor{position:relative;display:flex;flex-direction:column;border:var(--sol-input-border, var(--sol-border-width-default, 1px) solid var(--sre-border));border-radius:var(--sre-radius);background:var(--sre-bg);box-shadow:var(--sol-input-shadow, none);overflow:hidden;transition:border-color var(--sre-transition),box-shadow var(--sre-transition)}.sol-rich-editor:focus-within{border-color:var(--sre-border-focus);box-shadow:var(--sre-focus-ring)}.sol-rich-editor--disabled{opacity:var(--sol-disabled-opacity, .55)}.sol-rich-editor__toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:.125rem;padding:.375rem .5rem;background:var(--sre-toolbar-bg);border-bottom:1px solid var(--sre-border)}.sol-rich-editor__group{display:flex;align-items:center;gap:.125rem}.sol-rich-editor__group--menu{position:relative;display:inline-flex}.sol-rich-editor__sep{width:1px;align-self:stretch;margin:.125rem .25rem;background:var(--sre-border)}.sol-rich-editor__btn{display:inline-flex;align-items:center;justify-content:center;width:1.875rem;height:1.875rem;padding:0;border:none;border-radius:var(--sol-border-radius-sm, .375rem);background:transparent;color:var(--sre-text);cursor:pointer;transition:background-color var(--sre-transition),color var(--sre-transition)}.sol-rich-editor__btn:hover:not(:disabled){background:var(--sre-btn-hover)}.sol-rich-editor__btn:focus-visible{outline:2px solid var(--sre-border-focus);outline-offset:1px}.sol-rich-editor__btn.is-active{background:var(--sre-btn-active);color:var(--sol-color-primary, #6366f1)}.sol-rich-editor__btn:disabled{cursor:not-allowed;opacity:.5}.sol-rich-editor__menu{position:absolute;top:calc(100% + .25rem);left:0;z-index:var(--sol-z-dropdown, 1000);min-width:9rem;padding:.25rem;background:var(--sol-bg-surface, #ffffff);border:1px solid var(--sre-border);border-radius:var(--sol-border-radius-md, .5rem);box-shadow:var(--sol-shadow-lg, 0 10px 25px rgba(0, 0, 0, .12))}.sol-rich-editor__menu-item{display:block;width:100%;padding:.375rem .625rem;border:none;border-radius:var(--sol-border-radius-sm, .375rem);background:transparent;color:var(--sre-text);font-family:var(--sre-font);font-size:var(--sol-font-size-base, .9375rem);text-align:left;cursor:pointer}.sol-rich-editor__menu-item:hover{background:var(--sre-btn-hover)}.sol-rich-editor__menu-item--h1{font-size:1.375rem;font-weight:700}.sol-rich-editor__menu-item--h2{font-size:1.125rem;font-weight:700}.sol-rich-editor__menu-item--h3{font-size:1rem;font-weight:600}.sol-rich-editor__menu--table{min-width:auto}.sol-rich-editor__grid{display:flex;flex-direction:column;gap:2px}.sol-rich-editor__grid-row{display:flex;gap:2px}.sol-rich-editor__grid-cell{width:1rem;height:1rem;padding:0;border:1px solid var(--sre-border);border-radius:2px;background:var(--sol-bg-surface, #ffffff);cursor:pointer}.sol-rich-editor__grid-cell.is-on{background:color-mix(in srgb,var(--sol-color-primary, #6366f1) 45%,transparent);border-color:var(--sol-color-primary, #6366f1)}.sol-rich-editor__grid-label{margin-top:.375rem;text-align:center;font-family:var(--sre-font);font-size:var(--sol-font-size-sm, .75rem);color:var(--sre-muted)}.sol-rich-editor__menu--link{min-width:15rem}.sol-rich-editor__link-input{width:100%;height:var(--sol-size-input-height, 2.25rem);padding:0 .5rem;font-family:var(--sre-font);font-size:var(--sol-font-size-base, .9375rem);color:var(--sre-text);background:var(--sre-bg);border:1px solid var(--sre-border);border-radius:var(--sol-border-radius-sm, .375rem);outline:none;box-sizing:border-box}.sol-rich-editor__link-input:focus{border-color:var(--sre-border-focus)}.sol-rich-editor__link-actions{display:flex;gap:.375rem;margin-top:.375rem}.sol-rich-editor__link-btn{flex:1;padding:.375rem .5rem;border:1px solid var(--sre-border);border-radius:var(--sol-border-radius-sm, .375rem);background:transparent;color:var(--sre-text);font-family:var(--sre-font);font-size:var(--sol-font-size-sm, .75rem);cursor:pointer}.sol-rich-editor__link-btn:hover{background:var(--sre-btn-hover)}.sol-rich-editor__link-btn--primary{background:var(--sol-color-primary, #6366f1);border-color:var(--sol-color-primary, #6366f1);color:var(--sol-color-primary-contrast, #ffffff)}.sol-rich-editor__content{flex:1;padding:.75rem .875rem;overflow-y:auto;font-family:var(--sre-font);font-size:var(--sre-font-size);line-height:var(--sol-line-height, 1.6);color:var(--sre-text);outline:none;word-break:break-word}.sol-rich-editor__content.is-empty:before{content:attr(data-placeholder);color:var(--sre-muted);pointer-events:none}.sol-rich-editor__error{margin:0;padding:.375rem .875rem;font-family:var(--sre-font);font-size:var(--sol-font-size-sm, .75rem);color:var(--sol-color-danger, #ef4444)}.sol-rich-editor__file{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}.sol-rich-editor__popover{position:absolute;z-index:var(--sol-z-dropdown, 1000);min-width:12rem;max-width:18rem;max-height:14rem;overflow-y:auto;padding:.25rem;background:var(--sol-bg-surface, #ffffff);border:1px solid var(--sre-border);border-radius:var(--sol-border-radius-md, .5rem);box-shadow:var(--sol-shadow-lg, 0 10px 25px rgba(0, 0, 0, .12))}.sol-rich-editor__popover--task{min-width:16rem}.sol-rich-editor__popover-item{display:flex;align-items:center;gap:.5rem;width:100%;padding:.375rem .5rem;border:none;border-radius:var(--sol-border-radius-sm, .375rem);background:transparent;color:var(--sre-text);font-family:var(--sre-font);font-size:var(--sol-font-size-base, .9375rem);text-align:left;cursor:pointer}.sol-rich-editor__popover-item:hover,.sol-rich-editor__popover-item.is-active{background:var(--sre-btn-hover)}.sol-rich-editor__popover-label{flex:1;min-width:0}.sol-rich-editor__popover-label--truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-rich-editor__avatar{display:inline-flex;align-items:center;justify-content:center;width:1.5rem;height:1.5rem;flex-shrink:0;border-radius:9999px;background:color-mix(in srgb,var(--sol-color-primary, #6366f1) 20%,transparent);color:var(--sol-color-primary, #6366f1);font-size:var(--sol-font-size-sm, .75rem);font-weight:600}.sol-rich-editor__task-key{flex-shrink:0;padding:.0625rem .375rem;border-radius:var(--sol-border-radius-sm, .375rem);background:color-mix(in srgb,var(--sol-color-success, #10b981) 14%,transparent);color:var(--sol-color-success, #10b981);font-family:var(--sol-font-family-mono, ui-monospace, monospace);font-size:var(--sol-font-size-sm, .75rem);font-weight:600}.sol-rich-editor__content ::ng-deep span[data-mention-id]{display:inline-block;padding:0 .375rem;border-radius:var(--sol-border-radius-sm, .375rem);background:color-mix(in srgb,var(--sol-color-primary, #6366f1) 12%,transparent);color:var(--sol-color-primary, #6366f1);font-weight:500;white-space:nowrap}.sol-rich-editor__content ::ng-deep span[data-task-key]{display:inline-block;padding:0 .375rem;border-radius:var(--sol-border-radius-sm, .375rem);background:color-mix(in srgb,var(--sol-color-success, #10b981) 14%,transparent);color:var(--sol-color-success, #10b981);font-family:var(--sol-font-family-mono, ui-monospace, monospace);font-weight:600;white-space:nowrap}.sol-rich-editor__content ::ng-deep h1{font-size:1.5rem;font-weight:700;margin:.5rem 0;line-height:1.25}.sol-rich-editor__content ::ng-deep h2{font-size:1.25rem;font-weight:700;margin:.5rem 0;line-height:1.3}.sol-rich-editor__content ::ng-deep h3{font-size:1.0625rem;font-weight:600;margin:.5rem 0;line-height:1.35}.sol-rich-editor__content ::ng-deep p{margin:0 0 .5rem}.sol-rich-editor__content ::ng-deep ul,.sol-rich-editor__content ::ng-deep ol{margin:0 0 .5rem;padding-left:1.5rem}.sol-rich-editor__content ::ng-deep li{margin:.125rem 0}.sol-rich-editor__content ::ng-deep a{color:var(--sol-color-primary, #6366f1);text-decoration:underline}.sol-rich-editor__content ::ng-deep img{max-width:100%;height:auto;border-radius:var(--sol-border-radius-sm, .375rem)}.sol-rich-editor__content ::ng-deep table{border-collapse:collapse;margin:.5rem 0;width:auto}.sol-rich-editor__content ::ng-deep td,.sol-rich-editor__content ::ng-deep th{border:1px solid var(--sre-border);padding:.375rem .5rem;min-width:3rem}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolRichEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-rich-editor', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [SolIconComponent], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SolRichEditorComponent),
                            multi: true,
                        },
                    ], template: `
    <div class="sol-rich-editor" [class.sol-rich-editor--disabled]="isDisabled()">
      <!-- ── Toolbar ─────────────────────────────────────────────────── -->
      <div class="sol-rich-editor__toolbar" role="toolbar" [attr.aria-label]="labels().toolbar">
        <!-- Formato inline -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().bold" [disabled]="isDisabled()"
            [attr.aria-label]="labels().bold" [attr.title]="labels().bold" [attr.aria-pressed]="active().bold"
            (mousedown)="preventSteal($event)" (click)="cmd('bold')"
          ><sol-icon name="bold" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().italic" [disabled]="isDisabled()"
            [attr.aria-label]="labels().italic" [attr.title]="labels().italic" [attr.aria-pressed]="active().italic"
            (mousedown)="preventSteal($event)" (click)="cmd('italic')"
          ><sol-icon name="italic" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().underline" [disabled]="isDisabled()"
            [attr.aria-label]="labels().underline" [attr.title]="labels().underline" [attr.aria-pressed]="active().underline"
            (mousedown)="preventSteal($event)" (click)="cmd('underline')"
          ><sol-icon name="underline" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().strike" [disabled]="isDisabled()"
            [attr.aria-label]="labels().strike" [attr.title]="labels().strike" [attr.aria-pressed]="active().strike"
            (mousedown)="preventSteal($event)" (click)="cmd('strikeThrough')"
          ><sol-icon name="strikethrough" size="sm" /></button>
        </div>

        <span class="sol-rich-editor__sep" aria-hidden="true"></span>

        <!-- Encabezados -->
        <div class="sol-rich-editor__group sol-rich-editor__group--menu">
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="showHeadingMenu()" [disabled]="isDisabled()"
            [attr.aria-label]="labels().heading" [attr.title]="labels().heading"
            [attr.aria-expanded]="showHeadingMenu()"
            (mousedown)="onTriggerMousedown($event)" (click)="toggleMenu('heading')"
          ><sol-icon name="heading" size="sm" /></button>
          @if (showHeadingMenu()) {
            <div class="sol-rich-editor__menu" role="menu">
              <button type="button" role="menuitem" class="sol-rich-editor__menu-item"
                (mousedown)="preventSteal($event)" (click)="applyHeading('p')">{{ labels().paragraph }}</button>
              <button type="button" role="menuitem" class="sol-rich-editor__menu-item sol-rich-editor__menu-item--h1"
                (mousedown)="preventSteal($event)" (click)="applyHeading('h1')">{{ labels().heading1 }}</button>
              <button type="button" role="menuitem" class="sol-rich-editor__menu-item sol-rich-editor__menu-item--h2"
                (mousedown)="preventSteal($event)" (click)="applyHeading('h2')">{{ labels().heading2 }}</button>
              <button type="button" role="menuitem" class="sol-rich-editor__menu-item sol-rich-editor__menu-item--h3"
                (mousedown)="preventSteal($event)" (click)="applyHeading('h3')">{{ labels().heading3 }}</button>
            </div>
          }
        </div>

        <!-- Listas -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().bulletList" [disabled]="isDisabled()"
            [attr.aria-label]="labels().bulletList" [attr.title]="labels().bulletList" [attr.aria-pressed]="active().bulletList"
            (mousedown)="preventSteal($event)" (click)="cmd('insertUnorderedList')"
          ><sol-icon name="list-bullet" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().numberedList" [disabled]="isDisabled()"
            [attr.aria-label]="labels().numberedList" [attr.title]="labels().numberedList" [attr.aria-pressed]="active().numberedList"
            (mousedown)="preventSteal($event)" (click)="cmd('insertOrderedList')"
          ><sol-icon name="list-numbered" size="sm" /></button>
        </div>

        <span class="sol-rich-editor__sep" aria-hidden="true"></span>

        <!-- Alineación -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().alignLeft" [disabled]="isDisabled()"
            [attr.aria-label]="labels().alignLeft" [attr.title]="labels().alignLeft" [attr.aria-pressed]="active().alignLeft"
            (mousedown)="preventSteal($event)" (click)="align('left')"
          ><sol-icon name="align-left" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().alignCenter" [disabled]="isDisabled()"
            [attr.aria-label]="labels().alignCenter" [attr.title]="labels().alignCenter" [attr.aria-pressed]="active().alignCenter"
            (mousedown)="preventSteal($event)" (click)="align('center')"
          ><sol-icon name="align-center" size="sm" /></button>
          <button
            type="button" class="sol-rich-editor__btn"
            [class.is-active]="active().alignRight" [disabled]="isDisabled()"
            [attr.aria-label]="labels().alignRight" [attr.title]="labels().alignRight" [attr.aria-pressed]="active().alignRight"
            (mousedown)="preventSteal($event)" (click)="align('right')"
          ><sol-icon name="align-right" size="sm" /></button>
        </div>

        <span class="sol-rich-editor__sep" aria-hidden="true"></span>

        <!-- Inserción: imagen, tabla, enlace -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn" [disabled]="isDisabled()"
            [attr.aria-label]="labels().insertImage" [attr.title]="labels().insertImage"
            (mousedown)="onTriggerMousedown($event)" (click)="pickImage()"
          ><sol-icon name="image" size="sm" /></button>

          <!-- Tabla (selector de rejilla) -->
          <div class="sol-rich-editor__group--menu">
            <button
              type="button" class="sol-rich-editor__btn"
              [class.is-active]="showTableMenu()" [disabled]="isDisabled()"
              [attr.aria-label]="labels().insertTable" [attr.title]="labels().insertTable"
              [attr.aria-expanded]="showTableMenu()"
              (mousedown)="onTriggerMousedown($event)" (click)="toggleMenu('table')"
            ><sol-icon name="table" size="sm" /></button>
            @if (showTableMenu()) {
              <div class="sol-rich-editor__menu sol-rich-editor__menu--table" role="menu"
                   [attr.aria-label]="labels().tablePicker">
                <div class="sol-rich-editor__grid">
                  @for (row of gridRange(); track row) {
                    <div class="sol-rich-editor__grid-row">
                      @for (col of gridRange(); track col) {
                        <button
                          type="button" class="sol-rich-editor__grid-cell"
                          [class.is-on]="row <= tableRows() && col <= tableCols()"
                          (mousedown)="preventSteal($event)"
                          (mouseenter)="hoverTable(row, col)"
                          (click)="insertTable(row, col)"
                        ></button>
                      }
                    </div>
                  }
                </div>
                <div class="sol-rich-editor__grid-label">{{ tableRows() }} × {{ tableCols() }}</div>
              </div>
            }
          </div>

          <!-- Enlace -->
          <div class="sol-rich-editor__group--menu">
            <button
              type="button" class="sol-rich-editor__btn"
              [class.is-active]="showLinkMenu()" [disabled]="isDisabled()"
              [attr.aria-label]="labels().insertLink" [attr.title]="labels().insertLink"
              [attr.aria-expanded]="showLinkMenu()"
              (mousedown)="onTriggerMousedown($event)" (click)="toggleMenu('link')"
            ><sol-icon name="link" size="sm" /></button>
            @if (showLinkMenu()) {
              <div class="sol-rich-editor__menu sol-rich-editor__menu--link" role="menu">
                <input
                  #linkInput type="url" class="sol-rich-editor__link-input"
                  [placeholder]="labels().linkPlaceholder" [attr.aria-label]="labels().linkPlaceholder"
                  [value]="linkUrl()" (input)="linkUrl.set($any($event.target).value)"
                  (keydown.enter)="confirmLink()" (keydown.escape)="closeMenus()"
                />
                <div class="sol-rich-editor__link-actions">
                  <button type="button" class="sol-rich-editor__link-btn sol-rich-editor__link-btn--primary"
                    (mousedown)="preventSteal($event)" (click)="confirmLink()">{{ labels().linkConfirm }}</button>
                  <button type="button" class="sol-rich-editor__link-btn"
                    (mousedown)="preventSteal($event)" (click)="removeLink()">{{ labels().removeLink }}</button>
                </div>
              </div>
            }
          </div>
        </div>

        <span class="sol-rich-editor__sep" aria-hidden="true"></span>

        <!-- Quitar formato -->
        <div class="sol-rich-editor__group">
          <button
            type="button" class="sol-rich-editor__btn" [disabled]="isDisabled()"
            [attr.aria-label]="labels().removeFormat" [attr.title]="labels().removeFormat"
            (mousedown)="preventSteal($event)" (click)="removeFormat()"
          ><sol-icon name="remove-format" size="sm" /></button>
        </div>
      </div>

      <!-- ── Área editable ───────────────────────────────────────────── -->
      <div
        #editable
        class="sol-rich-editor__content"
        [class.is-empty]="isEmpty()"
        [attr.contenteditable]="isDisabled() ? 'false' : 'true'"
        [attr.data-placeholder]="placeholder()"
        [attr.aria-label]="editorAriaLabel()"
        [attr.aria-multiline]="'true'"
        role="textbox"
        [style.min-height]="minHeight()"
        [style.max-height]="maxHeight() || null"
        (input)="onInput()"
        (blur)="onBlur()"
        (keydown)="onKeyDown($event)"
        (keyup)="scheduleActiveUpdate()"
        (mouseup)="scheduleActiveUpdate()"
        (paste)="onPaste($event)"
      ></div>

      <!-- ── Popover de menciones (@) — opt-in ──────────────────────────── -->
      @if (showMentionPopover() && filteredUsers().length > 0) {
        <div
          class="sol-rich-editor__popover" role="listbox"
          [attr.aria-label]="labels().mentionList"
          [style.top.px]="popoverTop()" [style.left.px]="popoverLeft()"
        >
          @for (user of filteredUsers(); track user.id; let i = $index) {
            <button
              type="button" role="option" class="sol-rich-editor__popover-item"
              [class.is-active]="i === activeIndex()" [attr.aria-selected]="i === activeIndex()"
              (mousedown)="selectMention($event, i)" (mouseenter)="activeIndex.set(i)"
            >
              <span class="sol-rich-editor__avatar" aria-hidden="true">{{ initial(user.name) }}</span>
              <span class="sol-rich-editor__popover-label">{{ user.name }}</span>
            </button>
          }
        </div>
      }

      <!-- ── Popover de tareas (#) — opt-in ─────────────────────────────── -->
      @if (showTaskPopover() && filteredTasks().length > 0) {
        <div
          class="sol-rich-editor__popover sol-rich-editor__popover--task" role="listbox"
          [attr.aria-label]="labels().taskList"
          [style.top.px]="popoverTop()" [style.left.px]="popoverLeft()"
        >
          @for (task of filteredTasks(); track task.key; let i = $index) {
            <button
              type="button" role="option" class="sol-rich-editor__popover-item"
              [class.is-active]="i === activeIndex()" [attr.aria-selected]="i === activeIndex()"
              (mousedown)="selectTask($event, i)" (mouseenter)="activeIndex.set(i)"
            >
              <span class="sol-rich-editor__task-key" aria-hidden="true">{{ task.key }}</span>
              <span class="sol-rich-editor__popover-label sol-rich-editor__popover-label--truncate">{{ task.title }}</span>
            </button>
          }
        </div>
      }

      @if (imageError()) {
        <p class="sol-rich-editor__error" role="alert">{{ imageError() }}</p>
      }

      <!-- Selector de archivo oculto para insertar imágenes locales -->
      <input
        #fileInput type="file" accept="image/*" class="sol-rich-editor__file"
        (change)="onFileSelected($event)" tabindex="-1" aria-hidden="true"
      />
    </div>
  `, styles: [":host{display:block;--sre-bg: var(--sol-input-bg, var(--sol-bg-surface, #ffffff));--sre-text: var(--sol-color-text-primary, #1e293b);--sre-muted: var(--sol-color-text-muted, #94a3b8);--sre-border: var(--sol-border-color-default, #cbd5e1);--sre-border-focus: var(--sol-color-primary, #6366f1);--sre-radius: var(--sol-input-radius, var(--sol-border-radius-md, .5rem));--sre-toolbar-bg: var(--sol-bg-sunken, var(--sol-bg-page, #f8fafc));--sre-btn-hover: color-mix(in srgb, var(--sol-color-primary, #6366f1) 12%, transparent);--sre-btn-active: color-mix(in srgb, var(--sol-color-primary, #6366f1) 18%, transparent);--sre-focus-ring: var(--sol-input-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 30%, transparent));--sre-font: var(--sol-font-family, system-ui, sans-serif);--sre-font-size: var(--sol-font-size-base, .9375rem);--sre-transition: var(--sol-dur-fast, .15s) var(--sol-ease, ease)}.sol-rich-editor{position:relative;display:flex;flex-direction:column;border:var(--sol-input-border, var(--sol-border-width-default, 1px) solid var(--sre-border));border-radius:var(--sre-radius);background:var(--sre-bg);box-shadow:var(--sol-input-shadow, none);overflow:hidden;transition:border-color var(--sre-transition),box-shadow var(--sre-transition)}.sol-rich-editor:focus-within{border-color:var(--sre-border-focus);box-shadow:var(--sre-focus-ring)}.sol-rich-editor--disabled{opacity:var(--sol-disabled-opacity, .55)}.sol-rich-editor__toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:.125rem;padding:.375rem .5rem;background:var(--sre-toolbar-bg);border-bottom:1px solid var(--sre-border)}.sol-rich-editor__group{display:flex;align-items:center;gap:.125rem}.sol-rich-editor__group--menu{position:relative;display:inline-flex}.sol-rich-editor__sep{width:1px;align-self:stretch;margin:.125rem .25rem;background:var(--sre-border)}.sol-rich-editor__btn{display:inline-flex;align-items:center;justify-content:center;width:1.875rem;height:1.875rem;padding:0;border:none;border-radius:var(--sol-border-radius-sm, .375rem);background:transparent;color:var(--sre-text);cursor:pointer;transition:background-color var(--sre-transition),color var(--sre-transition)}.sol-rich-editor__btn:hover:not(:disabled){background:var(--sre-btn-hover)}.sol-rich-editor__btn:focus-visible{outline:2px solid var(--sre-border-focus);outline-offset:1px}.sol-rich-editor__btn.is-active{background:var(--sre-btn-active);color:var(--sol-color-primary, #6366f1)}.sol-rich-editor__btn:disabled{cursor:not-allowed;opacity:.5}.sol-rich-editor__menu{position:absolute;top:calc(100% + .25rem);left:0;z-index:var(--sol-z-dropdown, 1000);min-width:9rem;padding:.25rem;background:var(--sol-bg-surface, #ffffff);border:1px solid var(--sre-border);border-radius:var(--sol-border-radius-md, .5rem);box-shadow:var(--sol-shadow-lg, 0 10px 25px rgba(0, 0, 0, .12))}.sol-rich-editor__menu-item{display:block;width:100%;padding:.375rem .625rem;border:none;border-radius:var(--sol-border-radius-sm, .375rem);background:transparent;color:var(--sre-text);font-family:var(--sre-font);font-size:var(--sol-font-size-base, .9375rem);text-align:left;cursor:pointer}.sol-rich-editor__menu-item:hover{background:var(--sre-btn-hover)}.sol-rich-editor__menu-item--h1{font-size:1.375rem;font-weight:700}.sol-rich-editor__menu-item--h2{font-size:1.125rem;font-weight:700}.sol-rich-editor__menu-item--h3{font-size:1rem;font-weight:600}.sol-rich-editor__menu--table{min-width:auto}.sol-rich-editor__grid{display:flex;flex-direction:column;gap:2px}.sol-rich-editor__grid-row{display:flex;gap:2px}.sol-rich-editor__grid-cell{width:1rem;height:1rem;padding:0;border:1px solid var(--sre-border);border-radius:2px;background:var(--sol-bg-surface, #ffffff);cursor:pointer}.sol-rich-editor__grid-cell.is-on{background:color-mix(in srgb,var(--sol-color-primary, #6366f1) 45%,transparent);border-color:var(--sol-color-primary, #6366f1)}.sol-rich-editor__grid-label{margin-top:.375rem;text-align:center;font-family:var(--sre-font);font-size:var(--sol-font-size-sm, .75rem);color:var(--sre-muted)}.sol-rich-editor__menu--link{min-width:15rem}.sol-rich-editor__link-input{width:100%;height:var(--sol-size-input-height, 2.25rem);padding:0 .5rem;font-family:var(--sre-font);font-size:var(--sol-font-size-base, .9375rem);color:var(--sre-text);background:var(--sre-bg);border:1px solid var(--sre-border);border-radius:var(--sol-border-radius-sm, .375rem);outline:none;box-sizing:border-box}.sol-rich-editor__link-input:focus{border-color:var(--sre-border-focus)}.sol-rich-editor__link-actions{display:flex;gap:.375rem;margin-top:.375rem}.sol-rich-editor__link-btn{flex:1;padding:.375rem .5rem;border:1px solid var(--sre-border);border-radius:var(--sol-border-radius-sm, .375rem);background:transparent;color:var(--sre-text);font-family:var(--sre-font);font-size:var(--sol-font-size-sm, .75rem);cursor:pointer}.sol-rich-editor__link-btn:hover{background:var(--sre-btn-hover)}.sol-rich-editor__link-btn--primary{background:var(--sol-color-primary, #6366f1);border-color:var(--sol-color-primary, #6366f1);color:var(--sol-color-primary-contrast, #ffffff)}.sol-rich-editor__content{flex:1;padding:.75rem .875rem;overflow-y:auto;font-family:var(--sre-font);font-size:var(--sre-font-size);line-height:var(--sol-line-height, 1.6);color:var(--sre-text);outline:none;word-break:break-word}.sol-rich-editor__content.is-empty:before{content:attr(data-placeholder);color:var(--sre-muted);pointer-events:none}.sol-rich-editor__error{margin:0;padding:.375rem .875rem;font-family:var(--sre-font);font-size:var(--sol-font-size-sm, .75rem);color:var(--sol-color-danger, #ef4444)}.sol-rich-editor__file{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}.sol-rich-editor__popover{position:absolute;z-index:var(--sol-z-dropdown, 1000);min-width:12rem;max-width:18rem;max-height:14rem;overflow-y:auto;padding:.25rem;background:var(--sol-bg-surface, #ffffff);border:1px solid var(--sre-border);border-radius:var(--sol-border-radius-md, .5rem);box-shadow:var(--sol-shadow-lg, 0 10px 25px rgba(0, 0, 0, .12))}.sol-rich-editor__popover--task{min-width:16rem}.sol-rich-editor__popover-item{display:flex;align-items:center;gap:.5rem;width:100%;padding:.375rem .5rem;border:none;border-radius:var(--sol-border-radius-sm, .375rem);background:transparent;color:var(--sre-text);font-family:var(--sre-font);font-size:var(--sol-font-size-base, .9375rem);text-align:left;cursor:pointer}.sol-rich-editor__popover-item:hover,.sol-rich-editor__popover-item.is-active{background:var(--sre-btn-hover)}.sol-rich-editor__popover-label{flex:1;min-width:0}.sol-rich-editor__popover-label--truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-rich-editor__avatar{display:inline-flex;align-items:center;justify-content:center;width:1.5rem;height:1.5rem;flex-shrink:0;border-radius:9999px;background:color-mix(in srgb,var(--sol-color-primary, #6366f1) 20%,transparent);color:var(--sol-color-primary, #6366f1);font-size:var(--sol-font-size-sm, .75rem);font-weight:600}.sol-rich-editor__task-key{flex-shrink:0;padding:.0625rem .375rem;border-radius:var(--sol-border-radius-sm, .375rem);background:color-mix(in srgb,var(--sol-color-success, #10b981) 14%,transparent);color:var(--sol-color-success, #10b981);font-family:var(--sol-font-family-mono, ui-monospace, monospace);font-size:var(--sol-font-size-sm, .75rem);font-weight:600}.sol-rich-editor__content ::ng-deep span[data-mention-id]{display:inline-block;padding:0 .375rem;border-radius:var(--sol-border-radius-sm, .375rem);background:color-mix(in srgb,var(--sol-color-primary, #6366f1) 12%,transparent);color:var(--sol-color-primary, #6366f1);font-weight:500;white-space:nowrap}.sol-rich-editor__content ::ng-deep span[data-task-key]{display:inline-block;padding:0 .375rem;border-radius:var(--sol-border-radius-sm, .375rem);background:color-mix(in srgb,var(--sol-color-success, #10b981) 14%,transparent);color:var(--sol-color-success, #10b981);font-family:var(--sol-font-family-mono, ui-monospace, monospace);font-weight:600;white-space:nowrap}.sol-rich-editor__content ::ng-deep h1{font-size:1.5rem;font-weight:700;margin:.5rem 0;line-height:1.25}.sol-rich-editor__content ::ng-deep h2{font-size:1.25rem;font-weight:700;margin:.5rem 0;line-height:1.3}.sol-rich-editor__content ::ng-deep h3{font-size:1.0625rem;font-weight:600;margin:.5rem 0;line-height:1.35}.sol-rich-editor__content ::ng-deep p{margin:0 0 .5rem}.sol-rich-editor__content ::ng-deep ul,.sol-rich-editor__content ::ng-deep ol{margin:0 0 .5rem;padding-left:1.5rem}.sol-rich-editor__content ::ng-deep li{margin:.125rem 0}.sol-rich-editor__content ::ng-deep a{color:var(--sol-color-primary, #6366f1);text-decoration:underline}.sol-rich-editor__content ::ng-deep img{max-width:100%;height:auto;border-radius:var(--sol-border-radius-sm, .375rem)}.sol-rich-editor__content ::ng-deep table{border-collapse:collapse;margin:.5rem 0;width:auto}.sol-rich-editor__content ::ng-deep td,.sol-rich-editor__content ::ng-deep th{border:1px solid var(--sre-border);padding:.375rem .5rem;min-width:3rem}\n"] }]
        }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], minHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "minHeight", required: false }] }], maxHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxHeight", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], imageMaxBytes: [{ type: i0.Input, args: [{ isSignal: true, alias: "imageMaxBytes", required: false }] }], imageUpload: [{ type: i0.Input, args: [{ isSignal: true, alias: "imageUpload", required: false }] }], mentionableUsers: [{ type: i0.Input, args: [{ isSignal: true, alias: "mentionableUsers", required: false }] }], linkableTasks: [{ type: i0.Input, args: [{ isSignal: true, alias: "linkableTasks", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], mentionsChange: [{ type: i0.Output, args: ["mentionsChange"] }], taskLinksChange: [{ type: i0.Output, args: ["taskLinksChange"] }], editable: [{ type: i0.ViewChild, args: ['editable', { isSignal: true }] }], fileInput: [{ type: i0.ViewChild, args: ['fileInput', { isSignal: true }] }], linkInput: [{ type: i0.ViewChild, args: ['linkInput', { isSignal: true }] }] } });

/**
 * Cabecera de página del design system: título (H1) + subtítulo opcional a la
 * izquierda, con un slot proyectado de acciones alineadas a la derecha (p. ej.
 * un botón "Crear"). Tematizado con `var(--sol-*)` — soporta light y dark.
 *
 * Uso:
 * ```html
 * <sol-page-header title="Profesionales" subtitle="Gestiona tu equipo">
 *   <sol-button (clicked)="crear()">Crear</sol-button>
 * </sol-page-header>
 * ```
 */
class SolPageHeaderComponent {
    /** Título principal (H1). Obligatorio. */
    title = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    /** Subtítulo opcional bajo el título. */
    subtitle = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolPageHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolPageHeaderComponent, isStandalone: true, selector: "sol-page-header", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="sol-page-header">
      <div class="sol-page-header__titles">
        <h1 class="sol-page-header__title">{{ title() }}</h1>
        @if (subtitle()) {
          <p class="sol-page-header__subtitle">{{ subtitle() }}</p>
        }
      </div>
      <div class="sol-page-header__actions">
        <ng-content />
      </div>
    </div>
  `, isInline: true, styles: [":host{display:block}.sol-page-header{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:var(--sol-space-sm, .75rem)}.sol-page-header__titles{min-width:0}.sol-page-header__title{margin:0;font-family:var(--sol-font-display, var(--sol-font-family, inherit));font-size:var(--sol-font-size-xl, 1.5rem);font-weight:var(--sol-display-weight, var(--sol-font-weight-bold, 700));letter-spacing:var(--sol-display-tracking, -.01em);text-transform:var(--sol-display-transform, none);line-height:1.2;color:var(--sol-color-text-primary, #0f172a)}.sol-page-header__subtitle{margin:var(--sol-space-xs, .25rem) 0 0;font-size:var(--sol-font-size-sm, .8125rem);color:var(--sol-color-text-muted, #64748b)}.sol-page-header__actions{display:flex;align-items:center;gap:var(--sol-space-sm, .5rem);flex-shrink:0}.sol-page-header__actions:empty{display:none}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolPageHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-page-header', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-page-header">
      <div class="sol-page-header__titles">
        <h1 class="sol-page-header__title">{{ title() }}</h1>
        @if (subtitle()) {
          <p class="sol-page-header__subtitle">{{ subtitle() }}</p>
        }
      </div>
      <div class="sol-page-header__actions">
        <ng-content />
      </div>
    </div>
  `, styles: [":host{display:block}.sol-page-header{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:var(--sol-space-sm, .75rem)}.sol-page-header__titles{min-width:0}.sol-page-header__title{margin:0;font-family:var(--sol-font-display, var(--sol-font-family, inherit));font-size:var(--sol-font-size-xl, 1.5rem);font-weight:var(--sol-display-weight, var(--sol-font-weight-bold, 700));letter-spacing:var(--sol-display-tracking, -.01em);text-transform:var(--sol-display-transform, none);line-height:1.2;color:var(--sol-color-text-primary, #0f172a)}.sol-page-header__subtitle{margin:var(--sol-space-xs, .25rem) 0 0;font-size:var(--sol-font-size-sm, .8125rem);color:var(--sol-color-text-muted, #64748b)}.sol-page-header__actions{display:flex;align-items:center;gap:var(--sol-space-sm, .5rem);flex-shrink:0}.sol-page-header__actions:empty{display:none}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], subtitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "subtitle", required: false }] }] } });

/**
 * Botón cuadrado de solo ícono, con `aria-label` obligatorio por accesibilidad.
 * El ícono sale del registry de la librería vía `sol-icon` (nunca SVG inline).
 * Tematizado con `var(--sol-*)` — soporta light y dark.
 *
 * Uso:
 * ```html
 * <sol-icon-button icon="edit" ariaLabel="Editar" (clicked)="editar()" />
 * <sol-icon-button icon="trash" variant="danger" ariaLabel="Eliminar" (clicked)="eliminar()" />
 * ```
 */
class SolIconButtonComponent {
    /** Ícono del registry a mostrar. Obligatorio. */
    icon = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
    /** Etiqueta accesible obligatoria (el botón no tiene texto visible). */
    ariaLabel = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Atributo `type` nativo del botón. */
    type = input('button', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /** Estilo visual. */
    variant = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Tamaño cuadrado. */
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    /** Deshabilita el botón. */
    disabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    /** Se emite al hacer clic cuando el botón no está deshabilitado. */
    clicked = output();
    /** Clases CSS combinando variante y tamaño. */
    cssClass = computed(() => `sol-icon-btn sol-icon-btn--${this.variant()} sol-icon-btn--${this.size()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cssClass" }] : /* istanbul ignore next */ []));
    onClick(event) {
        if (this.disabled()) {
            event.stopPropagation();
            return;
        }
        this.clicked.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolIconButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolIconButtonComponent, isStandalone: true, selector: "sol-icon-button", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: true, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clicked: "clicked" }, ngImport: i0, template: `
    <button
      [type]="type()"
      [class]="cssClass()"
      [disabled]="disabled()"
      [attr.aria-label]="ariaLabel()"
      (click)="onClick($event)"
    >
      <sol-icon [name]="icon()" [size]="size()" />
    </button>
  `, isInline: true, styles: [":host{display:inline-block}.sol-icon-btn{display:grid;place-items:center;padding:0;border:1px solid transparent;border-radius:var(--sol-button-radius, var(--sol-border-radius-md, .5rem));background:transparent;color:var(--sol-color-text-muted, #64748b);cursor:pointer;transition:background-color var(--sol-dur-fast, .15s) var(--sol-ease, ease),color var(--sol-dur-fast, .15s) var(--sol-ease, ease),box-shadow var(--sol-dur-fast, .15s) var(--sol-ease, ease),transform var(--sol-dur-fast, .15s) var(--sol-ease, ease)}.sol-icon-btn:active:not(:disabled){transform:scale(var(--sol-press-scale, .96))}.sol-icon-btn:focus-visible{outline:none;box-shadow:var(--sol-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent))}.sol-icon-btn:disabled{cursor:not-allowed;opacity:var(--sol-disabled-opacity, .55)}.sol-icon-btn--default{border-color:var(--sol-border-color-default, #e2e8f0);background:var(--sol-bg-surface, #fff);color:var(--sol-color-text-muted, #64748b)}.sol-icon-btn--default:hover:not(:disabled){background:color-mix(in srgb,var(--sol-color-primary, #2563eb) 8%,var(--sol-bg-surface, #fff));color:var(--sol-color-text-primary, #0f172a)}.sol-icon-btn--danger{color:var(--sol-color-danger, #ef4444)}.sol-icon-btn--danger:hover:not(:disabled){background:color-mix(in srgb,var(--sol-color-danger, #ef4444) 12%,transparent)}.sol-icon-btn--ghost{color:var(--sol-color-text-muted, #64748b)}.sol-icon-btn--ghost:hover:not(:disabled){background:color-mix(in srgb,var(--sol-color-primary, #2563eb) 10%,transparent);color:var(--sol-color-text-primary, #0f172a)}.sol-icon-btn--sm{width:32px;height:32px}.sol-icon-btn--md{width:36px;height:36px}.sol-icon-btn--lg{width:40px;height:40px}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolIconButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-icon-button', standalone: true, imports: [SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <button
      [type]="type()"
      [class]="cssClass()"
      [disabled]="disabled()"
      [attr.aria-label]="ariaLabel()"
      (click)="onClick($event)"
    >
      <sol-icon [name]="icon()" [size]="size()" />
    </button>
  `, styles: [":host{display:inline-block}.sol-icon-btn{display:grid;place-items:center;padding:0;border:1px solid transparent;border-radius:var(--sol-button-radius, var(--sol-border-radius-md, .5rem));background:transparent;color:var(--sol-color-text-muted, #64748b);cursor:pointer;transition:background-color var(--sol-dur-fast, .15s) var(--sol-ease, ease),color var(--sol-dur-fast, .15s) var(--sol-ease, ease),box-shadow var(--sol-dur-fast, .15s) var(--sol-ease, ease),transform var(--sol-dur-fast, .15s) var(--sol-ease, ease)}.sol-icon-btn:active:not(:disabled){transform:scale(var(--sol-press-scale, .96))}.sol-icon-btn:focus-visible{outline:none;box-shadow:var(--sol-focus-ring, 0 0 0 3px color-mix(in srgb, var(--sol-color-primary, #6366f1) 40%, transparent))}.sol-icon-btn:disabled{cursor:not-allowed;opacity:var(--sol-disabled-opacity, .55)}.sol-icon-btn--default{border-color:var(--sol-border-color-default, #e2e8f0);background:var(--sol-bg-surface, #fff);color:var(--sol-color-text-muted, #64748b)}.sol-icon-btn--default:hover:not(:disabled){background:color-mix(in srgb,var(--sol-color-primary, #2563eb) 8%,var(--sol-bg-surface, #fff));color:var(--sol-color-text-primary, #0f172a)}.sol-icon-btn--danger{color:var(--sol-color-danger, #ef4444)}.sol-icon-btn--danger:hover:not(:disabled){background:color-mix(in srgb,var(--sol-color-danger, #ef4444) 12%,transparent)}.sol-icon-btn--ghost{color:var(--sol-color-text-muted, #64748b)}.sol-icon-btn--ghost:hover:not(:disabled){background:color-mix(in srgb,var(--sol-color-primary, #2563eb) 10%,transparent);color:var(--sol-color-text-primary, #0f172a)}.sol-icon-btn--sm{width:32px;height:32px}.sol-icon-btn--md{width:36px;height:36px}.sol-icon-btn--lg{width:40px;height:40px}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: true }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: true }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], clicked: [{ type: i0.Output, args: ["clicked"] }] } });

/**
 * Directiva interna (se exporta desde este archivo solo porque el
 * compilador de Angular exige que los `imports` de un componente standalone
 * sean símbolos exportados — NO se re-exporta desde `lib/ui/index.ts` ni
 * `public-api.ts`, así que sigue sin ser parte de la API pública de
 * `@solercia/ui`) que anima la entrada
 * de cada fila/tarjeta de `sol-data-table` con el MISMO contrato de tokens
 * y clases globales que `[solReveal]` (`@shared/lib` de la app boki-front):
 * `--sol-reveal-index` (stagger), `.sol-reveal-in`/`.sol-reveal-in--replay`
 * (definidas junto a los keyframes en el `styles.css` del consumidor,
 * dirigidas por `component.motion.*` del tema).
 *
 * La lib NO importa `SolRevealDirective` de la app — eso invertiría la
 * regla de dependencia (una librería no depende de quien la consume). Esta
 * es el punto de extensión OCP que restaura la paridad visual del widget
 * local borrado en PR7a (T51) sin acoplar `sol-data-table` a boki-front:
 * la lib reimplementa el mismo contrato (mismas clases/tokens), agnóstica
 * de qué app lo consume. Ver 4R de PR7 (11-a-solercia-ui), WARNING-1.
 *
 * Nota de mantenimiento: hay duplicación intencional con
 * `src/shared/lib/reveal.directive.ts` (boki-front) — un futuro candidato
 * a extraer sería mover `SolRevealDirective` a `@solercia/ui` para que
 * ambos consuman una única implementación; queda fuera de esta corrección
 * (fuera de alcance de PR7).
 */
class RowRevealDirective {
    host = inject(ElementRef);
    destroyRef = inject(DestroyRef);
    /** Apaga el efecto por completo (sin observer, sin ocultar el elemento). */
    solRowReveal = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "solRowReveal" }] : /* istanbul ignore next */ []));
    /** Índice del stagger: retrasa la entrada índice × tokens de duración. */
    solRowRevealIndex = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "solRowRevealIndex" }] : /* istanbul ignore next */ []));
    /** Valor arbitrario: cada cambio re-dispara la animación en filas ya reveladas. */
    solRowRevealReplay = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "solRowRevealReplay" }] : /* istanbul ignore next */ []));
    observer = null;
    revealed = false;
    altKeyframe = false;
    constructor() {
        effect(() => {
            this.host.nativeElement.style.setProperty('--sol-reveal-index', String(this.solRowRevealIndex()));
        });
        let initial = true;
        effect(() => {
            this.solRowRevealReplay();
            if (initial) {
                initial = false;
                return;
            }
            if (this.solRowReveal() && this.revealed) {
                this.replay();
            }
        });
    }
    ngOnInit() {
        if (!this.solRowReveal() || typeof IntersectionObserver === 'undefined') {
            return;
        }
        this.host.nativeElement.style.opacity = '0';
        this.observer = new IntersectionObserver(entries => {
            if (entries.some(entry => entry.isIntersecting)) {
                this.reveal();
            }
        }, { threshold: 0.05 });
        this.observer.observe(this.host.nativeElement);
        this.destroyRef.onDestroy(() => this.disconnect());
    }
    reveal() {
        this.disconnect();
        const element = this.host.nativeElement;
        element.style.removeProperty('opacity');
        element.classList.add('sol-reveal-in');
        this.revealed = true;
    }
    replay() {
        const element = this.host.nativeElement;
        this.altKeyframe = !this.altKeyframe;
        if (this.altKeyframe) {
            const name = getComputedStyle(element).getPropertyValue('--sol-reveal-name').trim() || 'solRevealFade';
            element.style.setProperty('--sol-reveal-name-b', `${name}B`);
            element.classList.add('sol-reveal-in--replay');
        }
        else {
            element.classList.remove('sol-reveal-in--replay');
        }
    }
    disconnect() {
        this.observer?.disconnect();
        this.observer = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: RowRevealDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.0.6", type: RowRevealDirective, isStandalone: true, selector: "[solRowReveal]", inputs: { solRowReveal: { classPropertyName: "solRowReveal", publicName: "solRowReveal", isSignal: true, isRequired: false, transformFunction: null }, solRowRevealIndex: { classPropertyName: "solRowRevealIndex", publicName: "solRowRevealIndex", isSignal: true, isRequired: false, transformFunction: null }, solRowRevealReplay: { classPropertyName: "solRowRevealReplay", publicName: "solRowRevealReplay", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: RowRevealDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[solRowReveal]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { solRowReveal: [{ type: i0.Input, args: [{ isSignal: true, alias: "solRowReveal", required: false }] }], solRowRevealIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "solRowRevealIndex", required: false }] }], solRowRevealReplay: [{ type: i0.Input, args: [{ isSignal: true, alias: "solRowRevealReplay", required: false }] }] } });
/**
 * Tabla de datos genérica dirigida por columnas: búsqueda, orden, paginación,
 * estado de carga (skeleton), estado vacío y acciones por fila. En viewport
 * móvil colapsa cada fila a un resumen expandible (sin scroll horizontal)
 * cuando el tema activo lo prefiere (`component.table.mobile: "collapse"`).
 *
 * Componente presentacional: no conoce dominio. Las acciones no genéricas se
 * proyectan por el slot `#rowActions` (TemplateRef que recibe la fila).
 * Tematizado con `var(--sol-*)` — soporta light y dark.
 */
class SolDataTableComponent {
    themeService = inject(ThemeService);
    data = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    columns = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    /**
     * Estado de carga de la fuente de datos: sustituye el cuerpo por filas
     * skeleton tokenizadas y oculta la paginación mientras esté activo.
     */
    loading = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    searchPlaceholder = input('Buscar...', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchPlaceholder" }] : /* istanbul ignore next */ []));
    emptyMessage = input('No hay datos disponibles', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    paginated = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paginated" }] : /* istanbul ignore next */ []));
    showToolbar = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showToolbar" }] : /* istanbul ignore next */ []));
    filterPosition = input('left', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterPosition" }] : /* istanbul ignore next */ []));
    showActions = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showActions" }] : /* istanbul ignore next */ []));
    showEditAction = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showEditAction" }] : /* istanbul ignore next */ []));
    showDeleteAction = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showDeleteAction" }] : /* istanbul ignore next */ []));
    trackByKey = input('id', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trackByKey" }] : /* istanbul ignore next */ []));
    /** Encabezado de la columna de acciones. */
    actionsLabel = input('Acciones', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "actionsLabel" }] : /* istanbul ignore next */ []));
    /**
     * aria-label del botón ▶ de expansión de fila en el modo móvil. El default
     * se alinea con el texto de la clave i18n `shared.table.toggleDetails`
     * para que cualquier consumidor que no lo sobreescriba (vía
     * `[toggleDetailsLabel]`) obtenga el texto correcto sin necesidad de
     * traducción explícita.
     */
    toggleDetailsLabel = input('Mostrar u ocultar el detalle de la fila', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toggleDetailsLabel" }] : /* istanbul ignore next */ []));
    /**
     * Activa la animación de entrada (`solRowReveal`, ver directiva interna
     * arriba) en cada fila/tarjeta. Default `true`: preserva el
     * comportamiento visual del widget local que este componente reemplazó
     * (PR7a/T51) sin requerir cambios en los consumidores existentes — el
     * intensity "none"/`prefers-reduced-motion` del tema ya neutraliza el
     * efecto (duración ~1ms, distancia 0) para quien no lo quiera, sin
     * necesidad de apagar este input.
     */
    rowReveal = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowReveal" }] : /* istanbul ignore next */ []));
    editClicked = output();
    deleteClicked = output();
    /**
     * Plantilla de acciones por fila proyectada con `#rowActions`. Recibe la fila
     * como `$implicit`. Cuando existe, reemplaza los botones editar/eliminar por
     * defecto: aquí van las acciones específicas del dominio del consumidor.
     */
    rowActionsTemplate = contentChild('rowActions', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowActionsTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Carga "estirada" a un mínimo visible (anti-flash): con un backend rápido
     * `loading` se apaga antes de que el skeleton se perciba. `loadingVisible`
     * mantiene el skeleton un instante mínimo — es lo que consume el template.
     */
    loadingVisible = stretchLoading(this.loading);
    searchTerm = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []));
    currentPage = signal(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []));
    pageSize = signal(10, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pageSize" }] : /* istanbul ignore next */ []));
    sortKey = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortKey" }] : /* istanbul ignore next */ []));
    sortDirection = signal('asc', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortDirection" }] : /* istanbul ignore next */ []));
    /**
     * Clave de replay de `solRowReveal`: cambia con cualquier búsqueda, orden
     * o paginación — reinicia la animación de entrada de las filas visibles
     * (paridad con el widget local: `solRevealReplay` sobre el mismo filtro).
     */
    revealReplayKey = computed(() => `${this.searchTerm()}:${this.sortKey()}:${this.sortDirection()}:${this.currentPage()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "revealReplayKey" }] : /* istanbul ignore next */ []));
    /** Señal reactiva de viewport móvil (breakpoint canónico 767px). */
    isMobileViewport = observeMobileViewport$1();
    /** Índices de las filas fantasma del estado de carga (7 filas fijas). */
    skeletonRows = [0, 1, 2, 3, 4, 5, 6];
    /**
     * Token aditivo `component.table.mobile` del ThemeFile activo.
     * "collapse" (default): filas colapsables sin scroll horizontal.
     * "scroll": conserva la tabla con overflow-x. El token ajusta la
     * preferencia — NUNCA la estructura del componente.
     */
    tableMobileMode = computed(() => {
        const file = this.themeService.activeTheme();
        const mode = this.themeService.isDark() ? 'dark' : 'light';
        return file?.modes?.[mode]?.component?.table?.mobile ?? 'collapse';
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableMobileMode" }] : /* istanbul ignore next */ []));
    /** El modo colapsado aplica solo en viewport móvil con preferencia "collapse". */
    mobileCollapse = computed(() => this.isMobileViewport() && this.tableMobileMode() === 'collapse', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mobileCollapse" }] : /* istanbul ignore next */ []));
    /** Filas expandidas del modo colapsado (por id de trackBy). */
    expandedRows = signal(new Set(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expandedRows" }] : /* istanbul ignore next */ []));
    /** Columna título de la fila colapsada = primera columna configurada. */
    mobileTitleCol = computed(() => this.columns()[0], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mobileTitleCol" }] : /* istanbul ignore next */ []));
    /** Columna del chip de estado = la marcada con `badge: true` (si existe). */
    mobileBadgeCol = computed(() => this.columns().find((col) => col.badge), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mobileBadgeCol" }] : /* istanbul ignore next */ []));
    /** Subdato = la segunda columna que no sea el chip de estado. */
    mobileSubtitleCol = computed(() => this.columns().find((col, index) => index > 0 && !col.badge), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mobileSubtitleCol" }] : /* istanbul ignore next */ []));
    /** Columnas ocultas en el colapso: todas menos título, subdato y chip. */
    mobileDetailCols = computed(() => {
        const title = this.mobileTitleCol();
        const subtitle = this.mobileSubtitleCol();
        const badge = this.mobileBadgeCol();
        return this.columns().filter((col) => col !== title && col !== subtitle && col !== badge);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mobileDetailCols" }] : /* istanbul ignore next */ []));
    filteredData = computed(() => {
        let result = [...this.data()];
        const term = this.searchTerm().toLowerCase();
        if (term) {
            result = result.filter((row) => this.columns().some((col) => String(this.resolveValue(row, col.key) ?? '').toLowerCase().includes(term)));
        }
        const key = this.sortKey();
        if (key) {
            const dir = this.sortDirection() === 'asc' ? 1 : -1;
            result.sort((a, b) => {
                const va = this.resolveValue(a, key);
                const vb = this.resolveValue(b, key);
                return va > vb ? dir : va < vb ? -dir : 0;
            });
        }
        return result;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredData" }] : /* istanbul ignore next */ []));
    pagedData = computed(() => {
        if (!this.paginated())
            return this.filteredData();
        const start = (this.currentPage() - 1) * this.pageSize();
        return this.filteredData().slice(start, start + this.pageSize());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pagedData" }] : /* istanbul ignore next */ []));
    resolveValue(row, key) {
        return key.split('.').reduce((obj, k) => (obj == null ? undefined : obj[k]), row) ?? '';
    }
    trackId(index, row) {
        const key = this.trackByKey();
        if (key) {
            const val = row[key];
            if (val !== undefined && val !== null && val !== '')
                return val;
        }
        return index;
    }
    /** Estado de expansión de una fila en el modo móvil colapsado. */
    isRowExpanded(id) {
        return this.expandedRows().has(id);
    }
    /** Expande/colapsa una fila del modo móvil colapsado. */
    toggleRow(id) {
        this.expandedRows.update((current) => {
            const next = new Set(current);
            if (next.has(id)) {
                next.delete(id);
            }
            else {
                next.add(id);
            }
            return next;
        });
    }
    onSearch(term) {
        this.searchTerm.set(term);
        this.currentPage.set(1);
        // Al filtrar, el detalle expandido pierde contexto — se colapsa todo.
        this.expandedRows.set(new Set());
    }
    onSort(key) {
        if (this.sortKey() === key) {
            this.sortDirection.update((d) => (d === 'asc' ? 'desc' : 'asc'));
        }
        else {
            this.sortKey.set(key);
            this.sortDirection.set('asc');
        }
    }
    onPageSizeChange(size) {
        this.pageSize.set(size);
        this.currentPage.set(1);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolDataTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolDataTableComponent, isStandalone: true, selector: "sol-data-table", inputs: { data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, searchPlaceholder: { classPropertyName: "searchPlaceholder", publicName: "searchPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, paginated: { classPropertyName: "paginated", publicName: "paginated", isSignal: true, isRequired: false, transformFunction: null }, showToolbar: { classPropertyName: "showToolbar", publicName: "showToolbar", isSignal: true, isRequired: false, transformFunction: null }, filterPosition: { classPropertyName: "filterPosition", publicName: "filterPosition", isSignal: true, isRequired: false, transformFunction: null }, showActions: { classPropertyName: "showActions", publicName: "showActions", isSignal: true, isRequired: false, transformFunction: null }, showEditAction: { classPropertyName: "showEditAction", publicName: "showEditAction", isSignal: true, isRequired: false, transformFunction: null }, showDeleteAction: { classPropertyName: "showDeleteAction", publicName: "showDeleteAction", isSignal: true, isRequired: false, transformFunction: null }, trackByKey: { classPropertyName: "trackByKey", publicName: "trackByKey", isSignal: true, isRequired: false, transformFunction: null }, actionsLabel: { classPropertyName: "actionsLabel", publicName: "actionsLabel", isSignal: true, isRequired: false, transformFunction: null }, toggleDetailsLabel: { classPropertyName: "toggleDetailsLabel", publicName: "toggleDetailsLabel", isSignal: true, isRequired: false, transformFunction: null }, rowReveal: { classPropertyName: "rowReveal", publicName: "rowReveal", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { editClicked: "editClicked", deleteClicked: "deleteClicked" }, queries: [{ propertyName: "rowActionsTemplate", first: true, predicate: ["rowActions"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <!-- Slot para filtros personalizados (fuera de la tarjeta) -->
    <div
      class="sol-data-table__filters"
      [style.justify-content]="filterPosition() === 'right' ? 'flex-end' : 'flex-start'"
    >
      <ng-content select="[tableFilters]" />
    </div>

    <div class="sol-data-table" [attr.aria-busy]="loadingVisible() || null">
      @if (showToolbar()) {
        <div class="sol-data-table__toolbar">
          <div class="sol-data-table__toolbar-left">
            <ng-content select="[tableActions]" />
          </div>
          <div class="sol-data-table__toolbar-right">
            <sol-search-input
              [placeholder]="searchPlaceholder()"
              (searchChange)="onSearch($event)"
            />
          </div>
        </div>
      }

      <!-- Acciones por fila compartidas entre el modo tabla y el modo móvil. -->
      <ng-template #rowActionButtons let-row>
        @if (rowActionsTemplate(); as tpl) {
          <ng-container *ngTemplateOutlet="tpl; context: { $implicit: row }" />
        } @else {
          <div class="sol-data-table__action-group">
            @if (showEditAction()) {
              <sol-button variant="ghost" size="sm" (clicked)="editClicked.emit(row)">
                <sol-icon name="edit" size="sm" />
              </sol-button>
            }
            @if (showDeleteAction()) {
              <sol-button variant="ghost" size="sm" (clicked)="deleteClicked.emit(row)">
                <sol-icon name="trash" size="sm" class="text-red-500" />
              </sol-button>
            }
          </div>
        }
      </ng-template>

      @if (mobileCollapse()) {
        <!-- Modo móvil colapsado: cada fila es [▶] título + subdato · chip de
             estado; el detalle despliega las columnas ocultas como pares
             clave/valor. -->
        @if (loadingVisible()) {
          <ul class="sol-data-table__cards">
            @for (i of skeletonRows; track i) {
              <li>
                <sol-skeleton variant="row" height="56px" />
              </li>
            }
          </ul>
        } @else {
          <ul class="sol-data-table__cards">
            @for (row of pagedData(); track trackId($index, row)) {
              <li
                class="sol-data-table__card"
                [solRowReveal]="rowReveal()"
                [solRowRevealIndex]="$index"
                [solRowRevealReplay]="revealReplayKey()"
              >
                <button
                  type="button"
                  class="sol-data-table__card-head"
                  [attr.aria-expanded]="isRowExpanded(trackId($index, row))"
                  [attr.aria-label]="toggleDetailsLabel()"
                  (click)="toggleRow(trackId($index, row))"
                  data-testid="fila-colapsada"
                >
                  <sol-icon
                    name="chevron-right"
                    size="sm"
                    class="sol-data-table__card-chevron"
                    [class.sol-data-table__card-chevron--open]="isRowExpanded(trackId($index, row))"
                  />
                  <span class="sol-data-table__card-main">
                    @if (mobileTitleCol(); as col) {
                      <span class="sol-data-table__card-title">
                        @if (col.cellTemplate) {
                          <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                        } @else {
                          {{ resolveValue(row, col.key) }}
                        }
                      </span>
                    }
                    @if (mobileSubtitleCol(); as col) {
                      <span class="sol-data-table__card-sub">
                        @if (col.cellTemplate) {
                          <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                        } @else {
                          {{ resolveValue(row, col.key) }}
                        }
                      </span>
                    }
                  </span>
                  @if (mobileBadgeCol(); as col) {
                    <span class="sol-data-table__card-chip">
                      @if (col.cellTemplate) {
                        <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                      } @else {
                        {{ resolveValue(row, col.key) }}
                      }
                    </span>
                  }
                </button>

                @if (isRowExpanded(trackId($index, row))) {
                  <div class="sol-data-table__card-details" data-testid="detalle-fila">
                    <dl class="sol-data-table__card-kv-list">
                      @for (col of mobileDetailCols(); track col.key) {
                        <div class="sol-data-table__card-kv">
                          <dt>{{ col.label }}</dt>
                          <dd>
                            @if (col.cellTemplate) {
                              <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                            } @else {
                              {{ resolveValue(row, col.key) }}
                            }
                          </dd>
                        </div>
                      }
                    </dl>
                    @if (showActions()) {
                      <div class="sol-data-table__card-actions">
                        <ng-container *ngTemplateOutlet="rowActionButtons; context: { $implicit: row }" />
                      </div>
                    }
                  </div>
                }
              </li>
            } @empty {
              <li class="sol-data-table__empty">{{ emptyMessage() }}</li>
            }
          </ul>
        }
      } @else {
        <div class="sol-data-table__wrapper">
          <table class="sol-data-table__table">
            <thead>
              <tr>
                @for (col of columns(); track col.key) {
                  <th
                    class="sol-data-table__th"
                    [style.width]="col.width || 'auto'"
                    [class.sol-data-table__th--sortable]="col.sortable"
                    (click)="col.sortable ? onSort(col.key) : null"
                  >
                    {{ col.label }}
                    @if (col.sortable && sortKey() === col.key) {
                      <span class="sol-data-table__sort-icon">
                        {{ sortDirection() === 'asc' ? '↑' : '↓' }}
                      </span>
                    }
                  </th>
                }
                @if (showActions()) {
                  <th class="sol-data-table__th sol-data-table__th--actions">{{ actionsLabel() }}</th>
                }
              </tr>
            </thead>
            <tbody>
              @if (loadingVisible()) {
                @for (i of skeletonRows; track i) {
                  <tr class="sol-data-table__tr">
                    <td class="sol-data-table__td" [attr.colspan]="columns().length + (showActions() ? 1 : 0)">
                      <sol-skeleton variant="row" />
                    </td>
                  </tr>
                }
              } @else {
                @for (row of pagedData(); track trackId($index, row)) {
                  <tr
                    class="sol-data-table__tr"
                    [solRowReveal]="rowReveal()"
                    [solRowRevealIndex]="$index"
                    [solRowRevealReplay]="revealReplayKey()"
                  >
                    @for (col of columns(); track col.key) {
                      <td class="sol-data-table__td">
                        @if (col.cellTemplate) {
                          <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                        } @else {
                          {{ resolveValue(row, col.key) }}
                        }
                      </td>
                    }
                    @if (showActions()) {
                      <td class="sol-data-table__td sol-data-table__td--actions">
                        <ng-container *ngTemplateOutlet="rowActionButtons; context: { $implicit: row }" />
                      </td>
                    }
                  </tr>
                } @empty {
                  <tr>
                    <td class="sol-data-table__empty" [attr.colspan]="columns().length + (showActions() ? 1 : 0)">
                      {{ emptyMessage() }}
                    </td>
                  </tr>
                }
              }
            </tbody>
          </table>
        </div>
      }
    </div>

    @if (paginated() && !loadingVisible()) {
      <div class="sol-data-table__footer">
        <sol-pagination
          [totalItems]="filteredData().length"
          [pageSize]="pageSize()"
          [currentPage]="currentPage()"
          (pageChanged)="currentPage.set($event)"
          (pageSizeChanged)="onPageSizeChange($event)"
        />
      </div>
    }
  `, isInline: true, styles: [".sol-data-table__filters{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px}.sol-data-table__filters:empty{display:none}.sol-data-table{background:var(--sol-card-bg, var(--sol-bg-surface, #fff));border:var(--sol-card-border, 1px solid var(--sol-border-color-default, #E2E8F0));border-radius:var(--sol-card-radius, var(--sol-border-radius-lg, 12px));box-shadow:var(--sol-card-shadow, var(--sol-shadow-sm));overflow:hidden}.sol-data-table__toolbar{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;gap:12px;border-bottom:1px solid var(--sol-border-color-default, #E2E8F0)}.sol-data-table__toolbar-left{display:flex;align-items:center;gap:8px}.sol-data-table__toolbar-right{display:flex;align-items:center;gap:8px;min-width:200px;max-width:280px}.sol-data-table__wrapper{overflow-x:auto}.sol-data-table__table{width:100%;border-collapse:collapse}.sol-data-table__th{padding:10px 16px;font-size:var(--sol-font-size-xs, 11px);font-weight:600;color:var(--sol-color-text-muted, #64748B);text-transform:uppercase;letter-spacing:.05em;text-align:left;background:color-mix(in srgb,var(--sol-border-color-default, #E2E8F0) 30%,transparent);border-bottom:1px solid var(--sol-border-color-default, #E2E8F0);white-space:nowrap;-webkit-user-select:none;user-select:none}.sol-data-table__th--sortable{cursor:pointer;transition:color .15s}.sol-data-table__th--sortable:hover{color:var(--sol-color-text-primary, #0F172A)}.sol-data-table__th--actions{width:100px;text-align:center}.sol-data-table__sort-icon{margin-left:4px;font-size:12px;color:var(--sol-color-primary, #2563EB)}.sol-data-table__tr{border-bottom:1px solid var(--sol-border-color-default, #E2E8F0);transition:background-color .15s}.sol-data-table__tr:last-child .sol-data-table__td{border-bottom:none}.sol-data-table__tr:hover{background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 3%,transparent)}.sol-data-table__td{padding:12px 16px;font-size:var(--sol-font-size-sm, 13px);color:var(--sol-color-text-primary, #0F172A);vertical-align:middle}.sol-data-table__td--actions{text-align:center}.sol-data-table__action-group{display:flex;align-items:center;justify-content:center;gap:4px}.sol-data-table__empty{padding:40px 16px;text-align:center;font-size:var(--sol-font-size-sm, 13px);color:var(--sol-color-text-muted, #94A3B8)}.sol-data-table__footer{padding:8px 4px 0}.sol-data-table__cards{list-style:none;margin:0;padding:0}.sol-data-table__card{border-bottom:1px solid var(--sol-border-color-default, #E2E8F0)}.sol-data-table__card:last-child{border-bottom:none}.sol-data-table__card-head{display:flex;align-items:center;gap:10px;width:100%;min-width:0;padding:12px;border:none;background:transparent;font:inherit;text-align:left;color:var(--sol-color-text-primary, #0F172A);cursor:pointer;box-sizing:border-box}.sol-data-table__card-chevron{flex-shrink:0;color:var(--sol-color-text-muted, #94A3B8);transition:transform var(--sol-dur-fast, .12s) var(--sol-ease, ease)}.sol-data-table__card-chevron--open{transform:rotate(90deg)}.sol-data-table__card-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.sol-data-table__card-title{font-size:var(--sol-font-size-sm, 13px);font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-data-table__card-sub{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-text-muted, #64748B);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-data-table__card-chip{flex-shrink:0;max-width:40%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:2px 10px;border-radius:var(--sol-border-radius-full, 9999px);font-size:11px;font-weight:600;color:var(--sol-color-primary, #2563EB);background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 12%,transparent)}.sol-data-table__card-details{padding:0 12px 12px 34px;animation:sol-data-table-reveal var(--sol-dur-base, .24s) var(--sol-ease-entrance, ease-out) backwards}@keyframes sol-data-table-reveal{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}.sol-data-table__card-kv-list{margin:0;display:flex;flex-direction:column;gap:6px}.sol-data-table__card-kv{display:flex;gap:8px;align-items:baseline;min-width:0}.sol-data-table__card-kv dt{flex-shrink:0;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--sol-color-text-muted, #64748B)}.sol-data-table__card-kv dd{margin:0;min-width:0;font-size:var(--sol-font-size-sm, 13px);color:var(--sol-color-text-primary, #0F172A);overflow-wrap:anywhere}.sol-data-table__card-actions{display:flex;justify-content:flex-end;gap:4px;margin-top:10px}@media(max-width:767px){.sol-data-table__toolbar{flex-wrap:wrap}.sol-data-table__toolbar-right{flex:1;min-width:0;max-width:none}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SolSearchInputComponent, selector: "sol-search-input", inputs: ["placeholder"], outputs: ["searchChange"] }, { kind: "component", type: SolPaginationComponent, selector: "sol-pagination", inputs: ["totalItems", "pageSize", "currentPage", "pageSizeOptions"], outputs: ["pageChanged", "pageSizeChanged"] }, { kind: "component", type: SolButtonComponent, selector: "sol-button", inputs: ["variant", "size", "disabled", "type", "loading"], outputs: ["clicked"] }, { kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }, { kind: "component", type: SolSkeletonComponent, selector: "sol-skeleton", inputs: ["variant", "width", "height", "aspectRatio", "count"] }, { kind: "directive", type: RowRevealDirective, selector: "[solRowReveal]", inputs: ["solRowReveal", "solRowRevealIndex", "solRowRevealReplay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolDataTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-data-table', standalone: true, imports: [
                        NgTemplateOutlet,
                        SolSearchInputComponent,
                        SolPaginationComponent,
                        SolButtonComponent,
                        SolIconComponent,
                        SolSkeletonComponent,
                        RowRevealDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <!-- Slot para filtros personalizados (fuera de la tarjeta) -->
    <div
      class="sol-data-table__filters"
      [style.justify-content]="filterPosition() === 'right' ? 'flex-end' : 'flex-start'"
    >
      <ng-content select="[tableFilters]" />
    </div>

    <div class="sol-data-table" [attr.aria-busy]="loadingVisible() || null">
      @if (showToolbar()) {
        <div class="sol-data-table__toolbar">
          <div class="sol-data-table__toolbar-left">
            <ng-content select="[tableActions]" />
          </div>
          <div class="sol-data-table__toolbar-right">
            <sol-search-input
              [placeholder]="searchPlaceholder()"
              (searchChange)="onSearch($event)"
            />
          </div>
        </div>
      }

      <!-- Acciones por fila compartidas entre el modo tabla y el modo móvil. -->
      <ng-template #rowActionButtons let-row>
        @if (rowActionsTemplate(); as tpl) {
          <ng-container *ngTemplateOutlet="tpl; context: { $implicit: row }" />
        } @else {
          <div class="sol-data-table__action-group">
            @if (showEditAction()) {
              <sol-button variant="ghost" size="sm" (clicked)="editClicked.emit(row)">
                <sol-icon name="edit" size="sm" />
              </sol-button>
            }
            @if (showDeleteAction()) {
              <sol-button variant="ghost" size="sm" (clicked)="deleteClicked.emit(row)">
                <sol-icon name="trash" size="sm" class="text-red-500" />
              </sol-button>
            }
          </div>
        }
      </ng-template>

      @if (mobileCollapse()) {
        <!-- Modo móvil colapsado: cada fila es [▶] título + subdato · chip de
             estado; el detalle despliega las columnas ocultas como pares
             clave/valor. -->
        @if (loadingVisible()) {
          <ul class="sol-data-table__cards">
            @for (i of skeletonRows; track i) {
              <li>
                <sol-skeleton variant="row" height="56px" />
              </li>
            }
          </ul>
        } @else {
          <ul class="sol-data-table__cards">
            @for (row of pagedData(); track trackId($index, row)) {
              <li
                class="sol-data-table__card"
                [solRowReveal]="rowReveal()"
                [solRowRevealIndex]="$index"
                [solRowRevealReplay]="revealReplayKey()"
              >
                <button
                  type="button"
                  class="sol-data-table__card-head"
                  [attr.aria-expanded]="isRowExpanded(trackId($index, row))"
                  [attr.aria-label]="toggleDetailsLabel()"
                  (click)="toggleRow(trackId($index, row))"
                  data-testid="fila-colapsada"
                >
                  <sol-icon
                    name="chevron-right"
                    size="sm"
                    class="sol-data-table__card-chevron"
                    [class.sol-data-table__card-chevron--open]="isRowExpanded(trackId($index, row))"
                  />
                  <span class="sol-data-table__card-main">
                    @if (mobileTitleCol(); as col) {
                      <span class="sol-data-table__card-title">
                        @if (col.cellTemplate) {
                          <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                        } @else {
                          {{ resolveValue(row, col.key) }}
                        }
                      </span>
                    }
                    @if (mobileSubtitleCol(); as col) {
                      <span class="sol-data-table__card-sub">
                        @if (col.cellTemplate) {
                          <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                        } @else {
                          {{ resolveValue(row, col.key) }}
                        }
                      </span>
                    }
                  </span>
                  @if (mobileBadgeCol(); as col) {
                    <span class="sol-data-table__card-chip">
                      @if (col.cellTemplate) {
                        <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                      } @else {
                        {{ resolveValue(row, col.key) }}
                      }
                    </span>
                  }
                </button>

                @if (isRowExpanded(trackId($index, row))) {
                  <div class="sol-data-table__card-details" data-testid="detalle-fila">
                    <dl class="sol-data-table__card-kv-list">
                      @for (col of mobileDetailCols(); track col.key) {
                        <div class="sol-data-table__card-kv">
                          <dt>{{ col.label }}</dt>
                          <dd>
                            @if (col.cellTemplate) {
                              <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                            } @else {
                              {{ resolveValue(row, col.key) }}
                            }
                          </dd>
                        </div>
                      }
                    </dl>
                    @if (showActions()) {
                      <div class="sol-data-table__card-actions">
                        <ng-container *ngTemplateOutlet="rowActionButtons; context: { $implicit: row }" />
                      </div>
                    }
                  </div>
                }
              </li>
            } @empty {
              <li class="sol-data-table__empty">{{ emptyMessage() }}</li>
            }
          </ul>
        }
      } @else {
        <div class="sol-data-table__wrapper">
          <table class="sol-data-table__table">
            <thead>
              <tr>
                @for (col of columns(); track col.key) {
                  <th
                    class="sol-data-table__th"
                    [style.width]="col.width || 'auto'"
                    [class.sol-data-table__th--sortable]="col.sortable"
                    (click)="col.sortable ? onSort(col.key) : null"
                  >
                    {{ col.label }}
                    @if (col.sortable && sortKey() === col.key) {
                      <span class="sol-data-table__sort-icon">
                        {{ sortDirection() === 'asc' ? '↑' : '↓' }}
                      </span>
                    }
                  </th>
                }
                @if (showActions()) {
                  <th class="sol-data-table__th sol-data-table__th--actions">{{ actionsLabel() }}</th>
                }
              </tr>
            </thead>
            <tbody>
              @if (loadingVisible()) {
                @for (i of skeletonRows; track i) {
                  <tr class="sol-data-table__tr">
                    <td class="sol-data-table__td" [attr.colspan]="columns().length + (showActions() ? 1 : 0)">
                      <sol-skeleton variant="row" />
                    </td>
                  </tr>
                }
              } @else {
                @for (row of pagedData(); track trackId($index, row)) {
                  <tr
                    class="sol-data-table__tr"
                    [solRowReveal]="rowReveal()"
                    [solRowRevealIndex]="$index"
                    [solRowRevealReplay]="revealReplayKey()"
                  >
                    @for (col of columns(); track col.key) {
                      <td class="sol-data-table__td">
                        @if (col.cellTemplate) {
                          <ng-container *ngTemplateOutlet="col.cellTemplate; context: { $implicit: resolveValue(row, col.key), row: row }" />
                        } @else {
                          {{ resolveValue(row, col.key) }}
                        }
                      </td>
                    }
                    @if (showActions()) {
                      <td class="sol-data-table__td sol-data-table__td--actions">
                        <ng-container *ngTemplateOutlet="rowActionButtons; context: { $implicit: row }" />
                      </td>
                    }
                  </tr>
                } @empty {
                  <tr>
                    <td class="sol-data-table__empty" [attr.colspan]="columns().length + (showActions() ? 1 : 0)">
                      {{ emptyMessage() }}
                    </td>
                  </tr>
                }
              }
            </tbody>
          </table>
        </div>
      }
    </div>

    @if (paginated() && !loadingVisible()) {
      <div class="sol-data-table__footer">
        <sol-pagination
          [totalItems]="filteredData().length"
          [pageSize]="pageSize()"
          [currentPage]="currentPage()"
          (pageChanged)="currentPage.set($event)"
          (pageSizeChanged)="onPageSizeChange($event)"
        />
      </div>
    }
  `, styles: [".sol-data-table__filters{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px}.sol-data-table__filters:empty{display:none}.sol-data-table{background:var(--sol-card-bg, var(--sol-bg-surface, #fff));border:var(--sol-card-border, 1px solid var(--sol-border-color-default, #E2E8F0));border-radius:var(--sol-card-radius, var(--sol-border-radius-lg, 12px));box-shadow:var(--sol-card-shadow, var(--sol-shadow-sm));overflow:hidden}.sol-data-table__toolbar{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;gap:12px;border-bottom:1px solid var(--sol-border-color-default, #E2E8F0)}.sol-data-table__toolbar-left{display:flex;align-items:center;gap:8px}.sol-data-table__toolbar-right{display:flex;align-items:center;gap:8px;min-width:200px;max-width:280px}.sol-data-table__wrapper{overflow-x:auto}.sol-data-table__table{width:100%;border-collapse:collapse}.sol-data-table__th{padding:10px 16px;font-size:var(--sol-font-size-xs, 11px);font-weight:600;color:var(--sol-color-text-muted, #64748B);text-transform:uppercase;letter-spacing:.05em;text-align:left;background:color-mix(in srgb,var(--sol-border-color-default, #E2E8F0) 30%,transparent);border-bottom:1px solid var(--sol-border-color-default, #E2E8F0);white-space:nowrap;-webkit-user-select:none;user-select:none}.sol-data-table__th--sortable{cursor:pointer;transition:color .15s}.sol-data-table__th--sortable:hover{color:var(--sol-color-text-primary, #0F172A)}.sol-data-table__th--actions{width:100px;text-align:center}.sol-data-table__sort-icon{margin-left:4px;font-size:12px;color:var(--sol-color-primary, #2563EB)}.sol-data-table__tr{border-bottom:1px solid var(--sol-border-color-default, #E2E8F0);transition:background-color .15s}.sol-data-table__tr:last-child .sol-data-table__td{border-bottom:none}.sol-data-table__tr:hover{background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 3%,transparent)}.sol-data-table__td{padding:12px 16px;font-size:var(--sol-font-size-sm, 13px);color:var(--sol-color-text-primary, #0F172A);vertical-align:middle}.sol-data-table__td--actions{text-align:center}.sol-data-table__action-group{display:flex;align-items:center;justify-content:center;gap:4px}.sol-data-table__empty{padding:40px 16px;text-align:center;font-size:var(--sol-font-size-sm, 13px);color:var(--sol-color-text-muted, #94A3B8)}.sol-data-table__footer{padding:8px 4px 0}.sol-data-table__cards{list-style:none;margin:0;padding:0}.sol-data-table__card{border-bottom:1px solid var(--sol-border-color-default, #E2E8F0)}.sol-data-table__card:last-child{border-bottom:none}.sol-data-table__card-head{display:flex;align-items:center;gap:10px;width:100%;min-width:0;padding:12px;border:none;background:transparent;font:inherit;text-align:left;color:var(--sol-color-text-primary, #0F172A);cursor:pointer;box-sizing:border-box}.sol-data-table__card-chevron{flex-shrink:0;color:var(--sol-color-text-muted, #94A3B8);transition:transform var(--sol-dur-fast, .12s) var(--sol-ease, ease)}.sol-data-table__card-chevron--open{transform:rotate(90deg)}.sol-data-table__card-main{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.sol-data-table__card-title{font-size:var(--sol-font-size-sm, 13px);font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-data-table__card-sub{font-size:var(--sol-font-size-sm, 12px);color:var(--sol-color-text-muted, #64748B);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sol-data-table__card-chip{flex-shrink:0;max-width:40%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:2px 10px;border-radius:var(--sol-border-radius-full, 9999px);font-size:11px;font-weight:600;color:var(--sol-color-primary, #2563EB);background:color-mix(in srgb,var(--sol-color-primary, #2563EB) 12%,transparent)}.sol-data-table__card-details{padding:0 12px 12px 34px;animation:sol-data-table-reveal var(--sol-dur-base, .24s) var(--sol-ease-entrance, ease-out) backwards}@keyframes sol-data-table-reveal{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}.sol-data-table__card-kv-list{margin:0;display:flex;flex-direction:column;gap:6px}.sol-data-table__card-kv{display:flex;gap:8px;align-items:baseline;min-width:0}.sol-data-table__card-kv dt{flex-shrink:0;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--sol-color-text-muted, #64748B)}.sol-data-table__card-kv dd{margin:0;min-width:0;font-size:var(--sol-font-size-sm, 13px);color:var(--sol-color-text-primary, #0F172A);overflow-wrap:anywhere}.sol-data-table__card-actions{display:flex;justify-content:flex-end;gap:4px;margin-top:10px}@media(max-width:767px){.sol-data-table__toolbar{flex-wrap:wrap}.sol-data-table__toolbar-right{flex:1;min-width:0;max-width:none}}\n"] }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], searchPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchPlaceholder", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], paginated: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginated", required: false }] }], showToolbar: [{ type: i0.Input, args: [{ isSignal: true, alias: "showToolbar", required: false }] }], filterPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPosition", required: false }] }], showActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showActions", required: false }] }], showEditAction: [{ type: i0.Input, args: [{ isSignal: true, alias: "showEditAction", required: false }] }], showDeleteAction: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDeleteAction", required: false }] }], trackByKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "trackByKey", required: false }] }], actionsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "actionsLabel", required: false }] }], toggleDetailsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "toggleDetailsLabel", required: false }] }], rowReveal: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowReveal", required: false }] }], editClicked: [{ type: i0.Output, args: ["editClicked"] }], deleteClicked: [{ type: i0.Output, args: ["deleteClicked"] }], rowActionsTemplate: [{ type: i0.ContentChild, args: ['rowActions', { isSignal: true }] }] } });
/**
 * "Estira" una señal de carga a un tiempo mínimo visible (patrón anti-flash).
 * Con un backend rápido `loading` pasa a `false` en pocos ms y el skeleton
 * parpadea imperceptiblemente; este helper lo mantiene visible al menos
 * `minMs` desde que se encendió, sin agregar latencia real a los datos.
 * Debe invocarse en contexto de inyección (inicializador de campo).
 */
function stretchLoading(source, minMs = 450) {
    const visible = signal(source(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    const destroyRef = inject(DestroyRef);
    let onSince = 0;
    let timer = null;
    const clear = () => {
        if (timer !== null) {
            clearTimeout(timer);
            timer = null;
        }
    };
    effect(() => {
        const loading = source();
        clear();
        if (loading) {
            onSince = Date.now();
            visible.set(true);
            return;
        }
        const elapsed = Date.now() - onSince;
        if (elapsed >= minMs) {
            visible.set(false);
        }
        else {
            timer = setTimeout(() => {
                visible.set(false);
                timer = null;
            }, minMs - elapsed);
        }
    });
    destroyRef.onDestroy(clear);
    return computed(() => visible());
}
/** Ancho canónico bajo el cual la tabla adopta su comportamiento móvil. */
const MOBILE_MEDIA_QUERY$1 = '(max-width: 767px)';
/**
 * Señal booleana reactiva al viewport móvil. Debe invocarse en contexto de
 * inyección (inicializador de campo): usa `DestroyRef` para retirar el
 * listener. Guarda para jsdom/SSR: sin `matchMedia` queda en `false`
 * (comportamiento desktop).
 */
function observeMobileViewport$1() {
    const destroyRef = inject(DestroyRef);
    const matches = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "matches" }] : /* istanbul ignore next */ []));
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
        return matches.asReadonly();
    }
    const mediaQueryList = window.matchMedia(MOBILE_MEDIA_QUERY$1);
    matches.set(mediaQueryList.matches);
    if (typeof mediaQueryList.addEventListener === 'function') {
        const onChange = (event) => matches.set(event.matches);
        mediaQueryList.addEventListener('change', onChange);
        destroyRef.onDestroy(() => mediaQueryList.removeEventListener('change', onChange));
    }
    return matches.asReadonly();
}

const PALETTE_SIZE = 8;
/**
 * Hash determinista (multiplicador 31, estilo `String.hashCode` de Java) de
 * una semilla a un índice `[0, paletteSize)`. PURA: sin `Date`/`Math.random`/
 * estado — la misma semilla SIEMPRE produce el mismo índice, en cualquier
 * instancia y en cualquier momento (spec: solercia-ui-vocero-atoms#color
 * estable entre instancias).
 *
 * Tolera `null`/`undefined` (índice 0/neutral) sin lanzar: `input.required()`
 * de Angular solo exige que el BINDING exista en el template — no que el
 * valor resuelto sea no-nulo en runtime. Un `[name]="entidad.nombre"` mientras
 * la data todavía carga pasa `undefined` sin que Angular lo bloquee (NG0950
 * solo dispara si el binding falta por completo, no si resuelve a `undefined`).
 */
function hashToPaletteIndex(seed, paletteSize = PALETTE_SIZE) {
    if (seed == null)
        return 0;
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
        hash = (hash * 31 + seed.charCodeAt(i)) | 0; // |0 trunca a entero de 32 bits (overflow controlado)
    }
    return Math.abs(hash) % paletteSize;
}
/**
 * Iniciales a partir de un nombre: nombre compuesto → primera letra de la
 * primera y de la última palabra ("Ana Torres" → "AT"); una sola palabra →
 * sus 2 primeras letras; vacío/solo espacios → cadena vacía; `null`/
 * `undefined` (mismo motivo que `hashToPaletteIndex` arriba) → `'?'` como
 * placeholder visual explícito. PURA.
 *
 * Segmenta por CODE POINT (`[...palabra]`), no por UTF-16 code unit
 * (`charAt`/índice numérico): un nombre que empieza con un carácter fuera
 * del BMP (la mayoría de emoji) ocupa 2 code units — `charAt(0)` corta el
 * primero suelto y produce U+FFFD (replacement character) en vez de la
 * inicial completa.
 */
function computeInitials(name) {
    if (name == null)
        return '?';
    const parts = name.trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0)
        return '';
    if (parts.length === 1)
        return [...parts[0]].slice(0, 2).join('').toUpperCase();
    const firstLetter = [...parts[0]][0] ?? '';
    const lastLetter = [...parts[parts.length - 1]][0] ?? '';
    return (firstLetter + lastLetter).toUpperCase();
}
/**
 * `sol-avatar` — iniciales + color de fondo estable por hash del `name`,
 * elegido entre una paleta fija de 8 tonos desaturados (spec:
 * solercia-ui-vocero-atoms). Sin conocimiento de dominio: recibe un `name`
 * genérico (persona, empresa, lo que sea) — nunca un modelo de negocio.
 *
 * Sin texto que traducir: las iniciales se derivan del propio `name` (dato
 * del consumidor, no copia de UI), así que no hay i18n que resolver aquí.
 */
class SolAvatarComponent {
    /**
     * Nombre o identificador de entrada — determina iniciales y color.
     * Tipado `string | null | undefined` a propósito: `input.required()` exige
     * que el BINDING exista en el template, no que su valor ya esté resuelto
     * (p. ej. `[name]="entidad.nombre"` mientras `entidad` todavía carga).
     */
    name = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    /** URL de imagen opcional; si se da, reemplaza las iniciales. */
    imageUrl = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "imageUrl" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    initials = computed(() => computeInitials(this.name()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "initials" }] : /* istanbul ignore next */ []));
    paletteIndex = computed(() => hashToPaletteIndex(this.name()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paletteIndex" }] : /* istanbul ignore next */ []));
    hostClass = computed(() => `sol-avatar sol-avatar--${this.size()} sol-avatar--palette-${this.paletteIndex()}`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolAvatarComponent, isStandalone: true, selector: "sol-avatar", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, imageUrl: { classPropertyName: "imageUrl", publicName: "imageUrl", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "img" }, properties: { "class": "hostClass()", "attr.aria-label": "name() ?? initials()" } }, ngImport: i0, template: `
    @if (imageUrl(); as src) {
      <img class="sol-avatar__image" [src]="src" alt="" />
    } @else {
      <span class="sol-avatar__initials" aria-hidden="true">{{ initials() }}</span>
    }
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;border-radius:50%;font-family:var(--sol-font-family);font-weight:600;color:#fff;-webkit-user-select:none;user-select:none}:host.sol-avatar--sm{width:1.75rem;height:1.75rem;font-size:var(--sol-font-size-xs, .7rem)}:host.sol-avatar--md{width:2.5rem;height:2.5rem;font-size:var(--sol-font-size-sm, .875rem)}:host.sol-avatar--lg{width:3.5rem;height:3.5rem;font-size:var(--sol-font-size-base, 1rem)}.sol-avatar__image{width:100%;height:100%;object-fit:cover}:host.sol-avatar--palette-0{background:var(--sol-avatar-palette-0, #78716c)}:host.sol-avatar--palette-1{background:var(--sol-avatar-palette-1, #a8756c)}:host.sol-avatar--palette-2{background:var(--sol-avatar-palette-2, #a68a56)}:host.sol-avatar--palette-3{background:var(--sol-avatar-palette-3, #6b9080)}:host.sol-avatar--palette-4{background:var(--sol-avatar-palette-4, #5b8a8a)}:host.sol-avatar--palette-5{background:var(--sol-avatar-palette-5, #6b83a6)}:host.sol-avatar--palette-6{background:var(--sol-avatar-palette-6, #8a75a6)}:host.sol-avatar--palette-7{background:var(--sol-avatar-palette-7, #a6688a)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolAvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-avatar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        '[class]': 'hostClass()',
                        role: 'img',
                        '[attr.aria-label]': 'name() ?? initials()',
                    }, template: `
    @if (imageUrl(); as src) {
      <img class="sol-avatar__image" [src]="src" alt="" />
    } @else {
      <span class="sol-avatar__initials" aria-hidden="true">{{ initials() }}</span>
    }
  `, styles: [":host{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;border-radius:50%;font-family:var(--sol-font-family);font-weight:600;color:#fff;-webkit-user-select:none;user-select:none}:host.sol-avatar--sm{width:1.75rem;height:1.75rem;font-size:var(--sol-font-size-xs, .7rem)}:host.sol-avatar--md{width:2.5rem;height:2.5rem;font-size:var(--sol-font-size-sm, .875rem)}:host.sol-avatar--lg{width:3.5rem;height:3.5rem;font-size:var(--sol-font-size-base, 1rem)}.sol-avatar__image{width:100%;height:100%;object-fit:cover}:host.sol-avatar--palette-0{background:var(--sol-avatar-palette-0, #78716c)}:host.sol-avatar--palette-1{background:var(--sol-avatar-palette-1, #a8756c)}:host.sol-avatar--palette-2{background:var(--sol-avatar-palette-2, #a68a56)}:host.sol-avatar--palette-3{background:var(--sol-avatar-palette-3, #6b9080)}:host.sol-avatar--palette-4{background:var(--sol-avatar-palette-4, #5b8a8a)}:host.sol-avatar--palette-5{background:var(--sol-avatar-palette-5, #6b83a6)}:host.sol-avatar--palette-6{background:var(--sol-avatar-palette-6, #8a75a6)}:host.sol-avatar--palette-7{background:var(--sol-avatar-palette-7, #a6688a)}\n"] }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: true }] }], imageUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "imageUrl", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }] } });

/** Color CSS (`var(--sol-color-*)` con fallback) por tono — fuente única para toda la lib. */
const TONE_COLOR = {
    success: 'var(--sol-color-success, #10b981)',
    warning: 'var(--sol-color-warning, #f59e0b)',
    danger: 'var(--sol-color-danger, #ef4444)',
    info: 'var(--sol-color-info, #3b82f6)',
    neutral: 'var(--sol-color-text-muted, #94a3b8)',
};

/** Default del spec: éxito ≥80, advertencia ≥50, peligro <50. */
const DEFAULT_SCORE_THRESHOLDS = [
    { upTo: 50, tone: 'danger' },
    { upTo: 80, tone: 'warning' },
    { upTo: Infinity, tone: 'success' },
];
/**
 * Resuelve el tono de `score` contra `thresholds` (ordenados ascendente por
 * `upTo`): el primero cuyo `upTo` sea mayor que `score` gana; si ninguno lo
 * es, se usa el tono del último umbral. PURA — sin dependencias de Angular.
 */
function resolveScoreTone(score, thresholds) {
    const sorted = [...thresholds].sort((a, b) => a.upTo - b.upTo);
    const match = sorted.find((t) => score < t.upTo);
    return match?.tone ?? sorted[sorted.length - 1]?.tone ?? 'neutral';
}
/**
 * `sol-score-badge` — puntaje numérico con tono resuelto contra umbrales
 * configurables (spec: solercia-ui-vocero-atoms). Genérico: no sabe si el
 * puntaje viene de un lead, una corrida del laboratorio o cualquier otra
 * métrica — eso lo decide el consumidor vía `[value]`/`[thresholds]`.
 *
 * Estados especiales:
 *   - `pending=true` ("en curso"): la métrica aún se está calculando.
 *   - `value=null` ("sin dato"): no hay puntaje disponible todavía.
 * Ambos usan el tono neutral y un texto por clave i18n en vez del número.
 */
class SolScoreBadgeComponent {
    i18n = inject(SOL_I18N);
    /** Puntaje a mostrar; `null` = sin dato todavía. */
    value = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /** Escala del puntaje (default 100). Los umbrales siempre se evalúan en escala 0-100. */
    max = input(100, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    thresholds = input(DEFAULT_SCORE_THRESHOLDS, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "thresholds" }] : /* istanbul ignore next */ []));
    /** `true` mientras la métrica se está calculando (p. ej. corrida del laboratorio en curso). */
    pending = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pending" }] : /* istanbul ignore next */ []));
    /**
     * `true` cuando no hay puntaje utilizable: `value=null` (sin dato todavía)
     * O `value` es `NaN` (p. ej. una división 0/0 corriente arriba, o un
     * `parseFloat` fallido). Sin esta guarda, `NaN < umbral` es SIEMPRE `false`
     * y `resolveScoreTone` cae al último tono ("éxito") mostrando una insignia
     * verde con el texto literal "NaN".
     */
    hasNoData = computed(() => {
        const v = this.value();
        return v === null || Number.isNaN(v);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasNoData" }] : /* istanbul ignore next */ []));
    /** Puntaje normalizado a 0-100 para evaluar contra los umbrales (el texto mostrado usa el valor crudo). */
    normalizedValue = computed(() => {
        const v = this.value();
        if (v === null)
            return null;
        const m = this.max();
        return m > 0 ? (v / m) * 100 : v;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "normalizedValue" }] : /* istanbul ignore next */ []));
    tone = computed(() => {
        if (this.pending() || this.hasNoData())
            return 'neutral';
        return resolveScoreTone(this.normalizedValue(), this.thresholds());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []));
    displayText = computed(() => {
        this.i18n.activeLang();
        if (this.pending())
            return this.i18n.translate('shared.scoreBadge.pending');
        return this.hasNoData() ? this.i18n.translate('shared.scoreBadge.empty') : `${this.value()}`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []));
    hostStyles = computed(() => {
        const color = TONE_COLOR[this.tone()];
        return `background: color-mix(in srgb, ${color} 15%, transparent); color: ${color};`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostStyles" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolScoreBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolScoreBadgeComponent, isStandalone: true, selector: "sol-score-badge", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, thresholds: { classPropertyName: "thresholds", publicName: "thresholds", isSignal: true, isRequired: false, transformFunction: null }, pending: { classPropertyName: "pending", publicName: "pending", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <span class="sol-score-badge" [style]="hostStyles()">{{ displayText() }}</span>
  `, isInline: true, styles: [":host{display:inline-flex}.sol-score-badge{display:inline-flex;align-items:center;justify-content:center;min-width:2.5rem;padding:.125rem .625rem;border-radius:var(--sol-border-radius-full, 9999px);font-family:var(--sol-font-family);font-weight:600;font-size:var(--sol-font-size-sm, .8125rem);line-height:1.5;white-space:nowrap}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolScoreBadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-score-badge', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <span class="sol-score-badge" [style]="hostStyles()">{{ displayText() }}</span>
  `, styles: [":host{display:inline-flex}.sol-score-badge{display:inline-flex;align-items:center;justify-content:center;min-width:2.5rem;padding:.125rem .625rem;border-radius:var(--sol-border-radius-full, 9999px);font-family:var(--sol-font-family);font-weight:600;font-size:var(--sol-font-size-sm, .8125rem);line-height:1.5;white-space:nowrap}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], thresholds: [{ type: i0.Input, args: [{ isSignal: true, alias: "thresholds", required: false }] }], pending: [{ type: i0.Input, args: [{ isSignal: true, alias: "pending", required: false }] }] } });

/** PURA: signo del delta determina la dirección. `0` siempre es `'flat'`. */
function resolveTrendDirection(delta) {
    if (delta > 0)
        return 'up';
    if (delta < 0)
        return 'down';
    return 'flat';
}
/** Formato por defecto: signo explícito (`+5`, `-15`, `0`). PURA. */
function defaultTrendFormat(delta) {
    return delta > 0 ? `+${delta}` : `${delta}`;
}
const DIRECTION_ICON = {
    up: 'chevron-up',
    down: 'chevron-down',
};
/** `flat` es SIEMPRE neutral (delta 0 neutro); `up`/`down` se resuelven vía `invert`. */
const DIRECTION_TONE = {
    up: 'success',
    down: 'danger',
    flat: 'neutral',
};
function invertTone(tone) {
    if (tone === 'success')
        return 'danger';
    if (tone === 'danger')
        return 'success';
    return tone;
}
/**
 * `sol-trend` — delta con flecha (↑/↓/plano) y signo, comparando `current`
 * contra `previous` (spec: solercia-ui-vocero-atoms). Genérico: no sabe si
 * mide un score, ingresos o cualquier otra métrica.
 */
class SolTrendComponent {
    i18n = inject(SOL_I18N);
    /** Valor actual de la métrica. */
    current = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []));
    /** Valor previo a comparar; `null` = sin comparación disponible todavía. */
    previous = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previous" }] : /* istanbul ignore next */ []));
    /** `true` invierte la semántica de color: subir es malo (p. ej. tasa de abandono). */
    invert = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invert" }] : /* istanbul ignore next */ []));
    /** Formateador opcional del delta (p. ej. agregar "%"). Default: signo explícito. */
    format = input(defaultTrendFormat, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "format" }] : /* istanbul ignore next */ []));
    /**
     * `null` = "sin dato" (sin `previous` AÚN, o el delta resultó `NaN` — p. ej.
     * `current`/`previous` no numéricos corriente arriba). Sin esta guarda,
     * `resolveTrendDirection(NaN)` cae a `'flat'` mostrando el texto literal
     * "NaN" en vez del estado de "sin dato".
     */
    delta = computed(() => {
        const prev = this.previous();
        if (prev === null)
            return null;
        const d = this.current() - prev;
        return Number.isNaN(d) ? null : d;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "delta" }] : /* istanbul ignore next */ []));
    direction = computed(() => {
        const d = this.delta();
        return d === null ? 'flat' : resolveTrendDirection(d);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "direction" }] : /* istanbul ignore next */ []));
    tone = computed(() => {
        const base = DIRECTION_TONE[this.direction()];
        return this.invert() ? invertTone(base) : base;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []));
    toneColor = computed(() => TONE_COLOR[this.tone()], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toneColor" }] : /* istanbul ignore next */ []));
    iconName = computed(() => DIRECTION_ICON[this.direction()] ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconName" }] : /* istanbul ignore next */ []));
    displayText = computed(() => {
        this.i18n.activeLang();
        const d = this.delta();
        return d === null ? this.i18n.translate('shared.trend.noData') : this.format()(d);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []));
    ariaLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate(`shared.trend.${this.direction()}`);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTrendComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolTrendComponent, isStandalone: true, selector: "sol-trend", inputs: { current: { classPropertyName: "current", publicName: "current", isSignal: true, isRequired: true, transformFunction: null }, previous: { classPropertyName: "previous", publicName: "previous", isSignal: true, isRequired: false, transformFunction: null }, invert: { classPropertyName: "invert", publicName: "invert", isSignal: true, isRequired: false, transformFunction: null }, format: { classPropertyName: "format", publicName: "format", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <span class="sol-trend" [style.color]="toneColor()" [attr.aria-label]="ariaLabel()">
      @if (iconName(); as icon) {
        <sol-icon [name]="icon" size="sm" />
      }
      <span class="sol-trend__value">{{ displayText() }}</span>
    </span>
  `, isInline: true, styles: [":host{display:inline-flex}.sol-trend{display:inline-flex;align-items:center;gap:2px;font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, .8125rem);font-weight:600;line-height:1}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTrendComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-trend', standalone: true, imports: [SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <span class="sol-trend" [style.color]="toneColor()" [attr.aria-label]="ariaLabel()">
      @if (iconName(); as icon) {
        <sol-icon [name]="icon" size="sm" />
      }
      <span class="sol-trend__value">{{ displayText() }}</span>
    </span>
  `, styles: [":host{display:inline-flex}.sol-trend{display:inline-flex;align-items:center;gap:2px;font-family:var(--sol-font-family);font-size:var(--sol-font-size-sm, .8125rem);font-weight:600;line-height:1}\n"] }]
        }], propDecorators: { current: [{ type: i0.Input, args: [{ isSignal: true, alias: "current", required: true }] }], previous: [{ type: i0.Input, args: [{ isSignal: true, alias: "previous", required: false }] }], invert: [{ type: i0.Input, args: [{ isSignal: true, alias: "invert", required: false }] }], format: [{ type: i0.Input, args: [{ isSignal: true, alias: "format", required: false }] }] } });

/** Ícono del registry por estado — NUNCA SVG inline (spec: solercia-ui-vocero-atoms). */
const STATUS_ICON = {
    pending: 'clock',
    sent: 'check',
    delivered: 'double-check',
    read: 'double-check', // mismo ícono que delivered — la marca lo distingue por color (ver tone)
    failed: 'exclamation-triangle',
};
/** `read` usa el color de marca (primary); el resto, tonos neutros/semánticos. */
const STATUS_COLOR = {
    pending: 'var(--sol-color-text-muted, #94a3b8)',
    sent: 'var(--sol-color-text-muted, #94a3b8)',
    delivered: 'var(--sol-color-text-secondary, #64748b)',
    read: 'var(--sol-color-primary, #2563eb)',
    failed: 'var(--sol-color-danger, #ef4444)',
};
/**
 * `sol-message-status` — ticks de estado de un mensaje (spec:
 * solercia-ui-vocero-atoms), inspirado en el patrón de WhatsApp. Genérico:
 * no sabe qué es un "mensaje" de dominio, solo un estado de entrega.
 *
 * `read` reutiliza el MISMO ícono `double-check` que `delivered` — la
 * diferencia visual es el color (token de marca `--sol-color-primary`),
 * igual que WhatsApp distingue el doble-check gris del azul.
 */
class SolMessageStatusComponent {
    i18n = inject(SOL_I18N);
    status = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []));
    iconName = computed(() => STATUS_ICON[this.status()], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconName" }] : /* istanbul ignore next */ []));
    color = computed(() => STATUS_COLOR[this.status()], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    statusLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate(`shared.messageStatus.${this.status()}`);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "statusLabel" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolMessageStatusComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolMessageStatusComponent, isStandalone: true, selector: "sol-message-status", inputs: { status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    <span class="sol-message-status" role="img" [style.color]="color()" [attr.aria-label]="statusLabel()">
      <sol-icon [name]="iconName()" size="sm" />
    </span>
  `, isInline: true, styles: [":host{display:inline-flex}.sol-message-status{display:inline-flex;align-items:center}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolMessageStatusComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-message-status', standalone: true, imports: [SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <span class="sol-message-status" role="img" [style.color]="color()" [attr.aria-label]="statusLabel()">
      <sol-icon [name]="iconName()" size="sm" />
    </span>
  `, styles: [":host{display:inline-flex}.sol-message-status{display:inline-flex;align-items:center}\n"] }]
        }], propDecorators: { status: [{ type: i0.Input, args: [{ isSignal: true, alias: "status", required: true }] }] } });

/**
 * Motor de posicionamiento del timeline (spec: solercia-ui-timeline, design.md
 * D5) — generaliza a N niveles el cálculo `%` de `sprint-timeline` de
 * `gestion_proyectos`. PURO en su totalidad: sin Angular, sin DOM, sin
 * dependencias externas (spec#Sin dependencias externas).
 *
 * Robustez de entrada (lección del PR3 — CRITICAL de `sol-avatar`): TODAS las
 * funciones exportadas toleran `nodes` nulo/indefinido y fechas inválidas sin
 * lanzar — Angular no garantiza que un `input.required()` resuelva a un valor
 * no-nulo en runtime, y las fechas suelen venir de una API externa.
 */
const MIN_WIDTH_PCT = 2; // igual que sprint-timeline: barras mínimamente visibles
/** `string | Date | null | undefined` → epoch-ms, o `null` si falta o es inválida. */
function toValidTime(value) {
    if (value == null)
        return null;
    const date = value instanceof Date ? value : new Date(value);
    const time = date.getTime();
    return Number.isNaN(time) ? null : time;
}
/**
 * Rango PROPIO de un nodo (ambas fechas válidas Y `start <= end`), o `null`
 * si le falta alguna o vienen invertidas. Fechas invertidas (`start > end`)
 * se tratan como "sin fecha" — igual criterio que una fecha ausente/inválida
 * (hallazgo de review: NUNCA posicionar una barra con rango negativo).
 */
function ownRange(node) {
    const start = toValidTime(node.start);
    const end = toValidTime(node.end);
    if (start === null || end === null || start > end)
        return null;
    return { start, end };
}
/**
 * Rango efectivo de un nodo: UNIÓN de su rango propio (si lo tiene) con la
 * envolvente recursiva de sus hijos (min/max de los rangos resueltos de los
 * hijos, que a su vez pueden ser envolventes) — spec#Barra envolvente del
 * padre. `null` si el nodo (y todo su subárbol) no tiene ninguna fecha
 * resoluble.
 *
 * CRÍTICO: este es el ÚNICO criterio de rango de un nodo en todo el motor —
 * {@link computeGlobalRange} llama a esta MISMA función sobre cada raíz (no
 * un cálculo aparte "solo hojas"). Antes del fix, computeGlobalRange
 * ignoraba las fechas propias de un nodo con hijos, mientras que esta
 * función SÍ las usaba (y ahí paraba, sin unir con los hijos) — la
 * asimetría producía barras fuera de `[0,100]` (un padre con fecha propia
 * más ancha que sus hijos quedaba posicionado contra un rango global más
 * angosto que el suyo propio).
 *
 * `visited` protege contra CICLOS (`node.children` que se referencia a sí
 * mismo, directa o transitivamente): un nodo ya visitado en esta misma
 * llamada-raíz corta con `null` en vez de recursar sin fin.
 */
function resolveNodeRange(node, visited = new WeakSet()) {
    if (visited.has(node))
        return null;
    visited.add(node);
    const own = ownRange(node);
    const childRanges = (node.children ?? [])
        .filter((child) => !!child)
        .map((child) => resolveNodeRange(child, visited))
        .filter((r) => r !== null);
    if (childRanges.length === 0)
        return own;
    const envelope = {
        start: Math.min(...childRanges.map((r) => r.start)),
        end: Math.max(...childRanges.map((r) => r.end)),
    };
    if (!own)
        return envelope;
    return {
        start: Math.min(own.start, envelope.start),
        end: Math.max(own.end, envelope.end),
    };
}
/**
 * Rango global del timeline: `min(start)/max(end)` de {@link resolveNodeRange}
 * sobre cada nodo RAÍZ de `nodes` — MISMO criterio que posiciona la barra de
 * cada nodo individual (ver el comentario de `resolveNodeRange`). `null` si
 * ninguna raíz tiene un rango resoluble.
 */
function computeGlobalRange(nodes) {
    const ranges = (nodes ?? [])
        .filter((node) => !!node)
        .map((node) => resolveNodeRange(node))
        .filter((r) => r !== null);
    if (ranges.length === 0)
        return null;
    return {
        start: Math.min(...ranges.map((r) => r.start)),
        end: Math.max(...ranges.map((r) => r.end)),
    };
}
/**
 * Aplana `nodes` a filas posicionadas (`leftPct`/`widthPct` como % de
 * `range`), recorriendo hasta N niveles. Un nodo (y todo su subárbol) SIN
 * fecha resoluble se omite aquí — se maneja aparte, ver
 * {@link collectUndatedNodes} (spec: sección "sin fechas", igual que
 * `sprint-timeline` hoy). Los hijos de un nodo colapsado (según
 * `options.isCollapsed`, o `node.collapsed` por defecto) no se incluyen.
 *
 * `leftPct`/`widthPct` se CLAMPEAN a `[0,100]` como red defensiva adicional
 * (aunque `resolveNodeRange`/`computeGlobalRange` ya comparten criterio y no
 * deberían producir valores fuera de rango).
 *
 * `options.visited` protege contra CICLOS en la propia estructura del árbol
 * (`node.children` recorrido aquí directamente, independiente de la guarda
 * interna de `resolveNodeRange`): un nodo ya visitado en esta llamada se
 * omite en vez de recursar sin fin.
 */
function positionRows(nodes, range, options) {
    const depth = options?.depth ?? 0;
    const isCollapsed = options?.isCollapsed ?? ((node) => !!node.collapsed);
    const visited = options?.visited ?? new WeakSet();
    const totalMs = range.end - range.start;
    const rows = [];
    for (const node of nodes ?? []) {
        if (!node || visited.has(node))
            continue;
        visited.add(node);
        const nodeRange = resolveNodeRange(node);
        if (!nodeRange)
            continue; // sin fecha resoluble en todo el subárbol → sección aparte
        const rawLeftPct = totalMs > 0 ? ((nodeRange.start - range.start) / totalMs) * 100 : 0;
        const rawWidthPct = totalMs > 0 ? ((nodeRange.end - nodeRange.start) / totalMs) * 100 : 100;
        const leftPct = Math.min(Math.max(rawLeftPct, 0), 100);
        const widthPct = Math.min(Math.max(rawWidthPct, MIN_WIDTH_PCT), 100 - leftPct);
        rows.push({ node, depth, leftPct, widthPct });
        if (!isCollapsed(node) && node.children?.length) {
            rows.push(...positionRows(node.children, range, { depth: depth + 1, isCollapsed, visited }));
        }
    }
    return rows;
}
/**
 * Recorre `nodes` y devuelve, en una lista PLANA (sin jerarquía — igual que
 * `sprint-timeline` hoy), todo nodo cuyo subárbol completo no tenga ninguna
 * fecha resoluble. Un nodo con fecha propia o con AL MENOS un descendiente
 * con fecha no entra aquí (se posiciona vía {@link positionRows}).
 * `visited` protege contra ciclos, igual que en `positionRows`.
 */
function collectUndatedNodes(nodes, visited = new WeakSet()) {
    const result = [];
    for (const node of nodes ?? []) {
        if (!node || visited.has(node))
            continue;
        visited.add(node);
        if (resolveNodeRange(node) === null) {
            result.push(node);
        }
        else if (node.children?.length) {
            result.push(...collectUndatedNodes(node.children, visited));
        }
    }
    return result;
}
const AXIS_TICK_EPSILON = 1e-9;
/**
 * Marcas del eje temporal (un tick por mes dentro de `range`, más el límite
 * final). PURA y AGNÓSTICA de i18n a propósito: devuelve `{year, month}`
 * crudos — el componente resuelve el nombre del mes por clave i18n (spec:
 * eje temporal en español, cero texto hardcodeado).
 *
 * DEDUPLICA el tick final contra el último generado por el bucle: si `end`
 * cae EXACTO en el 1º de un mes, el bucle ya agrega ese tick en `leftPct=100`
 * — sumar el tick de cierre de nuevo produciría dos entradas idénticas
 * (misma posición, mismo mes) y rompería el `@for track` del componente
 * (`NG0955`, clave de tracking duplicada).
 */
function computeMonthAxisTicks(range) {
    const { start, end } = range;
    if (!(end > start))
        return [];
    const totalMs = end - start;
    const ticks = [];
    const startDate = new Date(start);
    const cursor = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
    while (cursor.getTime() <= end) {
        const leftPct = ((cursor.getTime() - start) / totalMs) * 100;
        if (leftPct >= 0 && leftPct <= 100) {
            ticks.push({ leftPct, year: cursor.getFullYear(), month: cursor.getMonth() });
        }
        cursor.setMonth(cursor.getMonth() + 1);
    }
    const last = ticks[ticks.length - 1];
    const lastIsAlreadyBoundary = !!last && Math.abs(last.leftPct - 100) < AXIS_TICK_EPSILON;
    if (!lastIsAlreadyBoundary) {
        const endDate = new Date(end);
        ticks.push({ leftPct: 100, year: endDate.getFullYear(), month: endDate.getMonth() });
    }
    else {
        last.leftPct = 100; // asienta el redondeo de punto flotante exactamente en el borde
    }
    return ticks;
}
const DEFAULT_STATUS_TONE = {
    active: 'info',
    inprogress: 'info',
    done: 'success',
    completed: 'success',
    closed: 'success',
    blocked: 'danger',
    atrisk: 'warning',
    pending: 'neutral',
};
/**
 * Resolución de color por defecto cuando el consumidor no da `statusToken`:
 * normaliza `status` (minúsculas, sin espacios) contra un mapa reducido de
 * estados comunes → `SolTone`; cualquier estado no reconocido cae a
 * `'neutral'`. Reutiliza `ui/tone/sol-tone.ts` (mismo mapa que
 * `sol-score-badge`/`sol-trend`) en vez de inventar colores nuevos.
 *
 * `typeof status === 'string'` ANTES de `.trim()` (no solo `status?.`):
 * un `status` no-string (dato malformado o de un futuro esquema numérico)
 * pasaría el chequeo de nulidad de `?.` pero `.trim` no existe en un
 * `number` — mismo bug de forma que el `name` de `sol-avatar` en el PR3.
 */
const defaultStatusToken = (status) => {
    const key = typeof status === 'string' ? status.trim().toLowerCase().replace(/[\s_-]/g, '') : '';
    const tone = DEFAULT_STATUS_TONE[key] ?? 'neutral';
    return TONE_COLOR[tone];
};

const MONTH_KEYS = Array.from({ length: 12 }, (_, i) => `shared.timeline.months.${i}`);
/**
 * `sol-timeline` — timeline jerárquico N-niveles, genérico y sin
 * dependencias externas (spec: solercia-ui-timeline, design.md D5).
 * Generaliza el motor `%` de `sprint-timeline` de `gestion_proyectos`;
 * NUNCA conoce `epic`/`sprint`/`historia de usuario` — el consumidor mapea
 * su dominio al contrato `TimelineNode`.
 *
 * Colapso/expansión: "espejo" propio (mismo patrón que `sol-kanban-board`),
 * sembrado desde `node.collapsed` de la entrada y actualizado por clic —
 * NUNCA muta los objetos de entrada. Emite `nodeToggled` para que el
 * consumidor persista el estado si lo necesita.
 *
 * Robustez de entrada (lección del PR3): `nodes` tolera `null`/`undefined`
 * (Angular no garantiza que un `input.required()` resuelva a un valor
 * no-nulo en runtime) y cada nodo tolera fechas inválidas/ausentes — ver
 * `timeline-position.ts`.
 */
class SolTimelineComponent {
    i18n = inject(SOL_I18N);
    /**
     * Nodos raíz del timeline. Tipado `TimelineNode[] | null | undefined` a
     * propósito: `input.required()` exige que el BINDING exista, no que su
     * valor ya esté resuelto (lección del PR3 — `sol-avatar`).
     */
    nodes = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []));
    /** Resuelve `status` → color CSS. Default: `ui/tone/sol-tone.ts` (mismo mapa que score-badge/trend). */
    statusToken = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "statusToken" }] : /* istanbul ignore next */ []));
    legend = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "legend" }] : /* istanbul ignore next */ []));
    /** `false` deshabilita por completo el control de colapso (todo se renderiza expandido). */
    collapsible = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsible" }] : /* istanbul ignore next */ []));
    nodeToggled = output();
    nodeClicked = output();
    /** Espejo interno del colapso — sembrado desde `node.collapsed`, nunca muta la entrada. */
    collapsedIds = signal(new Set(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsedIds" }] : /* istanbul ignore next */ []));
    /**
     * Siembra `collapsedIds` SOLO la primera vez que `nodes()` tiene contenido
     * REAL (`length > 0`) — no basta con que el `effect` haya corrido una vez.
     * Distinto del patrón "espejo" de `sol-kanban-board`: ahí el re-siembro en
     * CADA cambio de `columns` es un rollback DELIBERADO (el consumidor
     * reasigna el input para deshacer un drag fallido). Aquí NO —
     * `TimelineNode.collapsed` es explícitamente el estado INICIAL al montar
     * (ver `timeline.model.ts`); reasignar `nodes` después (p. ej. porque
     * llegó una actualización del backend) NUNCA debe descartar lo que el
     * usuario ya colapsó/expandió con clics.
     *
     * CORRECCIÓN (bug introducido por el fix anterior): marcar "ya sembrado"
     * en la PRIMERA corrida del effect, sin mirar si `nodes()` traía datos,
     * rompía el caso `[nodes]="stream$ | async"` — el patrón asíncrono que
     * este mismo componente documenta arriba y habilita con
     * `input.required<TimelineNode[] | null | undefined>()`. Si la primera
     * emisión es `null`/`undefined`/`[]` (mientras la data carga), el
     * sembrado se marcaba completo SIN sembrar nada; cuando llegaban los
     * datos reales con `node.collapsed=true`, ya no se sembraban — los nodos
     * que debían iniciar colapsados se renderizaban expandidos. La condición
     * correcta es `!hasSeededCollapse && nodes()?.length` (con contenido
     * real), no solo `!hasSeededCollapse`.
     */
    hasSeededCollapse = false;
    constructor() {
        effect(() => {
            const currentNodes = this.nodes();
            if (this.hasSeededCollapse || !currentNodes?.length)
                return;
            this.hasSeededCollapse = true;
            const initial = new Set();
            const seed = (list, visited) => {
                for (const node of list) {
                    if (!node || visited.has(node))
                        continue; // guarda de ciclos (CRITICAL-3)
                    visited.add(node);
                    if (node.collapsed)
                        initial.add(node.id);
                    if (node.children?.length)
                        seed(node.children, visited);
                }
            };
            seed(currentNodes, new WeakSet());
            this.collapsedIds.set(initial);
        });
    }
    hasAnyNodes = computed(() => (this.nodes() ?? []).length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasAnyNodes" }] : /* istanbul ignore next */ []));
    globalRange = computed(() => computeGlobalRange(this.nodes()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "globalRange" }] : /* istanbul ignore next */ []));
    rows = computed(() => {
        const range = this.globalRange();
        if (!range)
            return [];
        const collapsible = this.collapsible();
        const collapsed = this.collapsedIds();
        return positionRows(this.nodes(), range, {
            isCollapsed: (node) => collapsible && collapsed.has(node.id),
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []));
    undatedNodes = computed(() => collectUndatedNodes(this.nodes()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "undatedNodes" }] : /* istanbul ignore next */ []));
    monthLabels = this.i18n.tMany(MONTH_KEYS);
    axisLabels = computed(() => {
        const range = this.globalRange();
        if (!range)
            return [];
        const labels = this.monthLabels();
        return computeMonthAxisTicks(range).map((tick) => ({
            leftPct: tick.leftPct,
            label: `${labels[tick.month] ?? ''} ${tick.year}`,
        }));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "axisLabels" }] : /* istanbul ignore next */ []));
    emptyLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.timeline.emptyState');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    undatedTitle = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.timeline.undatedTitle');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "undatedTitle" }] : /* istanbul ignore next */ []));
    expandLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.timeline.expandNode');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expandLabel" }] : /* istanbul ignore next */ []));
    collapseLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.timeline.collapseNode');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapseLabel" }] : /* istanbul ignore next */ []));
    labelOf(node) {
        if (node.labelKey) {
            this.i18n.activeLang();
            return this.i18n.translate(node.labelKey);
        }
        return node.label ?? '';
    }
    legendLabel(item) {
        this.i18n.activeLang();
        return this.i18n.translate(item.labelKey);
    }
    colorOf(node) {
        return this.resolveColor(node.status);
    }
    resolveColor(status) {
        const resolver = this.statusToken() ?? defaultStatusToken;
        return resolver(status);
    }
    isCollapsedRow(node) {
        return this.collapsedIds().has(node.id);
    }
    toggle(node) {
        if (!node.children?.length)
            return;
        const next = new Set(this.collapsedIds());
        const collapsed = !next.has(node.id);
        if (collapsed) {
            next.add(node.id);
        }
        else {
            next.delete(node.id);
        }
        this.collapsedIds.set(next);
        this.nodeToggled.emit({ id: node.id, collapsed });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTimelineComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolTimelineComponent, isStandalone: true, selector: "sol-timeline", inputs: { nodes: { classPropertyName: "nodes", publicName: "nodes", isSignal: true, isRequired: true, transformFunction: null }, statusToken: { classPropertyName: "statusToken", publicName: "statusToken", isSignal: true, isRequired: false, transformFunction: null }, legend: { classPropertyName: "legend", publicName: "legend", isSignal: true, isRequired: false, transformFunction: null }, collapsible: { classPropertyName: "collapsible", publicName: "collapsible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { nodeToggled: "nodeToggled", nodeClicked: "nodeClicked" }, ngImport: i0, template: `
    @if (!hasAnyNodes()) {
      <p class="sol-timeline__empty">{{ emptyLabel() }}</p>
    } @else {
      <div class="sol-timeline">
        @if (rows().length > 0) {
          <div class="sol-timeline__chart">
            <div class="sol-timeline__axis">
              @for (tick of axisLabels(); track tick.leftPct + tick.label) {
                <span class="sol-timeline__axis-label" [style.left.%]="tick.leftPct">{{ tick.label }}</span>
              }
            </div>
            <div class="sol-timeline__axis-rule"></div>

            <div class="sol-timeline__rows">
              @for (row of rows(); track row.node.id) {
                <div class="sol-timeline__row">
                  <div class="sol-timeline__row-header" [style.padding-left.px]="row.depth * 20">
                    @if (collapsible() && row.node.children?.length) {
                      <button
                        type="button"
                        class="sol-timeline__toggle"
                        [attr.aria-expanded]="!isCollapsedRow(row.node)"
                        [attr.aria-label]="isCollapsedRow(row.node) ? expandLabel() : collapseLabel()"
                        (click)="toggle(row.node)"
                      >
                        <sol-icon
                          name="chevron-right"
                          size="sm"
                          [style.transform]="isCollapsedRow(row.node) ? 'none' : 'rotate(90deg)'"
                        />
                      </button>
                    } @else {
                      <span class="sol-timeline__toggle-spacer" aria-hidden="true"></span>
                    }
                    <span class="sol-timeline__label">{{ labelOf(row.node) }}</span>
                  </div>

                  <div class="sol-timeline__track">
                    <div
                      class="sol-timeline__bar"
                      [style.left.%]="row.leftPct"
                      [style.width.%]="row.widthPct"
                      [style.background]="colorOf(row.node)"
                      [attr.title]="labelOf(row.node)"
                      (click)="nodeClicked.emit(row.node)"
                    ></div>
                  </div>
                </div>
              }
            </div>

            @if (legend().length > 0) {
              <div class="sol-timeline__legend">
                @for (item of legend(); track item.status) {
                  <span class="sol-timeline__legend-item">
                    <span class="sol-timeline__legend-swatch" [style.background]="resolveColor(item.status)"></span>
                    {{ legendLabel(item) }}
                  </span>
                }
              </div>
            }
          </div>
        }

        @if (undatedNodes().length > 0) {
          <div class="sol-timeline__undated">
            <p class="sol-timeline__undated-title">{{ undatedTitle() }}</p>
            <div class="sol-timeline__undated-list">
              @for (node of undatedNodes(); track node.id) {
                <span class="sol-timeline__chip" [style.color]="colorOf(node)">{{ labelOf(node) }}</span>
              }
            </div>
          </div>
        }
      </div>
    }
  `, isInline: true, styles: [":host{display:block;font-family:var(--sol-font-family)}.sol-timeline__empty{padding:var(--sol-space-lg, 24px) 0;text-align:center;font-size:var(--sol-font-size-sm, .875rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-timeline__chart{overflow-x:auto}.sol-timeline__axis{position:relative;height:20px;margin-bottom:var(--sol-space-xs, 4px);font-size:var(--sol-font-size-xs, .75rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-timeline__axis-label{position:absolute;white-space:nowrap;transform:translate(-50%)}.sol-timeline__axis-rule{height:1px;margin-bottom:var(--sol-space-sm, 8px);background:var(--sol-border-color-default, #e2e8f0)}.sol-timeline__rows{display:flex;flex-direction:column;gap:var(--sol-space-xs, 4px);min-width:480px}.sol-timeline__row{display:grid;grid-template-columns:minmax(140px,220px) 1fr;align-items:center;gap:var(--sol-space-sm, 8px);min-height:32px}.sol-timeline__row-header{display:flex;align-items:center;gap:var(--sol-space-xs, 4px);min-width:0}.sol-timeline__toggle{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;padding:0;border:none;border-radius:var(--sol-border-radius-sm, 4px);background:transparent;color:var(--sol-color-text-secondary, #64748b);cursor:pointer;flex-shrink:0}.sol-timeline__toggle:hover{background:color-mix(in srgb,var(--sol-color-primary, #6366f1) 10%,transparent)}.sol-timeline__toggle sol-icon{transition:transform .15s ease}.sol-timeline__toggle-spacer{display:inline-block;width:20px;flex-shrink:0}.sol-timeline__label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--sol-font-size-sm, .875rem);color:var(--sol-color-text-primary, #0f172a)}.sol-timeline__track{position:relative;height:20px;border-radius:var(--sol-border-radius-sm, 4px);background:color-mix(in srgb,var(--sol-color-text-muted, #94a3b8) 10%,transparent)}.sol-timeline__bar{position:absolute;inset-block:0;border-radius:var(--sol-border-radius-sm, 4px);cursor:pointer}.sol-timeline__legend{display:flex;flex-wrap:wrap;gap:var(--sol-space-md, 16px);margin-top:var(--sol-space-md, 16px);font-size:var(--sol-font-size-xs, .75rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-timeline__legend-item{display:inline-flex;align-items:center;gap:6px}.sol-timeline__legend-swatch{width:10px;height:10px;border-radius:var(--sol-border-radius-sm, 2px)}.sol-timeline__undated{margin-top:var(--sol-space-md, 16px)}.sol-timeline__undated-title{margin:0 0 var(--sol-space-sm, 8px);font-size:var(--sol-font-size-xs, .75rem);font-weight:500;color:var(--sol-color-text-muted, #94a3b8)}.sol-timeline__undated-list{display:flex;flex-wrap:wrap;gap:var(--sol-space-sm, 8px)}.sol-timeline__chip{display:inline-flex;align-items:center;border:1px solid var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-full, 9999px);padding:2px 10px;font-size:var(--sol-font-size-xs, .75rem);font-weight:500}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolTimelineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-timeline', standalone: true, imports: [SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (!hasAnyNodes()) {
      <p class="sol-timeline__empty">{{ emptyLabel() }}</p>
    } @else {
      <div class="sol-timeline">
        @if (rows().length > 0) {
          <div class="sol-timeline__chart">
            <div class="sol-timeline__axis">
              @for (tick of axisLabels(); track tick.leftPct + tick.label) {
                <span class="sol-timeline__axis-label" [style.left.%]="tick.leftPct">{{ tick.label }}</span>
              }
            </div>
            <div class="sol-timeline__axis-rule"></div>

            <div class="sol-timeline__rows">
              @for (row of rows(); track row.node.id) {
                <div class="sol-timeline__row">
                  <div class="sol-timeline__row-header" [style.padding-left.px]="row.depth * 20">
                    @if (collapsible() && row.node.children?.length) {
                      <button
                        type="button"
                        class="sol-timeline__toggle"
                        [attr.aria-expanded]="!isCollapsedRow(row.node)"
                        [attr.aria-label]="isCollapsedRow(row.node) ? expandLabel() : collapseLabel()"
                        (click)="toggle(row.node)"
                      >
                        <sol-icon
                          name="chevron-right"
                          size="sm"
                          [style.transform]="isCollapsedRow(row.node) ? 'none' : 'rotate(90deg)'"
                        />
                      </button>
                    } @else {
                      <span class="sol-timeline__toggle-spacer" aria-hidden="true"></span>
                    }
                    <span class="sol-timeline__label">{{ labelOf(row.node) }}</span>
                  </div>

                  <div class="sol-timeline__track">
                    <div
                      class="sol-timeline__bar"
                      [style.left.%]="row.leftPct"
                      [style.width.%]="row.widthPct"
                      [style.background]="colorOf(row.node)"
                      [attr.title]="labelOf(row.node)"
                      (click)="nodeClicked.emit(row.node)"
                    ></div>
                  </div>
                </div>
              }
            </div>

            @if (legend().length > 0) {
              <div class="sol-timeline__legend">
                @for (item of legend(); track item.status) {
                  <span class="sol-timeline__legend-item">
                    <span class="sol-timeline__legend-swatch" [style.background]="resolveColor(item.status)"></span>
                    {{ legendLabel(item) }}
                  </span>
                }
              </div>
            }
          </div>
        }

        @if (undatedNodes().length > 0) {
          <div class="sol-timeline__undated">
            <p class="sol-timeline__undated-title">{{ undatedTitle() }}</p>
            <div class="sol-timeline__undated-list">
              @for (node of undatedNodes(); track node.id) {
                <span class="sol-timeline__chip" [style.color]="colorOf(node)">{{ labelOf(node) }}</span>
              }
            </div>
          </div>
        }
      </div>
    }
  `, styles: [":host{display:block;font-family:var(--sol-font-family)}.sol-timeline__empty{padding:var(--sol-space-lg, 24px) 0;text-align:center;font-size:var(--sol-font-size-sm, .875rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-timeline__chart{overflow-x:auto}.sol-timeline__axis{position:relative;height:20px;margin-bottom:var(--sol-space-xs, 4px);font-size:var(--sol-font-size-xs, .75rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-timeline__axis-label{position:absolute;white-space:nowrap;transform:translate(-50%)}.sol-timeline__axis-rule{height:1px;margin-bottom:var(--sol-space-sm, 8px);background:var(--sol-border-color-default, #e2e8f0)}.sol-timeline__rows{display:flex;flex-direction:column;gap:var(--sol-space-xs, 4px);min-width:480px}.sol-timeline__row{display:grid;grid-template-columns:minmax(140px,220px) 1fr;align-items:center;gap:var(--sol-space-sm, 8px);min-height:32px}.sol-timeline__row-header{display:flex;align-items:center;gap:var(--sol-space-xs, 4px);min-width:0}.sol-timeline__toggle{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;padding:0;border:none;border-radius:var(--sol-border-radius-sm, 4px);background:transparent;color:var(--sol-color-text-secondary, #64748b);cursor:pointer;flex-shrink:0}.sol-timeline__toggle:hover{background:color-mix(in srgb,var(--sol-color-primary, #6366f1) 10%,transparent)}.sol-timeline__toggle sol-icon{transition:transform .15s ease}.sol-timeline__toggle-spacer{display:inline-block;width:20px;flex-shrink:0}.sol-timeline__label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--sol-font-size-sm, .875rem);color:var(--sol-color-text-primary, #0f172a)}.sol-timeline__track{position:relative;height:20px;border-radius:var(--sol-border-radius-sm, 4px);background:color-mix(in srgb,var(--sol-color-text-muted, #94a3b8) 10%,transparent)}.sol-timeline__bar{position:absolute;inset-block:0;border-radius:var(--sol-border-radius-sm, 4px);cursor:pointer}.sol-timeline__legend{display:flex;flex-wrap:wrap;gap:var(--sol-space-md, 16px);margin-top:var(--sol-space-md, 16px);font-size:var(--sol-font-size-xs, .75rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-timeline__legend-item{display:inline-flex;align-items:center;gap:6px}.sol-timeline__legend-swatch{width:10px;height:10px;border-radius:var(--sol-border-radius-sm, 2px)}.sol-timeline__undated{margin-top:var(--sol-space-md, 16px)}.sol-timeline__undated-title{margin:0 0 var(--sol-space-sm, 8px);font-size:var(--sol-font-size-xs, .75rem);font-weight:500;color:var(--sol-color-text-muted, #94a3b8)}.sol-timeline__undated-list{display:flex;flex-wrap:wrap;gap:var(--sol-space-sm, 8px)}.sol-timeline__chip{display:inline-flex;align-items:center;border:1px solid var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-full, 9999px);padding:2px 10px;font-size:var(--sol-font-size-xs, .75rem);font-weight:500}\n"] }]
        }], ctorParameters: () => [], propDecorators: { nodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "nodes", required: true }] }], statusToken: [{ type: i0.Input, args: [{ isSignal: true, alias: "statusToken", required: false }] }], legend: [{ type: i0.Input, args: [{ isSignal: true, alias: "legend", required: false }] }], collapsible: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsible", required: false }] }], nodeToggled: [{ type: i0.Output, args: ["nodeToggled"] }], nodeClicked: [{ type: i0.Output, args: ["nodeClicked"] }] } });

/**
 * `sol-kanban-card` — contenedor presentacional de un item; el CONTENIDO va
 * por `cardTemplate` proyectado (spec: solercia-ui-kanban#Estructura
 * genérica sin conocimiento de dominio).
 *
 * `cdkDrag` vía `hostDirectives` (PR5b, D1/T38): el HOST de la tarjeta se
 * vuelve arrastrable SIN que ningún consumidor escriba `cdkDrag` jamás — la
 * directiva se adopta internamente (`hostDirectives: [CdkDrag]`, forma
 * "desnuda" que NO reexpone ningún input/output de CDK hacia consumidores de
 * `<sol-kanban-card>`) y se cablea imperativamente (`data`, `previewClass`)
 * inyectando la instancia (`inject(CdkDrag, { host: true })`). Cualquier
 * archivo dentro de `ui/kanban/` puede importar `@angular/cdk/drag-drop`
 * (gate ESLint T40 exime el directorio completo, no un archivo puntual —
 * `kanban-board.component.ts` también importa `CdkDropListGroup`).
 *
 * A11y — CORRECCIÓN 4R (PR5b): `cdkDrag` de `@angular/cdk` 22.0.5 SOLO
 * registra listeners de `mousedown`/`touchstart`/`dragstart` — CERO soporte
 * de teclado (`keydown`). El comentario original de esta clase afirmaba lo
 * contrario; era falso y dejaba el tablero INOPERABLE para un usuario sin
 * mouse/touch (el drag es la única forma de mover una tarjeta). Por eso
 * `sol-kanban-column` ofrece un mecanismo alternativo 100% accesible por
 * teclado (un `<select>` nativo por tarjeta: "subir"/"bajar"/"mover a
 * columna X") que invoca el MISMO `KanbanReorderService` y emite el MISMO
 * `itemMoved` que el drag — ver `kanban-column.component.ts`. No se
 * reimplementa el drag por teclado de CDK (complejo y frágil); se da
 * paridad FUNCIONAL por una vía distinta.
 */
class SolKanbanCardComponent {
    cdkDrag = inject(CdkDrag, { host: true });
    /** El item de dominio del consumidor — genérico, la librería nunca lo interpreta. */
    item = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "item" }] : /* istanbul ignore next */ []));
    /** Template proyectado que renderiza el CONTENIDO de la tarjeta. */
    cardTemplate = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cardTemplate" }] : /* istanbul ignore next */ []));
    /**
     * `true` mientras esta tarjeta está siendo arrastrada, `false` al soltar
     * (corrección 4R WARNING, PR5b): `sol-kanban-board` necesita saber si hay
     * ALGÚN drag activo en el tablero para POSPONER el re-seed del espejo
     * (D4) — reasignar `columns()` mientras CDK arrastra el nodo DOM de esta
     * misma tarjeta podría destruirlo/recrearlo (`@for`) y corromper el
     * gesto. Se bubblea vía `sol-kanban-column` hasta el board.
     */
    dragActiveChanged = output();
    constructor() {
        this.cdkDrag.previewClass = 'sol-kanban-card__drag-preview';
        // Payload del drag: SIEMPRE el item actual, sincronizado reactivamente.
        // `KanbanReorderService`/`sol-kanban-board` reordenan por índices + ids
        // de columna (no leen `data`), pero CDK lo expone en
        // `CdkDragDrop.item.data` por si un futuro consumidor lo necesita.
        effect(() => {
            this.cdkDrag.data = this.item();
        });
        const destroyRef = inject(DestroyRef);
        this.cdkDrag.started.pipe(takeUntilDestroyed(destroyRef)).subscribe(() => this.dragActiveChanged.emit(true));
        this.cdkDrag.ended.pipe(takeUntilDestroyed(destroyRef)).subscribe(() => this.dragActiveChanged.emit(false));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolKanbanCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolKanbanCardComponent, isStandalone: true, selector: "sol-kanban-card", inputs: { item: { classPropertyName: "item", publicName: "item", isSignal: true, isRequired: true, transformFunction: null }, cardTemplate: { classPropertyName: "cardTemplate", publicName: "cardTemplate", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { dragActiveChanged: "dragActiveChanged" }, hostDirectives: [{ directive: i1.CdkDrag }], ngImport: i0, template: `
    <div class="sol-kanban-card">
      <ng-container
        *ngTemplateOutlet="cardTemplate(); context: { $implicit: item(), item: item() }"
      />
    </div>
  `, isInline: true, styles: [":host{display:block;cursor:grab}:host(.cdk-drag-dragging){cursor:grabbing}.sol-kanban-card{border:1px solid var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-md, 8px);background:var(--sol-bg-surface, #ffffff);box-shadow:var(--sol-shadow-sm, 0 1px 2px rgba(0, 0, 0, .05))}:host(.cdk-drag-placeholder) .sol-kanban-card{opacity:.4;border:1px dashed var(--sol-color-primary, #6366f1);background:transparent;box-shadow:none}::ng-deep .sol-kanban-card__drag-preview{transform:rotate(2deg);box-shadow:var(--sol-shadow-lg, 0 10px 25px rgba(0, 0, 0, .15));cursor:grabbing}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolKanbanCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-kanban-card', standalone: true, imports: [NgTemplateOutlet], hostDirectives: [CdkDrag], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-kanban-card">
      <ng-container
        *ngTemplateOutlet="cardTemplate(); context: { $implicit: item(), item: item() }"
      />
    </div>
  `, styles: [":host{display:block;cursor:grab}:host(.cdk-drag-dragging){cursor:grabbing}.sol-kanban-card{border:1px solid var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-md, 8px);background:var(--sol-bg-surface, #ffffff);box-shadow:var(--sol-shadow-sm, 0 1px 2px rgba(0, 0, 0, .05))}:host(.cdk-drag-placeholder) .sol-kanban-card{opacity:.4;border:1px dashed var(--sol-color-primary, #6366f1);background:transparent;box-shadow:none}::ng-deep .sol-kanban-card__drag-preview{transform:rotate(2deg);box-shadow:var(--sol-shadow-lg, 0 10px 25px rgba(0, 0, 0, .15));cursor:grabbing}\n"] }]
        }], ctorParameters: () => [], propDecorators: { item: [{ type: i0.Input, args: [{ isSignal: true, alias: "item", required: true }] }], cardTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "cardTemplate", required: true }] }], dragActiveChanged: [{ type: i0.Output, args: ["dragActiveChanged"] }] } });

/**
 * Contrato genérico de `sol-kanban-*` (spec: solercia-ui-kanban). Sin
 * conocimiento de dominio: NUNCA referencia `Task`/`Sprint`/`Lead` — el
 * consumidor extiende `KanbanItem` con su propio modelo y proyecta su propio
 * contenido de tarjeta vía `cardTemplate`.
 */
/**
 * Acción reservada del botón "+ Agregar" que `sol-kanban-column` emite y
 * `sol-kanban-board` reconoce para derivar `addRequested`. Constante
 * compartida (no un literal `'add'` repetido en 2 archivos) — un renombre
 * futuro no puede romper `addRequested` en silencio si un solo lado se
 * actualiza.
 */
const KANBAN_ADD_ACTION = 'add';

/**
 * `track` seguro para `@for` sobre datos del consumidor (items/columnas) cuyo
 * `id` no está garantizado único ni presente en runtime (dato optimista,
 * API externa malformada, etc.). Sin esta guarda, un `id` duplicado o
 * ausente hace que el reconciliador de Angular lance `NG0955` (clave de
 * `track` duplicada) en vez de degradar — mismo espíritu que las guardas de
 * `null`/`undefined` del resto de `sol-kanban-*` (lecciones PR3/PR4).
 *
 * Estrategia: cae al ÍNDICE de la iteración cuando el `id` está ausente o
 * repetido dentro del mismo arreglo — nunca lanza. El costo es que un item
 * con `id` duplicado pierde la identidad ESTABLE de `track` entre renders
 * (puede "saltar" de posición visualmente si el arreglo se reordena), pero
 * eso es preferible a que el tablero completo reviente.
 */
/** Cuenta cuántas veces aparece cada `id` en `items` (ignora entradas `null`/`undefined`). */
function countIds(items) {
    const frequency = new Map();
    for (const item of items) {
        if (!item)
            continue;
        const key = item.id;
        frequency.set(key, (frequency.get(key) ?? 0) + 1);
    }
    return frequency;
}
/** Clave de `track` segura: el índice si `id` está ausente o duplicado; si no, el propio `id`. */
function safeTrackKey(id, index, frequency) {
    if (id == null)
        return index;
    return (frequency.get(id) ?? 0) > 1 ? index : id;
}

/**
 * Resuelve el título de una columna: `titleKey` (i18n) > `title` (crudo) >
 * `''`. Tolera `column` inválido/no-string. `export` (corrección 4R): lo
 * reutiliza `sol-kanban-board` para resolver las etiquetas de "mover a
 * columna X" y el anuncio `aria-live` — evita duplicar la lógica.
 */
function resolveColumnTitle(column, translate) {
    if (!column)
        return '';
    if (typeof column.titleKey === 'string' && column.titleKey)
        return translate(column.titleKey);
    if (typeof column.title === 'string')
        return column.title;
    return '';
}
/**
 * `sol-kanban-column` — una columna con su lista de tarjetas, contador,
 * header y empty-state (spec: solercia-ui-kanban).
 *
 * `cdkDropList` (PR5b, D1/T38): el contenedor de items es un drop-list de
 * CDK — `[id]` (= `column.id`, usado por el board para resolver
 * origen/destino sin filtrar tipos de CDK), `[cdkDropListData]` (los items
 * actuales) y `[cdkDropListDisabled]` (respeta `column.droppable === false`).
 * `(cdkDropListDropped)` se traduce a un `KanbanRawDropEvent` CDK-free antes
 * de reenviarse al board vía `itemDropped` — cualquier archivo dentro de
 * `ui/kanban/` puede importar `@angular/cdk/drag-drop` (gate ESLint T40
 * exime el directorio completo: `kanban-card.component.ts` y
 * `kanban-board.component.ts` también lo importan). `(cdkDropListEntered)`/
 * `(cdkDropListExited)` alimentan el anillo de columna-destino activa
 * (spec#UX de arrastre del vocero).
 *
 * Mecanismo alternativo accesible por teclado (PR5b, corrección 4R —
 * CRITICAL): `cdkDrag` de CDK NO trae soporte de teclado (solo mouse/touch),
 * así que cada tarjeta expone un `<select>` NATIVO ("subir"/"bajar"/"mover a
 * columna X") — 100% operable por teclado sin reimplementar nada del drag.
 * El `change` del select se traduce al MISMO `KanbanRawDropEvent` y se
 * reenvía por el MISMO `itemDropped` que usa el drag real — ambos caminos
 * comparten `KanbanReorderService` en el board.
 *
 * `terminalAnchor` + `anchorTemplate` proyectado: la columna NUNCA conoce el
 * significado de negocio de un ancla (ganada/perdida/etc.) — solo renderiza
 * lo que el consumidor proyecta (spec#Anclas terminales por template
 * proyectado).
 *
 * Robustez de entrada (lecciones PR3/PR4): `column` y `column.items` toleran
 * `null`/`undefined` sin lanzar; `title`/`titleKey` se validan con
 * `typeof === 'string'` antes de usarse (nunca `.trim()`/acceso directo
 * sobre un dato que podría no ser string). Sin recursión/anidamiento en
 * este modelo (columnas → items planos) — no aplica guarda de ciclo.
 */
class SolKanbanColumnComponent {
    i18n = inject(SOL_I18N);
    /** Tolera `null`/`undefined` (lección PR3/PR4): `input.required()` no garantiza no-nulo en runtime. */
    column = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "column" }] : /* istanbul ignore next */ []));
    cardTemplate = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cardTemplate" }] : /* istanbul ignore next */ []));
    /** Override opcional del header completo. Sin este, se usa el título por defecto. */
    headerTemplate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerTemplate" }] : /* istanbul ignore next */ []));
    /** Template del ancla terminal — SOLO se renderiza si `column.terminalAnchor` es `true`. */
    anchorTemplate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "anchorTemplate" }] : /* istanbul ignore next */ []));
    /** Override opcional del empty-state. Sin este, se usa el texto por defecto (clave i18n). */
    emptyTemplate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyTemplate" }] : /* istanbul ignore next */ []));
    /**
     * TODAS las columnas del board (corrección 4R CRITICAL) — necesarias para
     * poblar las opciones "mover a columna X" del `<select>` accesible.
     * Reenviado tal cual desde `sol-kanban-board`; opcional (si no se provee,
     * el select solo ofrece subir/bajar dentro de la propia columna).
     */
    allColumns = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "allColumns" }] : /* istanbul ignore next */ []));
    action = output();
    /** Bubblea el `dragActiveChanged` de CADA `sol-kanban-card` hacia el board (corrección 4R WARNING — pospone el re-seed del espejo durante un drag). */
    dragActiveChanged = output();
    /**
     * Reenvío CDK-free del drop (PR5b/T38): el board arma el reorden completo
     * (necesita ver TODAS las columnas para un move cross-columna); esta
     * columna solo conoce la suya, así que traduce el `CdkDragDrop` real a un
     * `KanbanRawDropEvent` plano ANTES de emitir — el tipo de CDK nunca sale
     * de este archivo hacia el board.
     */
    itemDropped = output();
    items = computed(() => this.column()?.items ?? [], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    /** `id` del drop-list — string vacío si la columna es `null`/`undefined` o no trae `id` (degrade, no lanza). */
    columnId = computed(() => this.column()?.id ?? '', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnId" }] : /* istanbul ignore next */ []));
    /** Anillo de columna-destino activa mientras el cursor de arrastre está sobre esta columna (spec#UX de arrastre). */
    isDropTargetActive = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDropTargetActive" }] : /* istanbul ignore next */ []));
    /** Frecuencia de `id` entre los items actuales — soporte de `trackItem` (fix NG0955 con id duplicado/ausente). */
    itemIdFrequency = computed(() => countIds(this.items()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemIdFrequency" }] : /* istanbul ignore next */ []));
    /** `track` seguro: cae al índice si el `id` del item está ausente o duplicado, en vez de dejar que Angular lance `NG0955`. */
    trackItem(item, index) {
        return safeTrackKey(item?.id, index, this.itemIdFrequency());
    }
    title = computed(() => resolveColumnTitle(this.column(), (key) => this.i18n.translate(key)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    accentColor = computed(() => {
        const accent = this.column()?.accent;
        return typeof accent === 'string' && accent ? accent : TONE_COLOR.neutral;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "accentColor" }] : /* istanbul ignore next */ []));
    columnAria = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.kanban.columnAria', { title: this.title() });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnAria" }] : /* istanbul ignore next */ []));
    /**
     * Singular/plural correcto en español ("1 tarjeta" vs. "N tarjetas") — el
     * contrato `SolI18n` no soporta ICU MessageFormat, así que la elección de
     * clave se hace acá en vez de interpolar un plural incorrecto.
     */
    itemCountAria = computed(() => {
        this.i18n.activeLang();
        const count = this.items().length;
        return count === 1
            ? this.i18n.translate('shared.kanban.itemCountAriaSingular')
            : this.i18n.translate('shared.kanban.itemCountAriaPlural', { count });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemCountAria" }] : /* istanbul ignore next */ []));
    emptyLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.kanban.emptyColumn');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    addLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.kanban.addColumn');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "addLabel" }] : /* istanbul ignore next */ []));
    /** Destinos válidos para "mover a columna X": todas las de `allColumns()` EXCEPTO la propia. */
    otherColumns = computed(() => {
        const ownId = this.column()?.id;
        return (this.allColumns() ?? [])
            .filter((c) => !!c && c.id !== ownId)
            .map((c) => ({ id: c.id, label: resolveColumnTitle(c, (key) => this.i18n.translate(key)) }));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "otherColumns" }] : /* istanbul ignore next */ []));
    moveAriaLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.kanban.moveAriaLabel');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "moveAriaLabel" }] : /* istanbul ignore next */ []));
    movePlaceholder = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.kanban.movePlaceholder');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "movePlaceholder" }] : /* istanbul ignore next */ []));
    moveUpLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.kanban.moveUp');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "moveUpLabel" }] : /* istanbul ignore next */ []));
    moveDownLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.kanban.moveDown');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "moveDownLabel" }] : /* istanbul ignore next */ []));
    /** Método (no `computed`): necesita un parámetro (la etiqueta de la columna destino) para interpolar `{{column}}`. */
    moveToLabel(columnLabel) {
        return this.i18n.translate('shared.kanban.moveToColumn', { column: columnLabel });
    }
    requestAdd() {
        const columnId = this.column()?.id;
        if (!columnId)
            return;
        this.action.emit({ columnId, action: KANBAN_ADD_ACTION });
    }
    /**
     * Traduce el `CdkDragDrop` real a `KanbanRawDropEvent` (sin tipos de CDK) y
     * lo reenvía al board. Descarta el caso trivial (soltar en el MISMO
     * índice, MISMO contenedor) — no hay reorden real que aplicar.
     */
    onCdkDropped(event) {
        // El anillo se enciende al ENTRAR (onCdkEntered) pero CDK solo emite
        // `exited` cuando el item se retira SIN soltar — un drop exitoso en esta
        // misma columna nunca dispara `exited`, así que se apaga acá también.
        this.isDropTargetActive.set(false);
        if (event.previousContainer === event.container && event.previousIndex === event.currentIndex)
            return;
        this.itemDropped.emit({
            fromColumnId: event.previousContainer.id,
            toColumnId: event.container.id,
            previousIndex: event.previousIndex,
            currentIndex: event.currentIndex,
        });
    }
    onCdkEntered() {
        this.isDropTargetActive.set(true);
    }
    onCdkExited() {
        this.isDropTargetActive.set(false);
    }
    /**
     * Traduce la opción elegida en el `<select>` accesible al MISMO
     * `KanbanRawDropEvent`/`itemDropped` que usa el drag real (corrección 4R
     * CRITICAL) — "subir"/"bajar" reordenan dentro de esta misma columna;
     * "mover a columna X" usa `Number.MAX_SAFE_INTEGER` como `currentIndex`
     * porque `KanbanReorderService.reorder()` ya clampa el índice al tamaño
     * real de la columna destino (equivale a "agregar al final" sin que esta
     * columna necesite conocer cuántos items tiene la columna destino).
     */
    onMoveSelected(index, event) {
        const select = event.target;
        const value = select.value;
        select.value = ''; // vuelve al placeholder — permite re-elegir la misma opción después.
        if (!value)
            return;
        const fromColumnId = this.columnId();
        if (value === 'up') {
            if (index <= 0)
                return;
            this.itemDropped.emit({ fromColumnId, toColumnId: fromColumnId, previousIndex: index, currentIndex: index - 1 });
            return;
        }
        if (value === 'down') {
            if (index >= this.items().length - 1)
                return;
            this.itemDropped.emit({ fromColumnId, toColumnId: fromColumnId, previousIndex: index, currentIndex: index + 1 });
            return;
        }
        if (value.startsWith('to:')) {
            const toColumnId = value.slice(3);
            if (!toColumnId)
                return;
            this.itemDropped.emit({ fromColumnId, toColumnId, previousIndex: index, currentIndex: Number.MAX_SAFE_INTEGER });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolKanbanColumnComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolKanbanColumnComponent, isStandalone: true, selector: "sol-kanban-column", inputs: { column: { classPropertyName: "column", publicName: "column", isSignal: true, isRequired: true, transformFunction: null }, cardTemplate: { classPropertyName: "cardTemplate", publicName: "cardTemplate", isSignal: true, isRequired: true, transformFunction: null }, headerTemplate: { classPropertyName: "headerTemplate", publicName: "headerTemplate", isSignal: true, isRequired: false, transformFunction: null }, anchorTemplate: { classPropertyName: "anchorTemplate", publicName: "anchorTemplate", isSignal: true, isRequired: false, transformFunction: null }, emptyTemplate: { classPropertyName: "emptyTemplate", publicName: "emptyTemplate", isSignal: true, isRequired: false, transformFunction: null }, allColumns: { classPropertyName: "allColumns", publicName: "allColumns", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { action: "action", dragActiveChanged: "dragActiveChanged", itemDropped: "itemDropped" }, ngImport: i0, template: `
    <section
      class="sol-kanban-column"
      [class.sol-kanban-column--drop-active]="isDropTargetActive()"
      [style.border-top-color]="accentColor()"
      [attr.aria-label]="columnAria()"
    >
      <header class="sol-kanban-column__header">
        @if (headerTemplate(); as tpl) {
          <ng-container *ngTemplateOutlet="tpl; context: { $implicit: column() }" />
        } @else {
          <h3 class="sol-kanban-column__title">{{ title() }}</h3>
        }

        @if (column()?.terminalAnchor && anchorTemplate(); as anchor) {
          <span class="sol-kanban-column__anchor">
            <ng-container *ngTemplateOutlet="anchor; context: { $implicit: column() }" />
          </span>
        }

        <span class="sol-kanban-column__count" [attr.aria-label]="itemCountAria()">{{ items().length }}</span>
      </header>

      <div
        class="sol-kanban-column__items"
        cdkDropList
        [id]="columnId()"
        [cdkDropListData]="items()"
        [cdkDropListDisabled]="column()?.droppable === false"
        (cdkDropListDropped)="onCdkDropped($event)"
        (cdkDropListEntered)="onCdkEntered()"
        (cdkDropListExited)="onCdkExited()"
      >
        @for (item of items(); track trackItem(item, $index)) {
          <sol-kanban-card
            [item]="item"
            [cardTemplate]="cardTemplate()"
            (dragActiveChanged)="dragActiveChanged.emit($event)"
          />
          <select
            class="sol-kanban-column__move-select"
            [attr.aria-label]="moveAriaLabel()"
            (change)="onMoveSelected($index, $event)"
          >
            <option value="" selected>{{ movePlaceholder() }}</option>
            @if ($index > 0) {
              <option value="up">{{ moveUpLabel() }}</option>
            }
            @if ($index < items().length - 1) {
              <option value="down">{{ moveDownLabel() }}</option>
            }
            @for (target of otherColumns(); track target.id) {
              <option [value]="'to:' + target.id">{{ moveToLabel(target.label) }}</option>
            }
          </select>
        }
        @if (items().length === 0) {
          @if (emptyTemplate(); as tpl) {
            <ng-container *ngTemplateOutlet="tpl" />
          } @else {
            <p class="sol-kanban-column__empty">{{ emptyLabel() }}</p>
          }
        }
      </div>

      <button type="button" class="sol-kanban-column__add" (click)="requestAdd()">
        + {{ addLabel() }}
      </button>
    </section>
  `, isInline: true, styles: [":host{display:block}.sol-kanban-column{display:flex;flex-direction:column;width:18rem;flex-shrink:0;max-height:100%;border:1px solid var(--sol-border-color-default, #e2e8f0);border-top-width:3px;border-radius:var(--sol-border-radius-lg, 12px);background:color-mix(in srgb,var(--sol-bg-page, #f8fafc) 60%,transparent)}.sol-kanban-column__header{display:flex;align-items:center;gap:var(--sol-space-xs, 4px);padding:var(--sol-space-sm, 8px) var(--sol-space-md, 12px);border-bottom:1px solid var(--sol-border-color-default, #e2e8f0)}.sol-kanban-column__title{flex:1;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--sol-font-size-sm, .875rem);font-weight:600;color:var(--sol-color-text-primary, #0f172a)}.sol-kanban-column__anchor{display:inline-flex;align-items:center}.sol-kanban-column__count{display:grid;place-items:center;min-width:1.25rem;height:1.25rem;padding:0 .375rem;border-radius:var(--sol-border-radius-full, 9999px);background:color-mix(in srgb,var(--sol-color-text-muted, #94a3b8) 15%,transparent);font-size:var(--sol-font-size-xs, .6875rem);font-weight:500;color:var(--sol-color-text-muted, #94a3b8)}.sol-kanban-column__items{display:flex;flex:1;flex-direction:column;gap:var(--sol-space-sm, 8px);min-height:7.5rem;padding:var(--sol-space-sm, 8px);overflow-y:auto}.sol-kanban-column__empty{margin:0;padding:var(--sol-space-lg, 24px) var(--sol-space-sm, 8px);text-align:center;font-size:var(--sol-font-size-xs, .75rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-kanban-column__add{margin:var(--sol-space-sm, 8px);padding:var(--sol-space-sm, 8px) var(--sol-space-md, 12px);border:1px dashed var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-md, 8px);background:transparent;font-size:var(--sol-font-size-xs, .75rem);font-weight:500;color:var(--sol-color-text-muted, #94a3b8);cursor:pointer}.sol-kanban-column__add:hover{border-color:var(--sol-color-primary, #6366f1);color:var(--sol-color-primary, #6366f1)}.sol-kanban-column--drop-active{box-shadow:0 0 0 2px var(--sol-color-primary, #6366f1)}.sol-kanban-column__move-select{align-self:flex-end;margin-top:calc(-1 * var(--sol-space-sm, 8px));padding:.125rem .25rem;border:1px solid var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-sm, 4px);background:var(--sol-bg-surface, #ffffff);font-size:var(--sol-font-size-xs, .6875rem);color:var(--sol-color-text-muted, #94a3b8);cursor:pointer}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SolKanbanCardComponent, selector: "sol-kanban-card", inputs: ["item", "cardTemplate"], outputs: ["dragActiveChanged"] }, { kind: "directive", type: CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer", "cdkDropListHasAnchor"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolKanbanColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-kanban-column', standalone: true, imports: [NgTemplateOutlet, SolKanbanCardComponent, CdkDropList], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <section
      class="sol-kanban-column"
      [class.sol-kanban-column--drop-active]="isDropTargetActive()"
      [style.border-top-color]="accentColor()"
      [attr.aria-label]="columnAria()"
    >
      <header class="sol-kanban-column__header">
        @if (headerTemplate(); as tpl) {
          <ng-container *ngTemplateOutlet="tpl; context: { $implicit: column() }" />
        } @else {
          <h3 class="sol-kanban-column__title">{{ title() }}</h3>
        }

        @if (column()?.terminalAnchor && anchorTemplate(); as anchor) {
          <span class="sol-kanban-column__anchor">
            <ng-container *ngTemplateOutlet="anchor; context: { $implicit: column() }" />
          </span>
        }

        <span class="sol-kanban-column__count" [attr.aria-label]="itemCountAria()">{{ items().length }}</span>
      </header>

      <div
        class="sol-kanban-column__items"
        cdkDropList
        [id]="columnId()"
        [cdkDropListData]="items()"
        [cdkDropListDisabled]="column()?.droppable === false"
        (cdkDropListDropped)="onCdkDropped($event)"
        (cdkDropListEntered)="onCdkEntered()"
        (cdkDropListExited)="onCdkExited()"
      >
        @for (item of items(); track trackItem(item, $index)) {
          <sol-kanban-card
            [item]="item"
            [cardTemplate]="cardTemplate()"
            (dragActiveChanged)="dragActiveChanged.emit($event)"
          />
          <select
            class="sol-kanban-column__move-select"
            [attr.aria-label]="moveAriaLabel()"
            (change)="onMoveSelected($index, $event)"
          >
            <option value="" selected>{{ movePlaceholder() }}</option>
            @if ($index > 0) {
              <option value="up">{{ moveUpLabel() }}</option>
            }
            @if ($index < items().length - 1) {
              <option value="down">{{ moveDownLabel() }}</option>
            }
            @for (target of otherColumns(); track target.id) {
              <option [value]="'to:' + target.id">{{ moveToLabel(target.label) }}</option>
            }
          </select>
        }
        @if (items().length === 0) {
          @if (emptyTemplate(); as tpl) {
            <ng-container *ngTemplateOutlet="tpl" />
          } @else {
            <p class="sol-kanban-column__empty">{{ emptyLabel() }}</p>
          }
        }
      </div>

      <button type="button" class="sol-kanban-column__add" (click)="requestAdd()">
        + {{ addLabel() }}
      </button>
    </section>
  `, styles: [":host{display:block}.sol-kanban-column{display:flex;flex-direction:column;width:18rem;flex-shrink:0;max-height:100%;border:1px solid var(--sol-border-color-default, #e2e8f0);border-top-width:3px;border-radius:var(--sol-border-radius-lg, 12px);background:color-mix(in srgb,var(--sol-bg-page, #f8fafc) 60%,transparent)}.sol-kanban-column__header{display:flex;align-items:center;gap:var(--sol-space-xs, 4px);padding:var(--sol-space-sm, 8px) var(--sol-space-md, 12px);border-bottom:1px solid var(--sol-border-color-default, #e2e8f0)}.sol-kanban-column__title{flex:1;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--sol-font-size-sm, .875rem);font-weight:600;color:var(--sol-color-text-primary, #0f172a)}.sol-kanban-column__anchor{display:inline-flex;align-items:center}.sol-kanban-column__count{display:grid;place-items:center;min-width:1.25rem;height:1.25rem;padding:0 .375rem;border-radius:var(--sol-border-radius-full, 9999px);background:color-mix(in srgb,var(--sol-color-text-muted, #94a3b8) 15%,transparent);font-size:var(--sol-font-size-xs, .6875rem);font-weight:500;color:var(--sol-color-text-muted, #94a3b8)}.sol-kanban-column__items{display:flex;flex:1;flex-direction:column;gap:var(--sol-space-sm, 8px);min-height:7.5rem;padding:var(--sol-space-sm, 8px);overflow-y:auto}.sol-kanban-column__empty{margin:0;padding:var(--sol-space-lg, 24px) var(--sol-space-sm, 8px);text-align:center;font-size:var(--sol-font-size-xs, .75rem);color:var(--sol-color-text-muted, #94a3b8)}.sol-kanban-column__add{margin:var(--sol-space-sm, 8px);padding:var(--sol-space-sm, 8px) var(--sol-space-md, 12px);border:1px dashed var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-md, 8px);background:transparent;font-size:var(--sol-font-size-xs, .75rem);font-weight:500;color:var(--sol-color-text-muted, #94a3b8);cursor:pointer}.sol-kanban-column__add:hover{border-color:var(--sol-color-primary, #6366f1);color:var(--sol-color-primary, #6366f1)}.sol-kanban-column--drop-active{box-shadow:0 0 0 2px var(--sol-color-primary, #6366f1)}.sol-kanban-column__move-select{align-self:flex-end;margin-top:calc(-1 * var(--sol-space-sm, 8px));padding:.125rem .25rem;border:1px solid var(--sol-border-color-default, #e2e8f0);border-radius:var(--sol-border-radius-sm, 4px);background:var(--sol-bg-surface, #ffffff);font-size:var(--sol-font-size-xs, .6875rem);color:var(--sol-color-text-muted, #94a3b8);cursor:pointer}\n"] }]
        }], propDecorators: { column: [{ type: i0.Input, args: [{ isSignal: true, alias: "column", required: true }] }], cardTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "cardTemplate", required: true }] }], headerTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "headerTemplate", required: false }] }], anchorTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "anchorTemplate", required: false }] }], emptyTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyTemplate", required: false }] }], allColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "allColumns", required: false }] }], action: [{ type: i0.Output, args: ["action"] }], dragActiveChanged: [{ type: i0.Output, args: ["dragActiveChanged"] }], itemDropped: [{ type: i0.Output, args: ["itemDropped"] }] } });

/**
 * `KanbanReorderService` — transforma `(columns, KanbanRawDropEvent)` en un
 * nuevo arreglo de columnas + el `KanbanItemMoved` a emitir (spec: D4 del
 * design — "la transformación `CdkDragDrop → KanbanItemMoved` se extrae a
 * `KanbanReorderService` PURO, sin DOM, testeable en aislamiento").
 *
 * Cubre los 2 escenarios obligatorios del spec:
 * - mover una tarjeta ENTRE columnas (`fromColumnId !== toColumnId`)
 * - reordenar DENTRO de la misma columna (`fromColumnId === toColumnId`)
 *
 * NO muta los arreglos de entrada: siempre devuelve columnas/arreglos NUEVOS
 * (spread), para que el componente pueda hacer `mirroredColumns.set(...)`
 * con una referencia distinta y disparar la reactividad de signals.
 *
 * Optimista + rollback (D4): este servicio NO persiste nada — el consumidor
 * de `sol-kanban-board` recibe `itemMoved`, hace su PATCH y, si falla,
 * reasigna `[columns]` a la referencia PREVIA; el `effect` del board
 * (D4, siempre re-siembra el espejo) recompone el espejo desde esa
 * referencia anterior = rollback automático. A diferencia de `sol-timeline`
 * (donde re-sembrar en cada cambio era el BUG, PR4), en `sol-kanban` es el
 * comportamiento CORRECTO desde PR5a: es precisamente lo que permite este
 * rollback sin lógica adicional en el board.
 *
 * Robustez (lecciones PR3/PR4/PR5a): columnas ausentes/vacías, columna
 * origen/destino inexistente, índice fuera de rango o item ausente en el
 * índice indicado → devuelve `null` (no-op); el llamador simplemente ignora
 * un resultado `null` sin romper el tablero.
 */
class KanbanReorderService {
    reorder(columns, event) {
        if (!event)
            return null;
        const list = (columns ?? []).filter((column) => !!column);
        const fromIndex = list.findIndex((column) => column.id === event.fromColumnId);
        const toIndex = list.findIndex((column) => column.id === event.toColumnId);
        if (fromIndex === -1 || toIndex === -1)
            return null;
        const fromItems = [...(list[fromIndex].items ?? [])];
        if (event.previousIndex < 0 || event.previousIndex >= fromItems.length)
            return null;
        const [item] = fromItems.splice(event.previousIndex, 1);
        if (!item)
            return null;
        const sameColumn = fromIndex === toIndex;
        const toItems = sameColumn ? fromItems : [...(list[toIndex].items ?? [])];
        const insertAt = Math.max(0, Math.min(event.currentIndex, toItems.length));
        toItems.splice(insertAt, 0, item);
        const nextColumns = list.map((column, index) => {
            if (sameColumn && index === fromIndex)
                return { ...column, items: toItems };
            if (!sameColumn && index === fromIndex)
                return { ...column, items: fromItems };
            if (!sameColumn && index === toIndex)
                return { ...column, items: toItems };
            return column;
        });
        return {
            columns: nextColumns,
            moved: {
                item,
                fromColumnId: event.fromColumnId,
                toColumnId: event.toColumnId,
                previousIndex: event.previousIndex,
                // `insertAt` (CLAMPADO), no `event.currentIndex` crudo: el select
                // accesible de `sol-kanban-column` pide "mover al final" con
                // `Number.MAX_SAFE_INTEGER` (corrección 4R CRITICAL) — reportar ese
                // valor crudo en el `itemMoved` público sería inútil/engañoso para
                // un consumidor que sincroniza su propio estado con el índice real.
                currentIndex: insertAt,
            },
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: KanbanReorderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: KanbanReorderService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: KanbanReorderService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * `sol-kanban-board` — orquestador de columnas (spec: solercia-ui-kanban).
 * Sin conocimiento de dominio: recibe `columns` genéricas + `cardTemplate`
 * proyectado — nunca referencia `Task`/`Sprint`/`Lead`.
 *
 * Espejo interno (`signal` + `effect`, D4 del design): mantiene una copia
 * propia de `columns()`, re-sembrada en CADA cambio del input — a
 * diferencia de `sol-timeline` (donde re-sembrar en cada cambio era un bug
 * de UX), aquí es el comportamiento CORRECTO: el espejo debe reflejar
 * SIEMPRE la última verdad del input, no un estado "sembrado una vez".
 *
 * DnD (PR5b, D1/D4/T38): `cdkDropListGroup` en el contenedor conecta
 * automáticamente los `cdkDropList` de TODAS las columnas hijas (sin
 * `[cdkDropListConnectedTo]` manual). Cada columna reenvía su drop ya
 * traducido a `KanbanRawDropEvent` (CDK-free) vía `(itemDropped)`; el board
 * delega en `KanbanReorderService` (puro) para calcular el nuevo arreglo de
 * columnas + el `KanbanItemMoved` a emitir, y aplica el resultado SOLO sobre
 * el espejo (`mirroredColumns.set(...)`) — NUNCA sobre `columns()` (el
 * input, que sigue siendo propiedad del consumidor).
 *
 * Optimista + rollback (D4): el board NO persiste nada. El consumidor de
 * `itemMoved` hace su PATCH optimista y, si falla, DEBE llamar `rollback()`
 * para restaurar el espejo desde el `columns()` actual del input.
 *
 * CORRECCIÓN 4R (WARNING): el `effect` de abajo re-siembra el espejo cuando
 * `columns()` CAMBIA — pero los signal inputs comparan por `Object.is`, así
 * que reasignar la MISMA referencia (p. ej. la que el consumidor ya tenía
 * antes del drop) NO dispara nada: el rollback fallaría en silencio. Por
 * eso `rollback()` NO depende del juego de referencias — fuerza el re-seed
 * leyendo `columns()` directamente, sin pasar por la comparación del
 * signal. El consumidor puede además reasignar una referencia NUEVA (un
 * clon) para lograr el mismo efecto vía el `effect` normal, pero `rollback()`
 * es el mecanismo recomendado y documentado.
 *
 * CORRECCIÓN 4R (WARNING — reseed durante un drag activo): si el consumidor
 * reasigna `columns()` (refresh en vivo) MIENTRAS el usuario arrastra una
 * tarjeta, re-sembrar el espejo de inmediato destruiría/recrearía el nodo
 * DOM que CDK tiene tomado (`@for`), corrompiendo el gesto. Por eso el
 * `effect` de abajo POSPONE el re-seed si `isDragging()` es `true`
 * (guardado en `pendingColumnsSeed`, sin tocar `mirroredColumns` todavía) y
 * lo aplica recién cuando el drag TERMINA (`onCardDragActiveChanged`). La
 * lectura de `isDragging()` usa `untracked()` a propósito: el `effect` NO
 * debe reaccionar a que `isDragging` cambie por sí solo (si reaccionara,
 * CADA fin de drag re-sembraría desde el `columns()` viejo del consumidor y
 * pisaría la actualización optimista que `onItemDropped` ya aplicó — el
 * caso normal de cada drag-and-drop sin refresh en vivo). El `effect` solo
 * debe reaccionar cuando `columns()` mismo cambia.
 *
 * CORRECCIÓN QUIRÚRGICA (re-gate post-4R) — el drop GANA sobre un refresh
 * pospuesto del MISMO gesto: en CDK real, `cdkDropListDropped` dispara ANTES
 * que `cdkDrag.ended` para un mismo gesto. Si en ese gesto ocurrieron AMBOS
 * — un refresh externo (queda en `pendingColumnsSeed`) Y un drop real
 * (`onItemDropped` ya actualizó `mirroredColumns` de forma optimista y
 * emitió `itemMoved`) —, aplicar el `pendingColumnsSeed` al terminar el
 * drag SOBRESCRIBIRÍA el resultado del drop, perdiendo el reorden del
 * usuario en silencio (aunque el consumidor ya recibió `itemMoved`). Fix:
 * `droppedThisGesture` marca que hubo drop; `onCardDragActiveChanged(false)`
 * DESCARTA el `pendingColumnsSeed` si hubo drop (no lo pierde de verdad: se
 * re-reflejará en el PRÓXIMO cambio real de `columns()`, y el consumidor es
 * la fuente de verdad al persistir el `itemMoved` que ya recibió). Decisión
 * consciente: el drop optimista del usuario gana en SU PROPIO gesto.
 *
 * Mecanismo alternativo accesible por teclado (corrección 4R CRITICAL):
 * `cdkDrag` de CDK no soporta teclado — `sol-kanban-column` ofrece un
 * `<select>` nativo por tarjeta que emite el MISMO `itemDropped`. El board
 * anuncia cada `itemMoved` (venga del drag o del select) vía una región
 * `aria-live="polite"` — ver `announcement` y la plantilla.
 *
 * Robustez de entrada (lecciones PR3/PR4): `columns` tolera `null`/
 * `undefined` (se trata como arreglo vacío); un elemento `null`/`undefined`
 * dentro del arreglo se filtra sin romper el render.
 */
class SolKanbanBoardComponent {
    /** Tolera `null`/`undefined` (lección PR3/PR4): `input.required()` no garantiza no-nulo en runtime. */
    columns = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    cardTemplate = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cardTemplate" }] : /* istanbul ignore next */ []));
    headerTemplate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Template del ancla terminal (ganada/perdida/etc.), reenviado tal cual a
     * `sol-kanban-column`. Sin este reenvío, un consumidor que arme su
     * pipeline vía `sol-kanban-board` (en vez de `sol-kanban-column` directo)
     * no podría usar el ancla terminal sin tocar la librería — violaría el
     * objetivo O ("agregar dominio = pasar templates, sin tocar el
     * componente"). La columna YA soportaba `anchorTemplate`; solo faltaba
     * exponerlo/reenviarlo desde el board.
     */
    anchorTemplate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "anchorTemplate" }] : /* istanbul ignore next */ []));
    emptyTemplate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyTemplate" }] : /* istanbul ignore next */ []));
    columnAction = output();
    /** Atajo de conveniencia: se re-emite cada vez que llega `columnAction` con `action === 'add'`. */
    addRequested = output();
    /**
     * Único output público del arrastre (spec#Arrastrar y soltar encapsulado
     * — "DEBE exponer únicamente un output tipado `itemMoved`"). El board NO
     * persiste: el consumidor hace el PATCH optimista y, ante error, reasigna
     * `[columns]` para el rollback (ver doc de la clase).
     */
    itemMoved = output();
    reorderService = inject(KanbanReorderService);
    i18n = inject(SOL_I18N);
    /** `protected` (no `private`): el template de este mismo componente necesita leerlo, y Angular exige acceso no-privado para bindings de plantilla. */
    mirroredColumns = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mirroredColumns" }] : /* istanbul ignore next */ []));
    /** `true` mientras CUALQUIER tarjeta del board está siendo arrastrada (corrección 4R WARNING). */
    isDragging = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDragging" }] : /* istanbul ignore next */ []));
    /** Seed diferido: `columns()` que llegó mientras `isDragging()` era `true`, pendiente de aplicar al terminar el drag. `null` = nada pendiente. */
    pendingColumnsSeed = null;
    /**
     * `true` si `onItemDropped` aplicó un drop DENTRO del gesto de drag actual
     * (corrección quirúrgica, re-gate post-4R). En CDK real, `dropped` dispara
     * ANTES que `ended` para el MISMO gesto — si TAMBIÉN hubo un refresh
     * externo pospuesto (`pendingColumnsSeed`) durante ese gesto, aplicarlo al
     * terminar el drag (`onCardDragActiveChanged(false)`) SOBRESCRIBIRÍA el
     * resultado del drop que el usuario acaba de hacer (aunque `itemMoved` ya
     * se emitió) — el reorden se perdería en silencio. Decisión: el drop
     * optimista del usuario GANA dentro de su propio gesto; el refresh externo
     * pospuesto se DESCARTA (no se pierde de verdad: se re-reflejará en el
     * PRÓXIMO cambio real de `columns()`, y el consumidor es la fuente de
     * verdad de todos modos al persistir el `itemMoved` que ya recibió).
     */
    droppedThisGesture = false;
    /** Anuncio `aria-live` del último movimiento (drag real o select accesible) — corrección 4R CRITICAL. */
    announcement = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "announcement" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const incoming = (this.columns() ?? []).filter((c) => !!c);
            if (untracked(() => this.isDragging())) {
                // Pospone: ver doc de la clase (CORRECCIÓN 4R — reseed durante un drag activo).
                this.pendingColumnsSeed = incoming;
                return;
            }
            this.mirroredColumns.set(incoming);
        });
    }
    /** Frecuencia de `id` entre las columnas actuales — soporte de `trackColumn` (fix NG0955 con id duplicado/ausente). */
    columnIdFrequency = computed(() => countIds(this.mirroredColumns()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnIdFrequency" }] : /* istanbul ignore next */ []));
    /** `track` seguro: cae al índice si el `id` de la columna está ausente o duplicado. */
    trackColumn(column, index) {
        return safeTrackKey(column?.id, index, this.columnIdFrequency());
    }
    onColumnAction(action) {
        this.columnAction.emit(action);
        if (action.action === KANBAN_ADD_ACTION) {
            this.addRequested.emit(action.columnId);
        }
    }
    /**
     * Delega en `KanbanReorderService` (puro): si el evento es válido (columna
     * origen/destino existen, índice dentro de rango), aplica el resultado
     * SOLO sobre el espejo y emite `itemMoved`. Un resultado `null` (evento
     * inconsistente/columna inexistente) se ignora sin lanzar — mismo espíritu
     * de robustez que el resto de `sol-kanban-*` (lecciones PR3/PR4/PR5a).
     * Recibe el MISMO `KanbanRawDropEvent` tanto del drag real (CDK) como del
     * `<select>` accesible de `sol-kanban-column` — ambos caminos comparten
     * exactamente esta lógica y el mismo `itemMoved` (corrección 4R CRITICAL).
     */
    onItemDropped(event) {
        const result = this.reorderService.reorder(this.mirroredColumns(), event);
        if (!result)
            return;
        this.mirroredColumns.set(result.columns);
        this.itemMoved.emit(result.moved);
        this.announceMove(result.moved);
        // Marca el gesto como "con drop" — ver doc de `droppedThisGesture`.
        this.droppedThisGesture = true;
    }
    /**
     * Fuerza el re-seed del espejo desde el `columns()` ACTUAL (corrección 4R
     * WARNING) — NO depende de que la referencia cambie (a diferencia del
     * `effect`, que compara por `Object.is`). El consumidor la llama tras un
     * PATCH fallido para deshacer la actualización optimista. Respeta el
     * mismo diferido que el `effect` si hay un drag activo en curso.
     */
    rollback() {
        const incoming = (this.columns() ?? []).filter((c) => !!c);
        if (this.isDragging()) {
            this.pendingColumnsSeed = incoming;
            return;
        }
        this.mirroredColumns.set(incoming);
    }
    /**
     * Recibe el `dragActiveChanged` bubbleado desde CADA `sol-kanban-column`
     * (que a su vez lo recibe de cada `sol-kanban-card`). Al terminar el
     * drag (`active === false`), aplica cualquier reseed diferido pendiente
     * (corrección 4R WARNING).
     */
    onCardDragActiveChanged(active) {
        this.isDragging.set(active);
        if (active) {
            // Nuevo gesto: limpia cualquier rastro de un gesto ANTERIOR (defensivo).
            this.droppedThisGesture = false;
            return;
        }
        // Fin del gesto: si hubo un drop, GANA sobre cualquier refresh pospuesto
        // (ver doc de `droppedThisGesture`) — se descarta sin aplicar.
        if (this.pendingColumnsSeed && !this.droppedThisGesture) {
            this.mirroredColumns.set(this.pendingColumnsSeed);
        }
        this.pendingColumnsSeed = null;
        this.droppedThisGesture = false;
    }
    /** Anuncia el movimiento por `aria-live` (corrección 4R CRITICAL) — mismo texto venga del drag o del select accesible. */
    announceMove(moved) {
        this.i18n.activeLang();
        const toColumn = this.mirroredColumns().find((c) => c.id === moved.toColumnId);
        const columnLabel = resolveColumnTitle(toColumn, (key) => this.i18n.translate(key));
        this.announcement.set(moved.fromColumnId === moved.toColumnId
            ? this.i18n.translate('shared.kanban.movedWithinColumn')
            : this.i18n.translate('shared.kanban.movedToColumn', { column: columnLabel }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolKanbanBoardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolKanbanBoardComponent, isStandalone: true, selector: "sol-kanban-board", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, cardTemplate: { classPropertyName: "cardTemplate", publicName: "cardTemplate", isSignal: true, isRequired: true, transformFunction: null }, headerTemplate: { classPropertyName: "headerTemplate", publicName: "headerTemplate", isSignal: true, isRequired: false, transformFunction: null }, anchorTemplate: { classPropertyName: "anchorTemplate", publicName: "anchorTemplate", isSignal: true, isRequired: false, transformFunction: null }, emptyTemplate: { classPropertyName: "emptyTemplate", publicName: "emptyTemplate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { columnAction: "columnAction", addRequested: "addRequested", itemMoved: "itemMoved" }, ngImport: i0, template: `
    <div class="sol-kanban-board" cdkDropListGroup>
      @for (column of mirroredColumns(); track trackColumn(column, $index)) {
        <sol-kanban-column
          [column]="column"
          [cardTemplate]="cardTemplate()"
          [headerTemplate]="headerTemplate()"
          [anchorTemplate]="anchorTemplate()"
          [emptyTemplate]="emptyTemplate()"
          [allColumns]="mirroredColumns()"
          (action)="onColumnAction($event)"
          (itemDropped)="onItemDropped($event)"
          (dragActiveChanged)="onCardDragActiveChanged($event)"
        />
      }
    </div>
    <div class="sol-kanban-board__announce" aria-live="polite" role="status">{{ announcement() }}</div>
  `, isInline: true, styles: [":host{display:block}.sol-kanban-board{display:flex;align-items:flex-start;gap:var(--sol-space-md, 12px);overflow-x:auto;padding-bottom:var(--sol-space-sm, 8px)}.sol-kanban-board__announce{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n"], dependencies: [{ kind: "component", type: SolKanbanColumnComponent, selector: "sol-kanban-column", inputs: ["column", "cardTemplate", "headerTemplate", "anchorTemplate", "emptyTemplate", "allColumns"], outputs: ["action", "dragActiveChanged", "itemDropped"] }, { kind: "directive", type: CdkDropListGroup, selector: "[cdkDropListGroup]", inputs: ["cdkDropListGroupDisabled"], exportAs: ["cdkDropListGroup"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolKanbanBoardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-kanban-board', standalone: true, imports: [SolKanbanColumnComponent, CdkDropListGroup], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-kanban-board" cdkDropListGroup>
      @for (column of mirroredColumns(); track trackColumn(column, $index)) {
        <sol-kanban-column
          [column]="column"
          [cardTemplate]="cardTemplate()"
          [headerTemplate]="headerTemplate()"
          [anchorTemplate]="anchorTemplate()"
          [emptyTemplate]="emptyTemplate()"
          [allColumns]="mirroredColumns()"
          (action)="onColumnAction($event)"
          (itemDropped)="onItemDropped($event)"
          (dragActiveChanged)="onCardDragActiveChanged($event)"
        />
      }
    </div>
    <div class="sol-kanban-board__announce" aria-live="polite" role="status">{{ announcement() }}</div>
  `, styles: [":host{display:block}.sol-kanban-board{display:flex;align-items:flex-start;gap:var(--sol-space-md, 12px);overflow-x:auto;padding-bottom:var(--sol-space-sm, 8px)}.sol-kanban-board__announce{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], cardTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "cardTemplate", required: true }] }], headerTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "headerTemplate", required: false }] }], anchorTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "anchorTemplate", required: false }] }], emptyTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyTemplate", required: false }] }], columnAction: [{ type: i0.Output, args: ["columnAction"] }], addRequested: [{ type: i0.Output, args: ["addRequested"] }], itemMoved: [{ type: i0.Output, args: ["itemMoved"] }] } });

/** Superficie neutra por tokens — fallback compartido por el default null-object (sin `color`/`color` no seguro) y por `sol-calendar-grid` cuando una Strategy inyectada lanza (corrección 4R WARNING — resilience). */
const NEUTRAL_CALENDAR_COLOR = {
    bg: 'var(--sol-bg-sunken, var(--sol-bg-page, #f1f5f9))',
    border: 'var(--sol-border-color-default, #cbd5e1)',
    text: 'var(--sol-color-text-primary, #0f172a)',
};
const HEX_COLOR = /^#[0-9a-fA-F]{3,8}$/;
const FUNCTIONAL_COLOR = /^(rgb|hsl)a?\(/i;
const CSS_VAR = /^var\(--/;
/**
 * Whitelist estricta de formas CSS seguras para interpolar en
 * `color-mix()`/`[style]` (corrección 4R WARNING — risk, re-gate PR6):
 * hex (`#rgb`/`#rrggbb`/`#rrggbbaa`), notación funcional (`rgb()`/`rgba()`/
 * `hsl()`/`hsla()`) o referencia a token (`var(--sol-*)`). Cualquier otro
 * valor (p. ej. `url(...)`, `image-set(...)`, `expression(...)`) se
 * rechaza — `background`/`border`/`color` son propiedades shorthand que
 * ACEPTAN `url(...)`, así que un `color` de baja confianza (config de
 * tenant futura, dato de un consumidor no confiable) podría disparar una
 * petición de red ("CSS beacon") si se interpolara sin validar. NO acepta
 * nombres de color (`red`, `blue`) a propósito — whitelist mínima, no
 * exhaustiva.
 */
function isSafeCssColor(value) {
    return HEX_COLOR.test(value) || FUNCTIONAL_COLOR.test(value) || CSS_VAR.test(value);
}
/**
 * Default null-object (D3): si el evento trae `color` explícito Y SEGURO
 * (`isSafeCssColor`), deriva `{bg,border,text}` con `color-mix()` sobre
 * tokens `var(--sol-*)` — el `color` es la única fuente de verdad, sin
 * paleta hardcodeada. Sin `color` (ausente, no-string, o que no pase la
 * whitelist de seguridad), usa una superficie neutra (también por tokens).
 * Tolera `event` inválido o `color` no-string (lección PR3/PR4/PR5:
 * `typeof` antes de usar un campo que podría no ser el tipo esperado en
 * runtime).
 */
class DefaultCalendarColorStrategy {
    resolve(event, isDark) {
        const raw = event && typeof event.color === 'string' && event.color ? event.color : null;
        const color = raw && isSafeCssColor(raw) ? raw : null;
        if (!color) {
            return NEUTRAL_CALENDAR_COLOR;
        }
        return {
            bg: `color-mix(in srgb, ${color} ${isDark ? '35%' : '15%'}, var(--sol-bg-surface, #ffffff))`,
            border: color,
            text: isDark
                ? `color-mix(in srgb, ${color} 70%, white)`
                : `color-mix(in srgb, ${color} 70%, black)`,
        };
    }
}
/**
 * Token de inyección del puerto de color. Default: `DefaultCalendarColorStrategy`
 * (null-object) — la librería funciona "de fábrica" sin que el consumidor
 * provea nada; un consumidor con reglas de dominio (p. ej. la paleta de 6
 * estados de cita) provee su propia implementación vía
 * `{ provide: SOL_CALENDAR_COLOR, useClass/useValue: ... }`.
 */
const SOL_CALENDAR_COLOR = new InjectionToken('SOL_CALENDAR_COLOR', {
    providedIn: 'root',
    factory: () => new DefaultCalendarColorStrategy(),
});

/**
 * Funciones puras del motor de posicionamiento de `sol-calendar` — extraídas
 * para testear en aislamiento (mismo espíritu que `timeline-position.ts` del
 * PR4 y `kanban-reorder.service.ts` del PR5b: la lógica no trivial vive
 * fuera del ciclo de render). Robustez de entrada (lecciones PR3/PR4/PR5):
 * `start`/`end` inválidos o ausentes DEGRADAN (valor por defecto, nunca
 * lanzan) — un evento malformado no debe romper la grilla completa.
 */
/** Convierte `start`/`end` (`Date | string`) a un `Date` válido; `null` si es inválido/ausente. */
function parseEventDate(value) {
    if (value == null)
        return null;
    const date = value instanceof Date ? value : new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
}
/** Clave de agrupación por día calendario (año-mes-día), ignora la hora. */
function dayKey(date) {
    return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
}
/** Lunes de la semana que contiene `date` (semana lunes→domingo), a medianoche. */
function getWeekStart(date) {
    const d = new Date(date);
    const day = d.getDay(); // 0=domingo
    const diff = day === 0 ? -6 : 1 - day;
    d.setDate(d.getDate() + diff);
    d.setHours(0, 0, 0, 0);
    return d;
}
/**
 * Construye las columnas de día con sus eventos ya agrupados: 1 columna para
 * `'day'`, `dayCount` columnas (desde el lunes de la semana de `currentDate`)
 * para `'week'`. Tolera `events` null/undefined y elementos `null`/`undefined`
 * dentro del arreglo (se filtran); un evento con `start` inválido/ausente se
 * excluye de TODAS las columnas (no puede ubicarse en ningún día) sin lanzar.
 *
 * LIMITACIÓN DOCUMENTADA (corrección 4R WARNING — reliability, re-gate PR6):
 * un evento se agrupa ÚNICAMENTE por el día calendario de `start` — un
 * evento que CRUZA MEDIANOCHE (p. ej. `start` 23:30 / `end` 00:30 del día
 * siguiente) aparece SOLO en la columna del día de `start`; NO se replica
 * ni se recorta al día de `end`. Vista mes/multi-día es no-meta de esta
 * versión (ya diferida) — soportar eventos multi-día correctamente
 * requeriría particionar el evento por día, alcance NUEVO fuera de esta
 * corrección. `computeEventTop`/`computeEventHeight` sí clampan la caja al
 * rango horario visible para que NUNCA se salga de la grilla, incluso
 * cuando el evento cruza medianoche.
 */
function buildDayColumns(view, currentDate, events, dayCount) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const safeDayCount = Math.max(1, Math.trunc(dayCount) || 1);
    const dates = view === 'day'
        ? [new Date(currentDate)]
        : Array.from({ length: safeDayCount }, (_, i) => {
            const d = new Date(getWeekStart(currentDate));
            d.setDate(d.getDate() + i);
            return d;
        });
    const safeEvents = (events ?? []).filter((e) => !!e);
    return dates.map((date) => {
        const key = dayKey(date);
        const dateCopy = new Date(date);
        dateCopy.setHours(0, 0, 0, 0);
        return {
            date,
            isToday: dateCopy.getTime() === today.getTime(),
            events: safeEvents.filter((e) => {
                const start = parseEventDate(e.start);
                return start ? dayKey(start) === key : false;
            }),
        };
    });
}
/**
 * Offset vertical (px) del evento dentro de la grilla, según su hora de
 * inicio relativa a `hourStart`. `start` inválido/ausente → `0` (degrada,
 * no lanza). Clampado a `[0, (hourEnd-hourStart)*hourPx - minHeightPx]`
 * (corrección 4R WARNING — reliability, re-gate PR6): un evento que empieza
 * antes de `hourStart` se clampa al borde superior; uno que empieza en o
 * después de `hourEnd` (p. ej. cruza medianoche, `start` 23:30 con
 * `hourEnd`=22) se clampa al borde inferior — reservando `minHeightPx` para
 * que la caja NUNCA se salga por debajo de la grilla visible.
 */
function computeEventTop(event, hourStart, hourEnd, hourPx, minHeightPx = 22) {
    const start = parseEventDate(event?.start);
    if (!start)
        return 0;
    const hoursFromStart = start.getHours() - hourStart + start.getMinutes() / 60;
    const maxTop = Math.max(0, (hourEnd - hourStart) * hourPx - minHeightPx);
    return Math.min(Math.max(0, hoursFromStart * hourPx), maxTop);
}
/**
 * Alto (px) del evento según la duración `end - start`. `start`/`end`
 * inválidos, ausentes, o duración no positiva → `minHeightPx` (degrada, no
 * lanza) — nunca menor que `minHeightPx` (visibilidad mínima garantizada).
 * Clampado (corrección 4R WARNING — reliability, re-gate PR6) para que
 * `top + height` NUNCA exceda el borde inferior de la grilla visible — un
 * evento que cruza medianoche (fuera de `[hourStart, hourEnd)`) ya no
 * produce una caja gigante fuera de la grilla; se recorta visualmente al
 * día de `start` (ver limitación documentada en `buildDayColumns`).
 */
function computeEventHeight(event, hourStart, hourEnd, hourPx, minHeightPx = 22) {
    const start = parseEventDate(event?.start);
    const end = parseEventDate(event?.end);
    if (!start || !end)
        return minHeightPx;
    const durationMin = (end.getTime() - start.getTime()) / 60_000;
    if (!Number.isFinite(durationMin) || durationMin <= 0)
        return minHeightPx;
    const rawHeight = Math.max((durationMin / 60) * hourPx, minHeightPx);
    const top = computeEventTop(event, hourStart, hourEnd, hourPx, minHeightPx);
    const gridHeight = (hourEnd - hourStart) * hourPx;
    const maxHeight = Math.max(minHeightPx, gridHeight - top);
    return Math.min(rawHeight, maxHeight);
}
/**
 * Offset (px) de la línea de "ahora" dentro del rango horario visible;
 * `-1` si "ahora" cae fuera de `[hourStart, hourEnd)` (no se muestra la línea).
 */
function computeNowTop(now, hourStart, hourEnd, hourPx) {
    const h = now.getHours();
    const m = now.getMinutes();
    if (h < hourStart || h >= hourEnd)
        return -1;
    return (h - hourStart + m / 60) * hourPx;
}
/**
 * Frecuencia de `id` entre eventos — soporte de `safeEventTrackKey` (fix
 * NG0955 con id duplicado/ausente, mismo patrón que `kanban-track.ts` del
 * PR5a/`timeline-position.ts` del PR4 — duplicado localmente a propósito:
 * cada área de la librería mantiene su propia copia de esta utilidad
 * mínima, sin acoplar `ui/calendar` a `ui/kanban`).
 */
function countEventIds(events) {
    const frequency = new Map();
    for (const event of events ?? []) {
        if (!event)
            continue;
        frequency.set(event.id, (frequency.get(event.id) ?? 0) + 1);
    }
    return frequency;
}
/** Clave de `track` segura: el índice si `id` está ausente o duplicado; si no, el propio `id`. */
function safeEventTrackKey(id, index, frequency) {
    if (id == null)
        return index;
    return (frequency.get(id) ?? 0) > 1 ? index : id;
}

const HOUR_START = 6;
const HOUR_END = 22;
const HOUR_PX = 60; // px por hora
const TOTAL_HOURS = HOUR_END - HOUR_START;
const MOBILE_MEDIA_QUERY = '(max-width: 767px)';
/**
 * Señal booleana reactiva al viewport móvil (breakpoint canónico 767px).
 * Duplicado a propósito (mismo patrón que `sol-data-table`, PR7 del
 * proyecto): el widget de citas usaba `@shared/lib` (app-side, no
 * importable desde la librería); cada componente de `@solercia/ui` que
 * necesita esto mantiene su propia copia mínima, sin depender de la app.
 */
function observeMobileViewport() {
    const destroyRef = inject(DestroyRef);
    const matches = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "matches" }] : /* istanbul ignore next */ []));
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
        return matches.asReadonly();
    }
    const mediaQueryList = window.matchMedia(MOBILE_MEDIA_QUERY);
    matches.set(mediaQueryList.matches);
    if (typeof mediaQueryList.addEventListener === 'function') {
        const onChange = (event) => matches.set(event.matches);
        mediaQueryList.addEventListener('change', onChange);
        destroyRef.onDestroy(() => mediaQueryList.removeEventListener('change', onChange));
    }
    return matches.asReadonly();
}
/**
 * `sol-calendar-grid` — grilla de horas con posicionamiento absoluto (px por
 * minuto), línea de "ahora" y slots clicables (spec: solercia-ui-calendar).
 * Generaliza `boki-front/src/widgets/calendar/ui/calendar-grid.component.ts`:
 * eventos genéricos `{id,start,end,title,color?,data?}` (nunca
 * `clientName`/`professionalName`/`stateId`), color resuelto por
 * `SOL_CALENDAR_COLOR` (D3, en vez de una paleta hardcodeada) y el cuerpo de
 * cada tarjeta por `eventTemplate` proyectado (spec#Cuerpo de tarjeta por
 * template proyectado) — sin template, cae a mostrar solo `event.title`.
 *
 * Robustez de entrada (lecciones PR3/PR4/PR5): `events`/`view`/`currentDate`
 * toleran `null`/`undefined`/valores inválidos sin lanzar (degradan vía
 * `calendar-layout.ts`, funciones puras testeadas en aislamiento). Un evento
 * con `id` ausente/duplicado no rompe `@for` (fix NG0955, mismo patrón que
 * `sol-kanban`/`sol-timeline`).
 */
class SolCalendarGridComponent {
    colorResolver = inject(SOL_CALENDAR_COLOR);
    themeService = inject(ThemeService);
    i18n = inject(SOL_I18N);
    destroyRef = inject(DestroyRef);
    /** Tolera `null`/`undefined` (lección PR3/PR4/PR5): `input.required()` no garantiza un dato válido en runtime. */
    events = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    view = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []));
    currentDate = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentDate" }] : /* istanbul ignore next */ []));
    /** Sin este, el cuerpo del evento cae a mostrar solo `event.title` (spec#Cuerpo de tarjeta por template proyectado). */
    eventTemplate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "eventTemplate" }] : /* istanbul ignore next */ []));
    eventClicked = output();
    slotClicked = output();
    HOUR_PX = HOUR_PX;
    HOUR_START = HOUR_START;
    hours = Array.from({ length: TOTAL_HOURS }, (_, i) => HOUR_START + i);
    isMobileViewport = observeMobileViewport();
    /**
     * Token aditivo `component.calendar.mobileDays` del ThemeFile activo (v2).
     * Default 5 (lunes–viernes ajustados al ancho); 7 conserva la semana
     * completa — mismo patrón que `component.table.mobile` en `sol-data-table`.
     */
    mobileDays = computed(() => {
        const file = this.themeService.activeTheme();
        const mode = this.themeService.isDark() ? 'dark' : 'light';
        return file?.modes?.[mode]?.component?.calendar?.mobileDays ?? 5;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mobileDays" }] : /* istanbul ignore next */ []));
    dayCount = computed(() => {
        if (this.view() === 'day')
            return 1;
        return this.isMobileViewport() ? this.mobileDays() : 7;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dayCount" }] : /* istanbul ignore next */ []));
    validCurrentDate = computed(() => {
        const date = this.currentDate();
        return date instanceof Date && !Number.isNaN(date.getTime()) ? date : new Date();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "validCurrentDate" }] : /* istanbul ignore next */ []));
    dayColumns = computed(() => buildDayColumns(this.view() ?? 'week', this.validCurrentDate(), this.events(), this.dayCount()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dayColumns" }] : /* istanbul ignore next */ []));
    now = signal(new Date(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "now" }] : /* istanbul ignore next */ []));
    constructor() {
        const interval = setInterval(() => this.now.set(new Date()), 60_000);
        this.destroyRef.onDestroy(() => clearInterval(interval));
    }
    nowTop = computed(() => computeNowTop(this.now(), HOUR_START, HOUR_END, HOUR_PX), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nowTop" }] : /* istanbul ignore next */ []));
    /**
     * Frecuencia de `id` entre TODOS los eventos visibles (todas las columnas)
     * — soporte de `trackEvent` (fix NG0955 con id duplicado/ausente, mismo
     * patrón que `sol-kanban`/`sol-timeline`). `computed()` para no recalcular
     * en cada invocación de `trackEvent` dentro del mismo render.
     */
    allEventsIdFrequency = computed(() => countEventIds(this.dayColumns().flatMap((d) => d.events)), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "allEventsIdFrequency" }] : /* istanbul ignore next */ []));
    dayKeyOf(day) {
        return dayKey(day.date);
    }
    trackEvent(event, index) {
        return safeEventTrackKey(event?.id, index, this.allEventsIdFrequency());
    }
    formatHour(hour) {
        return `${hour}:00`;
    }
    dayLabel(date) {
        this.i18n.activeLang();
        const weekday = this.i18n.translate(`shared.calendar.weekdayShort.${date.getDay()}`);
        return `${weekday} ${date.getDate()}/${date.getMonth() + 1}`;
    }
    /**
     * DEUDA DOCUMENTADA (SUGGESTION del 4R, re-gate PR6, deliberadamente NO
     * implementada en esta corrección): `eventTop`/`eventHeight`/`eventColor`
     * se llaman COMO MÉTODOS dentro del `@for` de eventos, así que Angular
     * los reevalúa en CADA ciclo de detección de cambios (incluido el tick de
     * 60s de `now`, que solo afecta la línea de "ahora" pero dispara CD sobre
     * todo el componente). Con cientos de eventos visibles esto podría
     * degradar a lentitud. Mejora futura: memoizar el layout del día completo
     * vía un `computed()` sobre `(events, view, currentDate)` que devuelva
     * `{event, top, height, color}[]` ya resueltos, y que el `@for` itere esa
     * estructura en vez de llamar métodos por evento. No se implementó acá a
     * propósito — el 4R lo marcó opcional y esta corrección ya prioriza los 2
     * WARNING obligatorios (color inseguro + evento que cruza medianoche).
     */
    eventTop(event) {
        return computeEventTop(event, HOUR_START, HOUR_END, HOUR_PX);
    }
    eventHeight(event) {
        return computeEventHeight(event, HOUR_START, HOUR_END, HOUR_PX);
    }
    /**
     * Delega en el `colorResolver` INYECTADO (corrección 4R WARNING —
     * resilience, re-gate PR6): una `SolCalendarColorStrategy` de dominio
     * provista por el consumidor es código EXTERNO a la librería — si lanza,
     * antes rompía el render de TODA la grilla (un solo evento defectuoso
     * tumbaba el resto). Ahora degrada a `NEUTRAL_CALENDAR_COLOR` SOLO para
     * ESE evento; el resto del calendario sigue renderizando con normalidad.
     */
    eventColor(event) {
        try {
            return this.colorResolver.resolve(event, this.themeService.isDark());
        }
        catch {
            return NEUTRAL_CALENDAR_COLOR;
        }
    }
    onEventClick(event, domEvent) {
        domEvent.stopPropagation();
        this.eventClicked.emit(event);
    }
    onSlotClick(date, hour) {
        this.slotClicked.emit({ date, time: `${String(hour).padStart(2, '0')}:00` });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCalendarGridComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolCalendarGridComponent, isStandalone: true, selector: "sol-calendar-grid", inputs: { events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: true, transformFunction: null }, view: { classPropertyName: "view", publicName: "view", isSignal: true, isRequired: true, transformFunction: null }, currentDate: { classPropertyName: "currentDate", publicName: "currentDate", isSignal: true, isRequired: true, transformFunction: null }, eventTemplate: { classPropertyName: "eventTemplate", publicName: "eventTemplate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { eventClicked: "eventClicked", slotClicked: "slotClicked" }, ngImport: i0, template: `
    <div class="sol-calendar-grid-wrap">
      <div class="sol-calendar-grid-header" [style.--day-count]="dayCount()">
        <div class="sol-calendar-grid-header__corner"></div>
        @for (day of dayColumns(); track dayKeyOf(day)) {
          <div class="sol-calendar-grid-header__day" [class.sol-calendar-grid-header__day--today]="day.isToday">
            {{ dayLabel(day.date) }}
          </div>
        }
      </div>

      <div class="sol-calendar-grid-body">
        <div class="sol-calendar-grid-times">
          @for (hour of hours; track hour) {
            <div class="sol-calendar-grid-times__label" [style.height.px]="HOUR_PX">{{ formatHour(hour) }}</div>
          }
        </div>

        <div class="sol-calendar-grid-days" [style.--day-count]="dayCount()">
          @for (day of dayColumns(); track dayKeyOf(day)) {
            <div class="sol-calendar-grid-day" [class.sol-calendar-grid-day--today]="day.isToday">
              @for (hour of hours; track hour) {
                <div class="sol-calendar-grid-day__hour" [style.height.px]="HOUR_PX">
                  <div class="sol-calendar-grid-day__half-line"></div>
                </div>
              }

              @if (day.isToday && nowTop() >= 0) {
                <div class="sol-calendar-grid-now-line" [style.top.px]="nowTop()"></div>
              }

              @for (event of day.events; track trackEvent(event, $index)) {
                <div
                  class="sol-calendar-event"
                  [style.top.px]="eventTop(event)"
                  [style.height.px]="eventHeight(event)"
                  [style.background-color]="eventColor(event).bg"
                  [style.border-left]="'3px solid ' + eventColor(event).border"
                  [style.color]="eventColor(event).text"
                  (click)="onEventClick(event, $event)"
                >
                  @if (eventTemplate(); as tpl) {
                    <ng-container *ngTemplateOutlet="tpl; context: { $implicit: event, event: event }" />
                  } @else {
                    <div class="sol-calendar-event__title">{{ event.title }}</div>
                  }
                </div>
              }

              @for (hour of hours; track hour) {
                <div
                  class="sol-calendar-grid-day__slot"
                  [style.top.px]="hour * HOUR_PX - HOUR_START * HOUR_PX"
                  [style.height.px]="HOUR_PX"
                  (click)="onSlotClick(day.date, hour)"
                ></div>
              }
            </div>
          }
        </div>
      </div>
    </div>
  `, isInline: true, styles: [":host{display:block}.sol-calendar-grid-wrap{border:var(--sol-card-border, 1px solid var(--sol-border-color-default, #e5e7eb));border-radius:var(--sol-card-radius, var(--sol-border-radius-lg, 8px));box-shadow:var(--sol-card-shadow, var(--sol-shadow-sm));overflow:hidden;background:var(--sol-card-bg, var(--sol-bg-surface, #fff));display:flex;flex-direction:column;max-height:42rem}.sol-calendar-grid-header{display:grid;grid-template-columns:3.5rem repeat(var(--day-count, 7),1fr);flex-shrink:0;border-bottom:1px solid var(--sol-border-color-default, #e5e7eb);background:var(--sol-bg-surface, #fff);position:sticky;top:0;z-index:10}.sol-calendar-grid-header__corner{border-right:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-calendar-grid-header__day{text-align:center;padding:.625rem .25rem .5rem;font-size:var(--sol-font-size-xs, 12px);font-weight:600;color:var(--sol-color-text-muted);border-right:1px solid var(--sol-border-color-default, #e5e7eb);text-transform:uppercase;letter-spacing:.04em}.sol-calendar-grid-header__day--today{color:var(--sol-color-primary, #3b82f6)}.sol-calendar-grid-body{display:flex;overflow-y:auto;flex:1;min-height:0}.sol-calendar-grid-times{width:3.5rem;flex-shrink:0;border-right:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-calendar-grid-times__label{display:flex;align-items:flex-start;justify-content:flex-end;padding-right:.5rem;padding-top:.25rem;font-size:var(--sol-font-size-xs, 11px);color:var(--sol-color-text-muted);box-sizing:border-box;border-top:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-calendar-grid-times__label:first-child{border-top:none}.sol-calendar-grid-days{display:grid;grid-template-columns:repeat(var(--day-count, 7),1fr);flex:1;min-width:0}.sol-calendar-grid-day{position:relative;border-right:1px solid var(--sol-border-color-default, #e5e7eb);min-height:0}.sol-calendar-grid-day:last-child{border-right:none}.sol-calendar-grid-day--today{background:color-mix(in srgb,var(--sol-color-primary, #3b82f6) 4%,transparent)}.sol-calendar-grid-day__hour{position:relative;border-top:1px solid var(--sol-border-color-default, #e5e7eb);box-sizing:border-box}.sol-calendar-grid-day__hour:first-child{border-top:none}.sol-calendar-grid-day__half-line{position:absolute;top:50%;left:0;right:0;height:1px;border-top:1px dashed var(--sol-border-color-default, #e5e7eb);opacity:.6;pointer-events:none}.sol-calendar-grid-day__slot{position:absolute;left:0;right:0;cursor:pointer;z-index:0}.sol-calendar-grid-day__slot:hover{background:color-mix(in srgb,var(--sol-color-primary, #3b82f6) 6%,transparent)}.sol-calendar-grid-now-line{position:absolute;left:0;right:0;height:2px;background:var(--sol-color-danger, #ef4444);z-index:8;pointer-events:none}.sol-calendar-grid-now-line:before{content:\"\";position:absolute;left:-4px;top:-4px;width:10px;height:10px;border-radius:50%;background:var(--sol-color-danger, #ef4444)}.sol-calendar-event{position:absolute;left:2px;right:2px;border-radius:4px;padding:4px 6px;font-size:var(--sol-font-size-xs, 11px);overflow:hidden;cursor:pointer;z-index:2;transition:box-shadow .15s;box-sizing:border-box;min-height:22px}.sol-calendar-event:hover{box-shadow:var(--sol-shadow-md, 0 2px 8px rgba(0, 0, 0, .15));z-index:4}.sol-calendar-event__title{font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}@media(max-width:767px){.sol-calendar-grid-header{grid-template-columns:2.75rem repeat(var(--day-count, 5),minmax(0,1fr))}.sol-calendar-grid-times{width:2.75rem}.sol-calendar-grid-times__label{padding-right:.25rem;font-size:10px}.sol-calendar-grid-days{grid-template-columns:repeat(var(--day-count, 5),minmax(0,1fr))}.sol-calendar-grid-header__day{padding:.5rem .125rem .375rem;font-size:10px;letter-spacing:.02em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCalendarGridComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-calendar-grid', standalone: true, imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-calendar-grid-wrap">
      <div class="sol-calendar-grid-header" [style.--day-count]="dayCount()">
        <div class="sol-calendar-grid-header__corner"></div>
        @for (day of dayColumns(); track dayKeyOf(day)) {
          <div class="sol-calendar-grid-header__day" [class.sol-calendar-grid-header__day--today]="day.isToday">
            {{ dayLabel(day.date) }}
          </div>
        }
      </div>

      <div class="sol-calendar-grid-body">
        <div class="sol-calendar-grid-times">
          @for (hour of hours; track hour) {
            <div class="sol-calendar-grid-times__label" [style.height.px]="HOUR_PX">{{ formatHour(hour) }}</div>
          }
        </div>

        <div class="sol-calendar-grid-days" [style.--day-count]="dayCount()">
          @for (day of dayColumns(); track dayKeyOf(day)) {
            <div class="sol-calendar-grid-day" [class.sol-calendar-grid-day--today]="day.isToday">
              @for (hour of hours; track hour) {
                <div class="sol-calendar-grid-day__hour" [style.height.px]="HOUR_PX">
                  <div class="sol-calendar-grid-day__half-line"></div>
                </div>
              }

              @if (day.isToday && nowTop() >= 0) {
                <div class="sol-calendar-grid-now-line" [style.top.px]="nowTop()"></div>
              }

              @for (event of day.events; track trackEvent(event, $index)) {
                <div
                  class="sol-calendar-event"
                  [style.top.px]="eventTop(event)"
                  [style.height.px]="eventHeight(event)"
                  [style.background-color]="eventColor(event).bg"
                  [style.border-left]="'3px solid ' + eventColor(event).border"
                  [style.color]="eventColor(event).text"
                  (click)="onEventClick(event, $event)"
                >
                  @if (eventTemplate(); as tpl) {
                    <ng-container *ngTemplateOutlet="tpl; context: { $implicit: event, event: event }" />
                  } @else {
                    <div class="sol-calendar-event__title">{{ event.title }}</div>
                  }
                </div>
              }

              @for (hour of hours; track hour) {
                <div
                  class="sol-calendar-grid-day__slot"
                  [style.top.px]="hour * HOUR_PX - HOUR_START * HOUR_PX"
                  [style.height.px]="HOUR_PX"
                  (click)="onSlotClick(day.date, hour)"
                ></div>
              }
            </div>
          }
        </div>
      </div>
    </div>
  `, styles: [":host{display:block}.sol-calendar-grid-wrap{border:var(--sol-card-border, 1px solid var(--sol-border-color-default, #e5e7eb));border-radius:var(--sol-card-radius, var(--sol-border-radius-lg, 8px));box-shadow:var(--sol-card-shadow, var(--sol-shadow-sm));overflow:hidden;background:var(--sol-card-bg, var(--sol-bg-surface, #fff));display:flex;flex-direction:column;max-height:42rem}.sol-calendar-grid-header{display:grid;grid-template-columns:3.5rem repeat(var(--day-count, 7),1fr);flex-shrink:0;border-bottom:1px solid var(--sol-border-color-default, #e5e7eb);background:var(--sol-bg-surface, #fff);position:sticky;top:0;z-index:10}.sol-calendar-grid-header__corner{border-right:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-calendar-grid-header__day{text-align:center;padding:.625rem .25rem .5rem;font-size:var(--sol-font-size-xs, 12px);font-weight:600;color:var(--sol-color-text-muted);border-right:1px solid var(--sol-border-color-default, #e5e7eb);text-transform:uppercase;letter-spacing:.04em}.sol-calendar-grid-header__day--today{color:var(--sol-color-primary, #3b82f6)}.sol-calendar-grid-body{display:flex;overflow-y:auto;flex:1;min-height:0}.sol-calendar-grid-times{width:3.5rem;flex-shrink:0;border-right:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-calendar-grid-times__label{display:flex;align-items:flex-start;justify-content:flex-end;padding-right:.5rem;padding-top:.25rem;font-size:var(--sol-font-size-xs, 11px);color:var(--sol-color-text-muted);box-sizing:border-box;border-top:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-calendar-grid-times__label:first-child{border-top:none}.sol-calendar-grid-days{display:grid;grid-template-columns:repeat(var(--day-count, 7),1fr);flex:1;min-width:0}.sol-calendar-grid-day{position:relative;border-right:1px solid var(--sol-border-color-default, #e5e7eb);min-height:0}.sol-calendar-grid-day:last-child{border-right:none}.sol-calendar-grid-day--today{background:color-mix(in srgb,var(--sol-color-primary, #3b82f6) 4%,transparent)}.sol-calendar-grid-day__hour{position:relative;border-top:1px solid var(--sol-border-color-default, #e5e7eb);box-sizing:border-box}.sol-calendar-grid-day__hour:first-child{border-top:none}.sol-calendar-grid-day__half-line{position:absolute;top:50%;left:0;right:0;height:1px;border-top:1px dashed var(--sol-border-color-default, #e5e7eb);opacity:.6;pointer-events:none}.sol-calendar-grid-day__slot{position:absolute;left:0;right:0;cursor:pointer;z-index:0}.sol-calendar-grid-day__slot:hover{background:color-mix(in srgb,var(--sol-color-primary, #3b82f6) 6%,transparent)}.sol-calendar-grid-now-line{position:absolute;left:0;right:0;height:2px;background:var(--sol-color-danger, #ef4444);z-index:8;pointer-events:none}.sol-calendar-grid-now-line:before{content:\"\";position:absolute;left:-4px;top:-4px;width:10px;height:10px;border-radius:50%;background:var(--sol-color-danger, #ef4444)}.sol-calendar-event{position:absolute;left:2px;right:2px;border-radius:4px;padding:4px 6px;font-size:var(--sol-font-size-xs, 11px);overflow:hidden;cursor:pointer;z-index:2;transition:box-shadow .15s;box-sizing:border-box;min-height:22px}.sol-calendar-event:hover{box-shadow:var(--sol-shadow-md, 0 2px 8px rgba(0, 0, 0, .15));z-index:4}.sol-calendar-event__title{font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}@media(max-width:767px){.sol-calendar-grid-header{grid-template-columns:2.75rem repeat(var(--day-count, 5),minmax(0,1fr))}.sol-calendar-grid-times{width:2.75rem}.sol-calendar-grid-times__label{padding-right:.25rem;font-size:10px}.sol-calendar-grid-days{grid-template-columns:repeat(var(--day-count, 5),minmax(0,1fr))}.sol-calendar-grid-header__day{padding:.5rem .125rem .375rem;font-size:10px;letter-spacing:.02em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { events: [{ type: i0.Input, args: [{ isSignal: true, alias: "events", required: true }] }], view: [{ type: i0.Input, args: [{ isSignal: true, alias: "view", required: true }] }], currentDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentDate", required: true }] }], eventTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "eventTemplate", required: false }] }], eventClicked: [{ type: i0.Output, args: ["eventClicked"] }], slotClicked: [{ type: i0.Output, args: ["slotClicked"] }] } });

/**
 * `sol-calendar-header` — navegación (anterior/hoy/siguiente) + selector de
 * vista (semana/día). Generaliza
 * `boki-front/src/widgets/calendar/ui/calendar-header.component.ts`: SIN
 * leyenda (spec#Leyenda configurable — la renderiza `sol-calendar`, no el
 * header, para que "leyenda configurable" no dependa de esta sub-pieza) y
 * SIN conocimiento de dominio (nunca referencia estados de cita).
 *
 * Robustez de entrada (lecciones PR3/PR4/PR5): `currentDate`/`view` toleran
 * `null`/`undefined`/fecha inválida sin lanzar — degradan a una etiqueta
 * vacía y asumen `'week'` respectivamente.
 */
class SolCalendarHeaderComponent {
    i18n = inject(SOL_I18N);
    /** Tolera `null`/`undefined`/fecha inválida (lección PR3/PR4/PR5): `input.required()` no garantiza un dato válido en runtime. */
    currentDate = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentDate" }] : /* istanbul ignore next */ []));
    view = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []));
    dateChange = output();
    viewChange = output();
    todayLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.calendar.today');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "todayLabel" }] : /* istanbul ignore next */ []));
    previousLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.calendar.previous');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "previousLabel" }] : /* istanbul ignore next */ []));
    nextLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.calendar.next');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextLabel" }] : /* istanbul ignore next */ []));
    viewWeekLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.calendar.viewWeek');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewWeekLabel" }] : /* istanbul ignore next */ []));
    viewDayLabel = computed(() => {
        this.i18n.activeLang();
        return this.i18n.translate('shared.calendar.viewDay');
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "viewDayLabel" }] : /* istanbul ignore next */ []));
    dateRangeLabel = computed(() => {
        this.i18n.activeLang();
        const date = this.validDate();
        if (!date)
            return '';
        if (this.view() === 'day') {
            const weekday = this.i18n.translate(`shared.calendar.weekdayShort.${date.getDay()}`);
            const month = this.i18n.translate(`shared.calendar.months.${date.getMonth()}`);
            return `${weekday} ${date.getDate()} ${month}`;
        }
        const start = getWeekStart(date);
        const end = new Date(start);
        end.setDate(end.getDate() + 6);
        const startMonth = this.i18n.translate(`shared.calendar.months.${start.getMonth()}`);
        const endMonth = this.i18n.translate(`shared.calendar.months.${end.getMonth()}`);
        return `${start.getDate()} ${startMonth} – ${end.getDate()} ${endMonth}`;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dateRangeLabel" }] : /* istanbul ignore next */ []));
    navigatePrev() {
        const date = this.validDate();
        if (!date)
            return;
        const next = new Date(date);
        if (this.view() === 'day')
            next.setDate(next.getDate() - 1);
        else
            next.setDate(next.getDate() - 7);
        this.dateChange.emit(next);
    }
    navigateNext() {
        const date = this.validDate();
        if (!date)
            return;
        const next = new Date(date);
        if (this.view() === 'day')
            next.setDate(next.getDate() + 1);
        else
            next.setDate(next.getDate() + 7);
        this.dateChange.emit(next);
    }
    goToday() {
        this.dateChange.emit(new Date());
    }
    setView(view) {
        this.viewChange.emit(view);
    }
    /** `currentDate()` normalizado: `null` si es `null`/`undefined`/inválido (degrada, no lanza). */
    validDate() {
        const date = this.currentDate();
        return date instanceof Date && !Number.isNaN(date.getTime()) ? date : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCalendarHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.6", type: SolCalendarHeaderComponent, isStandalone: true, selector: "sol-calendar-header", inputs: { currentDate: { classPropertyName: "currentDate", publicName: "currentDate", isSignal: true, isRequired: true, transformFunction: null }, view: { classPropertyName: "view", publicName: "view", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { dateChange: "dateChange", viewChange: "viewChange" }, ngImport: i0, template: `
    <div class="sol-calendar-header">
      <div class="sol-calendar-header__nav">
        <span class="sol-calendar-header__range">{{ dateRangeLabel() }}</span>
        <button
          type="button"
          class="sol-calendar-header__arrow"
          (click)="navigatePrev()"
          [attr.aria-label]="previousLabel()"
        >
          <sol-icon name="chevron-left" size="sm" />
        </button>
        <button type="button" class="sol-calendar-header__today" (click)="goToday()">{{ todayLabel() }}</button>
        <button
          type="button"
          class="sol-calendar-header__arrow"
          (click)="navigateNext()"
          [attr.aria-label]="nextLabel()"
        >
          <sol-icon name="chevron-right" size="sm" />
        </button>
      </div>

      <div class="sol-calendar-header__view-toggle">
        <button
          type="button"
          class="sol-calendar-header__toggle-btn"
          [class.sol-calendar-header__toggle-btn--active]="view() === 'week'"
          (click)="setView('week')"
        >{{ viewWeekLabel() }}</button>
        <button
          type="button"
          class="sol-calendar-header__toggle-btn"
          [class.sol-calendar-header__toggle-btn--active]="view() === 'day'"
          (click)="setView('day')"
        >{{ viewDayLabel() }}</button>
      </div>
    </div>
  `, isInline: true, styles: [":host{display:block}.sol-calendar-header{display:flex;align-items:center;justify-content:space-between;gap:var(--sol-space-md, 16px);padding:var(--sol-space-sm, 12px) 0;border-bottom:1px solid var(--sol-border-color-default, #e5e7eb);flex-wrap:wrap}.sol-calendar-header__nav{display:flex;align-items:center;gap:var(--sol-space-xs, 6px)}.sol-calendar-header__range{font-size:var(--sol-font-size-sm, 15px);font-weight:600;color:var(--sol-color-text-primary);min-width:10rem}.sol-calendar-header__arrow{display:inline-flex;align-items:center;justify-content:center;width:2rem;height:2rem;background:var(--sol-bg-surface, #fff);border:1px solid var(--sol-border-color-default, #e5e7eb);border-radius:var(--sol-border-radius-md, 6px);cursor:pointer;color:var(--sol-color-text-primary);transition:background .15s}.sol-calendar-header__arrow:hover{background:var(--sol-border-color-default, #e5e7eb)}.sol-calendar-header__today{height:2rem;padding:0 .875rem;background:var(--sol-bg-surface, #fff);border:1px solid var(--sol-border-color-default, #e5e7eb);border-radius:var(--sol-border-radius-md, 6px);font-size:var(--sol-font-size-xs, 13px);font-weight:500;color:var(--sol-color-text-primary);cursor:pointer;transition:background .15s}.sol-calendar-header__today:hover{background:var(--sol-border-color-default, #e5e7eb)}.sol-calendar-header__view-toggle{display:flex;border:1px solid var(--sol-border-color-default, #e5e7eb);border-radius:var(--sol-border-radius-lg, 8px);overflow:hidden}.sol-calendar-header__toggle-btn{height:2rem;padding:0 .875rem;font-size:var(--sol-font-size-xs, 13px);font-weight:500;background:var(--sol-bg-surface, #fff);border:none;color:var(--sol-color-text-muted);cursor:pointer;transition:background .15s,color .15s}.sol-calendar-header__toggle-btn+.sol-calendar-header__toggle-btn{border-left:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-calendar-header__toggle-btn--active{background:var(--sol-color-primary, #3b82f6);color:#fff}.sol-calendar-header__toggle-btn:not(.sol-calendar-header__toggle-btn--active):hover{background:var(--sol-border-color-default, #e5e7eb)}\n"], dependencies: [{ kind: "component", type: SolIconComponent, selector: "sol-icon", inputs: ["name", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCalendarHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-calendar-header', standalone: true, imports: [SolIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-calendar-header">
      <div class="sol-calendar-header__nav">
        <span class="sol-calendar-header__range">{{ dateRangeLabel() }}</span>
        <button
          type="button"
          class="sol-calendar-header__arrow"
          (click)="navigatePrev()"
          [attr.aria-label]="previousLabel()"
        >
          <sol-icon name="chevron-left" size="sm" />
        </button>
        <button type="button" class="sol-calendar-header__today" (click)="goToday()">{{ todayLabel() }}</button>
        <button
          type="button"
          class="sol-calendar-header__arrow"
          (click)="navigateNext()"
          [attr.aria-label]="nextLabel()"
        >
          <sol-icon name="chevron-right" size="sm" />
        </button>
      </div>

      <div class="sol-calendar-header__view-toggle">
        <button
          type="button"
          class="sol-calendar-header__toggle-btn"
          [class.sol-calendar-header__toggle-btn--active]="view() === 'week'"
          (click)="setView('week')"
        >{{ viewWeekLabel() }}</button>
        <button
          type="button"
          class="sol-calendar-header__toggle-btn"
          [class.sol-calendar-header__toggle-btn--active]="view() === 'day'"
          (click)="setView('day')"
        >{{ viewDayLabel() }}</button>
      </div>
    </div>
  `, styles: [":host{display:block}.sol-calendar-header{display:flex;align-items:center;justify-content:space-between;gap:var(--sol-space-md, 16px);padding:var(--sol-space-sm, 12px) 0;border-bottom:1px solid var(--sol-border-color-default, #e5e7eb);flex-wrap:wrap}.sol-calendar-header__nav{display:flex;align-items:center;gap:var(--sol-space-xs, 6px)}.sol-calendar-header__range{font-size:var(--sol-font-size-sm, 15px);font-weight:600;color:var(--sol-color-text-primary);min-width:10rem}.sol-calendar-header__arrow{display:inline-flex;align-items:center;justify-content:center;width:2rem;height:2rem;background:var(--sol-bg-surface, #fff);border:1px solid var(--sol-border-color-default, #e5e7eb);border-radius:var(--sol-border-radius-md, 6px);cursor:pointer;color:var(--sol-color-text-primary);transition:background .15s}.sol-calendar-header__arrow:hover{background:var(--sol-border-color-default, #e5e7eb)}.sol-calendar-header__today{height:2rem;padding:0 .875rem;background:var(--sol-bg-surface, #fff);border:1px solid var(--sol-border-color-default, #e5e7eb);border-radius:var(--sol-border-radius-md, 6px);font-size:var(--sol-font-size-xs, 13px);font-weight:500;color:var(--sol-color-text-primary);cursor:pointer;transition:background .15s}.sol-calendar-header__today:hover{background:var(--sol-border-color-default, #e5e7eb)}.sol-calendar-header__view-toggle{display:flex;border:1px solid var(--sol-border-color-default, #e5e7eb);border-radius:var(--sol-border-radius-lg, 8px);overflow:hidden}.sol-calendar-header__toggle-btn{height:2rem;padding:0 .875rem;font-size:var(--sol-font-size-xs, 13px);font-weight:500;background:var(--sol-bg-surface, #fff);border:none;color:var(--sol-color-text-muted);cursor:pointer;transition:background .15s,color .15s}.sol-calendar-header__toggle-btn+.sol-calendar-header__toggle-btn{border-left:1px solid var(--sol-border-color-default, #e5e7eb)}.sol-calendar-header__toggle-btn--active{background:var(--sol-color-primary, #3b82f6);color:#fff}.sol-calendar-header__toggle-btn:not(.sol-calendar-header__toggle-btn--active):hover{background:var(--sol-border-color-default, #e5e7eb)}\n"] }]
        }], propDecorators: { currentDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentDate", required: true }] }], view: [{ type: i0.Input, args: [{ isSignal: true, alias: "view", required: true }] }], dateChange: [{ type: i0.Output, args: ["dateChange"] }], viewChange: [{ type: i0.Output, args: ["viewChange"] }] } });

/**
 * `sol-calendar` — orquestador genérico de `sol-calendar-header` +
 * `sol-calendar-grid` + leyenda (spec: solercia-ui-calendar). Generaliza
 * `boki-front/src/widgets/calendar`: evento genérico `{id,start,end,title,
 * color?,data?}` (NUNCA `clientName`/`professionalName`/`stateId`), color
 * por `SOL_CALENDAR_COLOR` (Strategy inyectable, D3), cuerpo de tarjeta por
 * `eventTemplate` proyectado y leyenda TOTALMENTE controlada por `[legend]`
 * (spec#Leyenda configurable — sin default hardcodeado de estados de cita).
 *
 * Vista mes y arrastrar-para-reagendar (`eventDropped`) quedan DIFERIDOS —
 * decisión ratificada, documentada como no-meta de esta versión (`view`
 * solo tipa `'week'|'day'`, `'month'` no existe en el tipo a propósito).
 *
 * Espejo interno (`signal` + `effect`, D4 del design, mismo patrón que
 * `sol-kanban`/`sol-timeline`): `currentDate`/`view` son inputs que
 * SIEMBRAN el estado interno de navegación — el consumidor puede montar
 * `sol-calendar` sin wiring adicional (autocontenido: los clics de
 * "anterior"/"siguiente"/"hoy"/toggle de vista los maneja este componente
 * internamente), y también puede saltar programáticamente a otra fecha
 * reasignando el input.
 *
 * Robustez de entrada (lecciones PR3/PR4/PR5): `events`/`view`/`currentDate`
 * toleran `null`/`undefined`/valores inválidos sin lanzar (degradan a
 * arreglo vacío / `'week'` / fecha actual del sistema, respectivamente).
 */
class SolCalendarComponent {
    i18n = inject(SOL_I18N);
    /** Tolera `null`/`undefined` (lección PR3/PR4/PR5): `input.required()` no garantiza un dato válido en runtime. */
    events = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "events" }] : /* istanbul ignore next */ []));
    view = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []));
    currentDate = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentDate" }] : /* istanbul ignore next */ []));
    /** Sin este, `sol-calendar-grid` cae a mostrar solo `event.title` (spec#Cuerpo de tarjeta por template proyectado). */
    eventTemplate = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "eventTemplate" }] : /* istanbul ignore next */ []));
    /** Leyenda TOTALMENTE controlada por el consumidor — sin este input, no se muestra ninguna leyenda (spec#Leyenda configurable). */
    legend = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "legend" }] : /* istanbul ignore next */ []));
    eventClicked = output();
    slotClicked = output();
    /** `protected` (no `private`): el template necesita leerlos, y Angular exige acceso no-privado para bindings de plantilla. */
    mirroredDate = signal(new Date(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mirroredDate" }] : /* istanbul ignore next */ []));
    mirroredView = signal('week', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mirroredView" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const date = this.currentDate();
            this.mirroredDate.set(date instanceof Date && !Number.isNaN(date.getTime()) ? date : new Date());
        });
        effect(() => {
            const view = this.view();
            this.mirroredView.set(view === 'day' ? 'day' : 'week');
        });
    }
    legendItems = computed(() => (this.legend() ?? []).filter((item) => !!item), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "legendItems" }] : /* istanbul ignore next */ []));
    legendLabel(item) {
        this.i18n.activeLang();
        return this.i18n.translate(item.labelKey);
    }
    /**
     * Valida `item.color` contra la whitelist de `isSafeCssColor` antes de
     * interpolarlo en `[style.background]` (corrección 4R WARNING — risk,
     * re-gate PR6): `background` es una propiedad shorthand que ACEPTA
     * `url(...)` — un color de baja confianza (config de tenant futura)
     * podría disparar una petición de red ("CSS beacon") si se enlazara sin
     * validar. Un color no seguro degrada a un tono neutro por token.
     */
    legendDotColor(item) {
        const color = typeof item?.color === 'string' && item.color ? item.color : null;
        return color && isSafeCssColor(color) ? color : 'var(--sol-color-text-muted, #94a3b8)';
    }
    onDateChange(date) {
        this.mirroredDate.set(date);
    }
    onViewChange(view) {
        this.mirroredView.set(view);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCalendarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.6", type: SolCalendarComponent, isStandalone: true, selector: "sol-calendar", inputs: { events: { classPropertyName: "events", publicName: "events", isSignal: true, isRequired: true, transformFunction: null }, view: { classPropertyName: "view", publicName: "view", isSignal: true, isRequired: true, transformFunction: null }, currentDate: { classPropertyName: "currentDate", publicName: "currentDate", isSignal: true, isRequired: true, transformFunction: null }, eventTemplate: { classPropertyName: "eventTemplate", publicName: "eventTemplate", isSignal: true, isRequired: false, transformFunction: null }, legend: { classPropertyName: "legend", publicName: "legend", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { eventClicked: "eventClicked", slotClicked: "slotClicked" }, ngImport: i0, template: `
    <div class="sol-calendar">
      <sol-calendar-header
        [currentDate]="mirroredDate()"
        [view]="mirroredView()"
        (dateChange)="onDateChange($event)"
        (viewChange)="onViewChange($event)"
      />

      @if (legendItems().length > 0) {
        <div class="sol-calendar__legend">
          @for (item of legendItems(); track item.labelKey) {
            <span class="sol-calendar__legend-item">
              <span class="sol-calendar__legend-dot" [style.background]="legendDotColor(item)"></span>
              <span class="sol-calendar__legend-label">{{ legendLabel(item) }}</span>
            </span>
          }
        </div>
      }

      <sol-calendar-grid
        [events]="events()"
        [view]="mirroredView()"
        [currentDate]="mirroredDate()"
        [eventTemplate]="eventTemplate()"
        (eventClicked)="eventClicked.emit($event)"
        (slotClicked)="slotClicked.emit($event)"
      />
    </div>
  `, isInline: true, styles: [":host{display:block}.sol-calendar{display:flex;flex-direction:column;gap:var(--sol-space-sm, 8px)}.sol-calendar__legend{display:flex;align-items:center;gap:var(--sol-space-md, 12px);flex-wrap:wrap}.sol-calendar__legend-item{display:inline-flex;align-items:center;gap:5px}.sol-calendar__legend-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}.sol-calendar__legend-label{font-size:var(--sol-font-size-xs, 12px);color:var(--sol-color-text-muted)}\n"], dependencies: [{ kind: "component", type: SolCalendarHeaderComponent, selector: "sol-calendar-header", inputs: ["currentDate", "view"], outputs: ["dateChange", "viewChange"] }, { kind: "component", type: SolCalendarGridComponent, selector: "sol-calendar-grid", inputs: ["events", "view", "currentDate", "eventTemplate"], outputs: ["eventClicked", "slotClicked"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.6", ngImport: i0, type: SolCalendarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sol-calendar', standalone: true, imports: [SolCalendarHeaderComponent, SolCalendarGridComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="sol-calendar">
      <sol-calendar-header
        [currentDate]="mirroredDate()"
        [view]="mirroredView()"
        (dateChange)="onDateChange($event)"
        (viewChange)="onViewChange($event)"
      />

      @if (legendItems().length > 0) {
        <div class="sol-calendar__legend">
          @for (item of legendItems(); track item.labelKey) {
            <span class="sol-calendar__legend-item">
              <span class="sol-calendar__legend-dot" [style.background]="legendDotColor(item)"></span>
              <span class="sol-calendar__legend-label">{{ legendLabel(item) }}</span>
            </span>
          }
        </div>
      }

      <sol-calendar-grid
        [events]="events()"
        [view]="mirroredView()"
        [currentDate]="mirroredDate()"
        [eventTemplate]="eventTemplate()"
        (eventClicked)="eventClicked.emit($event)"
        (slotClicked)="slotClicked.emit($event)"
      />
    </div>
  `, styles: [":host{display:block}.sol-calendar{display:flex;flex-direction:column;gap:var(--sol-space-sm, 8px)}.sol-calendar__legend{display:flex;align-items:center;gap:var(--sol-space-md, 12px);flex-wrap:wrap}.sol-calendar__legend-item{display:inline-flex;align-items:center;gap:5px}.sol-calendar__legend-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}.sol-calendar__legend-label{font-size:var(--sol-font-size-xs, 12px);color:var(--sol-color-text-muted)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { events: [{ type: i0.Input, args: [{ isSignal: true, alias: "events", required: true }] }], view: [{ type: i0.Input, args: [{ isSignal: true, alias: "view", required: true }] }], currentDate: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentDate", required: true }] }], eventTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "eventTemplate", required: false }] }], legend: [{ type: i0.Input, args: [{ isSignal: true, alias: "legend", required: false }] }], eventClicked: [{ type: i0.Output, args: ["eventClicked"] }], slotClicked: [{ type: i0.Output, args: ["slotClicked"] }] } });

// Shared UI — atomic design system components

/*
 * Public API Surface of @solercia/ui
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DEFAULT_SCORE_THRESHOLDS, EMIT_TABLE, KANBAN_ADD_ACTION, KanbanReorderService, NEUTRAL_CALENDAR_COLOR, SOL_CALENDAR_COLOR, SOL_CHART_ENGINE, SOL_DEFAULT_THEME, SOL_I18N, SOL_TENANT_RESOLVER, SolAvatarComponent, SolBadgeComponent, SolButtonComponent, SolCalendarComponent, SolCalendarGridComponent, SolCalendarHeaderComponent, SolCardComponent, SolChartComponent, SolCheckboxComponent, SolDataTableComponent, SolDatePickerComponent, SolDayPickerComponent, SolEmptyStateComponent, SolFileUploadComponent, SolFormFieldComponent, SolIconButtonComponent, SolIconComponent, SolInputComponent, SolKanbanBoardComponent, SolKanbanCardComponent, SolKanbanColumnComponent, SolMessageStatusComponent, SolModalComponent, SolPageHeaderComponent, SolPaginationComponent, SolProgressBarComponent, SolRichEditorComponent, SolScoreBadgeComponent, SolSearchInputComponent, SolSelectComponent, SolSkeletonComponent, SolSpinnerComponent, SolStepperComponent, SolTabsComponent, SolTextareaComponent, SolTimelineComponent, SolToggleComponent, SolTooltipComponent, SolTrendComponent, SolViewToggleComponent, SolVirtualScrollComponent, SolWizardComponent, SolWizardStepDirective, TCPDF_ALLOWED_STYLE_PROPERTIES, TCPDF_ALLOWED_TAGS, THEME_SOURCE, ThemeService, buildDayColumns, buildGoogleFontsUrl, collectUndatedNodes, computeEventHeight, computeEventTop, computeGlobalRange, computeInitials, computeMonthAxisTicks, computeNowTop, createIdentitySolI18n, dayKey, defaultStatusToken, defaultTrendFormat, getWeekStart, hashToPaletteIndex, isRenderableTheme, isSafeBackgroundImage, isSafeCssColor, parseEventDate, positionRows, provideTheme, resolveCssVars, resolveScoreTone, resolveTrendDirection, sanitizeAssetUrl, sanitizeHtmlToTcpdf, serializeElementToTcpdfHtml };
//# sourceMappingURL=solercia-ui.mjs.map
